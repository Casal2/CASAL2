#' Utility extract function
#'
#' @author Dan Fu
#' @keywords internal
#'
make.complete_vector <- function(lines) {
  data = string.to.vector.of.numbers(lines[1])
  data
}

