"casal2.binary.version"<-
function() {
return("22.01")
}
