Readme.txt for CASAL
============================================

CASAL (C++ algorithmic stock assessment laboratory) is a generalised age- or 
size-structured fish stock assessment model that allows a great deal of 
flexibility in specifying the population dynamics, parameter estimation, and 
model outputs. 

See the CASAL User Manual for more information.

License
=======

See the CASAL User Manual for a copy of the software license.

Getting CASAL
============

CCAMLR recommends the use of version v2.30-2012-03-21 rev. 4648 
for assessments (see para. 2.7, SC-CAMLR-XXIII, 2014).

This version of CASAL is available from NIWAs anonymous FTP site. 

ftp://ftp.niwa.co.nz/software/casal/CASALv230-2012-03-21.zip

Installation
============

The binary for CASAL, manual, examples, and other and assocated files are available 
from the zip file. 

Use Program/casal.exe for Microsoft-Windows systems and Program/Linux/casal for 
linux systems. 

To install, unzip the file and manually copy the CASAL binary to a location 
of your choice. 

To help when calling casal, either 

(i) put a copy of the binary in the directory where it will 
be used, or

(ii) put a copy of the binary into a directory that is in your PATH. See your 
operating system documentation for how to modify your PATH if required.

In both cases, only the CASAL executable is required. But note that CASAL is a 
console program, and can only be used from the command line.

Contact
=======

For more information about CASAL, please read the CASAL User Manual or 
contact the authors.
