// const char* time_stamp = "$Date: 2009-03-20 11:42:18 +1300 (Fri, 20 Mar 2009) $\n";
// const char* yields_id = "$Id: yields.h 3072 2009-03-19 22:42:18Z dunn $\n";

#if !defined(YIELDS)
#define YIELDS

//############################## YIELD CALCULATIONS ##############################
#include <string>
#include <iostream>
#include <vector>
#include "development.h"
#include "estimation_section.h"
#include "parameter_set.h"

// Forward declarations
template<CDVM> class Basic_population_section;
template<CDVM> class Harvest_strategy;
template<CDVM> class Get_Cav_Bav_Prisk;
class Run_diagnostic_output;

//////////////////////////////////////////////////////////////////////////////////////
template<class FUNCTION>
double maximise_yield(FUNCTION& f, double guess, int print = 1, ostream& out = cout, int max_upper_iter = 40);

template<class FUNCTION>
double maximise_yield_between(FUNCTION& f, double low, double high, int interval_no,
                              int print, ostream& out, int max_upper_iter);

template<CDVM>
void per_recruit_and_deterministic_MSY(Estimation_section<DVM>& e,
                                       const dvector& free_parameter_values,
                                       Parameter_set<DVM>& o, int is_weightless_model);

template<CDVM>
class Get_YPR_f_SPR_f{
  // This function object is used by per_recruit_and_deterministic_MSY:
  // (a) get(F) gives YPR(F) and SPR(F) for harvest rate F
  // (b) operator()(F) is the objective function which is to be maximised,
  //      it can be YPR(F) (unless the fishing pressure limit is breached, in which case -1e18)
  //        [for finding Fmax],
  //      or the negative squared difference of (slope of YPR curve) from
  //        (0.1 * slope of YPR curve at origin) [for finding F0.1],
  //      or the negative squared difference of SPR(F) from (x/100 * unfished SPR) [for finding Fx%).
  //      'to_maximise' decides which, and can be "YPR", "F0.1", or "Fx%". Set it from outside.
  // We set up the object this way so that it can be passed to the generic maximiser
  //  used for various other yield calculations.
  // Be warned that the calculation of YPR(F) and SPR(F) changes the population model passed
  //   to the Get_YPR_f_SPR_f constructor!! (The model is run to deterministic equilibrium.)
public:
  double operator()(double F, int print = 1, ostream& out = cout);
  dvector get(double F, int print = 1, ostream& out = cout);
  std::string to_maximise;
  double x,slope_at_origin, unfished_SPR;
  int stock;
  Get_YPR_f_SPR_f(Basic_population_section<DVM>* _popn, Harvest_strategy<DVM>* _strategy, double _x);
private:
  Basic_population_section<DVM>* popn;
  Harvest_strategy<DVM>* strategy;
};

template<CDVM>
double total_catch(Basic_population_section<DVM>* popn, int year, int stock = 0);

template<CDVM>
class Get_C_f_SSB_f{
  // This function object is used by per_recruit_and_deterministic_MSY:
  // (a) get(F) gives the C(F) and SSB(F) for harvest rate F, as % B0
  // (b) operator()(F) is the objective function which is to be maximised in the calculation of MSY:
  //     it is simply C(F) for harvest rate F, unless the fishing pressure limit is breached, in
  //     which case it is -1e18.
  // We set up the object this way so that it can be passed to the generic maximiser
  //  used for various other yield calculations.
  // Be warned that the calculation of C(F) and/or SSB(F) changes the population model passed
  //   to the Get_C_f_SSB_f constructor!! (The model is run to deterministic equilibrium.)
public:
  double operator()(double F, int print = 1, ostream& out = cout);
  dvector get(double F, int print = 1, ostream& out = cout);
  int stock;
  Get_C_f_SSB_f(Basic_population_section<DVM>* _popn,
                Harvest_strategy<DVM>* _strategy);
private:
  Basic_population_section<DVM>* popn;
  Harvest_strategy<DVM>* strategy;
};

template<CDVM>
void try_interpolation (double &MCY, dmatrix &result, Get_Cav_Bav_Prisk<DVM> MCY_Cav_Bav_Prisk);

template<CDVM>
void MCY_CAY(Estimation_section<DVM>& e_simulate,
             Estimation_section<DVM>& e_normal,
             dmatrix& free_parameter_values, Parameter_set<DVM>& o);

template<CDVM>
class Get_Cav_Bav_Prisk{
  // This function object is used by MCY_CAY:
  // (a) get(H) gives Cav(H), Bav(H), Prisk(H) for harvest rate H:
  //     one row per stock if there are multiple stocks
  // (b) operator()(F) is the objective function which is to be maximised in the calculation of MCY/CAY:
  //     for one stock, it is Cav(H), unless Prisk(H) is unacceptable, in which case it is 0:
  //     if there are multiple stocks, it is the sum over stocks of Cav(H), unless Prisk(H) is
  //      unacceptable for any stock, in which case it is 0.
  // We set up the object this way so that it can be passed to the generic maximiser
  //  used for various other yield calculations.
  // Be warned that the calculations change the population model passed to the constructor!!
  //  (The model is given parameter sets and run.)
  //
  // BB CHANGE 17/3/03: The objective function in operator() is now no longer sum(Cav(H)),
  //  but has been changed to sum(Cav) * (1+0.01*H / Hinitial guess)
public:
  double operator()(double H, int print = 1, ostream& out = cout);
  dmatrix get(double H, int print = 1, ostream& out = cout);
  void print(ostream& out = cout);
  Get_Cav_Bav_Prisk(Estimation_section<DVM>* _e,
                    Harvest_strategy<DVM>* _strategy, dmatrix* _free_parameter_values,
                    long _RNG_seed, Parameter_set<DVM>& o, double _H_initial_guess, dmatrix* _reference_SSBs,
                    std::vector<class Run_diagnostic_output>* _run_diagnostic_output);
  int num_opt_iterations;   // counter for number of calls by the optimisation routine
  std::vector<double>   save_H;       // save at each call the value of H
  std::vector<dmatrix>  save_result;  // save at each call the results (Cav, Bav, Prisk) for all stocks
  int second_risk;
  int run_risk;
  double p, q;
  double p2, q2;
  double p_run, q_run, r_run;
  int n_stocks;
  std::vector<std::string> stock_names;
private:
  Estimation_section<DVM>* e;
  Harvest_strategy<DVM>* strategy;
  dmatrix* free_parameter_values;
  std::vector<class Run_diagnostic_output>* run_diagnostic_output;
  int risk_year;
  int n_simulations, n_parameter_sets;
  int n_discard, n_keep;
  long RNG_seed;
  double H_initial_guess;
  dmatrix* reference_SSBs;
};

class Run_diagnostic_output{
  // If the yield_diagnostic_output switch is set,
  // each simulation run in MCY_CAY will fill in one of these data objects,
  // which will be printed to cout later.
public:
  void print(ostream& out = cout);
  dvector free_parameter_values;
  double harvest_rate;
  double abundance_error;
  dmatrix actual_catches;
  dmatrix SSBs;
  int n_stocks, n_fisheries, n_years, n_free_parameters;
  std::vector<std::string> stock_names, fishery_names;
  Run_diagnostic_output(int _n_stocks, int _n_fisheries, int _n_years, int _n_free_parameters, std::vector<std::string>& _stock_names, std::vector<std::string>& _fishery_names);
};

template<CDVM>
dvector get_CAY(double F_CAY, Harvest_strategy<DVM>* constant_mortality,
                Estimation_section<DVM>& e,
                const dmatrix& free_parameter_values, int n_simulations);

template<CDVM>
double expected_stock_level(Estimation_section<DVM>& e,
                            const dmatrix& free_parameter_values, int n_simulations);

template<CDVM>
void CSP(Estimation_section<DVM>& e,
         dmatrix& free_parameter_values,
         Parameter_set<DVM>& o);

template<CDVM>
class Get_E_Bpost{
  // This function object is used by CSP:
  // (a) get(catch) gives E(Bpost(current)), E(Bpost(current+1)), E(catch(current+1))
  //     one row per stock if there are multiple stocks
  // (b) operator()(catch) is the objective function which is to be maximised in the calculation of CSP:
  //     If there is only one stock or the individual_stocks switch is off,
  //      it is the -squared difference between sum(E(Bpost(current+1))) and sum(E(Bpost(current))),
  //      where the sum is over stocks and the expectation is over simulations.
  //     If there are multiple stocks and the individual_stocks switch is on,
  //      it is the negative squared difference between E(Bpost(current+1)) and E(Bpost(current)) for
  //      the stock of interest: first set stock_to_analyse which is the number of the stock.
  // We set up the object this way so that it can be passed to the generic maximiser
  //  used for various other yield calculations.
  // Be warned that the calculations change the population model passed to the constructor!!
  //  (The model is given parameter sets and run.)
public:
  double operator()(double catches, int print = 1, ostream& out = cout);
  dmatrix get(double catches, int print = 1, ostream& out = cout);
  int stock_to_analyse;
  Get_E_Bpost(Estimation_section<DVM>* _e,
              Harvest_strategy<DVM>* _next_catch, dmatrix* _free_parameter_values,
              long _RNG_seed, Parameter_set<DVM>& o);
private:
  Estimation_section<DVM>* e;
  Harvest_strategy<DVM>* next_catch;
  dmatrix* free_parameter_values;
  int individual_stocks;
  int n_simulations, n_parameter_sets;
  long RNG_seed;
  int n_stocks;
  std::vector<std::string> stock_names;
  int current;
};

//########################## HARVEST STRATEGIES ##########################
template<CDVM>
class Harvest_strategy{
  // Abstract class to model a harvest strategy.
  // Used to determine catches in MCY/CAY-type simulations. So, the derived classes
  //  include the Constant_catch, Constant_exploitation_rate, Constant_instantaneous_mortality
  //  strategies.
  // [So far these are only designed to be constructed by MCY_CAY(). You will need to modify
  //  the constructors or add new constructors if you want to use them elsewhere.]
  //
  // Typically, the key function is get_catch(), which takes various possible inputs into
  //   a harvest strategy - the harvest rate, last year's SSB (by stock), B0 (by stock),
  //    a measure of current abundance, a random number seed, and an indicator of whether
  //    this is the first year of a simulation -
  //  and returns the catch for each fishery (as a vector, with elements in the same order as the
  //  'annual_cycle.fishery_names' parameter, indexed from 1 up).
  //
  // The exception is the Constant_instantaneous_mortality strategy which does not return
  //   a catch. Instead it has constant_instantaneous_mortality()==1, which indicates
  //   that the harvest rate should be used as an instantaneous F in the Baranov equation.
  //
  // If a negative RNG seed is passed, then we are in a deterministic simulation and the
  //  variability in the harvest strategy (if any) should be 'turned off'.
  //
  // BB just added a function 'refresh' which is guaranteed to be called once per simulation run,
  //  before the deterministic part of a simulation (but currently in no other context).
  //  This is so the CBMSY strategy can get itself initialized at the start of each sim run.
public:
  virtual dvector get_catch(double harvest_rate, const VECTOR& last_SSB, const VECTOR& B0,
                            const DOUBLE& abundance, long seed, int first_year,
                            DOUBLE last_year_total_catch, int year) = 0;
  virtual double get_abundance_multiplier(long seed);
  virtual int use_abundance_multiplier(long seed);
  virtual int constant_instantaneous_mortality();
  virtual void refresh(){} // this must be called before a simulation run begins
  virtual void print(ostream& out = cout) = 0;
  int assess_frequency; // can be used in constant-catch, constant-exploitation-rate and chasing-BMSY strategies
};

template<CDVM>
class Constant_catch : public Harvest_strategy<DVM>{
  // Concrete class to model the constant-catch harvest strategy.
  // The 'harvest_rate' is the annual TAC.
  // The only complication is if there is an error applied to model uncertainty in initial abundance
  //   in a stochastic simulation.
  // ... A new complication has been added - the option of reducing catch if
  //  Bprevious (SSB of only stock in previous year) is less than a target biomass.
  //  There are new subcommands for error in estimating Bprevious in stochastic sims.
  //
  // Nov 2004: initial abundance error is now treated differently - it
  //  is handled externally based on a random number produced in get_abundance_multiplier,
  //  rather than in get_catch as it used to be.
public:
  dvector get_catch(double harvest_rate, const VECTOR& last_SSB, const VECTOR& B0,
                    const DOUBLE& abundance, long seed, int first_year,
                    DOUBLE last_year_total_catch, int year);
  double get_abundance_multiplier(long seed);
  int use_abundance_multiplier(long seed);
  void print(ostream& out = cout);
  Constant_catch(Parameter_set<DVM>& o, Parameter_set<DVM>& p,
                 int stochastic);
private:
  int n_fisheries;
  dvector catch_split;
  std::vector<std::string> fishery_names;
  std::string abundance_error_dist;
  double abundance_error_cv;
  int MCY_targs;
  double Btarg;
  std::string Bprevious_error_dist;
  double Bprevious_error_cv;
};

template<CDVM>
class Constant_exploitation_rate : public Harvest_strategy<DVM>{
  // Concrete class to model the constant-exploitation-rate strategy.
  // Used in simulations to determine the CAY.
  // The 'harvest_rate' is an exploitation rate, catch / Bpre (a user-defined measure of abundance),
  //   not an instantaneous mortality rate.
  // There is an option to apply a random error to the F each year, to reflect annual
  //   stock assessment uncertainty.
public:
  dvector get_catch(double harvest_rate, const VECTOR& last_SSB, const VECTOR& B0,
                    const DOUBLE& abundance, long seed, int first_year,
                    DOUBLE last_year_total_catch, int year);
  void print(ostream& out = cout);
  Constant_exploitation_rate(Parameter_set<DVM>& o, Parameter_set<DVM>& p,
                             const std::string& _description_of_abundance,
                             int stochastic);
private:
  int n_fisheries;
  dvector catch_split;
  std::vector<std::string> fishery_names;
  std::string description_of_abundance;
  std::string abundance_error_dist;
  double abundance_error_cv;
};

template<CDVM>
class Constant_instantaneous_mortality : public Harvest_strategy<DVM>{
  // Concrete class to model the constant-instantaneous_mortality strategy.
  // Only usable with the Baranov equation where there is only one fishery.
  // The 'harvest_rate' is the instantaneous mortality F.
public:
  dvector get_catch(double harvest_rate, const VECTOR& last_SSB, const VECTOR& B0,
                    const DOUBLE& abundance, long seed, int first_year,
                    DOUBLE last_year_total_catch, int year);
                    /* get_catch is not used - the fishing mortality function applies the F to determine the catch */
  int constant_instantaneous_mortality(){return 1;}
  void print(ostream& out = cout);
  Constant_instantaneous_mortality(Parameter_set<DVM>& o);
};

template<CDVM>
class Chasing_BMSY : public Harvest_strategy<DVM>{
  // Concrete class to model the chasing-BMSY harvest strategy.
  // The 'harvest_rate' is 'p' which specifies how hard we will chase the target biomass.
  // Constants in the strategy include Btarg (target biomass),
  //  M and R (mortality rate and recruitment-to-SSB to be used in simple projection calculation).
  // A current biomass is required for the strategy - SSB for the only stock
  //  will be used - uncertainty is applied to this (specified through the subcommands
  //  Bprevious_uncertainty_dist and Bprevious_uncertainty_cv) (if it is a stochastic
  //  simulation and not using the sample-based method).
public:
  dvector get_catch(double harvest_rate, const VECTOR& last_SSB, const VECTOR& B0,
                    const DOUBLE& abundance, long seed, int first_year,
                    DOUBLE last_year_total_catch, int year);
  void print(ostream& out = cout);
  void refresh(); // reset the last_year_TAC, second_last_SSB fields
  Chasing_BMSY(Parameter_set<DVM>& o, Parameter_set<DVM>& p,
               int stochastic);
private:
  int n_fisheries;
  dvector catch_split;
  std::vector<std::string> fishery_names;
  std::string Bprevious_error_dist;
  double Bprevious_error_cv;
  double Btarg, M, R;
  int BH_SR;
  double steepness;
  int simple_R; // use a simpler formula for R?
  double last_year_TAC, second_last_SSB;
  int n_calls; // since last refresh
};

//############################## END OF YIELDS.h ##############################
#endif
