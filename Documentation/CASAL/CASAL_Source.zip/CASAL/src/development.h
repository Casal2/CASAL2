//hi
// const char* time_stamp = "$Date: 2010-11-25 17:02:26 +1300 (Thu, 25 Nov 2010) $\n";
// const char* development_header_id = "$Id: development.h 3649 2010-11-25 04:02:26Z fud $\n";

#if !defined(DEVELOPMENT)
#define DEVELOPMENT

//############################### INCLUDES ##############################
#include "betadiff.h"
#include <string>
#include <vector>
#include <map>
#include <list>
#include <iomanip>
#include <algorithm>
#include <cctype>
// #include <algo.h>
#ifdef __MINGW32__
#ifndef _CONSOLE
  extern "C" {
  char *getlogin (void);
  int w32_gethostname(char* name, size_t size);
  }
#endif
#else
  #include <sys/utsname.h>
  #include <sys/times.h>
  #include <unistd.h>
#endif
#include <time.h>
#include <sstream>
#include "GetPot.h"
using namespace std;

//############################## TEMPLATING OF ARITHMETIC CLASSES #######################
#define CDVM             class DOUBLE,class VECTOR,class MATRIX
#define DVM              DOUBLE,VECTOR,MATRIX

//############################## CONSTANTS ##############################
#define PI 3.14159265358979
#define ZERO 1e-100
//########################### RETURN VALUES FOR CASAL ######################
#define STATUS_FATAL_ERROR      11
// a Betadiff error is 12 - see the Betadiff and ADOL-C code
#define STATUS_OK       0
#define STATUS_MINIMISER_CONVERGENCE_UNCLEAR 1
#define STATUS_MINIMISER_OUT_OF_ITERATIONS 2

//############################## ERROR HANDLING ##############################
static void fatal(const std::string& problem){
 cerr << "\nError: " << problem << '\n';
 exit(STATUS_FATAL_ERROR);
}

//############################## FUNCTION DEBUGGING ##############################
#if defined(_D0_)
void DEBUG0(const std::string& function_name);
#define DEBUG1(fn) ;
#define DEBUG2(fn) ;
#elif defined(_D1_)
void DEBUG0(const std::string& function_name);
void DEBUG1(const std::string& function_name);
#define DEBUG2(fn) ;
#elif defined(_D2_)
void DEBUG0(const std::string& function_name);
void DEBUG1(const std::string& function_name);
void DEBUG2(const std::string& function_name);
#else
#define DEBUG0(fn) ;
#define DEBUG1(fn) ;
#define DEBUG2(fn) ;
#endif

//############################## FUNCTIONS TO SUPPLEMENT THE STL ##############################
template<class C>
void concatenate(std::vector<C>& v1,const std::vector<C>& v2){
  v1.insert(v1.end(),v2.begin(),v2.end());
}

template<class C,class D>
int in(const std::list<C>& l,const D& d){
  C c(d);
  return(std::find(l.begin(),l.end(),c) != l.end());
}

template<class C,class D>
int in(const std::map<C,D>& m,const C& c){
  return(m.find(c) != m.end());
}

static int in(const std::string& s, const std::string& t){
  return (s.find(t)!=string::npos);
}

template<class C>
int in(const std::vector<C>& v,const C& c){
  for (int i=0; i<v.size(); i++){
    if (v[i]==c) return 1;}
  return 0;
}

template<class C,class D>
int pos(const std::vector<C>& v,const D& d){
  for (int i=0; i<v.size(); i++){
    if (v[i]==d) return i;}
  return -1;
}

static int in(const dvector& v,double d){
  for (int i = v.indexmin(); i<=v.indexmax(); i++){
    if (v[i]==d){
      return 1;
    }
  }
  return 0;
}

static int pos(const dvector& v,double d){
  for (int i = v.indexmin(); i<=v.indexmax(); i++){
    if (v[i]==d){
      return i;
    }
  }
  return 0;
}

static int in(const dvv& v,const dvariable& d){
  for (int i = v.indexmin(); i<=v.indexmax(); i++){
    if (v[i]==d){
      return 1;
    }
  }
  return 0;
}

static int pos(const dvv& v,const dvariable& d){
  for (int i = v.indexmin(); i<=v.indexmax(); i++){
    if (v[i]==d){
      return i;
    }
  }
  return 0;
}

template<class C>
C max(const std::vector<C>& v){
  C c = v[0];
  if (v.size()>1){
    for (int i=1; i<v.size(); i++){
      c = (c < v[i]) ? v[i] : c;
    }
  }
  return c;
}

static std::string itos(int i){
  /*
  char temp[10];
  sprintf(temp,"%d",i);
  return std::string(temp);
  */
  ostringstream s_stream;
  s_stream << i;
  return s_stream.str();
}


static std::string dtos(double d){
  /*
  char temp[10];
  sprintf(temp,"%g",d);
  return std::string(temp);
  */
  ostringstream s_stream;
  s_stream << d;
  return s_stream.str();

}

static int stoi(const std::string& s, std::string error_msg=std::string("no default"), std::string error_msg2=std::string("no default")){
  int val;
  istringstream s_stream((s+" ").c_str());
  s_stream >> val;
  if (!(s_stream.good())){
    if (error_msg=="no default"){
      fatal("stoi: Cannot convert value " + s + " to integer");
    } else {
      fatal(error_msg);
    }
  }
  std::string dummy;
  s_stream >> dummy;
  if (s_stream.good()){
    if (error_msg=="no default"){
      fatal("stoi: Two or more entries in " + s);
    } else {
      fatal(error_msg2);
    }
  }
  return val;
}

static int stoi(char* c, std::string error_msg=std::string("no default"), std::string error_msg2=std::string("no default")){
  return stoi(std::string(c),error_msg, error_msg2);
}

static double stod(const std::string& s, std::string error_msg=std::string("no default"), std::string error_msg2=std::string("no default")){
 /* This is where to go
  stringstream SStream(s);
  double val;
  SStream >> val;
 */

  double val;
  istringstream s_stream((s+" ").c_str());
  s_stream >> val;
  if (!(s_stream.good())){
    if (error_msg=="no default"){
      fatal("stod: Cannot convert value " + s + " to double");
    } else {
      fatal(error_msg);
    }
  }
  std::string dummy;
  s_stream >> dummy;
  if (s_stream.good()){
    if (error_msg=="no default"){
      fatal("stod: Two or more entries in " + s);
    } else {
      fatal(error_msg2);
    }
  }
  return val;
}

static double stod(char* c, std::string error_msg=std::string("no default"), std::string error_msg2=std::string("no default")){
  return stod(std::string(c),error_msg,error_msg2);
}


template<class C>
static C mean(const std::vector<C> V){
  // should work for double, dvariable, dvector, dvv, dmatrix, dvm at least
  C sum = 0;
  for (int i=0; i<V.size(); i++){
    sum += V[i];
  }
  return sum / V.size();
}

template<class C>
std::vector<C> intersection(const std::vector<C>& v1, const std::vector<C>& v2){
  std::vector<C> result;
  for (int i=0; i<v1.size(); i++){
    if (in(v2,v1[i])){
      result.push_back(v1[i]);
    }
  }
  return result;
}

template<class C,class D>
std::ostream& operator<<(std::ostream& out, const std::map<C,D>& m){
  out << '\n';
  typedef typename std::map<C,D>::const_iterator MAP_IT;
  for (MAP_IT i=m.begin(); i!=m.end(); ++i){
    out << "  " << i->first << '\t' << i->second << '\n';}
  return out;
}

template<class D>
std::ostream& operator<<(std::ostream& out, const std::map<std::string,D>& m){
  // if the key is a string, pad it with spaces
  out << '\n';
  typedef typename std::map<std::string,D>::const_iterator MAP_IT;
  for (MAP_IT i=m.begin(); i!=m.end(); ++i){
    out << "  ";
    out.setf(ios::left,ios::adjustfield);
    out << setw(30);
    out << i->first.c_str();
    out << '\t' << i->second << '\n';}
  return out;
}

static std::ostream& operator<<(std::ostream& out, const std::map<std::string,std::string>& m){
  // if the key is a string, pad it with spaces
  // if the value is a string, remove leading whitespace
  out << '\n';
  typedef std::map<std::string,std::string>::const_iterator MAP_IT;
  for (MAP_IT i=m.begin(); i!=m.end(); ++i){
    out << "  ";
    out.setf(ios::left,ios::adjustfield);
    out << setw(30);
    out << i->first.c_str();
    std::string value = i->second;
    if (value.find_first_of(" \t") != string::npos){
      value = value.substr(value.find_first_not_of(" \t"));}
    out << '\t' << value << '\n';}
  return out;
}

template<class D>
std::ostream& operator<<(std::ostream& out, const std::vector<D> v){
  for (int i=0; i<v.size(); i++){
    out << v[i] << ' ';}
  return out;
}

template<class D>
std::ostream& operator<<(std::ostream& out, const std::vector<std::vector<D> > v){
  for (int i=0; i<v.size(); i++){
    for (int j=0; j<v[i].size(); j++){
      out << v[i][j] << ' ';}
    out << '\n';
  }
  return out;
}

template<class D>
void print_column(const std::vector<D> v, std::ostream& out){
  for (int i=0; i<v.size(); i++){
    out << v[i] << '\n';}
}

static std::string date_of(const std::string& cvs_id){
  // grabs the date out of a CVS $Id field
  istringstream i(cvs_id.c_str());
  std::string id, name, version, date;
  i >> id >> name >> version >> date;
  return date;
}

static std::string time_of(const std::string& cvs_id){
  // grabs the time out of a CVS $Id field
  istringstream i(cvs_id.c_str());
  std::string id, name, version, date, time;
  i >> id >> name >> version >> date >> time;
  return time;
}

static void most_recent_timestamp(const vector<string> all_ids, std::string& most_recent_date, std::string& most_recent_time){
  // all_ids -> vector with cvs_id for each file in the program. This vector is read through and the most recent
  // date and time are returned in the variables most_recent_date, most_recent_time
  most_recent_date = date_of(all_ids[0]);
  most_recent_time = time_of(all_ids[0]);
  string current_date;
  string current_time;
  for (int i=1; i<=all_ids.size()-1; i++){
    current_date = date_of(all_ids[i]);
    current_time = time_of(all_ids[i]);
    if (current_date > most_recent_date){
      most_recent_date = current_date;
      most_recent_time = current_time;
    }
    if (current_date == most_recent_date && current_time > most_recent_time){
      most_recent_time = current_time;
    }
  }
}

template<class DOUBLE, class VECTOR, class MATRIX>
VECTOR stream_to_vector(istringstream& i, std::string error_msg="default"){
  // turns a stream based on a string which is a list of whitespace-separated numbers into a VECTOR
  // second argument is the error message to use if no valid numbers at the start of the string
  int count = 0;
  std::vector<DOUBLE> temp;
  DOUBLE dummy;
  while (i.good()){
    i >> dummy;
    temp.push_back(dummy);
    if (i.good()) count++;
  }
  if (count==0){
        if (error_msg=="default"){
          fatal("stream_to_vector did not get any valid numbers");
        } else {
          fatal(error_msg);
        }
  }
  VECTOR result(1,count);
  for (int j=1; j<=count; j++){
    result[j] = temp[j-1];
  }
  return result;
}

//############################## PROBABILITY DISTRIBUTIONS ##############################
template<class DOUBLE>
DOUBLE pnorm(const DOUBLE& x,const DOUBLE& mu=0,const DOUBLE& sigma=1){
  // Abramowitz & Stegun eqn 26.2.18
  // Equations: z = fabs((x-mu)/sigma);
  //            p = 1-0.5*pow((1+0.196854*z+0.115194*z*z+0.000344*z*z*z+0.019527*z*z*z*z),-4);
  //            if (x<mu) p=1-p;
  DOUBLE z = fabs((x - mu)/sigma);
  DOUBLE p = 1-0.5*pow((1+0.196854*z+0.115194*z*z+0.000344*z*z*z+0.019527*z*z*z*z),-4);
  if (x<mu) p = 1-p;
  return(p);
}

template<class DOUBLE>
DOUBLE dnorm(const DOUBLE& x,const DOUBLE& mu=0,const DOUBLE& sigma=1){
  DOUBLE z = 1/(sigma*sqrt(2*PI))*exp(-((x-mu)*(x-mu))/(2*sigma*sigma));
  return(z);
}

template<class DOUBLE>
DOUBLE plognorm(const DOUBLE& x, const DOUBLE& mu, const DOUBLE& sigma){
  // Parameterised by the mean and standard deviation of the (normal) distribution
  //  of log(x), NOT by those of the (lognormal) distribution of x.
  if (x<=0) return 0;
  else return pnorm<DOUBLE>(log(x),mu,sigma);
}

template<class DOUBLE>
DOUBLE dlognorm(const DOUBLE& x, const DOUBLE& mu, const DOUBLE& sigma){
  // Parameterised by the mean and standard deviation of the (normal) distribution
  //  of log(x), NOT by those of the (lognormal) distribution of x.
  if (x<=0) return 0;
  else return dnorm<DOUBLE>(log(x),mu,sigma);
}

template<class DOUBLE, class VECTOR, class MATRIX>
VECTOR distribution(dvector& class_mins, int plus_group = 0,
                    const std::string& dist = "normal", const DOUBLE& mean=0, const DOUBLE& stdev=1){
  // Probability distribution of a random variable over classes.
  // distribution(class_mins,plus_group,dist,mean,stdev)[i]
  // is the probability that a random variable with distribution 'dist', 'mean' and 'stdev'
  // falls between class_mins[i] and class_mins[i+1]
  // (unless i = class_mins.indexmax() and plus_group!=0, in which case
  // distribution(...)[i] is the probability that the random variable exceeds class_mins[i]).
  //
  // We use an approximation: P(X is more than 5 std.devs away from its mean) = 0.
  //  Almost true for the normal distribution, but may be problematic if you use something more skewed.
  DEBUG2("distribution");
  int first_class = class_mins.indexmin();
  int last_class = class_mins.indexmax() - (plus_group ? 0 : 1);
  VECTOR result(first_class,last_class);
  DOUBLE so_far;
  DOUBLE mu,sigma;
  if (dist=="lognormal"){
    sigma = sqrt(log(1+pow(stdev/mean,2)));
    mu = log(mean) - sigma*sigma/2;
  }
  if (class_mins[first_class] < value(mean)-5*value(stdev)){
    so_far = 0;
  } else {
    if (dist=="normal"){
      so_far = pnorm<DOUBLE>(class_mins[first_class],mean,stdev);
    } else if (dist=="lognormal"){
      so_far = plognorm<DOUBLE>(class_mins[first_class],mu,sigma);
    } else fatal("Unknown dist = " + dist + " in distribution()");
  }
  int c;
  for (c = first_class; c<last_class; c++){
    if (class_mins[c+1] > value(mean)+5*value(stdev)){
      result[c] = 1-so_far;
      so_far = 1;
    } else if (class_mins[c+1] < value(mean)-5*value(stdev)){
      result[c] = 0;
      so_far = 0;
    } else {
      if (dist=="normal"){
        result[c] = pnorm<DOUBLE>(class_mins[c+1],mean,stdev) - so_far;
      } else if (dist=="lognormal"){
        result[c] = plognorm<DOUBLE>(class_mins[c+1],mu,sigma) - so_far;
      }
      so_far += result[c];
    }
    if (result[c]<0 || result[c]!=result[c]){ cerr << "bad result in distribution\n";
      exit(STATUS_FATAL_ERROR);
    }
  }
  c = last_class;
  if (plus_group){
    result[c] = 1-so_far;
  } else {
    if (class_mins[c+1] > value(mean)+5*value(stdev)){
      result[c] = 1-so_far;
    } else {
      if (dist=="normal"){
        result[c] = pnorm<DOUBLE>(class_mins[c+1],mean,stdev) - so_far;
      } else if (dist=="lognormal"){
        result[c] = plognorm<DOUBLE>(class_mins[c+1],mu,sigma) - so_far;
      }
    }
    if (result[c]<0 || result[c]!=result[c]){ cerr << "bad result in distribution\n";
      exit(STATUS_FATAL_ERROR);
    }
  }
  return result;
};

template<class DOUBLE>
DOUBLE qnorm(const DOUBLE& q,const DOUBLE& mu=0,const DOUBLE& sigma=1){
  // Abramowitz & Stegun eqn 26.2.22
  // Equations: qq = q (q < 0.5) or 1-q (q > 0.5)
  //            t = sqrt(ln(1/(qq*qq)));
  //            pp = t - (2.30753 + 0.27061*t) / (1 + 0.99229*t + 0.04481*t*t)
  //            p = -pp (q < 0.5) or pp (q > 0.5)
  //            x = mu + p*sigma
  DOUBLE qq, t, pp, p;
  qq = ((q < 0.5) ? q : (1-q));
  t = sqrt(log(1/(qq*qq)));
  pp = t - (2.30753 + 0.27061*t) / (1 + 0.99229*t + 0.04481*t*t);
  p = ((q < 0.5) ? -pp : pp);
  return(mu+p*sigma);
}

template<class DOUBLE>
DOUBLE qlognorm(const DOUBLE& q,const DOUBLE& mu,const DOUBLE& sigma){
  // Parameterised by the mean and standard deviation of the (normal) distribution
  //  of log(x), NOT by those of the (lognormal) distribution of x.
  DOUBLE x = qnorm(q);
  return(exp(mu+x*sigma));
}

//############################## RANDOM NUMBER GENERATION ##############################
// Just a couple of auxiliary functions. They work off the Betadiff generators
// so RNG seeds are treated in the same way (which see betadiff.h).
// Watch out, syntax is not the same as S.
double rnorm(double mean, double stdev, long seed);

double rlognorm(double mean, double stdev, long seed);

//############################## VARIANCE/COVARIANCE ESTIMATION ##############################
dmatrix sample_covariance(dmatrix &x);

//############################## EIGENANALYSIS ##############################
static void get_qr(dmatrix &a, dmatrix &q, dmatrix &r);
static dmatrix remove_zerorowcols(dmatrix &x);

static dvector sorted_eigenvalues(dmatrix& xx){
  // used in estimation.C to calculate the eigenvalues of the Hessian matrix
  // return a sorted list of these eigenvalues
  // uses the shifted QR method - see e.g. http://media.pearsoncmg.com/aw/aw_lay_linearalg_3/cs_apps/qrmethod.pdf
  // rows and columns which are entirely zeros are removed first
  dmatrix x(remove_zerorowcols(xx));
  int n = x.rowsize();
  int n_left = n;
  dmatrix *a, *r, *q;
  dvector e(1,n);
  a = new dmatrix(x);
  r = new dmatrix(1,n,1,n);
  q = new dmatrix(1,n,1,n);
  int iterations = 0;
  double c;
  while (n_left > 1){
    iterations++;
    if (iterations > 100*n){
                fatal("Too many QR iterations in sorted_eigenvalues");
        }
    c = (*a)[n_left][n_left];
    for (int i=1; i<=n_left; i++){
                (*a)[i][i] -= c;
        }
    get_qr(*a,*q,*r);
        *a = (*r) * (*q);
    for (int i=1; i<=n_left; i++){
                (*a)[i][i] += c;
        }
        double max_abs_last_row = 0;
        for (int i=1; i<n_left; i++){
                max_abs_last_row = max(max_abs_last_row,fabs((*a)[n_left][i]));
        }
        if (max_abs_last_row <= 1e-7){
                // we have found an eigenvalue
                e[n-n_left+1] = (*a)[n_left][n_left];
                dmatrix old_a(*a);
                delete q;
        delete a;
                delete r;
        r = new dmatrix(1,n_left-1,1,n_left-1);
        a = new dmatrix(1,n_left-1,1,n_left-1);
                q = new dmatrix(1,n_left-1,1,n_left-1);
                for (int i=1; i<n_left; i++){
                  for (int j=1; j<n_left; j++){
                          (*a)[i][j] = old_a[i][j];
                  }
            }
                n_left--;
        }
  }
  e[n] = (*a)[1][1];
  delete a;
  delete r;
  delete q;
  return sort(e);
}

static void get_qr(dmatrix &a, dmatrix &q, dmatrix &r){
  // used by sorted_eigenvalues above
  // calculates the QR decomposition of a and returns it in q and r
  // uses a casual implementation of the Householder method
  int n = a.rowsize();
  dmatrix identity(1,n,1,n);
  identity = 0;
  for (int i=1; i<=n; i++){
          identity[i][i] = 1;
  }
  q = identity;
  dmatrix original_a(a);
  dmatrix h(1,n,1,n);
  dvector x(1,n);
  for (int i=1; i<n; i++){
         x = 0;
         for (int j=i; j<=n; j++){
          x[j] = a[j][i];
         }
         dvector v(x);
         v[i] = v[i] + sqrt(sum(elem_prod(x,x)));
         double norm_v = sqrt(sum(elem_prod(v,v)));
         v /= norm_v;
         h = identity - 2*(column_vector(v) * row_vector(v));
         a = h * a;
         q = q * h;
  }
  r = a;
}

static dmatrix remove_zerorowcols(dmatrix &x){
  // takes a symmetric matrix
  // removes all zero rows and columns
  // returns the result;
  int n = x.rowsize();
  dvector iszero(1,n);
  iszero=0;
  for (int i=1; i<=n; i++){
    double max_abs = 0;
    for (int j=1; j<=n; j++){
      max_abs = max(max_abs,fabs(x[i][j]));
    }
    if (max_abs==0) iszero[i]=1;
  }
  int n_nonzero = n - (int)(sum(iszero));
  dmatrix xx(n_nonzero,n_nonzero);
  int count1, count2;
  count1=0;
  for (int i=1; i<=n_nonzero; i++){
    count1++;
    while (iszero[count1]) count1++;
    count2=0;
    for (int j=1; j<=n_nonzero; j++){
      count2++;
      while (iszero[count2]) count2++;
      xx[i][j] = x[count1][count2];
    }
  }
  return xx;
}

//############################## END OF DEVELOPMENT.h ##############################
#endif
