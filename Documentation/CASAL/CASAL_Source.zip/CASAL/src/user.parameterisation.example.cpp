// const char* time_stamp = "$Date: 2006-08-08 15:18:31 +1200 (Tue, 08 Aug 2006) $\n";
// const char* user_parameterisation_example_cpp_id = "$Id: user.parameterisation.example.cpp 1593 2006-08-08 03:18:31Z adunn $\n";

#ifndef USER_PARAMETERISATION_CPP
#define USER_PARAMETERISATION_CPP

//############################## USER PARAMETERISATION.cpp ##############################
#include "development.h"

/////////////////////////////////////////////////////////////////////////////////////////
template<CDVM>
void user_parameterisation(
        std::vector<std::string>& new_scalar_names,
        std::vector<DOUBLE>& new_scalar_vals,
        std::vector<std::string>& new_vector_names,
        std::vector<VECTOR>& new_vector_vals,
        std::vector<std::string>& old_scalar_names,
        std::vector<DOUBLE>& old_scalar_vals,
        std::vector<std::string>& old_vector_names,
        std::vector<VECTOR>& old_vector_vals){

/*

   *** TEMPLATE - BRIAN BULL, 23/5/02 ***

   Use this function to implement a new parameterisation in the CASAL population section.

   The function should convert the values of the 'new' parameters (i.e. those in your *.csl files)
    back to the 'old' parameters (i.e. those in the CASAL manual).

   The inputs to this function are the names and values of the new scalar and vector parameters,
    the outputs are the names and values of the old scalar and vector parameters.

   You cannot reparameterise ogives.

   You need to use the std::vector and std::string classes
     (these are in the STL, see any good C++ book, e.g. Stroustrup)
   and DOUBLE and VECTOR, which are templates either for double and dvector or for dvariable and dvv
     (apart from double, these are Betadiff classes: see betadiff.h)

   Note that the indices of these VECTORs should always start at 1 (in this particular function)
    but the indices of the std::vectors always start at 0.
    So, the name of the first new vector parameter is new_vector_names[0],
    and its values are new_vector_vals[0][1], new_vector_vals[0][2]...
   The output arguments are passed as vectors of length 0: you need to grow them and fill them in.

*/

/*

   *** Brian Bull, 24/5/02. Converts log(B0) to B0 ***

   Converts initialization.log_B0 to initialization.B0.

   Need to insert the following in estimation.csl:
      @user_parameterisation 1
*/

  DEBUG1("user_parameterisation");

  if (!in<std::string>(new_scalar_names,"initialization.log_B0")){
          fatal("You need to estimate initialization.log_B0");}

  DOUBLE log_B0 = new_scalar_vals[pos<std::string>(new_scalar_names,"initialization.log_B0")];
  old_scalar_names.push_back("initialization.B0");
  old_scalar_vals.push_back(exp(log_B0));

}
//############################## END OF USER PARAMETERISATION.cpp ##############################
#endif
