// const char* time_stamp = "$Date: 2006-08-08 15:18:31 +1200 (Tue, 08 Aug 2006) $\n";
// const char* priors_cpp_id = "$Id: priors.cpp 1593 2006-08-08 03:18:31Z adunn $\n";

//############################## PRIORS ##############################
#include "priors.h"

///////////////////////////////////////////////////////////////////////
template<CDVM>
DOUBLE Scalar_prior<DVM>::prior(DOUBLE& p){
  fatal("prior() not defined for Scalar_prior's of this->type " + this->type);
  return(-1.0);
}

template<CDVM>
double Scalar_prior<DVM>::get_mu(){
  fatal("get_mu() not defined for Scalar_prior's of this->type " + this->type);
  return(-1.0);
}


template<CDVM>
double Scalar_prior<DVM>::get_cv(){
  fatal("get_cv() not defined for Scalar_prior's of this->type " + this->type);
  return(-1.0);
}


template<CDVM>
void Scalar_prior<DVM>::print(ostream& out){
  DEBUG2("Scalar_prior::print");
  out << "bounds from " << this->lower_bound << " to " << this->upper_bound << '\n';
}

template<CDVM>
Scalar_prior<DVM>::Scalar_prior(double _lower_bound, double _upper_bound){
  // Construct the prior object; for this base class there is no actual prior, just bounds.
  DEBUG2("Scalar_prior::Scalar_prior");
  this->type = "None";
  this->lower_bound = _lower_bound;
  this->upper_bound = _upper_bound;
  if (this->lower_bound > this->upper_bound){
    fatal("Lower bound of " + dtos(this->lower_bound) + " is greater than upper bound of " + dtos(this->upper_bound));}
}

template<CDVM>
DOUBLE Uniform_prior<DVM>::prior(DOUBLE& p){
  DEBUG2("Uniform_prior::prior");
  return 0;
}

template<CDVM>
void Uniform_prior<DVM>::print(ostream& out){
  DEBUG2("Uniform_prior::print");
  out << "uniform: ";
  Scalar_prior<DVM>::print(out);
}

template<CDVM>
Uniform_prior<DVM>::Uniform_prior(double _lower_bound, double _upper_bound)
  : Scalar_prior<DVM>(_lower_bound, _upper_bound){
  DEBUG2("Uniform_prior::Uniform_prior");
  this->type = "Uniform_prior";
}

template<CDVM>
DOUBLE Uniform_log_prior<DVM>::prior(DOUBLE& p){
  DEBUG2("Uniform_log_prior::prior");
  if (p<=0){
          fatal("You have used a uniform_log prior for a nonpositive parameter");}
  return log(p);
}

template<CDVM>
void Uniform_log_prior<DVM>::print(ostream& out){
  DEBUG2("Uniform_log_prior::print");
  out << "uniform-log: ";
  Scalar_prior<DVM>::print(out);
}

template<CDVM>
Uniform_log_prior<DVM>::Uniform_log_prior(double _lower_bound, double _upper_bound)
  : Scalar_prior<DVM>(_lower_bound, _upper_bound){
  DEBUG2("Uniform_log_prior::Uniform_log_prior");
  this->type = "Uniform_log_prior";
}

template<CDVM>
DOUBLE Normal_prior<DVM>::prior(DOUBLE& p){
  DEBUG2("Normal_prior::prior");
  return 0.5 * ((p-mu)/(cv*mu)) * ((p-mu)/(cv*mu));
}

template<CDVM>
void Normal_prior<DVM>::print(ostream& out){
  DEBUG2("Normal_prior::print");
  out << "normal with mean " << mu << ", c.v. " << cv << " : ";
  Scalar_prior<DVM>::print(out);
}

template<CDVM>
Normal_prior<DVM>::Normal_prior(double _lower_bound, double _upper_bound, double _mu, double _cv)
  : Scalar_prior<DVM>(_lower_bound, _upper_bound){
  DEBUG2("Normal_prior::Normal_prior");
  this->type = "Normal_prior";
  mu = _mu;
  cv = _cv;
  if (mu*cv<=0.0001){
          fatal("The normal_prior has very small stdev");}
}

template<CDVM>
DOUBLE Normal_by_stdev_prior<DVM>::prior(DOUBLE& p){
  DEBUG2("Normal_by_stdev_prior::prior");
  return 0.5 * ((p-mu)/stdev) * ((p-mu)/stdev);
}

template<CDVM>
void Normal_by_stdev_prior<DVM>::print(ostream& out){
  DEBUG2("Normal_by_stdev_prior::print");
  out << "normal with mean " << mu << ", std.dev. " << stdev << " : ";
  Scalar_prior<DVM>::print(out);
}

template<CDVM>
Normal_by_stdev_prior<DVM>::Normal_by_stdev_prior(double _lower_bound, double _upper_bound, double _mu, double _stdev)
  : Scalar_prior<DVM>(_lower_bound, _upper_bound){
  DEBUG2("Normal_by_stdev_prior::Normal_by_stdev_prior");
  this->type = "Normal_by_stdev_prior";
  mu = _mu;
  stdev = _stdev;
  if (stdev<=0.0001){
          fatal("The normal_by_stdev_prior has very small stdev");}
}

template<CDVM>
DOUBLE Lognormal_prior<DVM>::prior(DOUBLE& p){
  DEBUG2("Lognormal_prior::prior");
  if (p<=0){
          fatal("You have used a lognormal prior on a nonpositive parameter, this is not allowed.");}
  return log(p) + 0.5 * pow(log(p/mu)/sigma + sigma*0.5, 2);
}

template<CDVM>
void Lognormal_prior<DVM>::print(ostream& out){
  DEBUG2("Lognormal_prior::print");
  out << "lognormal with mean " << mu << ", c.v. " << cv << " : ";
  Scalar_prior<DVM>::print(out);
}

template<CDVM>
Lognormal_prior<DVM>::Lognormal_prior(double _lower_bound, double _upper_bound, double _mu, double _cv)
  : Scalar_prior<DVM>(_lower_bound, _upper_bound){
  DEBUG2("Lognormal_prior::Lognormal_prior");
  this->type = "Lognormal_prior";
  mu = _mu;
  cv = _cv;
  sigma = sqrt(log(1+cv*cv));
}

template<CDVM>
DOUBLE Normal_log_prior<DVM>::prior(DOUBLE& p){
  DEBUG2("Normal_log_prior::prior");
  if (p<=0){
          fatal("You have used a normal_log_prior on a nonpositive parameter, this is not allowed.");}
  return log(p) + 0.5 * ((log(p) - m) / s) * ((log(p) - m) / s);
}

template<CDVM>
void Normal_log_prior<DVM>::print(ostream& out){
  DEBUG2("Normal_log_prior::print");
  out << "normal-log, with mean of log(p) " << m << ", std.dev. of log(p) " << s << " : ";
  Scalar_prior<DVM>::print(out);
}

template<CDVM>
double Normal_log_prior<DVM>::get_mu(){
  if (m<0) fatal("Fatal error in Normal_log_prior<DVM>::get_mu: m<0");
  return log(m) - s*s*0.5;
}

template<CDVM>
double Normal_log_prior<DVM>::get_cv(){
  return sqrt(exp(s*s)-1);
}

template<CDVM>
Normal_log_prior<DVM>::Normal_log_prior(double _lower_bound, double _upper_bound, double _m, double _s)
  : Scalar_prior<DVM>(_lower_bound, _upper_bound){
  DEBUG2("Normal_log_prior::Normal_log_prior");
  this->type = "Normal_log_prior";
  m = _m;
  s = _s;
}

template<CDVM>
DOUBLE Beta_prior<DVM>::prior(DOUBLE& p){
  DEBUG2("Beta_prior::prior");
  return (1-m) * log(p-Abound) + (1-n) * log(Bbound-p);
}

template<CDVM>
void Beta_prior<DVM>::print(ostream& out){
  DEBUG2("Beta_prior::print");
  out << "beta with mean " << mu << ", st.dev. " << stdev << ", and range from A = "
      << Abound << " to B = " << Bbound << " : ";
  Scalar_prior<DVM>::print(out);
}

template<CDVM>
Beta_prior<DVM>::Beta_prior(double _lower_bound, double _upper_bound, double _mu, double _stdev,
                            double _Abound, double _Bbound)
  : Scalar_prior<DVM>(_lower_bound, _upper_bound){
  if (_lower_bound < _Abound || _upper_bound > _Bbound){
    fatal("Bad bounds on Beta prior: " + dtos(this->lower_bound) + ", " + dtos(this->upper_bound));}
  if (_Abound >= _Bbound){
    fatal("Bad range parameters on Beta prior: A (" + dtos(Abound) + ") must be less than B (" + dtos(Bbound) + ").");}
  DEBUG2("Beta_prior::Beta_prior");
  this->type = "Beta_prior";
  mu = _mu;
  stdev = _stdev;
  Abound = _Abound;
  Bbound = _Bbound;
  nu = (mu - Abound) / (Bbound - Abound);
  t = (((mu - Abound) * (Bbound - mu)) / (stdev * stdev)) - 1;
  if(t <= 0){
    fatal("Bad standard deviation on Beta prior: stdev of " + dtos(stdev) + " is too large.");}
  m = t * nu;
  n = t * (1 - nu);
}

template<CDVM>
DOUBLE Vector_prior<DVM>::prior(const VECTOR& p){
  fatal("prior() not defined for Vector_prior's of this->type " + this->type);
  return(-1.0);
}

template<CDVM>
void Vector_prior<DVM>::print(ostream& out){
  DEBUG2("Vector_prior::print");
  out << "bounds of\n" << lower_bounds << "\n" << upper_bounds << '\n';
}

template<CDVM>
Vector_prior<DVM>::Vector_prior(const dvector& _lower_bounds, const dvector& _upper_bounds)
  : lower_bounds(_lower_bounds)
  , upper_bounds(_upper_bounds){
  // Construct the prior object; for this base class there is no actual prior, just bounds.
  DEBUG2("Vector_prior::Vector_prior");
  this->type = "None";
}

template<CDVM>
DOUBLE Uniform_vector_prior<DVM>::prior(const VECTOR& p){
  DEBUG2("Uniform_vector_prior::prior");
  return 0;
}

template<CDVM>
void Uniform_vector_prior<DVM>::print(ostream& out){
  DEBUG2("Uniform_vector_prior::print");
  out << "uniform:\n";
  Vector_prior<DVM>::print(out);
}

template<CDVM>
Uniform_vector_prior<DVM>::Uniform_vector_prior(const dvector& _lower_bounds,
                                                const dvector& _upper_bounds)
  : Vector_prior<DVM>(_lower_bounds, _upper_bounds){
  DEBUG2("Uniform_vector_prior::Uniform_vector_prior");
  this->type = "Uniform_vector_prior";
}

template<CDVM>
DOUBLE Uniform_log_vector_prior<DVM>::prior(const VECTOR& p){
  DEBUG2("Uniform_log_vector_prior::prior");
  if (min(p)<=0){
          fatal("You have used a uniform_log_vector_prior on a nonpositive parameter, this is not allowed.");}
  return sum(log(p));
}

template<CDVM>
void Uniform_log_vector_prior<DVM>::print(ostream& out){
  DEBUG2("Uniform_log_vector_prior::print");
  out << "uniform-log:\n";
  Vector_prior<DVM>::print(out);
}

template<CDVM>
Uniform_log_vector_prior<DVM>::Uniform_log_vector_prior(const dvector& _lower_bounds,
                                                        const dvector& _upper_bounds)
  : Vector_prior<DVM>(_lower_bounds, _upper_bounds){
  DEBUG2("Uniform_log_vector_prior::Uniform_log_vector_prior");
  this->type = "Uniform_log_vector_prior";
}

template<CDVM>
DOUBLE Normal_vector_prior<DVM>::prior(const VECTOR& p){
  DEBUG2("Normal_vector_prior::prior");
  DOUBLE result = 0;
  for (int i=1; i<=mu.size(); i++){
    result += 0.5 * ((p[i]-mu[i])/(cv[i]*mu[i])) * ((p[i]-mu[i])/(cv[i]*mu[i]));}
  return result;
}

template<CDVM>
void Normal_vector_prior<DVM>::print(ostream& out){
  DEBUG2("Normal_vector_prior::print");
  out << "normal with means " << mu << "c.v.s " << cv << ":\n";
  Vector_prior<DVM>::print(out);
}

template<CDVM>
Normal_vector_prior<DVM>::Normal_vector_prior(const dvector& _lower_bounds,
                                              const dvector& _upper_bounds,
                                              const dvector& _mu, const dvector& _cv)
  : Vector_prior<DVM>(_lower_bounds, _upper_bounds)
  , mu(_mu)
  , cv(_cv){
  DEBUG2("Normal_vector_prior::Normal_vector_prior");
  this->type = "Normal_vector_prior";
  if(mu.size() != _upper_bounds.size()){
    fatal("The values for 'mu' parameter of the Normal_vector_prior are the wrong length\n");}
  if(cv.size() != _upper_bounds.size()){
    fatal("The values for 'cv' parameter of the Normal_vector_prior are the wrong length\n");}
  if (min(elem_prod(mu,cv)) <= 0){
          fatal("Bad parameter for Normal_vector_prior: mu<=0 or cv<=0.");}
}

template<CDVM>
DOUBLE Normal_by_stdev_vector_prior<DVM>::prior(const VECTOR& p){
  DEBUG2("Normal_by_stdev_vector_prior::prior");
  DOUBLE result = 0;
  for (int i=1; i<=mu.size(); i++){
    result += 0.5 * ((p[i]-mu[i])/stdev[i]) * ((p[i]-mu[i])/stdev[i]);}
  return result;
}

template<CDVM>
void Normal_by_stdev_vector_prior<DVM>::print(ostream& out){
  DEBUG2("Normal_by_stdev_vector_prior::print");
  out << "normal with means " << mu << "std.devs " << stdev << ":\n";
  Vector_prior<DVM>::print(out);
}

template<CDVM>
Normal_by_stdev_vector_prior<DVM>::Normal_by_stdev_vector_prior(const dvector& _lower_bounds,
                                              const dvector& _upper_bounds,
                                              const dvector& _mu, const dvector& _stdev)
  : Vector_prior<DVM>(_lower_bounds, _upper_bounds)
  , mu(_mu)
  , stdev(_stdev){
  DEBUG2("Normal_by_stdev_vector_prior::Normal_by_stdev_vector_prior");
  this->type = "Normal_by_stdev_vector_prior";
  if(mu.size() != _upper_bounds.size()){
    fatal("The values for 'mu' parameter of the Normal_by_stdev_vector_prior are the wrong length\n");}
  if(stdev.size() != _upper_bounds.size()){
    fatal("The values for 'stdev' parameter of the Normal_by_stdev_vector_prior are the wrong length\n");}
  if (min(stdev) <= 0){
          fatal("Bad parameter for Normal_by_stdev_vector_prior: stdev<=0.");}
}

template<CDVM>
DOUBLE Lognormal_vector_prior<DVM>::prior(const VECTOR& p){
  DEBUG2("Lognormal_vector_prior::prior");
  DOUBLE result = 0;
  if (min(elem_prod(cv,mu)) <= 0){
          fatal("Bad parameter for Lognormal_vector_prior: cv<=0 or mu<=0.");}
  if (min(p)<=0){
          fatal("You have used a lognormal_vector_prior on a nonpositive parameter, this is not allowed.");}
  for (int i=1; i<=mu.size(); i++){
    // updated to correct error in definition of c.v.
    // result += log(p[i]) + 0.5 * pow(log(p[i]/mu[i])/(cv[i]*mu[i]) + cv[i]*mu[i]/2, 2);}
    result += log(p[i]) + 0.5 * pow(log(p[i]/mu[i])/sqrt(log(1+cv[i]*cv[i])) + (sqrt(log(1+cv[i]*cv[i])))*0.5, 2);}
  return result;
}

template<CDVM>
void Lognormal_vector_prior<DVM>::print(ostream& out){
  DEBUG2("Lognormal_vector_prior::print");
  out << "lognormal with means " << mu << "c.v.s " << cv << ":\n";
  Vector_prior<DVM>::print(out);
}

template<CDVM>
Lognormal_vector_prior<DVM>::Lognormal_vector_prior(const dvector& _lower_bounds,
                                                    const dvector& _upper_bounds,
                                                    const dvector& _mu, const dvector& _cv)
  : Vector_prior<DVM>(_lower_bounds, _upper_bounds)
  , mu(_mu)
  , cv(_cv){
  DEBUG2("Lognormal_vector_prior::Lognormal_vector_prior");
  this->type = "Lognormal_vector_prior";
  if(mu.size() != _upper_bounds.size()){
    fatal("The values for 'mu' parameter of the Lognormal_vector_prior are the wrong length\n");}
  if(cv.size() != _upper_bounds.size()){
    fatal("The values for 'cv' parameter of the Lognormal_vector_prior are the wrong length\n");}
}

template<CDVM>
DOUBLE Normal_log_vector_prior<DVM>::prior(const VECTOR& p){
  DEBUG2("Normal_log_vector_prior::prior");
  DOUBLE result = 0;
  if (min(s)<=0){
          fatal("Bad parameter for Normal_log_vector_prior: s<=0.");}
  if (min(p)<=0){
          fatal("You have used a normal_log_vector_prior on a nonpositive parameter, this is not allowed.");}
  for (int i=1; i<=m.size(); i++){
    result += log(p[i]) + 0.5 * ((log(p[i]) - m[i]) / s[i]) * ((log(p[i]) - m[i]) / s[i]);}
  return result;
}

template<CDVM>
void Normal_log_vector_prior<DVM>::print(ostream& out){
  DEBUG2("Normal_log_vector_prior::print");
  out << "normal-log, with means of log(p) " << m << "std.devs of log(p) " << s << ":\n";
  Vector_prior<DVM>::print(out);
}

template<CDVM>
Normal_log_vector_prior<DVM>::Normal_log_vector_prior(const dvector& _lower_bounds,
                                                      const dvector& _upper_bounds,
                                                      const dvector& _m, const dvector& _s)
  : Vector_prior<DVM>(_lower_bounds, _upper_bounds)
  , m(_m)
  , s(_s){
  DEBUG2("Normal_log_vector_prior::Normal_log_vector_prior");
  this->type = "Normal_log_vector_prior";
  if(m.size() != _upper_bounds.size()){
    fatal("The values for 'm' parameter of the Normal_log_vector_prior are the wrong length\n");}
  if(s.size() != _upper_bounds.size()){
    fatal("The values for 's' parameter of the Normal_log_vector_prior are the wrong length\n");}
}

template<CDVM>
DOUBLE Beta_vector_prior<DVM>::prior(const VECTOR& p){
  DEBUG2("Beta_vector_prior::prior");
  DOUBLE result = 0;
  for (int i=1; i<=mu.size(); i++){
    result += (1-m[i]) * log(p[i]-Abound[i]) + (1-n[i]) * log(Bbound[i]-p[i]);}
  return result;
}

template<CDVM>
void Beta_vector_prior<DVM>::print(ostream& out){
  DEBUG2("Beta_vector_prior::print");
  out << "beta with mean " << mu << ", st.dev. " << stdev << ", and range from A = "
      << Abound << " to B = " << Bbound << " : ";
  Vector_prior<DVM>::print(out);
}

template<CDVM>
Beta_vector_prior<DVM>::Beta_vector_prior(const dvector& _lower_bounds, const dvector& _upper_bounds,
                                          const dvector& _mu, const dvector& _stdev, const dvector& _Abound,
                                          const dvector& _Bbound)
  : Vector_prior<DVM>(_lower_bounds, _upper_bounds)
  , mu(_mu)
  , stdev(_stdev)
  , Abound(_Abound)
  , Bbound(_Bbound)
  , m(1,_mu.size())
  , n(1,_mu.size())
  , nu(1,_mu.size())
  , t(1,_mu.size()){
  DEBUG2("Beta_vector_prior::Beta_vector_prior");
  this->type = "Beta_vector_prior";
  if(mu.size() != _upper_bounds.size()){
    fatal("The values for 'mu' parameter of the Beta_vector_prior are the wrong length\n");}
  if(stdev.size() != _upper_bounds.size()){
    fatal("The values for 'stdev' parameter of the Beta_vector_prior are the wrong length\n");}
  for (int i=1; i<=mu.size(); i++){
    if (_lower_bounds[i] < _Abound[i] || _upper_bounds[i] > _Bbound[i]){
      fatal("Bad bounds on Beta prior: " + dtos(this->lower_bounds[i]) + ", " + dtos(this->upper_bounds[i]));}
    if (_Abound[i] >= _Bbound[i]){
      fatal("Bad range parameters on Beta prior: A (" + dtos(Abound[i]) + ") must be less than B (" + dtos(Bbound[i]) + ").");}
    nu[i] = (mu[i] - Abound[i]) / (Bbound[i] - Abound[i]);
    t[i] = (((mu[i] - Abound[i]) * (Bbound[i] - mu[i])) / (stdev[i] * stdev[i])) - 1;
    if(t[i] <= 0){
      fatal("Bad standard deviation on Beta prior: stdev of " + dtos(stdev[i]) + " is too large.");}
    m[i] = t[i] * nu[i];
    n[i] = t[i] * (1 - nu[i]);
  }
}

template<CDVM>
DOUBLE Normal_AR_prior<DVM>::prior(const VECTOR& p){
  DEBUG2("Normal_AR_prior::prior");
  double n = p.size();
  if (sigma<=0 || rho>=0.99){
          fatal("Bad parameter for Normal_AR_prior: sigma<=0 or rho>=0.99.");}
  if (min(p)<=0){
          fatal("You have used a normal_AR_prior on a nonpositive parameter, this is not allowed.");}
  DOUBLE result = (p[1]-mu)*(p[1]-mu)/(2*sigma*sigma);
  for (int i=2; i<=n; i++){
//  result += pow(p[i] - rho*p[i-1] - mu*(1-rho), 2.0) / (2*sigma*sigma*(1-rho)*(1-rho));}
//  corrected C. Francis, October 2002
    result += pow(p[i] - rho*p[i-1] - mu*(1-rho), 2) / (2*sigma*sigma*(1-(rho*rho)));}
  result += n*log(sigma);
  result += 0.5*(n-1)*log(1-rho*rho);
  return result;
}

template<CDVM>
void Normal_AR_prior<DVM>::print(ostream& out){
  DEBUG2("Normal_AR_prior::print");
  out << "multivariate normal from a stationary AR(1) process with mean " << mu << " st.dev " << sigma << " rho = " << rho << " :\n";
  Vector_prior<DVM>::print(out);
}

template<CDVM>
Normal_AR_prior<DVM>::Normal_AR_prior(const dvector& _lower_bounds,
                                      const dvector& _upper_bounds,
                                      double _mu, double _sigma, double _rho)
  : Vector_prior<DVM>(_lower_bounds, _upper_bounds){
  DEBUG2("Normal_AR_prior::Normal_AR_prior");
  this->type = "Normal_AR_prior";
  mu = _mu;
  sigma = _sigma;
  rho = _rho;
}

template<CDVM>
DOUBLE Normal_log_AR_prior<DVM>::prior(const VECTOR& p){
  DEBUG2("Normal_log_AR_prior::prior");
  double n = p.size();
  if (s<=0 || r>=0.99){
          fatal("Bad parameter for Normal_log_AR_prior: s<=0 or r>=0.99.");}
  if (min(p)<=0){
          fatal("You have used a normal_log_AR_prior on a nonpositive parameter, this is not allowed.");}
  DOUBLE result = (log(p[1])-m)*(log(p[1])-m)/(2*s*s);
  for (int i=2; i<=n; i++){
//  result += pow(log(p[i]) - r*log(p[i-1]) - m*(1-r), 2.0) / (2*s*s*(1-r)*(1-r));}
//  corrected C. Francis, October 2002
    result += pow(log(p[i]) - r*log(p[i-1]) - m*(1-r), 2) / (2*s*s*(1-(r*r)));}
  result += n*log(s);
  result += 0.5*(n-1)*log(1-r*r);
  result += sum(p);
  return result;
}

template<CDVM>
void Normal_log_AR_prior<DVM>::print(ostream& out){
  DEBUG2("Normal_log_AR_prior::print");
  out << "multivariate normal-log, where log(p) forms a stationary AR(1) process with mean " << m << " st.dev " << s << " r = " << r << " :\n";
  Vector_prior<DVM>::print(out);
}

template<CDVM>
Normal_log_AR_prior<DVM>::Normal_log_AR_prior(const dvector& _lower_bounds,
                                              const dvector& _upper_bounds,
                                              double _m, double _s, double _r)
  : Vector_prior<DVM>(_lower_bounds, _upper_bounds){
  DEBUG2("Normal_log_AR_prior::Normal_log_AR_prior");
  this->type = "Normal_log_AR_prior";
  m = _m;
  s = _s;
  r = _r;
}

template<CDVM>
DOUBLE Normal_log_mean1_AR_prior<DVM>::prior(const VECTOR& p){
  DEBUG2("Normal_log_mean1_AR_prior::prior");
  double n = p.size();
  DOUBLE result = (log(p[1])-m)*(log(p[1])-m)/(2*s*s);
  if (s<=0 || r>=0.99){
          fatal("Bad parameter for Normal_log_mean1_AR_prior: s<=0 or r>=0.99.");}
  if (min(p)<=0){
          fatal("You have used a normal_log_mean1_AR_prior on a nonpositive parameter, this is not allowed.");}
  for (int i=2; i<=n; i++){
//  result += pow(log(p[i]) - r*log(p[i-1]) - m*(1-r), 2.0) / (2*s*s*(1-r)*(1-r));}
//  corrected C. Francis, October 2002
    result += pow(log(p[i]) - r*log(p[i-1]) - m*(1-r), 2) / (2*s*s*(1-(r*r)));}
  result += n*log(s);
  result += 0.5*(n-1)*log(1-r*r);
  result += sum(p);
  return result;
}

template<CDVM>
void Normal_log_mean1_AR_prior<DVM>::print(ostream& out){
  DEBUG2("Normal_log_mean1_AR_prior::print");
  out << "multivariate normal-log, where E(p)=1 and log(p) forms a stationary AR(1) process with st.dev " << s << " r = " << r << " :\n";
  Vector_prior<DVM>::print(out);
}

template<CDVM>
Normal_log_mean1_AR_prior<DVM>::Normal_log_mean1_AR_prior(const dvector& _lower_bounds,
                                                          const dvector& _upper_bounds,
                                                          double _s, double _r)
  : Vector_prior<DVM>(_lower_bounds, _upper_bounds){
  DEBUG2("Normal_log_mean1_AR_prior::Normal_log_mean1_AR_prior");
  this->type = "Normal_log_mean1_AR_prior";
  s = _s;
  r = _r;
  m = -0.5*s*s;
}

//############################## ENDD OF PRIORS.cpp ##############################

// Create particular instantiations of the template
template class Vector_prior<double, dvector, dmatrix>;
template class Uniform_vector_prior<double, dvector, dmatrix>;
template class Uniform_log_vector_prior<double, dvector, dmatrix>;
template class Normal_vector_prior<double, dvector, dmatrix>;
template class Normal_by_stdev_vector_prior<double, dvector, dmatrix>;
template class Lognormal_vector_prior<double, dvector, dmatrix>;
template class Normal_log_vector_prior<double, dvector, dmatrix>;
template class Beta_vector_prior<double, dvector, dmatrix>;
template class Normal_AR_prior<double, dvector, dmatrix>;
template class Normal_log_AR_prior<double, dvector, dmatrix>;
template class Normal_log_mean1_AR_prior<double, dvector, dmatrix>;
template class Scalar_prior<double, dvector, dmatrix>;
template class Uniform_prior<double, dvector, dmatrix>;
template class Uniform_log_prior<double, dvector, dmatrix>;
template class Normal_prior<double, dvector, dmatrix>;
template class Normal_by_stdev_prior<double, dvector, dmatrix>;
template class Lognormal_prior<double, dvector, dmatrix>;
template class Beta_prior<double, dvector, dmatrix>;
template class Normal_log_prior<double, dvector, dmatrix>;

template class Vector_prior<dvariable, dvv, dvm>;
template class Uniform_vector_prior<dvariable, dvv, dvm>;
template class Uniform_log_vector_prior<dvariable, dvv, dvm>;
template class Normal_vector_prior<dvariable, dvv, dvm>;
template class Normal_by_stdev_vector_prior<dvariable, dvv, dvm>;
template class Lognormal_vector_prior<dvariable, dvv, dvm>;
template class Normal_log_vector_prior<dvariable, dvv, dvm>;
template class Beta_vector_prior<dvariable, dvv, dvm>;
template class Normal_AR_prior<dvariable, dvv, dvm>;
template class Normal_log_AR_prior<dvariable, dvv, dvm>;
template class Normal_log_mean1_AR_prior<dvariable, dvv, dvm>;
template class Scalar_prior<dvariable, dvv, dvm>;
template class Uniform_prior<dvariable, dvv, dvm>;
template class Uniform_log_prior<dvariable, dvv, dvm>;
template class Normal_prior<dvariable, dvv, dvm>;
template class Normal_by_stdev_prior<dvariable, dvv, dvm>;
template class Lognormal_prior<dvariable, dvv, dvm>;
template class Beta_prior<dvariable, dvv, dvm>;
template class Normal_log_prior<dvariable, dvv, dvm>;



