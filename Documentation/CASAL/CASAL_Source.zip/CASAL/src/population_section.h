// const char* time_stamp = "$Date: 2010-11-25 17:02:26 +1300 (Thu, 25 Nov 2010) $\n";
// const char* population_section_id = "$Id: population_section.h 3649 2010-11-25 04:02:26Z fud $\n";

#if !defined(POPULATION_SECTION)
#define POPULATION_SECTION

//############################## POPULATION SECTION ##############################
#include <vector>
#include <iostream>
#include <string>
#include "development.h"
#include "yields.h"
#include "parameter_set.h"

// Forward declarations
template<CDVM> class Mean_weight;
template<CDVM> class Selectivity;
template<CDVM> class Basic_nonpartition_maturity;
template<CDVM> class Basic_initialization_data;
template<CDVM> class Basic_annual_cycle;
template<CDVM> class Basic_ageing;
template<CDVM> class Basic_recruitment;
template<CDVM> class Growth;
template<CDVM> class Mortality;
template<CDVM> class Migration;
template<CDVM> class Basic_partition_maturity;
template<CDVM> class Harvest_strategy;
template<CDVM> class Catch_at_request;
template<CDVM> class Abundance_request;
template<CDVM> class Numbers_at_request;
template<CDVM> class Basic_results;
template<CDVM> class Basic_requests;
template<CDVM> class DiseaseMortality;
template<CDVM> class TaggingFish;
template<CDVM> class TagLoss;
class Print_requests;

/////////////////////////////////////////////////////////////////////////////////////
template<CDVM>
class Partition{
  // The Partition class is the main element of the state object in the basic model.
  // It comprises the partition matrix and various members which operate on the
  // partition or describe its structure.
  //
  // The columns of the partition are age/size classes, indexed from col_min to col_max.
  // The rows are combinations of characters, indexed from 1 to n_rows.
  // Each row has a combination of 0 or more characters:
  // each character has a name ("sex", "maturity", "area", "stock", "tag", "growthpath"...?)
  // and a number (0, 1, 2...).
  // These are stored in char_names and char_nos respectively,
  // and can be accessed by character_names() and character_numbers().
  // The character values for each row are stored in all_values, and can also be
  // accessed via character_value().
  // Other information members include:
  // - character_lengths and character_labels, which say what values each character
  //   takes and what the values are called. Values are always integers starting from 1,
  //   and labels are always strings, so for example a "sex" character might have
  //   values 1 and 2 labelled "male" and "female".
  // - rows_with(), which tells you which rows have a given value for a given character
  // - corresponding_rows() and corresponding_row(), which, given a set of rows, a character
  //   and a value, tells you the matching rows which have the same character values except with
  //   the specified value for the specified character (E.g.: Which row is equivalent to this
  //   row in every way, except it is for mature fish instead of immature?)
  // - all_values_map, which tells you which row has a specific set of character values
  // Members which carry out calculations using the partition matrix include
  // - average_partition, which is used to back-calculate partitions during a mortality episode,
  //   either as a weighted average, or a weighted geometric average, of the current
  //   partition and a copy of the partition saved before the mortality was removed.
  // - initialize_partition, which is used to empty the partition.
  //
  // Currently these functions have a lot of error checking; you may want to
  // #define it out for production code, if it slows down the program significantly.
  //
  // class Partition currently has only one constructor, which is for use by the basic model,
  // called while constructing the basic state.
public:
  std::vector<VECTOR> partition;
  // The partition matrix.
  // Access the [i,j]th element by 'partition[i][j]'.
  // Actually the partition is stored as a vector of Betadiff VECTORs
  // rather than a Betadiff MATRIX - it's more convenient because it means it's not
  // necessary to know the number of rows in order to construct it.
  void initialize_partition();
  void move(const DOUBLE& proportion,int source,int sink=0);
  void move(VECTOR& proportions,int source,int sink=0);
  int n_rows, n_cols, col_min, col_max;
  std::vector<int> col_names;
  int n_characters;
  std::string character_names(int number);
  int character_numbers(const std::string& name);
  std::vector<int> character_lengths;
  // character_lengths[k] is the number of (consecutive integer) values taken
  // by character k (k=0,1,...,n_characters-1). E.g., if sex_char is the number of character 'sex',
  // then probably character_lengths[sex_char]==2.
  std::vector<std::vector<std::string> > character_labels;
  // character_labels[k] is a vector of strings which are the names of the values
  // taken by character k. E.g., if sex_char is the number of character 'sex', then probably
  // character_labels[sex_char][1]=="male", character_labels[sex_char][2]=="female".
  std::vector<std::map<std::string,int> > character_label_values;
  // character_label_values[k] is a map from the names of the values taken by character k
  // to their numeric values. E.g., if sex_char is the number of character 'sex', then probably
  // character_label_values[sex_char]["male"]==1, character_label_values[sex_char]["female"]==2.
  // The inverse of character_labels.
  int character_value(int row, int character);
  dvector rows_with(int character, int value);
  dvector corresponding_rows(const dvector& rows,int character,int value);
  int corresponding_row(int row,int character,int value);
  std::vector<std::vector<int> > all_values;
  // all_values[i][k] is the value of character k for row i
  // The inverse of all_values_map.
  std::map<std::vector<int>,int> all_values_map;
  // all_values_map[values] is the number of the row which has character values 'values'.
  // The inverse of all_values.
  void average_partition(std::vector<VECTOR>& during, const std::vector<VECTOR>& before,
                         double proportion, const std::string& method);
  void print_matrix(ostream& out, const MATRIX& vec);
  void print_matrix(ostream& out, const std::vector<VECTOR>& vec);
  void print_vector(ostream& out, const VECTOR& vec, const std::string& column_label);
  void print_vector(ostream& out, const std::vector<DOUBLE>& vec, const std::string& column_label);
  void print_several_vectors(ostream& out, const std::vector<VECTOR>& vecs, const std::vector<std::string>& column_labels);
  void print(ostream& out = cout);
  Partition(Parameter_set<DVM>& p, const std::string& model_type);
private:
  std::map<int,std::string> char_names;
  std::map<std::string,int> char_nos;
  std::vector<dvector> char_value;
  std::vector<std::vector<dvector> > rows_by_char;
  std::vector<std::vector<dvector> > corresponding_rows_by_char;
  std::vector<std::string> exclusions_names1;
  std::vector<std::string> exclusions_labels1;
  std::vector<std::string> exclusions_names2;
  std::vector<std::string> exclusions_labels2;
  // The way the exclusions work is that each combination of character values for which
  // (the character named exclusions_char1[i] takes the value exclusions_val1[i] &&
  //  the character named exclusions_char2[i] takes the value exclusions_val2[i])
  // is not allowed.
  // So, if no female fish are allowed in area home,
  // then a set of values are "sex","female","area","home" respectively.
  // The character numbers and values are stored as numbers in the following:
  std::vector<int> exclusions_nums1, exclusions_vals1, exclusions_nums2, exclusions_vals2;
};

template<CDVM>
class Basic_state : public Partition<DVM>{
  // The Basic_state is one of the key components of the Basic_population_section.
  // It inherits from class Partition, which contains the partition matrix
  // and information and manipulation members relating to it.
  // It also contains the SSBs object - the other 'data' component of the state object -
  // and various information members.
  //
  // -abundance() is used to calculate the current biomass or total numbers, in rows with
  // a specified set of character values, optionally with an ogive applied
  // to every row, optionally on a specified partition matrix (typically
  // a back-calculated mid-mortality partition).
  // Similarly mature_abundance().
  //
  // -numbers_at() is used to calculate the current numbers-at-size or at-age,
  // optionally by sex, in rows with a specified set of character values, optionally
  // with an ogive applied to every row, optionally on a specified partition matrix
  // (typically a back-calculated mid-mortality partition). The return value is a matrix,
  // with 2 rows if sexed or 1 else.
  // For numbers-at-size in an age-based model, use numbers_at_size_in_agebased(),
  // which also needs to be passed size class minimums, and told whether the last
  // size class is a plus_group.
  // Similarly mature_numbers_at() and mature_numbers_at_size_in_agebased().
  //
  // Basic_population_section::set_initial_state() is used to initialize the Basic_state.
  //
  // Note - make sure that the default copy constructor and assignment work properly for
  // class Basic_state. If, for example, you add any pointer members, you will
  // need to write an explicit copy constructor and assignment.
public:
  MATRIX SSBs;
  // SSBs[stock][year] stores the SSB in 'year' for 'stock'
  //  ('stock' = 1, 2, 3..., or always 1 in a single-stock model)
  int size_based;
  // ==1 if the model is size_based, 0 if age_based.
  int min_age;
  // In an age-based model, the age of the first age class (unused in a size-based model)
  int plus_group;
  // ==1 if the last age/size class is a plus group, 0 if not.
  dvector class_mins;
  // class_mins[i] is the minimum size of the ith size class. If plus_group==0,
  // there is a class_mins[n_cols+1] which is the maximum size of the last size class.
  double plus_group_size;
  // The assumed size of fish in the plus group when calculating LFs and mean-weight-at-size.
  int sex_partition;
  // ==1 if sex is in the partition, 0 else.
  int mature_partition;
  // ==1 if maturity is in the partition, 0 else.
  int n_growthpaths;
  // The number of growthpaths in the partition, or 1 if growthpath is not in the partition.
  int n_areas;
  // The number of areas in the partition, or 1 if area is not in the partition.
  std::map<std::string,int> area_numbers;
  // area_numbers["name"] = the number of area "name", from 1 to n_areas
  std::vector<std::string> area_names;
  // area_names[i] = the name of area i, from 1 to n_areas
  int n_stocks;
  // The number of stocks in the partition, or 1 if stock is not in the partition.
  std::map<std::string,int> stock_numbers;
  // stock_numbers["name"] = the number of stock "name", from 1 to n_stocks
  std::vector<std::string> stock_names;
  // stock_names[i] = the name of stock i, from 1 to n_stocks
  int n_tag_states;
  // The number of tag states a fish can have - n_tags, +1 for 'no tag' - or 1 if tag is not in the partition
  std::map<std::string,int> tag_numbers;
  // tag_numbers["name"] = the number of tag "name", from 1 to n_tags+1 (1 is returned by tag_numbers["no_tag"])
  std::vector<std::string> tag_names;
  // tag_names[i] = the name of tag state i, from 1 (always "no_tag") to n_tags+1
  DOUBLE abundance(const std::string& type, int year, int step,
                   Mean_weight<DVM>* mean_weight,
                   const std::vector<int>& character_nums = std::vector<int>(),
                   const std::vector<int>& character_vals = std::vector<int>(),
                   const std::vector<VECTOR>& _partition = std::vector<VECTOR>(),
                   Selectivity<DVM> *selectivity = 0);
  DOUBLE mature_abundance(const std::string& type, int year, int step,
                          Mean_weight<DVM>* mean_weight,
                          Basic_nonpartition_maturity<DVM>* maturity_props,
                          const std::vector<int>& character_nums = std::vector<int>(),
                          const std::vector<int>& character_vals = std::vector<int>(),
                          const std::vector<VECTOR>& _partition = std::vector<VECTOR>(),
                          Selectivity<DVM> *selectivity = 0);
  MATRIX numbers_at(int sexed, int year, int step,
                    const std::vector<int>& character_nums = std::vector<int>(),
                    const std::vector<int>& character_vals = std::vector<int>(),
                    const std::vector<VECTOR>& _partition = std::vector<VECTOR>(),
                    Selectivity<DVM> *selectivity = 0, int just_the_ogive=0);
  MATRIX mature_numbers_at(int sexed, int year, int step,
                    Basic_nonpartition_maturity<DVM>* maturity_props,
                    const std::vector<int>& character_nums = std::vector<int>(),
                    const std::vector<int>& character_vals = std::vector<int>(),
                    const std::vector<VECTOR>& _partition = std::vector<VECTOR>(),
                    Selectivity<DVM> *selectivity = 0, int just_the_ogive=0);
  MATRIX numbers_at_size_in_agebased(int sexed, int year, int step, dvector& class_mins, int plus_group,
                                     Size_at_age<DVM>* size_at_age,
                                     const std::vector<int>& character_nums = std::vector<int>(),
                                     const std::vector<int>& character_vals = std::vector<int>(),
                                     const std::vector<VECTOR>& _partition = std::vector<VECTOR>(),
                                     Selectivity<DVM> *selectivity = 0);
  MATRIX mature_numbers_at_size_in_agebased(int sexed, int year, int step,
                                     dvector& class_mins, int plus_group,
                                     Basic_nonpartition_maturity<DVM>* maturity_props,
                                     Size_at_age<DVM>* size_at_age,
                                     const std::vector<int>& character_nums = std::vector<int>(),
                                     const std::vector<int>& character_vals = std::vector<int>(),
                                     const std::vector<VECTOR>& _partition = std::vector<VECTOR>(),
                                     Selectivity<DVM> *selectivity = 0);
  int valid_area(std::string area);
  int valid_stock(std::string stock);
  int valid_tag(std::string tag);
  void print(ostream& out = cout);
  Basic_state(Parameter_set<DVM>& p);
  ~Basic_state();
};

template<CDVM>
class Basic_requests{
  // This class tells the Population_model what results it must put into its Basic_results
  // member, and also what outputs it must print during the run.
  // There are two categories of entries in the Basic_requests:
  // -output switches, like 'B0', which say whether the corresponding result should be recorded,
  // -maps of request objects, like 'catch_at', containing one object per request of that type,
  //  giving its details. The index of the map is the label of the data.
   // See also the set_requests function, which fills in the entries of the requests object.
public:
  int actual_catches, actual_catches_by_stock, actual_catches_by_area,fishing_pressure, removals, discards;
  int B0, Binitial, Bmean, R0, Rinitial, Rmean;
  int recruitments, YCS, true_YCS, Ts, migration_annual_variation;
  int SSBs;
  int numbers_tagged;
  int disease_biomass_loss;


  // ==1 if these results are to be recorded

  std::map<std::string, Catch_at_request<DVM> > catch_at;
  // includes [sexed] catch-at-age, catch-at-size
  std::map<std::string, Abundance_request<DVM> > abundance;
  // includes [selected] numbers / biomasses
  std::map<std::string, Numbers_at_request<DVM> > numbers_at;
  // includes [sexed] [selected] numbers-at-age, numbers-at-size
  std::vector<std::string> catch_at_labels, abundance_labels, numbers_at_labels;
  // the indices of the above maps

  void print(Basic_state<DVM>& s, ostream& out = cout);
  Basic_requests(Parameter_set<DVM>& p);
  ~Basic_requests();
};

template<CDVM>
class Basic_population_section{
  // This class is the population section for the basic model.
  // There are four main data components - the state object, the annual cycle, the requests
  // for outputs, and the output results.
  //
  // set_requests function() is to convey parameters into the 'requests' and 'annual_cycle'
  //   members.
  //
  // deterministic_equilibrium() is to find the equilibrium state under a given Harvest_strategy
  //   using constant recruitment.
  //
  // stochastic_simulation() runs the model over a simulation period under a given Harvest_strategy
  //   using random recruitment.
public:
  Basic_state<DVM> state;
  Basic_annual_cycle<DVM> *annual_cycle;
  Basic_requests<DVM> requests;
  Basic_results<DVM> results;
  void set_requests(Parameter_set<DVM>& p);
  // Set the requests for results.
  void set_annual_cycle(Parameter_set<DVM>& p);
  // Set the processes and calculations necessary in the annual cycle.
  void set_initial_state();
  // Set the state object to whatever constitutes the initial state.
  // Any data necessary to do this can be stored in the components of annual_cycle and/or state.
  void run_model(int to=0);
  // OPTIM: Changed DOUBLE& harvest_rate to double& harvest_rate
  int deterministic_equilibrium(Harvest_strategy<DVM> *harvest_strategy,
                                const double& harvest_rate);
  // OPTIM: Changed DOUBLE& harvest_rate to double& harvest_rate
  void stochastic_simulation(Harvest_strategy<DVM> *harvest_strategy,
                             const double& harvest_rate, long RNG_seed);
  Print_requests* print_requests;
  void print(ostream& out = cout);
  Basic_population_section(Parameter_set<DVM>& p, Print_requests *_print_requests);
  ~Basic_population_section();
};

template<CDVM>
class Basic_annual_cycle{
  // The Basic_annual_cycle is one of the key components of the Basic_population_section.
  //
  // Its key member is do_year(), which carries out one annual cycle.
  //
  // Then there are the time sequence members,
  //  notably 'initial', 'current', and 'final'  (by default the model is run from the start
  //  of year initial to the end of year current; if projections are being done, they
  //  extend up to the end of year 'final')
  //  'time_steps' and the times of individual events, for example 'recruitment_time',
  //  the numbers of instances of each type of process, for example 'n_fisheries',
  //  information about how the SSB is recorded, for example 'spawning_time',
  //  and a few general informations, for examples 'baranov' and 'midmortality_method'
  //
  // And the processes and calculations, which are stored as pointers to the base class,
  //  and are typically called using ->apply(), ->get_row, ->print()...
  //  Some processes have multiple instances per annual cycle, and are stored as
  //  vectors of pointers to base class. For example, there is one mortality object
  //  per time step, and the Mortality member contains a pointer to each.
  //
  // And some objects used as temporary work areas in do_year(),
  //
  // And finally, there are a handful of information members which are duplicated in some
  //  form in the individual processes, and are only included here for printing purposes.
  //  Could probably take these out at a later stage of development.
  //
  // Make sure that all components of Basic_annual_cycle which are created by 'new'
  // get 'delete' in the Basic_annual_cycle destructor! Otherwise there will be memory
  // leaks causing serious problems.
  //
  // Added the member function randomise(), which randomises the recruitment YCS and T's
  //  for a projection (and, if any other components of the model were randomised when projecting,
  //  this could be done here).
public:
  void do_year(Basic_state<DVM>& s, int print_state_every_step, const std::string& type, int year = -1,
               Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0,
               Harvest_strategy<DVM>* harvest_strategy = 0,
               double harvest_rate = 0, long RNG_seed = -1);
  int initial, current, final;
  int time_steps;
  int ageing_time, recruitment_time, disease_time;
  dvector *growth_times, *migration_times, *maturation_times;
  // These specify the number of time steps and the time step in which each process occurs.
  int baranov;
  // ==1 if catch is removed using the Baranov equation
  dvector *growth_props;
  // growth_props[i] is the proportion of the year's growth which has occurred by time period i.
  int n_growths, n_fisheries, n_maturations, n_migrations;
  std::vector<int> recruitment_areas;
  dvector *M_props;
  dvector *fishery_times;
  dvector *fishery_areas;
  std::vector<std::string> fishery_names;
  int spawning_time, spawning_use_total_B;
  int semelparous_time;
  DOUBLE semelparous_mortality;
  //dvector *spawning_areas;
  std::vector<std::vector<int> > spawning_areas;	//To allow multiple spawning areas for a stock
  int spawning_all_areas;
  VECTOR *spawning_ps;
  double spawning_part_mort;
  std::string spawning_sex;
  // These specify the time step and area in which SSB is recorded, whether (if maturity is
  // not in the partition) the SSB is based on the total biomass or on the mature biomass,
  // if SSB is for both sexes, males only, or females only,
  // how far through the mortality episode the SSB is recorded
  // (typically halfway - spawning_part_mort = 0.5),
  // and the proportion applied to mid-season (mature or total) biomass to get SSB.
  std::string midmortality_method;
  // Can be "weighted_sum" or "weighted_product"; indicates how the partition
  // partway through a mortality episode is back-calculated.
  dvector *migrate_from;
  dvector *migrate_to;
  std::vector<std::string> migration_names;
  // BEGIN PROCESS AND CALCULATION OBJECTS
  Basic_ageing<DVM>* ageing;
  std::vector<Basic_recruitment<DVM>*> recruitment;
  // *(recruitment[i]) is recruitment for stock i (i = 1, 2...)
  std::vector<Growth<DVM>*> growth;
  // *(growth[i]) is growth process i (i = 1, 2...).
  std::vector<Mortality<DVM>*> mortality;
  // *(mortality[i]) is the mortality occurring in time step i.
  std::vector<Migration<DVM>*> migration;
  // *(migration[i]) is migration process i (i = 1, 2...).
  std::vector<Basic_partition_maturity<DVM>*> maturation;
  // *(maturation[i]) is maturation process i (i = 1, 2...).
  std::vector<TaggingFish<DVM>*> tagging;
  // *(tagging[i]) is tagging episode i (i = 1, 2...)
  // a single tagging episode refers to a single tag type in a single time step of a single year
  std::vector<TagLoss<DVM>*> tag_loss;
  // *(tag_loss[i]) is for tag i (i = 1, 2... n_tags)
  std::vector<std::string> selectivity_names;
  std::map<std::string,Selectivity<DVM>*> selectivities;
  Size_at_age<DVM>* size_at_age;
  Mean_weight<DVM>* mean_weight;
  Basic_nonpartition_maturity<DVM>* maturity_props;
  std::vector<Basic_initialization_data<DVM>*> initialization;
  void multiply_initial_abundance(int stock, double multiplier);
  DiseaseMortality<DVM>* disease;
 // END PROCESS AND CALCULATION OBJECTS
  std::vector<VECTOR> premortality_partition;
  std::vector<VECTOR> partmortality_partition;
  DOUBLE biomass;
  VECTOR *SSBs;
  //std::vector<std::vector<int> > spawning_chars;
  //std::vector<std::vector<int> > spawning_vals;
  std::vector<std::vector<std::vector<int> > >spawning_chars; //by stock and area
  std::vector<std::vector<std::vector<int> > >spawning_vals;  //by stock and area

  DOUBLE absYCS,YCS,T,CR;
  int y_enter;
  dvector *ones;
  int catches_calculated;
  std::map<std::string,double> catches_this_year;
  // These last 15 members are used to hold working in do_year().
  void randomise(long seed);
  int valid_step(int step);
  int valid_fishery(std::string fishery);
  int valid_selectivity(std::string selectivity);
  int valid_migration(std::string migration);
  // OPTIM: changed dvector& to dvector. Compiler didn't like the reference.
  // void print(Basic_state<DVM>& s, ostream& out=cout,int every_mean_size = 0,
  //            dvector& print_sizebased_ogives_at = dvector("{-1}"));
  void print(Basic_state<DVM>& s, ostream& out=cout,int every_mean_size = 0,
             dvector print_sizebased_ogives_at = dvector("{-1}"));
  Basic_annual_cycle(Parameter_set<DVM>& p, Basic_state<DVM>& s);
  ~Basic_annual_cycle();
};

template<CDVM>
class Catch_at_request{
  // 'Catch_at' is short for 'catch-at-age or catch-at-size'.
  // "catch at age or size, optionally by sex, for specified fisheries in
  // specified years (if catch at size in an age-based model, the size classes
  // may be specified separately for different fisheries)"
private:
  std::string command;
public:
  dvector years;
  int at_size;         // 1 = at-size, 0 = at-age
  int sexed;           // 1 = sexed, 0 = unsexed (the result is a matrix with 2 or 1 rows respectively)
  std::vector<std::string> fishery_names;
                       // one request can include 2 or more fisheries; the data are pooled
  std::vector<int> fisheries;
  dvector class_mins;  // used for numbers-at-size in age-based model
  int plus_group;      // ditto
  void print(Basic_state<DVM>& s, ostream& out = cout);
  Catch_at_request(Parameter_set<DVM>& p, Basic_state<DVM>& s, const std::string& label);
  Catch_at_request(){}
};

template<CDVM>
class Abundance_request{
  // 'abundance' covers a whole bunch of related quantities that can be requested.
  // " biomasses or numbers of fish, optionally with a selectivity ogive applied,
  //   for one area or all areas pooled, for one stock or all stocks, for mature fish only
  //   or all fish, in specified years and time steps, after a specified proportion of the
  //   mortality in the time step "
private:
  std::string command;
public:
  DOUBLE get_result(Basic_state<DVM>& s, Basic_annual_cycle<DVM>& a, int year, int before_mortality);
  dvector years;
  int step;
  int area;                     // 0 = all areas
  int stock;                    // 0 = all stocks
  int mature_only;              // 1 = mature fish only, 0 = all fish
  double proportion_mortality;  // observation is after this proportion of the mortality
  int biomass;                  // 1 = biomass, 0 = numbers
  std::string selectivity_name; // the name of the ogive in the common block, or "none"
  void print(Basic_state<DVM>& s, ostream& out = cout);
  Abundance_request(Parameter_set<DVM>& p, Basic_state<DVM>& s, const std::string& label);
  Abundance_request(){}
};

template<CDVM>
class Numbers_at_request{
  // 'Numbers_at' is short for 'numbers-at-size' or 'numbers-at-age'.
  // Note the difference from 'Catch-at'.
  // "numbers at age or size, optionally by sex, optionally with a selectivity ogive applied, optionally only fish with a particular tag,
  // in specified areas, years, and time steps (after a specified proportion of the mortality
  // in the time step: default half) (or alternatively just before or after a specified migration)"
  // BB has just added the 'just_the_ogive' subcommand which is used for Ogive_at pseudo-observations.
  // "If this subcommand is supplied to Numbers_at_request, it should
  //  (a) work as if there was 1 fish in each column of the partition,
  //  (b) check that the ogive values are the same for each specified row of the partition and error out if not."
private:
  std::string command;
public:
  MATRIX get_result(Basic_state<DVM>& s, Basic_annual_cycle<DVM>& a, int year, int before_mortality);
  dvector years;
  int at_size;                  // 1 = at-size, 0 = at-age
  int step;
  double proportion_mortality;  // observation is after this proportion of the mortality
  std::string migration;        // or, if this != "", it is timed either before or after this migration,
  int before, after;            // as indicated by these parameters,
  std::string tagging_episode;  // or, if this != "", it is timed after this tagging episode (but before tagging mortality is applied).
  int area;
  int stock;                    // 0 = all stocks
  int sexed;
  int tag;                      // 0 = any tag status, 1 = no tag, 2,3... specific tags
  int mature_only;              // 1 = mature fish only, 0 = all fish
  std::string selectivity_name; // the name of the ogive in the common block, or "none"
  dvector class_mins;           // used for numbers-at-size in age-based model
  int plus_group;               // ditto
  int just_the_ogive;           // if 1, this is a dummy request, we don't really want the numbers-at, just the ogive values
  void print(Basic_state<DVM>& s, ostream& out = cout);
  Numbers_at_request(Parameter_set<DVM>& p, Basic_state<DVM>& s, const std::string& label);
  Numbers_at_request(){}
};

template<CDVM>
class Basic_results{
  // Contains various containers for the results requested in Basic_requests.
  // Plus empty(), which empties / initializes everything.
public:
  void empty();
  std::map<int,std::map<std::string,DOUBLE> > actual_catches, specified_catches, fishing_pressure, removals, discards;
  // actual_catches[year][fishery_name] gives the actual catch,
  // similarly specified_catches and fishing pressure.
  std::map<int,std::map<std::string,std::map<std::string,DOUBLE> > > actual_catches_by_stock, removals_by_stock, discards_by_stock,actual_catches_by_area, removals_by_area, discards_by_area;
  // actual_catches_by_stock[year][fishery_name][stock] gives the actual catch
  int fishing_pressure_limit_exceeded;
  // Set to 1 if the fishing pressure limit is exceeded during the
  // run_model or run_model_from run.
  std::map<std::string,DOUBLE> numbers_tagged;
  // how many fish tagged in each tagging episode? Key is label of episode.
  std::map<int,DOUBLE> disease_biomass_loss;

  std::map<int,std::map<std::string,DOUBLE> > migration_annual_variation;
  // annual_migration_variation[year][migration_name] gives the migration annual variation,


  VECTOR *B0, *Binitial, *Bmean, *R0, *Rinitial, *Rmean;
  // Fill these in during set_initial_state.
  MATRIX *recruitments;
  // Recruitments as absolute numbers of fish indexed by the year in which they recruit.
  // Row indices are stock numbers, column indices are years.
  // Values are filled in by recruitment::apply().
  MATRIX *YCS;
  // YCS as deviates indexed by the year in which the fish are spawned.
  // Row indices are stock numbers, column indices are years.
  // Values are filled in by recruitment::apply().
  MATRIX *true_YCS;
  // YCS*CR*SR indexed by the year in which the fish are spawned.
  // Row indices are stock numbers, column indices are years.
  // Values are filled in by recruitment::apply().
  MATRIX *Ts;
  // Climate data T indexed by year.
  // Row indices are stock numbers, column indices are years.
  // Values are filled in by recruitment::apply().
  MATRIX *SSBs;
  // Copy out the SSBs from the state object into here.
  // Row indices are stock numbers, column indices are years.
  // Values are filled in by annual_cycle::do_year().
  std::map<std::string,std::map<int,MATRIX> > catch_at;
  // catch_at[label][yr] is the (at-size or at-age) result of requests.catch_at[label] in year yr.
  // It's a matrix, with rows 1 and 2 if the catch_at is sexed or just 1 if not.
  std::map<std::string,std::map<int,DOUBLE> > abundance;
  // abundance[label][yr] is the (numbers or biomass) result of requests.abundance[label] in year yr.
  std::map<std::string,std::map<int,MATRIX> > numbers_at;
  // numbers_at[label][yr] is the (at-size or at-age) result of requests.numbers_at[label] in year yr.
  // It's a matrix, with rows 1 and 2 if the catch_at is sexed or just 1 if not.
  void print(Basic_state<DVM>& s, Basic_requests<DVM>& requests,ostream& out = cout);
  Basic_results(Parameter_set<DVM>& p);
  ~Basic_results();
};

//############################## END OF POPULATION_SECTION.h ##############################
#endif
