// const char* time_stamp = "$Date: 2009-04-03 14:04:04 +1300 (Fri, 03 Apr 2009) $\n";
// const char* yields_cpp_id = "$Id: yields.cpp 3089 2009-04-03 01:04:04Z dunn $\n";

//############################## YIELD CALCULATIONS ##############################
#include "yields.h"

//////////////////////////////////////////////////////////////////////////////////
template<class FUNCTION>
//double maximise_yield(FUNCTION& f, double guess, int print = 1, ostream& out = cout, int max_upper_iter = 40){
double maximise_yield(FUNCTION& f, double guess, int print, ostream& out, int max_upper_iter){//richard
  // A univariate optimiser used in various yield calculations. Returns the x maximising f(x).
  // f should have an operator()(double,int print,ostream& out) which returns the function
  //  value, and prints a trace to 'out' if 'print'==1.
  // The optimiser was originally designed for a non-negative function with a single local maximum
  //  at some positive x. However, I found that some of these yield functions can have multiple small
  //  local maxima, and redesigned it accordingly.
  //
  // If the maximum value of f(x) occurs at the upper end point of the interval over which is
  // being searched (see maximise_yield_between) then the upper end point is increased. However,
  // if f(x) continues to increase with x then this process of increasing the upper end point
  // could continue indefinitely. The parameter max_upper_iter puts an upper bound on the
  // number of the times the upper end point can be increased. It has a default value, and
  // can also be set as a subcommand to @MCY_CAY. If the max_upper_iter value is reached
  // then the maximisation function returns.
  DEBUG0("maximise_yield");
  return maximise_yield_between(f,0,guess*2,1,print,cout, max_upper_iter);
}

template<class FUNCTION>
double maximise_yield_between(FUNCTION& f, double low, double high, int interval_no,
                              int print, ostream& out, int max_upper_iter){
  // Called by maximise_yield()
  // My only recursive function I think!

  double width = (high-low);
  std::vector<double> xs;
  std::vector<double> fs;
  double x;
  for (int i=1; i<=6; i++){
    x = low + (i-1) * width / 5;
    xs.push_back(x);
    fs.push_back(f(x,print,out));
  }
  int highest = pos(fs,max(fs));
  double last_highest_x = xs[highest];
  int max_out = 0;

  while (highest==(fs.size()-1)){
    max_out += 1;
    if (max_out == max_upper_iter + 1){
        cout << "Convergence not reached." << endl;
        cout << "An upper bound for the optimal value was not found after " << max_upper_iter << " attempts." << endl;
        cout << "This is likely to be because the objective function is asymptotic.\n\n";
                return x;
    }
    x += width*0.2;
    xs.push_back(x);
    fs.push_back(f(x,print,out));
    highest = pos(fs,max(fs));
  }
  if (interval_no == 5) return xs[highest];
  else return maximise_yield_between(f,fmax(0,xs[highest]-0.15*width),xs[highest]+0.15*width,interval_no+1,print,cout,max_upper_iter);
}

template<CDVM>
void per_recruit_and_deterministic_MSY(Estimation_section<DVM>& e,
                                       const dvector& free_parameter_values,
                                       Parameter_set<DVM>& o, int is_weightless_model){
  // Calculate per-recruit yield measures - any or all of
  //  - data to plot a YPR curve (YPR vs mortality rate) or an SPR curve (SPR vs mortality rate).
  //  - F0.1, the mortality rate at which the slope of the YPR curve is 0.1 times
  //    its slope at the origin
  //  - Fmax, the mortality rate which maximizes YPR
  //  - Fx%, the mortality rate at which the SPR is x% of its unfished value (Clark 1991).
  // Calculate deterministic MSY and/or data for a SSB vs yield plot.
  //
  // The estimation section should have been created with the _do_yields switch.
  DEBUG0("per_recruit_and_deterministic_MSY");

  /* This has been changed to allow YPR/SPR calculations for multiple stocks
  if (e.population_section->state.n_stocks > 1){
  fatal("Per-recruit and deterministic MSY calculations are not implemented for multiple stocks.");}
  */
  // what kind of mortality rate are we using? instantaneous mortality or exploitation rate?
  int instantaneous_mortality;
  if (e.population_section->annual_cycle->baranov) {
    if(e.population_section->annual_cycle->n_fisheries > 1)
      fatal("If you use the Baranov catch equation, deterministic yields cannot be calcuated if there is more than one fishery");
    instantaneous_mortality = 1;
  } else {
    instantaneous_mortality = 0;
  }
  // If it is an exploitation rate, we need to set up the Constant_exploitation_rate
  //   harvest strategy, and also the Bpre measure of abundance it uses. We also need to send
  //   a request to the Population_section to calculate this Bpre.
  // Or if it is an instantaneous mortality rate, we need to set up the Constant_instantaneous_mortality
  //   harvest strategy.
  Harvest_strategy<double,dvector,dmatrix> *constant_mortality;
  if (!instantaneous_mortality){
    // Find out how Bpre is defined
    int first_fishery_step = (int)min(*(e.population_section->annual_cycle->fishery_times));
    int step = o.get_int("B_pre.step",first_fishery_step);
    double proportion_mortality = o.get_constant("B_pre.proportion_mortality");
    std::string area = o.get_string("B_pre.area","");
    std::string selectivity = o.get_string("B_pre.selectivity");
    int mature_only = o.get_bool("B_pre.mature_only");
    // Send requests for the calculation of Bpre to the Population_section
    e.p.put_int("abundance[Bpre].step",step);
    e.p.put_constant("abundance[Bpre].proportion_mortality",proportion_mortality);
    if (area != "") e.p.put_string("abundance[Bpre].area",area);
    if (selectivity != "") e.p.put_string("abundance[Bpre].ogive",selectivity);
    e.p.put_int("abundance[Bpre].mature_only",mature_only);
    e.p.put_int("abundance[Bpre].biomass",1);
    dvector years(1,1);
    years[1] = 0; // for a deterministic simulation we only use year 0
    e.p.put_constant_vector("abundance[Bpre].years",years);
    // Make a description of Bpre to pass to the Harvest_strategy constructor
    std::string Bpre_description = (mature_only ? "mature biomass" : "biomass");
    Bpre_description += " in time step " + itos(step);
    Bpre_description += " after proportion " + dtos(proportion_mortality) + " of the mortality";
    if (e.p.get_int("n_areas") > 1){
      if (area==""){
        Bpre_description += " in all areas";
      } else {
        Bpre_description += " in area " + area;
      }
    }
    if (selectivity != ""){
      Bpre_description += " applying the selectivity ogive " + selectivity;}
    constant_mortality = new Constant_exploitation_rate<double,dvector,dmatrix>(o, e.p,
                                                                                Bpre_description, 0);
  } else if (instantaneous_mortality){
    constant_mortality = new Constant_instantaneous_mortality<double,dvector,dmatrix>(o);
  }
  // Other requests for results for the Population_section
  e.p.put_int("requests.actual_catches",1);
  if(e.population_section->state.n_stocks>1)
    e.p.put_int("requests.actual_catches_by_stock",1);
  e.p.put_int("requests.B0",1);
  e.p.put_int("requests.SSBs",1);
  e.p.put_int("requests.recruitments",1);
  // Pass all these requests to the population section
  e.population_section->set_requests(e.p);
  // Pass the supplied free parameters to the estimation section
  e.free_parameters->set(free_parameter_values);
  e.insert_free_parameters();
  // Now what tasks are being requested?
  int do_YPR_SPR = o.get_bool("per_recruit.do_YPR_SPR",0);
  dvector Fs_to_try(o.get_constant_vector("per_recruit.F",dvector("{-1}")));
  int do_Fmax = o.get_bool("per_recruit.do_Fmax",0);
  int do_F0_1 = o.get_bool("per_recruit.do_F0_1",0);
  int do_Fx = o.get_bool("per_recruit.do_Fx",0);
  double x = o.get_constant("per_recruit.x",0);
  double YPR_guess = o.get_constant("per_recruit.guess",0.1);
  int do_yield_vs_SSB = o.get_bool("deterministic_MSY.do_yield_vs_SSB",0);
  dvector Fs_to_try_2(o.get_constant_vector("deterministic_MSY.F",dvector("{-1}")));
  int do_MSY = o.get_bool("deterministic_MSY.do_MSY",0);

  if (is_weightless_model){
    if (do_YPR_SPR||do_Fmax||do_F0_1||do_Fx||do_MSY)
      fatal("CASAL cannot estimate deterministic YPR and MSY in a weightless model.");
  }

  double MSY_guess = o.get_constant("deterministic_MSY.guess",0.1);
  // Create the calculation object which figures YPR(F) and SPR(F)
  Get_YPR_f_SPR_f<DVM> get_YPR_f_SPR_f(e.population_section,constant_mortality,x);
  // Create the calculation object which figures C(F) and SSB(F)
  Get_C_f_SSB_f<DVM> get_C_f_SSB_f(e.population_section,constant_mortality);
  // Print out the requests for yields
  if (o.get_bool("print.yields",1)){
    cout << "Deterministic yield calculations:\n";
    if (do_YPR_SPR){
      cout << "Calculate YPR and SPR for F = " << Fs_to_try << '\n';}
    if (do_Fmax){
      cout << "Calculate Fmax (the F which maximises the YPR)\n";}
    if (do_F0_1){
      cout << "Calculate F0.1 (the F at which the slope of the YPR curve is 10% that at the origin)\n";}
    if (do_Fx){
      cout << "Calculate F" << x << "% (the F at which the SPR is " << x << "% that of the unfished population)\n";}
    if (do_Fmax || do_F0_1 || do_Fx){
      cout << "Start all YPR estimates at the guesstimate " << YPR_guess << '\n';}
    if (do_yield_vs_SSB){
      cout << "Calculate yield and SSB for F = " << Fs_to_try_2 << '\n';}
    if (do_MSY){
      cout << "Calculate deterministic MSY, starting from the guesstimate of " << MSY_guess << "\n";}
    cout << "Definition of constant F: ";
    constant_mortality->print(cout);
    cout << "\n\n";
  }
  // Go ahead and calculate the yields
  if (do_YPR_SPR){
    get_YPR_f_SPR_f.to_maximise = "Not maximising";
    // calculate YPR(F) and SPR(F) for each of the fish stocks
    for(int stock=1;stock<=e.population_section->state.n_stocks;stock++){
      get_YPR_f_SPR_f.stock=stock;
      if(e.population_section->state.n_stocks>1)
        cout<<"stock "<<e.population_section->state.stock_names[stock]<<"\n";
      // calculate YPR(F) and SPR(F) for a range of F values and print
      for (int i=1; i<=Fs_to_try.size(); i++){
        double F = Fs_to_try[i];
        get_YPR_f_SPR_f(F,1,cout);
      }
      cout << '\n';
    }
  }
  if (do_Fmax){
    get_YPR_f_SPR_f.to_maximise = "YPR";
    // calculate the Fmax, i.e. the F which maximises YPR
    for(int stock=1;stock<=e.population_section->state.n_stocks;stock++){
      get_YPR_f_SPR_f.stock=stock;
      if(e.population_section->state.n_stocks>1)
        cout<<"stock "<<e.population_section->state.stock_names<<"\n";
        // calculate YPR(F) and SPR(F) for a range of F values and print
        double Fmax = maximise_yield< Get_YPR_f_SPR_f<DVM> >(get_YPR_f_SPR_f,YPR_guess,1,cout);
        dvector result(get_YPR_f_SPR_f.get(Fmax,0));
        cout << "Fmax     = " << Fmax << '\n';
        cout << "YPR      = " << result[1] << '\n';
        cout << "SPR      = " << result[2] << '\n' << '\n';
      }
  }
  if (do_F0_1){
    get_YPR_f_SPR_f.to_maximise = "F0.1";
    // calculate F0.1, i.e. the F for which the slope of the YPR curve is 0.1 that at the origin
    for(int stock=1;stock<=e.population_section->state.n_stocks;stock++){
      get_YPR_f_SPR_f.stock=stock;
      if(e.population_section->state.n_stocks>1)
        cout<<"stock "<<e.population_section->state.stock_names<<"\n";
      double Fpoint1 = maximise_yield< Get_YPR_f_SPR_f<DVM> >(get_YPR_f_SPR_f,YPR_guess,1,cout);
      cout << "F0.1     = " << Fpoint1 << '\n';
      cout << "slope of YPR curve at origin = " << get_YPR_f_SPR_f.slope_at_origin << "\n\n";
    }
  }
  if (do_Fx){
    get_YPR_f_SPR_f.to_maximise = "Fx%";
    // calculate Fx%, i.e. the F at which the SPR is x% of its unfished value
    for(int stock=1;stock<=e.population_section->state.n_stocks;stock++){
      get_YPR_f_SPR_f.stock=stock;
      if(e.population_section->state.n_stocks>1)
        cout<<"stock "<<e.population_section->state.stock_names<<"\n";
        double Fxpercent = maximise_yield< Get_YPR_f_SPR_f<DVM> >(get_YPR_f_SPR_f,YPR_guess,1,cout);
        cout << "Fx%      = " << Fxpercent << "\n";
        cout << "(x = " << get_YPR_f_SPR_f.x << ", unfished SPR = " << get_YPR_f_SPR_f.unfished_SPR << ")\n\n";
    }
  }
  if (do_yield_vs_SSB){
    // calculate C(F) and SSB(F) for a range of F values and print
    for(int stock=1;stock<=e.population_section->state.n_stocks;stock++){
      get_C_f_SSB_f.stock=stock;
      if(e.population_section->state.n_stocks>1)
        cout<<"stock "<<e.population_section->state.stock_names<<"\n";
      for (int i=1; i<=Fs_to_try_2.size(); i++){
        double F = Fs_to_try_2[i];
        get_C_f_SSB_f.get(F,1,cout);
      }
    }
    cout << '\n';
  }

  if (do_MSY){
    // calculate the MSY
    for(int stock=1;stock<=e.population_section->state.n_stocks;stock++){
      get_C_f_SSB_f.stock=stock;
      if(e.population_section->state.n_stocks>1)
        cout<<"stock "<<e.population_section->state.stock_names<<"\n";
      double F_MSYdet = maximise_yield< Get_C_f_SSB_f<DVM> >(get_C_f_SSB_f,MSY_guess,1,cout);
      dvector result(get_C_f_SSB_f.get(F_MSYdet,0));
      cout << "MSY      = " << result[1] << " (%B0)\n";
      cout << "B_MSY    = " << result[2] << " (%B0)\n";
      cout << "F_MSYdet = " << F_MSYdet << "\n" << "\n";
    }
  }
}

template<CDVM>
double Get_YPR_f_SPR_f<DVM>::operator()(double F,int print, ostream& out){
  // What this returns depends on 'to_maximise'. Seems like an awkward way of doing it:
  // it's to fit in with the syntax of maximise_yield().
  // In all three cases, return instead -1e18 if the maximum fishing pressure limit is reached.
  DEBUG0("Get_YPR_f_SPR_f::operator()");
  if (to_maximise == "YPR" || to_maximise == "Not maximising"){
    // return YPR
    double result = get(F,print,out)[1];
    if (F > 0 && result==0) return -1e18;
    else return result;
  } else if (to_maximise == "F0.1") {
    // return the negative squared difference between the slope and (10% slope at origin)
    double result1 = get(F+0.0001,0)[1];
    double result2 = get(F,print,out)[1];
    double slope = (result1 - result2) / 0.0001;
    if (print) out << "slope = " << slope << "\n";
    if (F > 0 && result1==0) return -1e18;
    else return -pow(slope - (0.1 * slope_at_origin),2);
  } else if (to_maximise == "Fx%") {
    // return the negative squared difference between SPR and (x/100 * unfished SPR)
    dvector result(get(F,print,out));
    double SPR = result[2];
    if (F > 0 && result[1]==0) return -1e18;
    else return -pow(SPR - (x*0.01 * unfished_SPR),2);
  }
}

template<CDVM>
dvector Get_YPR_f_SPR_f<DVM>::get(double F,int print, ostream& out){
  // Calculate YPR(f) and SPR(f) for a given harvest rate F.
  // Return a 2-vector whose elements are YPR(F) and SPR(F),
  // except if the fishing pressure limit is breached, in which case return a 2-vector of zeros.
  DEBUG0("Get_YPR_f_SPR_f::operator()");
  // run the model to deterministic equilibrium: the results are filled in
  dvector result(1,2);
  int status;
  status = popn->deterministic_equilibrium(strategy,F);
  if (status == 0){
    result = 0;
    if (print){
      out << "At F = " << F << " the fishing pressure limit is breached.\n";}
  } else {
    // determine YPR(F) (yield per recruit) and SPR(F) (SSB per recruit)
    double C_f, R_f, SSB_f, YPR_f, SPR_f;
    C_f = total_catch<DVM>(popn, 0,stock); // only use year 0
    R_f = (*popn->results.recruitments)[stock][0]; // stock 1, year 0
    SSB_f = (*(popn->results.SSBs))[stock][0]; // stock 1, year 0
    YPR_f = C_f / R_f;
    SPR_f = SSB_f / R_f;
    result[1] = YPR_f;
    result[2] = SPR_f;
    if (print){
      out << "F " << F << " YPR " << YPR_f << " SPR " << SPR_f << " Catch " << C_f << " Recruits " << R_f << " SSB " << SSB_f ;
      if (!(strategy->constant_instantaneous_mortality())){
        out << " B_pre " << (popn->results.abundance)["Bpre"][0] << '\n';
      } else {
        out << '\n';
      }
    }
  }
  return result;
}

template<CDVM>
//double total_catch(Basic_population_section<DVM>* popn, int year, int stock = 0){
double total_catch(Basic_population_section<DVM>* popn, int year, int stock){//richard
  // Extract the total catch for 'stock' if provided, or for all stocks if not,
  // in 'year', from popn->results. So the Population_section should already have been run,
  // and actual_catches should have been requested (if the stock argument is not supplied),
  // or actual_catches_by_stock (otherwise).
  DEBUG1("total_catch");
  int n_stocks = popn->state.n_stocks;
  int n_fisheries = popn->annual_cycle->n_fisheries;
  std::vector<std::string> fishery_names = popn->annual_cycle->fishery_names;
  double result = 0;
  if (stock == 0 || n_stocks == 1){
    if (!in(popn->results.actual_catches,year)){
      fatal("In total_catch, trying to extract the total catch for all stocks combined in year " + itos(year) + " but this result is not in the Population_section.");}
    for (int i=1; i<=n_fisheries; i++){
      result += popn->results.actual_catches[year][fishery_names[i]];}
  } else {
    std::vector<std::string> stock_names = popn->state.stock_names;
    if (!in(popn->results.actual_catches_by_stock,year)){
      fatal("In total_catch, trying to extract the total catch for stock " + stock_names[stock] + " in year " + itos(year) + " but this result is not in the Population_section.");}
    for (int i=1; i<=n_fisheries; i++){
      result += popn->results.actual_catches_by_stock[year][fishery_names[i]][stock_names[stock]];}
  }
  return result;
}

template<CDVM>
Get_YPR_f_SPR_f<DVM>::Get_YPR_f_SPR_f(Basic_population_section<DVM>* _popn,
                                      Harvest_strategy<DVM>* _strategy,
                    double _x){
  // the x is as in Fx%
  // Need to calculate the slope of the YPR curve at the origin, in case we do F0.1 later,
  //  and the unfished SPR, in case we do Fx%.
  DEBUG0("Get_YPR_f_SPR_f::Get_YPR_f_SPR_f");
  popn = _popn;
  strategy = _strategy;
  x = _x;
  stock=1;      // default
  to_maximise = ""; // not decided yet
  slope_at_origin = (get(0.0001,0)[1] - get(0,0)[1]) / 0.0001;
  unfished_SPR = get(0,0)[2];
}

template<CDVM>
double Get_C_f_SSB_f<DVM>::operator()(double F, int print, ostream& out){
  // return C(F), unless the fishing pressure limit is breached, in which case -1e18.
  DEBUG0("Get_C_f_SSB_f::operator()");
  double result(get(F,print,out)[1]);
  if (F>0 && result==0) return -1e18;
  else return result;
}

template<CDVM>
dvector Get_C_f_SSB_f<DVM>::get(double F, int print, ostream& out){
  // Calculate C_f and SSB_f for a given harvest rate F.
  // Return a 2-vector whose elements are C_f and SSB_f, as proportions of B0,
  // except if the fishing pressure limit is breached, in which case return a 2-vector of zeros.
  DEBUG0("Get_C_f_SSB_f::get");
  dvector result(1,2);
  // run the model to deterministic equilibrium: the results are filled in
  int status;
  status = popn->deterministic_equilibrium(strategy,F);
  if (status == 0){
    result = 0;
    if (print){
      out << "At F = " << F << " the fishing pressure limit is breached.\n";}
  } else {
    // determine C_f (total catch over fisheries) and SSB_f, as proportions of B0
    double C_f, SSB_f, B0;
    B0 = (*(popn->results.B0))[stock]; // 1 because there can only be 1 stock
    C_f = total_catch<DVM>(popn,0,stock); // only use year 0
    C_f *= (100/B0);
    SSB_f = (*(popn->results.SSBs))[stock][0] * (100/B0); // [1][1] because stock 1, year 0
    result[1] = C_f;
    result[2] = SSB_f;
    if (print){
      out << "F " << F << " C_f " << C_f << " SSB_f " << SSB_f << '\n';}
  }
  return result;
}

template<CDVM>
Get_C_f_SSB_f<DVM>::Get_C_f_SSB_f(Basic_population_section<DVM>* _popn,
                                  Harvest_strategy<DVM>* _strategy){
  // not much to do - just initialize the pointer members
  DEBUG0("Get_C_f_SSB_f::Get_C_f_SSB_f");
  popn = _popn;
  strategy = _strategy;
}

template<CDVM>
void try_interpolation (double &H, dmatrix &result, Get_Cav_Bav_Prisk<DVM> MCY_Cav_Bav_Prisk){
     // If the optimal H value (either MCY or F_CAY) occurs when the maximum Prisk (q) is  reached
     // then the maximisation routine underestimates the optimal H value. If this is the case then
     // linear interpolation is used to obtain results (H, Cav, Bav, Prisk) at q. These are
     // returned via the referenced variables MCY and result.

     // Note that when interpolating the objective function used for checking if there is
     // a better H value is sum(Cav), not sum(Cav) * ( 1 + 0.01*H/Hinitial guess ). This second
     // objective function encourages the optimisation not to get stuck at a local maxima for
     // a smaller than optimal H, which is not of concern in the interpolating step.
    DEBUG0("try_interpolation");

    int num_opt_iterations = MCY_Cav_Bav_Prisk.num_opt_iterations;
    double q_value = MCY_Cav_Bav_Prisk.q;
    int second_risk = MCY_Cav_Bav_Prisk.second_risk;
    double q2_value = 0;
    if (second_risk) q2_value = MCY_Cav_Bav_Prisk.q2;
    int run_risk = MCY_Cav_Bav_Prisk.run_risk;
    double r_run_value = 0;
    if (run_risk) r_run_value = MCY_Cav_Bav_Prisk.r_run;
    int n_stocks = MCY_Cav_Bav_Prisk.n_stocks;
    std::vector<std::string> stock_names = MCY_Cav_Bav_Prisk.stock_names;

    dmatrix  high_result(n_stocks,5), try_result(n_stocks,5);
    double   high_H, try_H;   // corresponding to the above line
    double   try_Prisk, try_Prisk2, try_Prisk_run;

    // Check if there is a higher harvest rate H which was ignored because
    // one constraint was broken for one stock. (Don't use it if multiple breakages occurred.)
    // Record the stock and output values at this H
    int stock_to_inter = 0;
    double sum_Cav = 0;
    for (int i=1; i<=n_stocks ; i++ ){
      sum_Cav += result[i][1];
    }
    // Loop through the last six H values at which a maximum was searched for (the last
    // sweep of the maximisation routine). N.B. The calculated optimal value occurs at
    // the H value that is missed at the end of the loop on i.
        int constraint_broken=0; // 1 = p/q, 2 = p2/q2, 3 = p_run/q_run/r_run
    int i = num_opt_iterations - 6;
    while(i <= num_opt_iterations - 1 && stock_to_inter == 0){
        try_result = MCY_Cav_Bav_Prisk.save_result[i];
        try_H = MCY_Cav_Bav_Prisk.save_H[i];
        double try_sum_Cav = 0;
        for(int j = 1; j<=n_stocks; j++){
          try_sum_Cav += try_result[j][1];
        }
           if (try_sum_Cav <= sum_Cav){
                i++;
                continue; // no use
           }
        // Now loop through the stocks for a given H value
        // The first stock with a broken constraint causes a H value to be excluded from the optimisation
        // and hence possibly a target for interpolation.
        // But if the H value has multiple broken constraints we won't use it.
        for (int j=1; j<=n_stocks; j++){
             if (try_result[j][3] > q_value){
                                 if (stock_to_inter==0){
                   stock_to_inter = j;
                   high_result = try_result;
                   high_H = try_H;
                   constraint_broken = 1;
                             } else { // a second constraint exceeded- no good
                                   stock_to_inter=0;
                                   break;
                             }
             }
             if (try_result[j][4] > q2_value && second_risk){
                                 if (stock_to_inter==0){
                   stock_to_inter = j;
                   high_result = try_result;
                   high_H = try_H;
                   constraint_broken = 2;
                             } else { // a second constraint exceeded- no good
                                   stock_to_inter=0;
                                   break;
                             }
             }
             if (try_result[j][3] > r_run_value && run_risk){
                                 if (stock_to_inter==0){
                   stock_to_inter = j;
                   high_result = try_result;
                   high_H = try_H;
                   constraint_broken = 3;
                             } else { // a second constraint exceeded- no good
                                   stock_to_inter=0;
                                   break;
                             }
             }
        }
        i++;
    }
    if (stock_to_inter == 0) return; // no valid candidate for interpolating with

       // How near to the risk cutoff are we? If too far, then don't dare to interpolate.
      double percent_of;
      if (constraint_broken==1){
                  percent_of = (q_value - result[stock_to_inter][3])/q_value*100;
          } else if (constraint_broken==2){
                  percent_of = (q2_value - result[stock_to_inter][4])/q2_value*100;
          } else if (constraint_broken==3){
                  percent_of = (r_run_value - result[stock_to_inter][5])/r_run_value*100;
      }
      if (percent_of > 5.0) return;

    // Do the interpolation
    if(stock_to_inter!=0){
        double prop_along;
        if (constraint_broken==1){
          prop_along = (q_value - result[stock_to_inter][3])/( high_result[stock_to_inter][3] - result[stock_to_inter][3] );
            } else if (constraint_broken==2){
          prop_along = (q2_value - result[stock_to_inter][4])/( high_result[stock_to_inter][4] - result[stock_to_inter][4] );
            } else if (constraint_broken==3){
          prop_along = (r_run_value - result[stock_to_inter][5])/( high_result[stock_to_inter][5] - result[stock_to_inter][5] );
            }
        H = H + prop_along*(high_H - H);
        result = result + prop_along * (high_result - result);
    }
}

template<CDVM>
void MCY_CAY(Estimation_section<DVM>& e_simulate,
             Estimation_section<DVM>& e_normal,
             dmatrix& free_parameter_values, Parameter_set<DVM>& o){
  // Calculate MCY and/or CAY. ... now and/or CBMSY (chasing B_MSY) strategy as well
  //
  // e_simulate is for simulation and should have been created with the _do_yields switch.
  // e_normal is for evaluating current and projected status and should not have been created
  //   with the _do_yields switch.
  DEBUG0("MCY_CAY");
  int n_stocks = e_simulate.population_section->state.n_stocks;
  std::vector<std::string> stock_names = e_simulate.population_section->state.stock_names;

  int do_MCY = o.get_bool("MCY_CAY.do_MCY",0);
  int do_CAY = o.get_bool("MCY_CAY.do_CAY",0);
  int do_CBMSY = o.get_bool("MCY_CAY.do_CBMSY",0);
  int interactive = o.get_bool("MCY_CAY.interactive",0);
  double MCY_guess=0.0;
  if (do_MCY){
          MCY_guess = o.get_constant("MCY_CAY.MCY_guess");
  }
  double F_CAY_guess=0.0;
  if (do_CAY){
          F_CAY_guess = o.get_constant("MCY_CAY.F_CAY_guess");
  }
  double p_CBMSY_guess=0.0;
  if (do_CBMSY){
          p_CBMSY_guess = o.get_constant("MCY_CAY.p_CBMSY_guess");
  }
  int n_discard = o.get_int("MCY_CAY.n_discard");
  int n_keep = o.get_int("MCY_CAY.n_keep");
  int max_upper_iter = o.get_int("MCY_CAY.max_upper_iter",40); // Same default as for function maximise_yield
  int simulation_length = n_discard + n_keep;
  int risk_year = o.get_int("MCY_CAY.MCY_CAY_risk_year",-1); // Default: use B0 (this is the usual case)
  if (do_MCY && free_parameter_values.rowsize() > 1){
    // sample-based MCY: make sure MCY_uncertainty_dist is turned off
    if (o.present("MCY_CAY.MCY_uncertainty_dist") || o.present("MCY_CAY.MCY_uncertainty_cv")){
      if(o.get_string("MCY_CAY.MCY_uncertainty_dist","none")!="none"  || o.present("MCY_CAY.MCY_uncertainty_cv"))
        fatal("Turn off MCY_uncertainty_dist and _cv for sample-based MCY calculations");
    }
  }
  int yield_diagnostic_output = o.get_int("print.yield_diagnostic_output",0);
  std::vector<class Run_diagnostic_output> run_diagnostic_output;

  // Start by building the constant_catch and constant_F and chasing-MSY Harvest_strategies,
  //  and setting up the Estimation_section for simulation.
  Harvest_strategy<double,dvector,dmatrix> *constant_catch, *constant_mortality, *chasing_BMSY;
  constant_catch = new Constant_catch<double,dvector,dmatrix>(o, e_simulate.p, 1);
  chasing_BMSY = new Chasing_BMSY<double,dvector,dmatrix>(o, e_simulate.p, 1);

  // what kind of mortality rate are we using in the constant_F harvest strategy?
  // instantaneous mortality or exploitation rate?
  int instantaneous_mortality;
  if (e_simulate.population_section->annual_cycle->baranov) {
      if(e_simulate.population_section->annual_cycle->n_fisheries > 1)
        fatal("If you use the Baranov catch equation, MCY/CAY yields cannot be calcuated if there is more than one fishery");
      instantaneous_mortality = 1;
  } else {
    instantaneous_mortality = 0;
  }
  std::string Bpre_description;
  if (!instantaneous_mortality && do_CAY){
          // We need to set up the pre-fishery biomass Bpre to be used in the
          // constant-exploitation-rate strategy, TAC = Bpre * F.
          // We also need to send a request to the Population_section to calculate this Bpre.
          int first_fishery_step = (int)min(*(e_simulate.population_section->annual_cycle->fishery_times));
          int step = o.get_int("B_pre.step",first_fishery_step);
          double proportion_mortality = o.get_constant("B_pre.proportion_mortality",0);
          std::string area = o.get_string("B_pre.area","");
          std::string selectivity = o.get_string("B_pre.selectivity");
          int mature_only = o.get_bool("B_pre.mature_only");
          // Send requests for the calculation of Bpre to the two Population_sections
          e_simulate.p.put_int("abundance[Bpre].step",step);
          e_normal.p.put_int("abundance[Bpre].step",step);
          e_simulate.p.put_constant("abundance[Bpre].proportion_mortality",proportion_mortality);
          e_normal.p.put_constant("abundance[Bpre].proportion_mortality",proportion_mortality);
          if (area != ""){
                e_simulate.p.put_string("abundance[Bpre].area",area);
                e_normal.p.put_string("abundance[Bpre].area",area);
          }
          if (selectivity != ""){
                e_simulate.p.put_string("abundance[Bpre].ogive",selectivity);
                e_normal.p.put_string("abundance[Bpre].ogive",selectivity);
          }
          e_simulate.p.put_int("abundance[Bpre].mature_only",mature_only);
          e_normal.p.put_int("abundance[Bpre].mature_only",mature_only);
          e_simulate.p.put_int("abundance[Bpre].biomass",1);
          e_normal.p.put_int("abundance[Bpre].biomass",1);
          dvector years_sim(1,simulation_length+1);
          years_sim.fill_seqadd(1,1); // request Bpre for simulation
          e_simulate.p.put_constant_vector("abundance[Bpre].years",years_sim);
          dvector years_pro(1,1);
          int current = e_normal.population_section->annual_cycle->current;
          years_pro[1] = current+1; // request Bpre for projection
          e_normal.p.put_constant_vector("abundance[Bpre].years",years_pro);
          // Make a description of Bpre to pass to the Harvest_strategy constructor
          Bpre_description = (mature_only ? "mature biomass" : "biomass");
          Bpre_description += " in time step " + itos(step);
          Bpre_description += " after proportion " + dtos(proportion_mortality) + " of the mortality";
          if (e_simulate.p.get_int("n_areas") > 1){
                if (area==""){
                  Bpre_description += " in all areas";
                } else {
                  Bpre_description += " in area " + area;
                }
          }
          if (selectivity != ""){
                Bpre_description += " applying the selectivity ogive " + selectivity;}
  }

  // If CAY uses an exploitation rate, we need to set up the Constant_exploitation_rate harvest strategy.
  // Or if it uses an instantaneous mortality rate, we need to set up the Constant_instantaneous_mortality harvest strategy.
  if (!instantaneous_mortality){
    constant_mortality = new Constant_exploitation_rate<double,dvector,dmatrix>(o, e_simulate.p, Bpre_description, 1);
  } else if (instantaneous_mortality){
    if (o.get_string("MCY_CAY.CAY_uncertainty_dist","none") != "none"){
      fatal("Annual stock assessment uncertainty has not yet been implemented for instantaneous mortality  - redefine F as an exploitation rate");}
    constant_mortality = new Constant_instantaneous_mortality<double,dvector,dmatrix>(o);
  }

  // Other requests for results for the Population_section
  e_simulate.p.put_int("requests.actual_catches",1);
  e_normal.p.put_int("requests.actual_catches",1);
  e_simulate.p.put_int("requests.B0",1);
  e_normal.p.put_int("requests.B0",1);
  e_simulate.p.put_int("requests.SSBs",1);
  e_normal.p.put_int("requests.SSBs",1);
  if (n_stocks > 1){
    e_simulate.p.put_int("requests.actual_catches_by_stock",1);
    e_normal.p.put_int("requests.actual_catches_by_stock",1);
  }
  e_simulate.p.put_int("requests.recruitments",1);

  // continue setting up the estimation sections
  dmatrix *reference_SSBs = 0; // if used, index by number of parameter-values set then stock
  if (risk_year != -1){
        // The risk constraint is relative to the SSB in year 'risk_year',
        // rather than B0. We need to calculate these 'reference year' SSBs
        // and pass them to the Get_Cav_Bav_Prisk constructors.
   int n_parameter_sets = free_parameter_values.rowsize();
   if (n_parameter_sets == 1){
     reference_SSBs = new dmatrix(1,1,1,n_stocks); // just one parameter set, so 1 set of SSBs
     e_normal.free_parameters->set(free_parameter_values[1]);
     e_normal.insert_free_parameters();
     e_normal.population_section->run_model();
         for (int stock=1; stock<=n_stocks; stock++){
                (*reference_SSBs)[1][stock] = (*(e_normal.population_section->results.SSBs))[stock][risk_year];
         }
   } else if (n_parameter_sets > 1){
     reference_SSBs = new dmatrix(1,n_parameter_sets,1,n_stocks); // one set of SSBs per parameter set
         for (int i=1; i<=free_parameter_values.rowmax(); i++){
       e_normal.free_parameters->set(free_parameter_values[i]);
       e_normal.insert_free_parameters();
       e_normal.population_section->run_model();
           for (int stock=1; stock<=n_stocks; stock++){
             (*reference_SSBs)[i][stock] = (*(e_normal.population_section->results.SSBs))[stock][risk_year];
           }
         }
   }
  }

  // Create the objects used to calculate Cav(H), Bav(H), and Prisk(H)
  Get_Cav_Bav_Prisk<DVM> MCY_Cav_Bav_Prisk(&e_simulate, constant_catch, &free_parameter_values,
                                           e_simulate.RNG_seed, o, MCY_guess, reference_SSBs, &run_diagnostic_output);

  Get_Cav_Bav_Prisk<DVM> CAY_Cav_Bav_Prisk(&e_simulate, constant_mortality, &free_parameter_values,
                                           e_simulate.RNG_seed, o, F_CAY_guess, reference_SSBs, &run_diagnostic_output);

  Get_Cav_Bav_Prisk<DVM> CBMSY_Cav_Bav_Prisk(&e_simulate, chasing_BMSY, &free_parameter_values,
                                             e_simulate.RNG_seed, o, p_CBMSY_guess, reference_SSBs, &run_diagnostic_output);

  // Print a description of the requests for yield calculations
  if (o.get_bool("print.yields",1)){
    if (do_MCY){
      cout << "Calculate MCY ";
      if (interactive){
        cout << "interactively.\n";
      } else {
        cout << "using an initial guess of MCY = " << MCY_guess << "t.\n";
      }
      MCY_Cav_Bav_Prisk.print(cout);
      cout << '\n';
    }
    if (do_CAY){
      cout << "Calculate CAY ";
      if (interactive){
        cout << "interactively.\n";
      } else {
        cout << "using an initial guess of F_CAY = " << F_CAY_guess << ".\n";
      }
      CAY_Cav_Bav_Prisk.print(cout);
      cout << '\n';
    }
    if (do_CBMSY){
      cout << "Calculate CBMSY ";
      if (interactive){
        cout << "interactively.\n";
      } else {
        cout << "using an initial guess of p_CBMSY = " << p_CBMSY_guess << ".\n";
      }
      CBMSY_Cav_Bav_Prisk.print(cout);
      cout << '\n';
        }
    cout << "In stochastic simulations, discard the first " << n_discard << " years and base results on the next " << n_keep << " years.\n";
    cout << "\n";
  }
  int second_risk = o.get_bool("MCY_CAY.second_risk",0);
  int run_risk = o.get_bool("MCY_CAY.run_risk",0);

  // Now figure MCY if requested:
  if (do_MCY){
    double MCY;
    if (!interactive){     // do an automated search
      MCY_Cav_Bav_Prisk.num_opt_iterations = 0;
      MCY_Cav_Bav_Prisk.save_result.push_back(dmatrix());
      MCY_Cav_Bav_Prisk.save_H.push_back(0);
      MCY = maximise_yield< Get_Cav_Bav_Prisk<DVM> >(MCY_Cav_Bav_Prisk,MCY_guess,1,cout,max_upper_iter);
    }
    else if (interactive){ // do a manual search
      double guess;
      cout << "Interactive calculation of MCY:\n";
      while (1){
        cout << "\nEnter a harvest rate H (catch in t), or a negative value to stop: ";
        cin >> guess;
        if (guess < 0) break;
        MCY = guess;
        MCY_Cav_Bav_Prisk.get(MCY,1,cout);
      }
    }

          dmatrix result(MCY_Cav_Bav_Prisk.get(MCY,0));

          // If the optimal MCY value occurs when the maximum Prisk (q) is reached then the maximisation
          // routine tends to underestimate the optimal MCY value. If this is the case then linear interpolation
          // is used to obtain results at q.
          if(!interactive) try_interpolation(MCY, result, MCY_Cav_Bav_Prisk);

          cout << "\nMCY      = " << MCY << '\n';
          if (n_stocks==1){
            cout << "Avg catch under MCY = " << result[1][1] << '\n';
            cout << "B_MCY               = " << result[1][2] << '\n';
            cout << "Prisk               = " << result[1][3] << '\n';
            if (second_risk) cout << "Prisk2              = " << result[1][4] << '\n';
            if (run_risk)    cout << "Prisk_run           = " << result[1][5] << '\n';
          } else {
            for (int i=1; i<=n_stocks; i++){
              cout << "Avg catch under MCY for stock " << stock_names[i] << " = " << result[i][1] << '\n';
              cout << "B_MCY               for stock " << stock_names[i] << " = " << result[i][2] << '\n';
              cout << "Prisk               for stock " << stock_names[i] << " = " << result[i][3] << '\n';
              if (second_risk) cout << "Prisk2               for stock " << stock_names[i] << " = " << result[i][4] << '\n';
              if (run_risk)    cout << "Prisk_run            for stock " << stock_names[i] << " = " << result[i][5] << '\n';
            }
          }
          if (n_stocks == 1){
            // Calculate 'current MCY' using projection. Currently only implemented for a single stock.
            int n_simulations = (int) fmax(o.get_int("MCY_CAY.n_simulations",300),100);
            double E_Bcurrent_over_B0 = expected_stock_level<DVM>(e_normal, free_parameter_values, n_simulations);
            double current_MCY;
            if (E_Bcurrent_over_B0 < 0.2){
              current_MCY = MCY * E_Bcurrent_over_B0*5;
            } else {
              current_MCY = MCY;
            }
            cout << "'current' MCY = " << current_MCY << '\n';
          }
          cout << '\n';

  }   // end of do_MCY block

  // And CAY if requested.
  if (do_CAY){
    // First calculate F_CAY using simulation.
    double F_CAY;
    if (!interactive){ // do an automated search
      CAY_Cav_Bav_Prisk.num_opt_iterations = 0;
      CAY_Cav_Bav_Prisk.save_result.push_back(dmatrix());
      CAY_Cav_Bav_Prisk.save_H.push_back(0);
      F_CAY = maximise_yield< Get_Cav_Bav_Prisk<DVM> >(CAY_Cav_Bav_Prisk,F_CAY_guess,1,cout,max_upper_iter);

    }
    else if (interactive){ // do a manual search
      double guess = 0;
      cout << "Interactive calculation of F_CAY:\n";
      while (1){
        cout << "\nEnter a harvest rate H (mortality rate), or a negative value to stop: ";
        cin >> guess;
        if (guess < 0) break;
        F_CAY = guess;
        CAY_Cav_Bav_Prisk.get(F_CAY,1,cout);
      }
    }

        dmatrix result(CAY_Cav_Bav_Prisk.get(F_CAY,0));

        // If the optimal F_CAY value occurs when the maximum Prisk (q) is reached then the maximisation
        // routine tends to underestimate the optimal F_CAY value. If this is the case then linear interpolation
        // is used to obtain results at q.
        if (!interactive) try_interpolation(F_CAY, result, CAY_Cav_Bav_Prisk);

        cout << "\nF_CAY    = " << F_CAY << '\n';
        if (n_stocks==1){
          cout << "MAY      = " << result[1][1] << '\n';
          cout << "B_MAY    = " << result[1][2] << '\n';
          cout << "Prisk    = " << result[1][3] << '\n';
          if (second_risk) cout << "Prisk2   = " << result[1][4] << '\n';
          if (run_risk)    cout << "Prisk_run= " << result[1][5] << '\n';
        } else {
          for (int i=1; i<=n_stocks; i++){
            cout << "MAY       for stock " << stock_names[i] << " = " << result[i][1] << '\n';
            cout << "B_MAY     for stock " << stock_names[i] << " = " << result[i][2] << '\n';
            cout << "Prisk     for stock " << stock_names[i] << " = " << result[i][3] << '\n';
            if (second_risk) cout << "Prisk2    for stock " << stock_names[i] << " = " << result[i][4] << '\n';
            if (run_risk)    cout << "Prisk_run for stock " << stock_names[i] << " = " << result[i][5] << '\n';
          }
        }
        cout << '\n';
        // Next calculate CAY using projection.
        int n_simulations = (int) fmax(o.get_int("MCY_CAY.n_simulations",300),100);
        dvector CAY(get_CAY<DVM>(F_CAY, constant_mortality, e_normal, free_parameter_values, n_simulations));
        if (n_stocks==1){
          cout << "CAY      = " << CAY << '\n';
        } else {
          for (int i=1; i<=n_stocks; i++){
            cout << "CAY   for stock " << stock_names[i] << " = " << CAY[i] << '\n';
          }
        }
        cout << '\n';

  }  // end of do_CAY block

  // And CBMSY if requested.
  if (do_CBMSY){
    // First calculate p_CBMSY using simulation.
    double p_CBMSY;
    if (!interactive){ // do an automated search
      CBMSY_Cav_Bav_Prisk.num_opt_iterations = 0;
      CBMSY_Cav_Bav_Prisk.save_result.push_back(dmatrix());
      CBMSY_Cav_Bav_Prisk.save_H.push_back(0);
      p_CBMSY = maximise_yield_between< Get_Cav_Bav_Prisk<DVM> >(CBMSY_Cav_Bav_Prisk,0,1,1,1,cout,max_upper_iter);
    }
    else if (interactive){ // do a manual search
      double guess = 0;
      cout << "Interactive calculation of p_CBMSY:\n";
      while (1){
        cout << "\nEnter a harvest rate H (which is the chasing rate p), or a negative value to stop: ";
        cin >> guess;
        if (guess < 0) break;
        p_CBMSY = guess;
        CBMSY_Cav_Bav_Prisk.get(p_CBMSY,1,cout);
      }
    }

        dmatrix result(CBMSY_Cav_Bav_Prisk.get(p_CBMSY,0));

        // If the optimal p_CBMSY value occurs when the maximum Prisk (q) is reached then the maximisation
        // routine tends to underestimate the optimal p_CBMSY value. If this is the case then linear interpolation
        // is used to obtain results at q.
        if (!interactive) try_interpolation(p_CBMSY, result, CBMSY_Cav_Bav_Prisk);

        cout << "\np_CBMSY    = " << p_CBMSY << '\n';
        if (n_stocks==1){
          cout << "Avg catch under CBMSY = " << result[1][1] << '\n';
          cout << "B_CBMSY               = " << result[1][2] << '\n';
          cout << "Prisk                 = " << result[1][3] << '\n';
          if (second_risk) cout << "Prisk2                = " << result[1][4] << '\n';
          if (run_risk)    cout << "Prisk_run             = " << result[1][5] << '\n';
        } else {
          for (int i=1; i<=n_stocks; i++){
            cout << "Avg catch under CBMSY for stock " << stock_names[i] << " = " << result[i][1] << '\n';
            cout << "B_CBMSY               for stock " << stock_names[i] << " = " << result[i][2] << '\n';
            cout << "Prisk                 for stock " << stock_names[i] << " = " << result[i][3] << '\n';
            if (second_risk) cout << "Prisk2                for stock " << stock_names[i] << " = " << result[i][4] << '\n';
            if (run_risk)    cout << "Prisk_run             for stock " << stock_names[i] << " = " << result[i][5] << '\n';
          }
        }
        cout << '\n';

  }  // end of do_CBMSY block

  if (yield_diagnostic_output && run_diagnostic_output.size()>0){
    // Now that all the simulations are done, dump the diagnostic output to cout.
          cout << "# Yield diagnostic output\n";
          cout << "# Runs\n";
          cout << run_diagnostic_output.size() << '\n';
          cout << "# Stocks Fisheries Years Free_parameters\n";
          cout << run_diagnostic_output[0].n_stocks << ' ' << run_diagnostic_output[0].n_fisheries << ' ' << run_diagnostic_output[0].n_years << ' ' << run_diagnostic_output[0].n_free_parameters << '\n';
          cout << '\n';
      for (int i=0; i<run_diagnostic_output.size(); i++){
                  run_diagnostic_output[i].print(cout);
                  cout << '\n';
          }
  }
}

template<CDVM>
double Get_Cav_Bav_Prisk<DVM>::operator()(double H, int print, ostream& out){
  // return Cav(H)*(1+0.01*H / H_initial guess), unless Prisk(H) > q, in which case return -1e18 (i.e. 'real bad')
  // Now there are two more constraints which, if broken, cause the function to return -1e18
  DEBUG0("Get_Cav_Bav_Prisk::operator()");
  dmatrix result(get(H,print,out));
  double sum_Cav = 0;
  for (int i=1; i<=n_stocks; i++){
    if (result[i][3] > q){
      return -1e18;
    } else if (second_risk && result[i][4] > q2){
      return -1e18;
    } else if (run_risk && result[i][5] > r_run){
      return -1e18;
        } else {
      sum_Cav += result[i][1];
    }
  }
  return sum_Cav*(1+0.01*H/H_initial_guess);
}

template<CDVM>
dmatrix Get_Cav_Bav_Prisk<DVM>::get(double H, int print, ostream& out){
  // Calculate Cav(H), Bav(H), and Prisk(H) for a given harvest rate H.
  // Return a matrix whose columns are Cav(H), Bav(H), and Prisk(H), with one row per stock.
  // If 1 set of free parameter values was supplied, we do a single deterministic simulation
  //  and use that as the starting point for each of (n_simulations) stochastic sims.
  // If multiple sets were supplied, we do a deterministic sim followed by a stochastic sim for each.
  // In either case, we calculate one Cav, Bav, and Prisk value for each, and average over
  //   simulations to get Cav(H), Bav(H), and Prisk(H).
  // If a particular deterministic sim breaks the fishing pressure limit,
  //   then skip its stochastic sim and give it Cav = Bav = 0, Prisk = 1.
  //
  // To check convergence, we also print the quantities E(sum over stocks(SSB(n_discard))) and
  //   E(sum over stocks(SSB(n_discard+1))) for each H. If the second is substantially less than
  //   the first, the n_discard period may not be long enough.
  //   (Mind you, if they are about the same, it still may not be long enough, for example the
  //    stochastically recruited fish may not have reached the spawning stock yet.)
  //
  // August 2004: We now return two more columns, now totalling 5.
  //  The fourth is another risk, with new p and q parameters called p2 and q2.
  //  The fifth is a 'run-based risk'. It is an indicator variable, set to 1 if the
  //  proportion of (kept) years in which B < p_run*B0 is >= q_run.
  //  We will use these to implement two more constraints.
  //
  // Nov 2004: We now scale the initial abundance by a random number,
  //  for single-stock MCY calculations with initial abundance error.
  DEBUG0("Get_Cav_Bav_Prisk::get");
  RNG_reset(RNG_seed); // so we get the same random numbers each time
  dmatrix result(1,n_stocks,1,5);
  std::vector<dmatrix> individual_sim_results;
  dmatrix convergence_checks(1,n_simulations,1,2); // SSB(n_discard) and SSB(n_discard+1)
  double abundance_mult = 1;
  if (n_parameter_sets == 1 && !strategy->use_abundance_multiplier(RNG_seed)){
    // use the single set of free parameters provided
    e->free_parameters->set((*free_parameter_values)[1]);
    e->insert_free_parameters();
    // run the model to deterministic equilibrium
    int status;
    status = e->population_section->deterministic_equilibrium(strategy,H);
    if (status == 0){
      // exploitation rate exceeded in deterministic sim
      for (int i=1; i<=n_stocks; i++){
        result[i][1] = 0;
        result[i][2] = 0;
        result[i][3] = 1;
        result[i][4] = 1;
        result[i][5] = 1;
      }
      if (print){
        out << "At H = " << H << ", fishing pressure limit exceeded in deterministic sim\n";}
      return result;
    }
    Basic_state<double,dvector,dmatrix> start_state(e->population_section->state);
    for (int i=1; i<=n_simulations; i++){
      e->population_section->state = start_state;
      e->population_section->stochastic_simulation(strategy,H,RNG_seed);
      dvector Cav(1,n_stocks), Bav(1,n_stocks), Prisk(1,n_stocks), Prisk2(1,n_stocks), Prisk_run(1,n_stocks);
      dmatrix sim_result(1,n_stocks,1,5);
      for (int stock = 1; stock <= n_stocks; stock++){
        double sum_C = 0, sum_B = 0, sum_risk = 0, sum_risk2 = 0, sum_risk_run = 0;
        for (int year=(n_discard+1); year<=(n_discard+n_keep); year++){
          if (n_stocks == 1){
            sum_C += total_catch<DVM>(e->population_section,year);
          } else {
            sum_C += total_catch<DVM>(e->population_section,year,stock);
          }
          double SSB = (*(e->population_section->results.SSBs))[stock][year];
          sum_B += SSB;
          double B0 = (*(e->population_section->results.B0))[stock];
          double Breference = 0;
          if (risk_year == -1){
                  Breference = B0;
          } else {
                  Breference = (*reference_SSBs)[1][stock];
          }
          sum_risk += (SSB < p*Breference);
          sum_risk2 += (SSB < p2*Breference);
          sum_risk_run += (SSB < p_run*Breference);
        }
        Cav[stock] = sum_C / n_keep;
        Bav[stock] = sum_B / n_keep;
        Prisk[stock] = sum_risk / n_keep;
        Prisk2[stock] = sum_risk2 / n_keep;
        Prisk_run[stock] = (((sum_risk_run / n_keep) >= q_run) ? 1 : 0);
      }
      sim_result.colfill(1,Cav);
      sim_result.colfill(2,Bav);
      sim_result.colfill(3,Prisk);
      sim_result.colfill(4,Prisk2);
      sim_result.colfill(5,Prisk_run);
      individual_sim_results.push_back(sim_result);
      convergence_checks[i][1] = sum(extract_column(*(e->population_section->results.SSBs),n_discard));
      convergence_checks[i][2] = sum(extract_column(*(e->population_section->results.SSBs),n_discard+1));
          if (run_diagnostic_output!=0){
                  // Collect some info on this run - will be printed later
                  Run_diagnostic_output run(
                            e->population_section->state.n_stocks,
                            e->population_section->annual_cycle->n_fisheries,
                        n_discard+n_keep, free_parameter_values->colsize(),
                        e->population_section->state.stock_names,
                        e->population_section->annual_cycle->fishery_names);
                  run.harvest_rate = value(H);
                  run.abundance_error = 1; // none
                  run.free_parameter_values = value((*free_parameter_values)[1]);
          for (int year=1; year<=(n_discard+n_keep); year++){
                         for (int stock=1; stock<=run.n_stocks; stock++){
                                 run.SSBs[year][stock] = value((*(e->population_section->results.SSBs))[stock][year]);}
                         for (int fishery=1; fishery<=run.n_fisheries; fishery++){
                                 run.actual_catches[year][fishery] = value(e->population_section->results.actual_catches[year][run.fishery_names[fishery]]);}
                  }
                  run_diagnostic_output->push_back(run);
          }
    }

  } else if (n_parameter_sets == 1 && strategy->use_abundance_multiplier(RNG_seed)){

    // use the single set of free parameters provided
    // apply initial abundance error (this means we can't use the strategy
    //  above of running one deterministic sim and using it as the base for many
    //  stochastic sims)
    for (int i=1; i<=n_simulations; i++){
    // For single-stock MCY calculations with initial abundance error, we scale the partition by a random number
      e->free_parameters->set((*free_parameter_values)[1]);
      e->insert_free_parameters();
    abundance_mult = strategy->get_abundance_multiplier(RNG_seed);
    e->population_section->annual_cycle->multiply_initial_abundance(1,abundance_mult);
    // run the model to deterministic equilibrium
      e->population_section->deterministic_equilibrium(strategy,H);
      // and run the stochastic simulation
      e->population_section->stochastic_simulation(strategy,H,RNG_seed);
      dvector Cav(1,n_stocks), Bav(1,n_stocks), Prisk(1,n_stocks), Prisk2(1,n_stocks), Prisk_run(1,n_stocks);
      dmatrix sim_result(1,n_stocks,1,5);
      for (int stock = 1; stock <= n_stocks; stock++){
        double sum_C = 0, sum_B = 0, sum_risk = 0, sum_risk2 = 0, sum_risk_run = 0;
        for (int year=(n_discard+1); year<=(n_discard+n_keep); year++){
          if (n_stocks == 1){
            sum_C += total_catch<DVM>(e->population_section,year);
          } else {
            sum_C += total_catch<DVM>(e->population_section,year,stock);
          }
          double SSB = (*(e->population_section->results.SSBs))[stock][year];
          sum_B += SSB;
          double B0 = (*(e->population_section->results.B0))[stock];
          double Breference = 0;
          if (risk_year == -1){
                  Breference = B0;
          } else {
                  Breference = (*reference_SSBs)[1][stock];
          }
          sum_risk += (SSB < p*Breference);
          sum_risk2 += (SSB < p2*Breference);
          sum_risk_run += (SSB < p_run*Breference);
        }
        Cav[stock] = sum_C / n_keep;
        Bav[stock] = sum_B / n_keep;
        Prisk[stock] = sum_risk / n_keep;
        Prisk2[stock] = sum_risk2 / n_keep;
        Prisk_run[stock] = (((sum_risk_run / n_keep) >= q_run) ? 1 : 0);
      }
      sim_result.colfill(1,Cav);
      sim_result.colfill(2,Bav);
      sim_result.colfill(3,Prisk);
      sim_result.colfill(4,Prisk2);
      sim_result.colfill(5,Prisk_run);
      individual_sim_results.push_back(sim_result);
      convergence_checks[i][1] = sum(extract_column(*(e->population_section->results.SSBs),n_discard));
      convergence_checks[i][2] = sum(extract_column(*(e->population_section->results.SSBs),n_discard+1));
          if (run_diagnostic_output!=0){
                  // Collect some info on this run - will be printed later
                  Run_diagnostic_output run(
                            e->population_section->state.n_stocks,
                            e->population_section->annual_cycle->n_fisheries,
                        n_discard+n_keep, free_parameter_values->colsize(),
                        e->population_section->state.stock_names,
                        e->population_section->annual_cycle->fishery_names);
                  run.harvest_rate = value(H);
                  run.abundance_error = abundance_mult;
                  run.free_parameter_values = value((*free_parameter_values)[1]);
          for (int year=1; year<=(n_discard+n_keep); year++){
                         for (int stock=1; stock<=run.n_stocks; stock++){
                                 run.SSBs[year][stock] = value((*(e->population_section->results.SSBs))[stock][year]);}
                         for (int fishery=1; fishery<=run.n_fisheries; fishery++){
                                 run.actual_catches[year][fishery] = value(e->population_section->results.actual_catches[year][run.fishery_names[fishery]]);}
                  }
                  run_diagnostic_output->push_back(run);
          }
       // put the abundance back the way it was
       e->population_section->annual_cycle->multiply_initial_abundance(1,1.0 / abundance_mult);

    }

  } else if (n_parameter_sets > 1){

    // do one simulation from each parameter set
    for (int i=1; i<=n_parameter_sets; i++){
      e->free_parameters->set((*free_parameter_values)[i]);
      e->insert_free_parameters();
      // run the model to deterministic equilibrium
      int status;
      status = e->population_section->deterministic_equilibrium(strategy,H);
        e->population_section->stochastic_simulation(strategy,H,RNG_seed);
      dvector Cav(1,n_stocks), Bav(1,n_stocks), Prisk(1,n_stocks), Prisk2(1,n_stocks), Prisk_run(1,n_stocks);
      dmatrix sim_result(1,n_stocks,1,5);
        for (int stock = 1; stock <= n_stocks; stock++){
          double sum_C = 0, sum_B = 0, sum_risk = 0, sum_risk2 = 0, sum_risk_run = 0;
          for (int year=(n_discard+1); year<=(n_discard+n_keep); year++){
            if (n_stocks == 1){
              sum_C += total_catch<DVM>(e->population_section,year);
            } else {
              sum_C += total_catch<DVM>(e->population_section,year,stock);
            }
            double SSB = (*(e->population_section->results.SSBs))[stock][year];
            sum_B += SSB;
            double B0 = (*(e->population_section->results.B0))[stock];
            double Breference = 0;
            if (risk_year == -1){
                  Breference = B0;
            } else {
                  Breference = (*reference_SSBs)[i][stock];
            }
            sum_risk += (SSB < p*Breference);
            sum_risk2 += (SSB < p2*Breference);
            sum_risk_run += (SSB < p_run*Breference);
          }
          Cav[stock] = sum_C / n_keep;
          Bav[stock] = sum_B / n_keep;
          Prisk[stock] = sum_risk / n_keep;
          Prisk2[stock] = sum_risk2 / n_keep;
          Prisk_run[stock] = (((sum_risk_run / n_keep) >= q_run) ? 1 : 0);
        }

        sim_result.colfill(1,Cav);
        sim_result.colfill(2,Bav);
        sim_result.colfill(3,Prisk);
        sim_result.colfill(4,Prisk2);
        sim_result.colfill(5,Prisk_run);
        individual_sim_results.push_back(sim_result);
        convergence_checks[i][1] = sum(extract_column(*(e->population_section->results.SSBs),n_discard));
        convergence_checks[i][2] = sum(extract_column(*(e->population_section->results.SSBs),n_discard+1));
                if (run_diagnostic_output!=0){
                  // Collect some info on this run - will be printed later
                  Run_diagnostic_output run(
                            e->population_section->state.n_stocks,
                            e->population_section->annual_cycle->n_fisheries,
                        n_discard+n_keep, free_parameter_values->colsize(),
                        e->population_section->state.stock_names,
                        e->population_section->annual_cycle->fishery_names);
                  run.harvest_rate = value(H);
                  run.abundance_error = 1; // no error
                  run.free_parameter_values = value((*free_parameter_values)[i]);
          for (int year=1; year<=(n_discard+n_keep); year++){
                         for (int stock=1; stock<=run.n_stocks; stock++){
                                 run.SSBs[year][stock] = value((*(e->population_section->results.SSBs))[stock][year]);}
                         for (int fishery=1; fishery<=run.n_fisheries; fishery++){
                                 run.actual_catches[year][fishery] = value(e->population_section->results.actual_catches[year][run.fishery_names[fishery]]);}
                  }
                  run_diagnostic_output->push_back(run);
                }
     }
   }

  // average the results across simulations
  dmatrix subtotals(1,n_stocks,1,5);
  subtotals = 0;
  for (int i=0; i<n_simulations; i++){
    subtotals += individual_sim_results[i];}
  subtotals /= n_simulations;
  result = subtotals;
  // ditto the convergence statistics;
  dvector convergence(1,2);
  convergence = 0;
  for (int i=1; i<=n_simulations; i++){
    convergence += convergence_checks[i];
  }
  convergence /= n_simulations;
  if (print){
    if (n_stocks == 1){
      out << "H " << H << " Cav(H) " << result[1][1] << " Bav(H) " << result[1][2] << " Prisk(H) " << result[1][3];
      if (second_risk) out << " Prisk2(H) " << result[1][4];
      if (run_risk) out << " Prisk_run(H) " << result[1][5];
      out << " ";
    } else if (n_stocks > 1){
      out << "At H = " << H << ",\n";
      out << "stock  Cav(H)  Bav(H)  Prisk(H)";
      if (second_risk) out << " Prisk2(H) ";
      if (run_risk) out << " Prisk_run(H) ";
      out << "\n";
      for (int i=1; i<=n_stocks; i++){
        out << stock_names[i] << ' ' << result[i][1] << ' ' << result[i][2] << ' ' << result[i][3];
        if (second_risk) out << " " << result[i][4];
        if (run_risk) out << " " << result[i][5];
        out << '\n';
      }
    }
    out << "E(SSB(n_discard)) " << convergence[1] << " E(SSB(n_discard+1)) " << convergence[2] << endl;
  }

  // Save values in case needed for interpolation when Prisk is close to q
  num_opt_iterations ++;
  save_result.push_back(result);
  save_H.push_back(H);

  return result;
}

template<CDVM>
void Get_Cav_Bav_Prisk<DVM>::print(ostream& out){
  DEBUG2("Get_Cav_Bav_Prisk::print");
  out << "For each mortality rate H, ";
  if (n_parameter_sets==1){
    out << "run " << n_simulations << " simulations using the parameters provided.";
  } else {
    out << "run 1 simulation using each of the " << n_parameter_sets << " parameter sets provided.";
  }
  out << "\nDefinition of mortality rate H: ";
  strategy->print(out);
  out << "\nRisk is unacceptable if SSB drops below " << 100*p << "% " << (risk_year==-1 ? "B0" : "SSB in "+itos(risk_year)) << " more than " << 100*q << "% of the time.\n";
  if (second_risk){
    out << "'Second risk' constraint: Risk is also unacceptable if SSB drops below " << 100*p2 << "% " << (risk_year==-1 ? "B0" : "SSB in "+itos(risk_year)) << " more than " << 100*q2 << "% of the time.\n";
  }
  if (run_risk){
    out << "'Run-based risk' constraint: Risk is also unacceptable if SSB drops below " << 100*p_run << "% " << (risk_year==-1 ? "B0" : "SSB in "+itos(risk_year)) << " more than " << 100*q_run << "% of the time in more than " << 100*r_run << "% of simulation runs.\n";
  }
}

template<CDVM>
Get_Cav_Bav_Prisk<DVM>::Get_Cav_Bav_Prisk(Estimation_section<DVM>* _e,
                                          Harvest_strategy<DVM>* _strategy,
                                          dmatrix* _free_parameter_values,
                                          long _RNG_seed,
                                          Parameter_set<DVM>& o,
                                          double _H_initial_guess,
                                          dmatrix* _reference_SSBs,
                                          std::vector<class Run_diagnostic_output>* _run_diagnostic_output){
  // Construct the calculation object
  DEBUG0("Get_Cav_Bav_Prisk::Get_Cav_Bav_Prisk");
  e = _e;
  strategy = _strategy;
  free_parameter_values = _free_parameter_values;
  RNG_seed = _RNG_seed;
  p = o.get_constant("MCY_CAY.p",0.2);
  q = o.get_constant("MCY_CAY.q",0.1);
  risk_year = o.get_int("MCY_CAY.MCY_CAY_risk_year",-1); // Default: use B0 (this is the usual case)
  reference_SSBs = _reference_SSBs; // only used if risk_year != 1;
  n_parameter_sets = free_parameter_values->rowsize();
  if (n_parameter_sets == 1){
    n_simulations = o.get_int("MCY_CAY.n_simulations",100);
  } else {
    n_simulations = n_parameter_sets;
  }
  n_discard = o.get_int("MCY_CAY.n_discard");
  n_keep = o.get_int("MCY_CAY.n_keep");
  n_stocks = e->population_section->state.n_stocks;
  stock_names = e->population_section->state.stock_names;
  H_initial_guess = _H_initial_guess;
  second_risk = o.get_bool("MCY_CAY.second_risk",0);
  if (second_risk){
    p2 = o.get_constant("MCY_CAY.p2");
    q2 = o.get_constant("MCY_CAY.q2");
  }
  run_risk = o.get_bool("MCY_CAY.run_risk",0);
  if (run_risk){
    p_run = o.get_constant("MCY_CAY.p_run");
    q_run = o.get_constant("MCY_CAY.q_run");
    r_run = o.get_constant("MCY_CAY.r_run");
  }
  if (o.get_int("print.yield_diagnostic_output",0)==0) run_diagnostic_output = 0;
  else run_diagnostic_output = _run_diagnostic_output; // use this to return the details of the run - will be printed later
}

void Run_diagnostic_output::print(ostream& out){
        // dump the details of the run to stdout. No need to output the n_ parameters, they are dumped by a higher level printer
        DEBUG2("Run_diagnostic_output::print");
        cout << "Harvest rate \n";
        cout << harvest_rate << '\n';
        cout << "Free parameters \n";
        cout << free_parameter_values << '\n';
        cout << "Assessment error\n";
        cout << abundance_error << '\n';
        cout << "SSBs \n";
        if (n_stocks>1){
                for (int i=1; i<=n_stocks; i++){
                        cout << stock_names[i] << ' ';}
                cout << '\n';
        }
        for (int i=1; i<=n_stocks; i++){
          dvector this_col(extract_column(SSBs,i));
          cout << this_col << '\n';
        }
        cout << "Actual catches\n";
        if (n_fisheries>1){
                for (int i=1; i<=n_fisheries; i++){
                        cout << fishery_names[i] << ' ';}
                cout << '\n';
        }
        for (int i=1; i<=n_fisheries; i++){
          dvector this_col(extract_column(actual_catches,i));
          cout << this_col << '\n';
        }
}

Run_diagnostic_output::Run_diagnostic_output(int _n_stocks, int _n_fisheries, int _n_years, int _n_free_parameters,
                                                  std::vector<std::string>& _stock_names, std::vector<std::string>& _fishery_names) :
        actual_catches(1,_n_years,1,_n_fisheries),
        SSBs(1,_n_years,1,_n_stocks),
        free_parameter_values(1,_n_free_parameters){
        // Build the object - mostly dimensioning matrices and vectors
        n_fisheries = _n_fisheries;
        n_years = _n_years ;
        n_stocks = _n_stocks;
        n_free_parameters = _n_free_parameters;
        stock_names = _stock_names;
        fishery_names = _fishery_names;
}

template<CDVM>
dvector get_CAY(double F_CAY, Harvest_strategy<DVM>* constant_mortality,
                Estimation_section<DVM>& e,
                const dmatrix& free_parameter_values, int n_simulations){
  // Called by MCY_CAY().
  // Calculates the CAY for each stock using projection,
  //  given F_CAY, a constant-mortality Harvest_strategy, an Estimation_section to use for projection,
  //  a matrix of parameter sets, and a number of simulations to be done (this last is only used if
  //  only 1 parameter set is provided)
  // The projection population_section should have requests already set for B0, SSB, actual catches (by
  //  stock in a multi-stock model) and the measure of abundance Bpre used by the constant mortality
  //  Harvest_strategy (if any).
  DEBUG0("get_CAY");
  int n_parameter_sets = free_parameter_values.rowsize();
  int initial = e.population_section->annual_cycle->initial;
  int current = e.population_section->annual_cycle->current;
  int final = e.population_section->annual_cycle->final;
  if (final <= current) fatal("In get_CAY, trying to do 1-year projections. The 'final' parameter should be greater than 'current'.");
  int n_fisheries = e.population_section->annual_cycle->n_fisheries;
  std::vector<std::string> fishery_names = e.population_section->annual_cycle->fishery_names;
  int n_stocks = e.population_section->state.n_stocks;
  std::vector<std::string> stock_names = e.population_section->state.stock_names;
  dmatrix *projected_catches; // one row per stock, one column per simulation
  int old_assess_frequency = constant_mortality->assess_frequency;
  constant_mortality->assess_frequency = 1; // force an assessment this year - do not use last year's TAC
  // we will reset assess_frequency to the original value at the end of this function
  if (n_parameter_sets == 1){
    projected_catches = new dmatrix(1,n_stocks,1,n_simulations);
    e.free_parameters->set(free_parameter_values[1]);
    e.insert_free_parameters();
    for (int i=1; i<=n_simulations; i++){
      // randomise the YCS and anything else that changes between projections
      e.population_section->annual_cycle->randomise(e.RNG_seed);
      // do a 1-year projection
      e.population_section->run_model();
      e.population_section->annual_cycle->do_year(e.population_section->state,0,
                                                  "stochastic_simulation",current+1,
                                                  &e.population_section->requests,
                                                  &e.population_section->results,
                                                  constant_mortality,F_CAY,e.RNG_seed);
      // extract the projected catch for each stock
      if (n_stocks == 1){
        double projected_catch = total_catch<DVM>(e.population_section,current+1);
        (*projected_catches)[1][i] = projected_catch;
      } else {
        for (int stock=1; stock<=n_stocks; stock++){
          double projected_catch = total_catch<DVM>(e.population_section,current+1,stock);
          (*projected_catches)[stock][i] = projected_catch;
        }
      }
    }
  } else if (n_parameter_sets > 1){
    // one projection per parameter set
    projected_catches = new dmatrix(1,n_stocks,1,n_parameter_sets);
    for (int i=1; i<=n_parameter_sets; i++){
      // get a set of free parameters
      e.free_parameters->set(free_parameter_values[i]);
      e.insert_free_parameters();
      // randomise the YCS and anything else that changes between projections
      e.population_section->annual_cycle->randomise(e.RNG_seed);
      // do a 1-year projection
      e.population_section->run_model();
      e.population_section->annual_cycle->do_year(e.population_section->state,0,
                                                  "stochastic_simulation",current+1,
                                                  &e.population_section->requests,
                                                  &e.population_section->results,
                                                  constant_mortality,F_CAY,e.RNG_seed);
      // extract the projected catch for each stock
      if (n_stocks == 1){
        double projected_catch = total_catch<DVM>(e.population_section,current+1);
        (*projected_catches)[1][i] = projected_catch;
      } else {
        for (int stock=1; stock<=n_stocks; stock++){
          double projected_catch = total_catch<DVM>(e.population_section,current+1,stock);
          (*projected_catches)[stock][i] = projected_catch;
        }
      }
    }
  }
  // return chasing_BMSY->assess_frequency to the original value
  constant_mortality->assess_frequency = old_assess_frequency;
  // done the projections, calculate the CAY for each stock from the results
  dvector CAY(1,n_stocks);
  for (int i=1; i<=n_stocks; i++){
    CAY[i] = mean((*projected_catches)[i]);}
  return CAY;
}

template<CDVM>
double expected_stock_level(Estimation_section<DVM>& e,
                            const dmatrix& free_parameter_values, int n_simulations){
  // Called by MCY_CAY(). Used to calculate the 'current MCY' as opposed to the 'long-term MCY'.
  // Calculates the expectation of (current SSB / B0) using projection, given an Estimation_section
  //  to use for projection, a matrix of parameter sets, and a number of simulations
  //  to be done (this last is only used if only 1 parameter set is provided)
  // The projection population_section should have requests already set for B0 and SSB.
  DEBUG0("expected_stock_level");
  int n_parameter_sets = free_parameter_values.rowsize();
  int current = e.population_section->annual_cycle->current;
  dvector *Bcurrent_over_B0;
  if (n_parameter_sets == 1){
    Bcurrent_over_B0 = new dvector(1,n_simulations);
    e.free_parameters->set(free_parameter_values[1]);
    e.insert_free_parameters();
    for (int i=1; i<=n_simulations; i++){
      // randomise the YCS and anything else that changes between projections
      e.population_section->annual_cycle->randomise(e.RNG_seed);
      // run the model
      e.population_section->run_model();
      // extract the Bcurrent and B0
      double Bcurrent, B0;
      Bcurrent = (*(e.population_section->results.SSBs))[1][current]; // assuming only 1 stock
      B0 = (*(e.population_section->results.B0))[1]; // assuming only 1 stock
      (*Bcurrent_over_B0)[i] = Bcurrent / B0;
    }
  } else if (n_parameter_sets > 1){
    // one projection per parameter set
    Bcurrent_over_B0 = new dvector(1,n_parameter_sets);
    for (int i=1; i<=n_parameter_sets; i++){
      // get a set of free parameters
      e.free_parameters->set(free_parameter_values[i]);
      e.insert_free_parameters();
      // randomise the YCS and anything else that changes between projections
      e.population_section->annual_cycle->randomise(e.RNG_seed);
      // run the model
      e.population_section->run_model();
      // extract the Bcurrent and B0
      double Bcurrent, B0;
      Bcurrent = (*(e.population_section->results.SSBs))[1][current]; // assuming only 1 stock
      B0 = (*(e.population_section->results.B0))[1]; // assuming only 1 stock
      (*Bcurrent_over_B0)[i] = Bcurrent / B0;
    }
  }
  // done the projections, calculate the expected stock level from the results
  double expected_stock_level = mean(*Bcurrent_over_B0);
  return expected_stock_level;
}

template<CDVM>
void CSP(Estimation_section<DVM>& e,
         dmatrix& free_parameter_values,
         Parameter_set<DVM>& o){
  // Calculate CSP.
  DEBUG0("CSP");
  int n_stocks = e.population_section->state.n_stocks;
  std::vector<std::string> stock_names = e.population_section->state.stock_names;
  int do_CSP = o.get_bool("CSP.do_CSP",0);
  int individual_stocks = o.get_bool("CSP.individual_stocks",0);
  double guess = o.get_int("CSP.CSP_guess");
  // How is Bpost defined?
  int last_fishery_step = (int)max(*(e.population_section->annual_cycle->fishery_times));
  int step = o.get_int("B_post.step",last_fishery_step);
  double proportion_mortality = o.get_constant("B_post.proportion_mortality",1);
  std::string area = o.get_string("B_post.area","");
  std::string selectivity = o.get_string("B_post.selectivity","");
  int mature_only = o.get_bool("B_post.mature_only",1);
  // Send requests for the calculation of Bpost to the Population_section
  // In a multi-stock model, one Bpost per stock
  for (int i=1; i<=n_stocks; i++){
    std::string command;
    if (n_stocks == 1){
      command = "abundance[Bpost].";
    } else if (n_stocks > 1){
      command = "abundance[Bpost." + stock_names[i] + "].";
      e.p.put_string(command + "stock",stock_names[i]);
    }
    e.p.put_int(command + "step",step);
    e.p.put_constant(command + "proportion_mortality",proportion_mortality);
    if (area != ""){
      e.p.put_string(command + "area",area);}
    if (selectivity != ""){
      e.p.put_string(command + "ogive",selectivity);}
    e.p.put_int(command + "mature_only",mature_only);
    e.p.put_int(command + "biomass",1);
    dvector years(1,2);
    int current = e.population_section->annual_cycle->current;
    years[1] = current;
    years[2] = current+1;
    e.p.put_constant_vector(command + "years",years);
  }
  // Other requests to the population section
  e.p.put_int("requests.actual_catches",1);
  if (n_stocks > 1){
    e.p.put_int("requests.actual_catches_by_stock",1);}
  if (o.get_bool("print.yields",1)){
    // Print a description of the CSP calculation
    cout << "Calculate CSP.\n";
    cout << "Use Bpost = " << (mature_only ? "mature biomass" : "biomass");
    cout << " in time step " + itos(step);
    cout << " after proportion " + dtos(proportion_mortality) + " of the mortality";
    if (e.p.get_int("n_areas") > 1){
      if (area==""){
        cout << " in all areas";
      } else {
        cout << " in area " + area;
      }
    }
    if (selectivity != ""){
      cout << " applying the selectivity ogive " + selectivity;}
    cout << ".\n";
    cout << "Use an initial guess of " << guess << ".\n";
    if (n_stocks > 1){
      cout << "Figure CSP ";
      if (individual_stocks){
        cout << "separately for individual stocks.\n";
      } else {
        cout << "for all stocks combined.\n";
      }
    }
    cout << "\n";
  }
  // Make a Harvest_strategy object to handle the catch in year 'current+1'.
  Constant_catch<DVM> next_catch(o,e.p,0);
  // Create the object used to calculate expectations of Bpost in years (current) and (current+1)
  Get_E_Bpost<DVM> get_E_Bpost(&e, &next_catch, &free_parameter_values, e.RNG_seed, o);
  // Now figure CSP:
  if (n_stocks == 1 || !individual_stocks){
    double CSP = maximise_yield< Get_E_Bpost<DVM> >(get_E_Bpost,guess,1,cout);
    cout << "CSP = " << CSP << '\n';
  } else if (n_stocks > 1 && individual_stocks){
    dvector CSPs(1,n_stocks);
    for (int stock=1; stock<=n_stocks; stock++){
      get_E_Bpost.stock_to_analyse = stock;
      double CSP_catch = maximise_yield< Get_E_Bpost<DVM> >(get_E_Bpost,guess,1,cout);
      dmatrix result(get_E_Bpost.get(CSP_catch,0));
      CSPs[stock] = result[stock][3];
    }
    for (int stock=1; stock<=n_stocks; stock++){
      cout << "CSP for stock " << e.population_section->state.stock_names[stock] << " = " << CSPs[stock] << '\n';
    }
  }
  cout << '\n';
}

template<CDVM>
double Get_E_Bpost<DVM>::operator()(double catches, int print, ostream& out){
  // return squared difference between sum(E(Bpost(current+1))) and sum(E(Bpost(current))),
  // unless there are multiple stocks and the individual_stocks switch is on,
  //  in which case return the squared difference between E(Bpost(current+1)) and E(Bpost(current))
  //  for stock 'stock_to_analyse'.
  // The total catch should be non-negative and we return a very large -ve value otherwise.
  DEBUG0("Get_E_Bpost::operator()");
  if (catches<0) return -1e18;
  dmatrix result(get(catches,print,out));
  double difference = 0;
  if (n_stocks==1 || !individual_stocks){
    for (int stock=1; stock<=n_stocks; stock++){
      difference += result[stock][1] - result[stock][2];}
  } else if (n_stocks>1 && individual_stocks){
    difference = result[stock_to_analyse][1] - result[stock_to_analyse][2];
  }
  return -(difference*difference);
}

template<CDVM>
dmatrix Get_E_Bpost<DVM>::get(double catches, int print, ostream& out){
  // Calculate E(Bpost(current)), E(Bpost(current+1)), E(actual catch(current))
  //  for a given total catch in year (current+1).
  // Return a matrix with one row per stock.
  // If 1 set of free parameter values was supplied, we do n_simulations runs,
  // if more than one set, then we do one row per set.
  DEBUG0("Get_E_Bpost::get");
  RNG_reset(RNG_seed); // so we get the same random numbers each time
  dmatrix result(1,n_stocks,1,3);
  std::vector<dmatrix> individual_sim_results;
  dmatrix sim_result(1,n_stocks,1,3);
  dvector Bpost_current(1,n_stocks);
  dvector Bpost_next(1,n_stocks);
  dvector actual_catch(1,n_stocks);
  if (n_parameter_sets == 1){
    // use the single set of free parameters provided
    e->free_parameters->set((*free_parameter_values)[1]);
    e->insert_free_parameters();
    for (int i=1; i<=n_simulations; i++){
      e->population_section->annual_cycle->randomise(RNG_seed);
      e->population_section->run_model();
      e->population_section->annual_cycle->do_year(e->population_section->state,0,
                                                   "stochastic_simulation",current+1,
                                                   &(e->population_section->requests),
                                                   &(e->population_section->results),
                                                   next_catch, catches, RNG_seed);
      for (int stock=1; stock<=n_stocks; stock++){
        if (n_stocks == 1){
          Bpost_current[stock] = e->population_section->results.abundance["Bpost"][current];
          Bpost_next[stock] = e->population_section->results.abundance["Bpost"][current+1];
          actual_catch[stock] = total_catch<DVM>(e->population_section,current+1);
        } else if (n_stocks > 1){
          Bpost_current[stock] = e->population_section->results.abundance["Bpost."+stock_names[stock]][current];
          Bpost_next[stock] = e->population_section->results.abundance["Bpost."+stock_names[stock]][current+1];
          actual_catch[stock] = total_catch<DVM>(e->population_section,current+1,stock);
        }
      }
      sim_result.colfill(1,Bpost_current);
      sim_result.colfill(2,Bpost_next);
      sim_result.colfill(3,actual_catch);
      individual_sim_results.push_back(sim_result);
    }
  } else if (n_parameter_sets > 1){
    // do one simulation from each parameter set
    for (int i=1; i<=n_parameter_sets; i++){
      e->free_parameters->set((*free_parameter_values)[i]);
      e->insert_free_parameters();
      e->population_section->annual_cycle->randomise(RNG_seed);
      e->population_section->run_model();
      e->population_section->annual_cycle->do_year(e->population_section->state,0,
                                                   "stochastic_simulation",current+1,
                                                   &(e->population_section->requests),
                                                   &(e->population_section->results),
                                                   next_catch, catches, RNG_seed);
      for (int stock=1; stock<=n_stocks; stock++){
        if (n_stocks==1){
          Bpost_current[stock] = e->population_section->results.abundance["Bpost"][current];
          Bpost_next[stock] = e->population_section->results.abundance["Bpost"][current+1];
          actual_catch[stock] = total_catch<DVM>(e->population_section,current+1);
        } else if (n_stocks>1){
          Bpost_current[stock] = e->population_section->results.abundance["Bpost."+stock_names[stock]][current];
          Bpost_next[stock] = e->population_section->results.abundance["Bpost."+stock_names[stock]][current+1];
          actual_catch[stock] = total_catch<DVM>(e->population_section,current+1,stock);
        }
      }
      sim_result.colfill(1,Bpost_current);
      sim_result.colfill(2,Bpost_next);
      sim_result.colfill(3,actual_catch);
      individual_sim_results.push_back(sim_result);
    }
  }
  // take an average over simulations
  result = 0;
  for (int i=0; i<n_simulations; i++){
    result += individual_sim_results[i];}
  result /= n_simulations;
  if (print){
    if (n_stocks == 1){
      out << "total_catch " << catches << " E(Bpost(current)) " << result[1][1] << " E(Bpost(current+1)) " << result[1][2] << " E(actual_catch(current+1)) " << result[1][3] << '\n';
    } else {
      out << "With total catch = " << catches << ",\n";
      out << "stock E(Bpost(current)) E(Bpost(current+1)) E(actual_catch(current+1))\n";
      for (int stock=1; stock<=n_stocks; stock++){
        out << stock_names[stock] << ' ' << result[stock] << '\n';}
      out << '\n';
    }
  }
  return result;
}

template<CDVM>
Get_E_Bpost<DVM>::Get_E_Bpost(Estimation_section<DVM>* _e,
                              Harvest_strategy<DVM>* _next_catch,
                              dmatrix* _free_parameter_values,
                              long _RNG_seed,
                              Parameter_set<DVM>& o){
  // Construct the calculation object
  DEBUG0("Get_E_Bpost::Get_E_Bpost");
  e = _e;
  next_catch = _next_catch;
  free_parameter_values = _free_parameter_values;
  RNG_seed = _RNG_seed;
  n_parameter_sets = free_parameter_values->rowsize();
  if (n_parameter_sets == 1){
    n_simulations = o.get_int("CSP.n_simulations",100);
  } else {
    n_simulations = n_parameter_sets;
  }
  n_stocks = e->population_section->state.n_stocks;
  stock_names = e->population_section->state.stock_names;
  if (n_stocks > 1){
    individual_stocks = o.get_bool("CSP.individual_stocks",0);
  } else {
    individual_stocks = 1;
  }
  current = e->population_section->annual_cycle->current;
}

//########################## HARVEST STRATEGIES ##########################
template<CDVM>
int Harvest_strategy<DVM>::constant_instantaneous_mortality(){
  // generally the instantaneous mortality is not constant
  return 0;
}

template<CDVM>
double Harvest_strategy<DVM>::get_abundance_multiplier(long seed){
  // only applies for Constant_catch with initial abundance error
  return 1;
}

template<CDVM>
int Harvest_strategy<DVM>::use_abundance_multiplier(long seed){
  // only for Constant_catch with initial abundance error
  return 0;
}

template<CDVM>
dvector Constant_catch<DVM>::get_catch(double harvest_rate, const VECTOR& last_SSB,
                                       const VECTOR& B0, const DOUBLE& abundance,
                                       long seed, int first_year,
                                       DOUBLE last_year_total_catch, int year){
  // Calculate the catch under a constant catch strategy.
  DEBUG1("Constant_catch::get_catch");
  double TAC = harvest_rate;
  if (year!=0 /* not a deterministic sim */ && this->assess_frequency>1 && ((year % this->assess_frequency)!=1)){
          TAC = last_year_total_catch; // no assessment this year
  } else {
    if (MCY_targs){
                // We may reduce the TAC if current biomass is low
                double Bprevious = last_SSB[1]; // assumption of only 1 stock
                double Bprevious_error;
                if (seed<=0 || Bprevious_error_dist=="none"){
                   // if this is not a stochastic sim, then Bprevious_error_dist has already been set to 'none'
                   Bprevious_error = 1;
                } else if (Bprevious_error_dist == "lognormal"){
                   Bprevious_error = rlognorm(1, Bprevious_error_cv, seed);
                } else if (Bprevious_error_dist == "normal"){
                   Bprevious_error = rnorm(1, Bprevious_error_cv, seed);
                }
    if (Bprevious_error < 0) Bprevious_error = 0;
                Bprevious *= Bprevious_error;
                if (Bprevious < Btarg){
                        // Reduce catch - biomass is under target
                        TAC *= Bprevious/Btarg;
                }
        }
  }
  return TAC * catch_split;
}

template<CDVM>
double Constant_catch<DVM>::get_abundance_multiplier(long seed){
  double multiplier = 1;
  if (seed>=0 && abundance_error_dist != "none" && abundance_error_cv!=0){
        if (abundance_error_dist == "lognormal"){
          multiplier = rlognorm(1, abundance_error_cv, seed);
        } else if (abundance_error_dist == "normal"){
          multiplier = rnorm(1, abundance_error_cv, seed);
        }
  if (multiplier < 0) multiplier = 0;
  }
  return multiplier;
}

template<CDVM>
int Constant_catch<DVM>::use_abundance_multiplier(long seed){
  return (seed>=0 && abundance_error_dist != "none" && abundance_error_cv!=0);
}

template<CDVM>
void Constant_catch<DVM>::print(ostream& out){
  DEBUG2("Constant_catch::print");
  out << "constant catch. ";
  if (n_fisheries > 1){
    out << "Fixed catch split of: ";
    for (int i=1; i<=n_fisheries; i++){
      out << "(" << fishery_names[i] << ") " << catch_split[i] << ' ';
    }
    out << ". ";
  }
  if (abundance_error_dist != "none"){
    out << "A " << abundance_error_dist << " error with c.v. " << abundance_error_cv << " is applied to initial abundance. ";
  }
  if (MCY_targs){
          out << "If Bprevious, the previous year's SSB, is less than Btarg = " << Btarg << ", the catch is reduced to H * (Bprevious / Btarg). ";
          if (Bprevious_error_dist != "none"){
                out << "A " << Bprevious_error_dist << " error with c.v. " << Bprevious_error_cv << " is applied to Bprevious when determining catches, to reflect the effects of annual stock assessment uncertainty. ";
          }
  }
  if (this->assess_frequency>1){
          out << "TAC is only changed every " << this->assess_frequency << " years (to simulate the effects of time gaps between assessments).";
  }
}

template<CDVM>
Constant_catch<DVM>::Constant_catch(Parameter_set<DVM>& o,
                                    Parameter_set<DVM>& p,
                                    int stochastic)
  : n_fisheries(p.get_vector_of_strings("annual_cycle.fishery_names").size())
  , catch_split(1,n_fisheries){
  // Build the Constant_catch.
  // Just need to extract the catch split from the estimation Parameter_set
  //  and read off the fishery names from the population Parameter_set (for printing)
  // Set 'stochastic' to 1 if this is for a stochastic simulation (then abundance errors can be included)
  DEBUG1("Constant_catch::Constant_catch");
  if (n_fisheries==1){
    catch_split[1] = 1;
  } else {
    if (o.get_constant_vector("catch_split").size()!=n_fisheries){
      fatal("The @catch_split vector is the wrong length - should be "+itos(n_fisheries));
    }
    catch_split = o.get_constant_vector("catch_split");
    catch_split /= sum(catch_split);
    fishery_names = p.get_vector_of_strings("annual_cycle.fishery_names");
    fishery_names.insert(fishery_names.begin(),""); // so that indices start from 1
  }
  if (stochastic){
    abundance_error_dist = o.get_string("MCY_CAY.MCY_uncertainty_dist","none");
    if (abundance_error_dist != "none"){
      abundance_error_cv = o.get_constant("MCY_CAY.MCY_uncertainty_cv",0.2);
      if (abundance_error_cv > 0 && p.get_int("n_stocks",1)>1){
    fatal("You have supplied MCY_CAY.MCY_uncertainty_* in a multi-stock model - this combination is not allowed.");
    }
  }
    Bprevious_error_dist = o.get_string("MCY_CAY.Bprevious_uncertainty_dist","none");
    if (Bprevious_error_dist != "none"){
      Bprevious_error_cv = o.get_constant("MCY_CAY.Bprevious_uncertainty_cv",0.2);}
  } else {
    abundance_error_dist = "none";
    Bprevious_error_dist = "none";
  }
  this->assess_frequency = o.get_int("MCY_CAY.assess_frequency",1);
  if (this->assess_frequency<1) fatal("MCY_CAY.assess_frequency should be an integer >= 1");
  MCY_targs = o.get_bool("MCY_CAY.MCY_targs",0);
  if (MCY_targs){
    if (p.get_int("n_stocks",1) > 1) fatal("You have set the MCY_targs switch in MCY_CAY to True. This is only valid in a single-stock model.");
    Btarg = o.get_constant("MCY_CAY.Btarg");
  }
}

template<CDVM>
dvector Constant_exploitation_rate<DVM>::get_catch(double harvest_rate,
                                                   const VECTOR& last_SSB, const VECTOR& B0,
                                                   const DOUBLE& abundance, long seed, int first_year,
                                                   DOUBLE last_year_total_catch, int year){
  // Calculate the catch under a constant exploitation rate strategy.
  // With seed<0, do not apply the normal error.
  DEBUG1("Constant_exploitation_rate::get_catch");
  if (year!=0 /* not a deterministic sim */ && this->assess_frequency>1 && ((year % this->assess_frequency)!=1)){
          double TAC = value(last_year_total_catch); // no assessment this year
          return TAC * catch_split;
  } else {
    double F = harvest_rate;
    double error;
    if (seed<0 || abundance_error_dist == "none"){
      error = 1;
    } else if (abundance_error_dist == "lognormal"){
      error = rlognorm(1, abundance_error_cv, seed);
    } else if (abundance_error_dist == "normal"){
      error = fmax(rnorm(1, abundance_error_cv, seed),0);
    }
    return F * abundance * error * catch_split;
  }
}

template<CDVM>
void Constant_exploitation_rate<DVM>::print(ostream& out){
  DEBUG2("Constant_exploitation_rate::print");
  out << "constant exploitation rate (catch / Bpre) not an instantaneous mortality rate. Bpre is defined as " << description_of_abundance << ". ";
  if (n_fisheries > 1){
    out << "Fixed catch split of: ";
    for (int i=1; i<=n_fisheries; i++){
      out << "(" << fishery_names[i] << ") " << catch_split[i] << ' ';
    }
    out << ". ";
  }
  if (abundance_error_dist != "none"){
    out << "A " << abundance_error_dist << " error with c.v. " << abundance_error_cv << " is applied to the actual abundance when determining catches, to reflect the effects of annual stock assessment uncertainty. ";
  }
  if (this->assess_frequency>1){
          out << "TAC is only changed every " << this->assess_frequency << " years (to simulate the effects of time gaps between assessments).";
  }
}

template<CDVM>
Constant_exploitation_rate<DVM>::Constant_exploitation_rate(Parameter_set<DVM>& o,
                                                            Parameter_set<DVM>& p,
                                                            const std::string& _description_of_abundance,
                                                            int stochastic)
  : n_fisheries(p.get_vector_of_strings("annual_cycle.fishery_names").size())
  , catch_split(1,n_fisheries){
  // Build the Constant_exploitation_rate.
  // Need to extract the catch split from the estimation Parameter_set and set up for
  //   generation of random errors.
  // Also read off the fishery names from the population Parameter_set (for printing)
  // The string argument is a description of the measure of abundance used,
  //   passed so that it can be printed out by Constant_exploitation_rate::print.
  // Set 'stochastic' to 1 if this is for a stochastic simulation (then abundance errors can be included)
  DEBUG1("Constant_exploitation_rate::Constant_exploitation_rate");
  if (n_fisheries==1){
    catch_split[1] = 1;
  } else {
    if (o.get_constant_vector("catch_split").size()!=n_fisheries){
      fatal("The @catch_split vector is the wrong length - should be "+itos(n_fisheries));
    }
    catch_split = o.get_constant_vector("catch_split");
    catch_split /= sum(catch_split);
    fishery_names = p.get_vector_of_strings("annual_cycle.fishery_names");
    fishery_names.insert(fishery_names.begin(),""); // so that indices start from 1
  }
  description_of_abundance = _description_of_abundance;
  if (stochastic){
    abundance_error_dist = o.get_string("MCY_CAY.CAY_uncertainty_dist","lognormal");
    if (abundance_error_dist != "none"){
      abundance_error_cv = o.get_constant("MCY_CAY.CAY_uncertainty_cv",0.2);
    }
  } else {
    abundance_error_dist = "none";
  }
  this->assess_frequency = o.get_int("MCY_CAY.assess_frequency",1);
  if (this->assess_frequency<1) fatal("MCY_CAY.assess_frequency should be an integer >= 1");
}

template<CDVM>
dvector Constant_instantaneous_mortality<DVM>::get_catch(double harvest_rate,
                                                         const VECTOR& last_SSB, const VECTOR& B0,
                                                         const DOUBLE& abundance, long seed, int first_year,
                                                         DOUBLE last_year_total_catch, int year){
  /* Not used - the fishing mortality function applies the F to determine the catch */
  DEBUG2("Constant_instantaneous_mortality::get_catch");
  fatal("get_catch() should not be called for Constant_instantaneous_mortality");
  return 0;
 }

template<CDVM>
void Constant_instantaneous_mortality<DVM>::print(ostream& out){
  DEBUG2("Constant_instantaneous_mortality::print");
  out << "constant instantaneous mortality - the harvest rate is the F of the Baranov equation.";
}

template<CDVM>
Constant_instantaneous_mortality<DVM>::Constant_instantaneous_mortality(Parameter_set<DVM>& o){
  // not much to do
  DEBUG1("Constant_instantaneous_mortality::Constant_instantaneous_mortality");
  if (o.get_int("MCY_CAY.assess_frequency",1)!=1) fatal("MCY_CAY.assess_frequency must be 1 when you are calculating CAY with constant instantaneous mortality (as opposed to constant exploitation rate)");
}

template<CDVM>
dvector Chasing_BMSY<DVM>::get_catch(double harvest_rate, const VECTOR& last_SSB,
                                     const VECTOR& B0, const DOUBLE& abundance,
                                     long seed, int first_year,
                                     DOUBLE last_year_total_catch, int year){
  // Calculate the catch under a chasing-BMSY strategy.
  DEBUG1("Chasing_BMSY::get_catch");
  if (M==-1 || Btarg==-1) fatal("You must supply M and Btarg in the @MCY_CAY block if you are doing 'chasing BMSY'");
  double TAC;
  n_calls++;
  if (year!=0 /* not a deterministic sim */ && this->assess_frequency>1 && ((year % this->assess_frequency)!=1)){
          TAC = last_year_total_catch; // no assessment this year - use last year's TAC
  } else {
    // cerr << "year " << year << " B0 " << B0[1] << " Bprevious " << last_SSB[1] ;
    double R0 = B0[1] * (1-exp(-M)); // assumption of only 1 stock
    double Bprevious = last_SSB[1]; // assumption of only 1 stock
    double Bprevious_error;
    if (seed<=0 || Bprevious_error_dist=="none"){
           // if this is not a stochastic sim, then Bprevious_error_dist has already been set to 'none'
           Bprevious_error = 1;
        } else if (Bprevious_error_dist == "lognormal"){
       Bprevious_error = rlognorm(1, Bprevious_error_cv, seed);
    } else if (Bprevious_error_dist == "normal"){
       Bprevious_error = rnorm(1, Bprevious_error_cv, seed);
    }
    if (Bprevious_error < 0) Bprevious_error = 0;
    Bprevious *= Bprevious_error;
    if (!simple_R && last_year_TAC!=-1 && second_last_SSB!=-1 && (year>0 || n_calls>5) && year!=1){
                double Bprev2 = second_last_SSB;
                double Bprev2_error;
                if (seed<=0 || Bprevious_error_dist=="none"){
                   // if this is not a stochastic sim, then Bprevious_error_dist has already been set to 'none'
                   Bprev2_error = 1;
                } else if (Bprevious_error_dist == "lognormal"){
                   Bprev2_error = rlognorm(1, Bprevious_error_cv, seed);
                } else if (Bprevious_error_dist == "normal"){
                   Bprev2_error = rnorm(1, Bprevious_error_cv, seed);
                }
    if (Bprev2_error < 0) Bprev2_error = 0;
                Bprev2 *= Bprev2_error;
                /* In the following formula, we really should use the last year's total catch,
                  but we approximate with the TAC during the initialization period. */
                R = Bprevious - Bprev2*exp(-M) + (year==0 ? last_year_TAC : last_year_total_catch);
        } else if (BH_SR){
                R = (R0*Bprevious/B0[1])/(1-((5*steepness-1)/(4*steepness))*(1-(Bprevious/B0[1])));
        } else R = R0;
    double p = harvest_rate;
    if (this->assess_frequency==1){
                TAC = Bprevious * exp(-M) + R - p * Btarg - (1-p) * Bprevious;
        } else {
                double summation = 0;
                for (int i=1; i<=this->assess_frequency; i++){
                        summation += exp(-M*(i-1));
                }
                TAC = R + (Bprevious*(exp(-(this->assess_frequency)*M)-(1-p))-p*Btarg)/summation;
        }
  }
  if (TAC<0) TAC=0;
  // cerr << " TAC " << TAC << '\n';
  last_year_TAC = TAC;
  second_last_SSB = last_SSB[1];
  return TAC * catch_split;
}

template<CDVM>
void Chasing_BMSY<DVM>::print(ostream& out){
  DEBUG2("Chasing_BMSY::print");
  out << "p parameter in 'chasing B_MSY' strategy. The catch C is chosen to solve ";
  if (this->assess_frequency==1){
          out << "(Bprevious*exp(-M) - C + R) = p*Btarg + (1-p)Bprevious, ";
  } else if (this->assess_frequency>1){
          out << "C = R + [(Bprevious*(exp(-kM)-(1-p))-p*Btarg)/(sum over i=1..k of exp(-M*(i-1)))], ";
  }
  out << "where p is the 'chasing rate', Btarg is a target biomass of " << Btarg << ", Bprevious is the SSB for the previous year, M is a nominal natural mortality of " << M;
  out << ", R is chosen as ";
  if (!simple_R){
        out << "Bprevious - Bprev2*exp(-M) + Cprevious, where Bprev2 is the SSB from 2 years ago and Cprevious is last year's actual catch";
  } else {
          if (simple_R && BH_SR){
                  out << "(R0*Bprevious/B0)/(1-((5h-1)/(4h))*(1-(Bprevious/B0))), where h = Beverton-Holt steepness = " << steepness << " and R0 = ";
          } else {
                  out << "R0 = ";
          }
          out << "B0(1-exp(-M))";
  }
  if (this->assess_frequency>1){
          out << " and k = " << this->assess_frequency << ". TAC is only changed every " << this->assess_frequency << " years (to simulate the effects of time gaps between assessments). ";
  } else {
          out << ". ";
  }
  if (n_fisheries > 1){
    out << "Fixed catch split of: ";
    for (int i=1; i<=n_fisheries; i++){
      out << "(" << fishery_names[i] << ") " << catch_split[i] << ' ';
    }
    out << ". ";
  }
  if (Bprevious_error_dist != "none"){
    out << "A " << Bprevious_error_dist << " error with c.v. " << Bprevious_error_cv << " is applied to Bprevious " << (simple_R ? "and Bprev2 " : "") << "when determining catches, to reflect the effects of annual stock assessment uncertainty. ";
  }
}

template<CDVM>
void Chasing_BMSY<DVM>::refresh(){
        // Empty the 2nd last SSB and last TAC fields.
        // These will be filled in as the simulation run proceeds.
        // The -1 means a value not to be used
        //  (i.e. no calls yet since the last refresh)
        DEBUG2("Chasing_BMSY::Chasing_BMSY");
        second_last_SSB = -1;
        last_year_TAC = -1;
        n_calls = 0;
}

template<CDVM>
Chasing_BMSY<DVM>::Chasing_BMSY(Parameter_set<DVM>& o,
                                Parameter_set<DVM>& p,
                                int stochastic)
  : n_fisheries(p.get_vector_of_strings("annual_cycle.fishery_names").size())
  , catch_split(1,n_fisheries){
  // Build the Chasing_BMSY.
  // Need to extract the catch split from the estimation Parameter_set
  //  and read off the fishery names from the population Parameter_set (for printing)
  // And set up the constants for the biomass projection equation.
  // Set 'stochastic' to 1 if this is for a stochastic simulation (then abundance errors can be included)
  DEBUG1("Chasing_BMSY::Chasing_BMSY");
  if (o.get_bool("MCY_CAY.do_CBMSY",0) && p.get_int("n_stocks",1) > 1) fatal("You have asked for 'chasing BMSY'. This is only valid in a single-stock model.");
  M = o.get_constant("MCY_CAY.M_for_CBMSY",-1);
  Btarg = o.get_constant("MCY_CAY.Btarg",-1);
  simple_R = o.get_int("MCY_CAY.CBMSY_simple_R",0);
  // R will be calculated in the get_catch function since this sees B0
  if (n_fisheries==1){
    catch_split[1] = 1;
  } else {
    if (o.get_constant_vector("catch_split").size()!=n_fisheries){
      fatal("The @catch_split vector is the wrong length - should be "+itos(n_fisheries));
    }
    catch_split = o.get_constant_vector("catch_split");
    catch_split /= sum(catch_split);
    fishery_names = p.get_vector_of_strings("annual_cycle.fishery_names");
    fishery_names.insert(fishery_names.begin(),""); // so that indices start from 1
  }
  if (stochastic){
    Bprevious_error_dist = o.get_string("MCY_CAY.Bprevious_uncertainty_dist","none");
    if (Bprevious_error_dist != "none"){
      Bprevious_error_cv = o.get_constant("MCY_CAY.Bprevious_uncertainty_cv",0.2);}
  } else {
    Bprevious_error_dist = "none";
  }
  std::string simulation_SR = p.get_string("recruitment.SR","none");
  if (simulation_SR=="none"){
          BH_SR = 0;
  } else if (simulation_SR=="BH"){
      BH_SR = 1;
      steepness = p.get_constant("recruitment.steepness");
  } else {
          fatal("You can only use CBMSY with a BH stock-recruit relationship or none at all.");
  }
  this->assess_frequency = o.get_int("MCY_CAY.assess_frequency",1);
  if (this->assess_frequency<1) fatal("MCY_CAY.assess_frequency should be an integer >= 1");
}

//############################## END OF YIELDS.cpp ##############################

// Create particular instantiations of the template
template void per_recruit_and_deterministic_MSY(
                        Estimation_section<double, dvector, dmatrix>&,
                        const dvector&,
                        Parameter_set<double, dvector, dmatrix>&, int);

template void CSP(Estimation_section<double, dvector, dmatrix>&,
                  dmatrix&,
                  Parameter_set<double, dvector, dmatrix>&);

template void MCY_CAY(Estimation_section<double, dvector, dmatrix>&,
                      Estimation_section<double, dvector, dmatrix>&,
                      dmatrix&,
                      Parameter_set<double, dvector, dmatrix>&);
