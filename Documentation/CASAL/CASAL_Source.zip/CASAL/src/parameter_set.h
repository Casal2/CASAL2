// const char* time_stamp = "$Date: 2006-08-08 15:18:31 +1200 (Tue, 08 Aug 2006) $\n";
// const char* parameter_set_id = "$Id: parameter_set.h 1593 2006-08-08 03:18:31Z adunn $\n";

#if !defined(PARAMETER_SET)
#define PARAMETER_SET

//############################## PARAMETER SETS ##############################
#include <string>
#include <map>
#include <iostream>
#include "development.h"
#include "dictionary.h"

// Forward declarations
template <CDVM> class Size_at_age;
template <CDVM> class Ogive;

//////////////////////////////////////////////////////////////////////////////////
template<CDVM> class Parameter_set{
  // The Parameter_set comprises a bunch of containers for various sorts
  // of parameters. There is a 'strings' section, which can contain actual string parameters,
  // or any of the other kinds of parameters, stored as strings. There are also 'doubles',
  // 'vectors', and 'ogives' sections, which contain potentially free numeric parameters,
  // stored as DOUBLE, VECTOR, and Ogive* respectively.
  //
  // One way to get parameters into a Parameter_set is to extract them from an input
  // file using read_file(). This dumps them into the 'strings' section, without
  // converting them into numbers, or even checking whether they are valid numbers.
  // Another way is to insert them using the put_ functions - see below.
  //
  // When the program needs to read a parameter from the Parameter_set, it uses the
  // get_ functions. A simple example (with Parameter_set p):
  //
  // int size_based = p.get_bool("size_based");
  //
  // If the size_based parameter is not in the Parameter_set, the program says so
  // and errors out. Alternatively, give it a default argument:
  //
  // int size_based = p.get_bool("size_based",0);
  //
  // get_bool interprets T/true/t/1  as 1, and F/false/f/0  as 0.
  //
  // get_int interprets T, true or t as 1, and F, false or f as 0. However, for
  // retrieving the values of parameters that take boolean values, this function
  // is now superseeded by the function  get_bool.
  //
  // Other get_ functions include
  // get_constant, get_estimable, get_constant_vector, get_estimable_vector, get_ogive_values,
  // get_ogive_base, get_ogive_type, get_ogive_free_parameters, get_string, get_vector_of_strings.
  //
  // get_constant returns a double and get_estimable returns a DOUBLE.
  // get_constant_vector returns a dvector and get_estimable_vector returns a VECTOR;
  //   in both cases the indices always start at 1.
  // get_string returns a std::string and get_vector_of_strings returns a std::vector<std::string>.
  // The get_ogive_values function returns a VECTOR whose indices cover the range of
  //   columns in the partition. If the ogive is size-based in an age-based model, then
  //   you need to pass it a pointer to the size-at-age object, and the year, time step
  //   and row of the partition for which the ogive is calculated (otherwise omit these arguments
  //   or pass zeros). get_ogive_values() can hence calculate mean sizes-at-age at that time,
  //   and use them to convert the size-based ogive into an age-based ogive. The results will only
  //   be correct for that time step if fish growth occurs between birthdays, and will only be correct
  //   for that year if size-at-age varies between years. It is the calling program's
  //   responsibility to make sure that the results are not used for other times.
  //   The last argument of get_ogive_values is a shift, which moves the ogive horizontally.
  //   This is not possible with some ogive types.
  // There is also a get_ogive_base function which returns 1 if the ogive is
  //  size-based or 0 if age-based, get_ogive_type which returns the type of the ogive as a string,
  //  and get_ogive_free_parameters which returns the free parameters of the ogive as a vector.
  //
  // All the get_ functions except the get_ogive_ ones take default arguments.
  // (But don't use -999 or a vector containing a single -999 as a default - these are used
  //  internally to say "no default".)
  //
  // If a get() function is asked to find "command[1].subcommand",
  //  it will look for "command.subcommand" instead. (Because the first instance of
  //  a command in a datafile yields the parameter command.subcommand, as opposed to the second,
  //  which yields command[2].subcommand.)
  // (Similarly, put() functions asked to insert "command[1].subcommand"
  //  will insert "command.subcommand" instead.)
  //
  // Also see present(), which says whether a parameter is in the set, and if so, in which compartment.
  //
  // Some examples follow, using Parameter_set p taken from the following (incomplete)
  // command-block file:
  //
  // # My command file
  //
  // @size_based 0 # (or F, f, false)
  // @fishery_names trawl longline
  // @modeller_name brian
  //
  // @recruitment
  // YCS 1.1 1.2 0.8
  //
  // @natural_mortality
  // all 0.3
  //
  // @maturation
  // rates_all sizebased logistic 35 22
  //
  // @maturation
  // rates_male constant 0.3
  // rates_female constant 0.4
  //
  // @fishery trawl
  // catches 100 120 130
  // U_max 0.8
  //
  // @fishery longline
  // catches 120 80 110
  //
  // and the following commands:
  //
  // int size_based = p.get_bool("size_based");
  //    // 0
  // int mature_partition = p.get_bool("mature_partition");
  //    // fatal error
  // int mature_partition = p.get_bool("mature_partition",0);
  //    // 0
  // double U_max = p.get_constant("fishery[trawl].U_max");
  //    // 0.8
  // DOUBLE M = p.get_estimable("natural_mortality.rates_all");
  //    // 0.3
  // dvector catch(p.get_constant_vector("fishery[longline].catches"));
  //    // 120 80 110 (indices 1,2,3)
  // dvector class_mins(p.get_constant_vector("class_mins",dvector("{4,6,8}"));
  //    // 4 6 8 (indices 1,2,3)
  // VECTOR YCS(p.get_estimable_vector("recruitment.YCS"));
  //    // 1.1 1.2 0.8 (indices 1,2,3)
  // VECTOR k(p.get_estimable_vector("size_at_age.k",VECTOR("{0.1,0.2}")));
  //    // 0.1 0.2 (indices 1,2,3)
  // std::string modeller = p.get_string("modeller");
  //    // "brian"
  // std::vector<std::string> names = p.get_vector_of_strings("fishery_names");
  //    // "trawl", "longline"
  // p.get_ogive_base("maturation[2].rates_male");
  //    // 1 (age-based)
  // p.get_ogive_free_parameters("maturation[2].rates_male");
  //    // 0.3
  // VECTOR maturation_rates(p.get_ogive_values("maturation[2].rates_male"));
  //    // values of 0.3 for all indices, index range equal to the range of
  //    // columns in the partition
  // p.get_ogive_base("maturation[1].rates_all");
  //    // 1 (size-based)
  // p.get_ogive_free_parameters("maturation[1].rates_male");
  //    // 35 22
  //
  // The Parameter_set keeps count of the number of occurrences of each command in
  // the 'command_counts' object. Access this by get_command_count: in the above example,
  // get_command_count("fishery")==2.
  // get_command_labels("fishery") would return a std::vector containing "trawl", "longline".
  // Note that if you make changes to how Parameter_set works, you need to make sure
  // command_counts is updated whenever parameters are added or removed.
  //
  // A Parameter_set has four compartments to store parameters in.
  // In the first 'string' compartment, parameter arguments are stored in strings,
  // as described above. This is fine for parameters which have been read in from
  // a datafile. However, if the Parameter_set is being used to convey free parameters
  // between the estimation and population sections, it needs to carry them as numeric
  // objects. (If instead they were converted into strings at one end and back into
  // numbers at the other, then Betadiff would lose track of them and not be able to
  // differentiate.) So, the other three 'numeric' compartments of the Parameter_set
  // hold parameters whose arguments are stored as DOUBLEs, VECTORs, and pointers to ogives.
  // The get_estimable, get_estimable_vector, get_ogive commands look in the numeric compartments
  // before looking in the string compartment. The put_estimable, put_estimable_vector,
  // and put_ogive_parameters commands (see below) insert parameters into these numeric compartments,
  // effectively overwriting the string versions.
  //
  // The put_ functions are used to insert parameters into the Parameter_set.
  // They are put_int, put_constant, put_estimable, put_constant_vector,
  // put_estimable_vector, put_ogive, put_string, and put_vector_of_strings.
  // Put_constant_vector and put_estimable_vector only accept vectors whose indices start at 1 (because
  // the corresponding get_ functions always produce vectors whose indices start at 1).
  // Put_ogive should be used to supply a new set of free parameters for an ogive which
  // is already in the Parameter_set (it errors out if the ogive is not there already).
  //
  // Note also that the ogive member functions need to know what indices the ogives
  // should have. This is not known at the time when the Parameter_set is constructed
  // or filled in, so the relevant information is filled in by set_ogive_unpacker_members()
  // the first time a get_ogive or put_ogive function is called.
  //
  // Just added a check on which parameters are accessed
  // A std::map of parameter names is created by read_file():
  // the values of the map are 0 ('not accessed') and are changed to 1 ('accessed') whenever the
  // relevant parameter is looked at by present(), and hence by any get() function.
  // The get_unused() function returns a std::vector containing all entries of the map
  //  which still have 0 values, i.e. all those parameters which were never accessed.
  // Note that it only returns parameters read in using read_file(), not those added by CASAL
  // via the put_ functions.
  //
  // BB, Mar 2003
  // Just added testing of commands read in read_file, using the global dictionary object
  //  which lists all legitimate commands and subcommands. Error out if any unrecognised command is issued.
public:
  void read_file(const std::string& filename, std::string file);
  int get_bool(const std::string& s, const int default_val = -999);
  int  get_int(const std::string& s, const int default_val = -999);
  double get_constant(const std::string& s, const double default_val = -999);
  DOUBLE get_estimable(const std::string& s, const DOUBLE& default_val = -999);
  dvector get_constant_vector(const std::string& s, const dvector& default_val = dvector("{-999}"));
  VECTOR get_estimable_vector(const std::string& s, const VECTOR& default_val = VECTOR("{-999}"));
  VECTOR get_ogive_values(const std::string& s, Size_at_age<DVM> *size_at_age = 0,
                          int year = 0, int step = 0, int row = 0, const DOUBLE& shift = -999,
                          VECTOR* at_sizes = 0);
  std::string get_string(const std::string& s, const std::string& default_val = "don't use default");
  std::vector<std::string> get_vector_of_strings(const std::string& s,
          const std::vector<std::string>& default_val = std::vector<std::string>(1,"don't use default"));
  int get_ogive_base(const std::string& s);
  std::string get_ogive_type(const std::string& s);
  VECTOR get_ogive_free_parameters(const std::string& s);
  int present(const std::string& s);
  int get_command_count(const std::string& s);
  std::vector<std::string> get_command_labels(const std::string& s);
  void empty();
  void put_int(std::string name, int i);
  void put_constant(std::string name, double d);
  void put_estimable(std::string name, DOUBLE d);
  void put_constant_vector(std::string name, const dvector& v);
  void put_estimable_vector(std::string name, const VECTOR& v);
  void put_ogive(std::string name, const VECTOR& v);
  void put_string(std::string name, const std::string& s);
  void put_vector_of_strings(std::string name, std::vector<std::string>& vs);
  std::map<std::string,int> parameters_accessed;
  std::vector<std::string> get_unused(ostream& out = cout);
  void extract_subcommands_of_command(Parameter_set<DVM>& to, std::string command, std::string label);
  void dump_as_subcommands(ostream &o);
  void print(ostream& out = cout);
  Parameter_set(const Parameter_set& p){fatal("never copy-construct a Parameter_set");}
  Parameter_set();
  ~Parameter_set();
  Dictionary& dictionary() {return dict;}
private:
  std::map<std::string,std::string> strings;
  // contains all string data, and any numeric data stored as strings
  std::map<std::string,DOUBLE> doubles;
  std::map<std::string,VECTOR> vectors;
  std::map<std::string,Ogive<DVM>*> ogives;
  // these three members contain any data stored in numeric form
  std::map<std::string,int> command_counts;
  void update_command_counts(std::string& name);
  int low, high, size_based;
  dvector *class_sizes;
  int n_quant;
  dvector *quantiles, *quantiles_at;
  // these last seven members are used to unpack ogives
  int ogive_unpacker_members_done;
  void set_ogive_unpacker_members();
  Dictionary dict; // NOTE: added by GJM
};

void decompose(const std::string &parname, std::string &command, std::string &label, std::string &subcommand);
std::string decompose_into_words(const std::string &parname);

int isws(const std::string &s);

template<CDVM>
std::string check_parname(std::string& parname, Parameter_set<DVM>& p, Parameter_set<DVM>& e, std::string source, std::vector<std::string>& permitted_types);

//############################## END OF PARAMETER_SET.h ##############################
#endif
