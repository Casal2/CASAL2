// const char* time_stamp = "$Date: 2011-04-01 14:43:13 +1300 (Fri, 01 Apr 2011) $\n";
// const char* user_likelihood_cpp_id = "$Id: user.likelihood.cpp 4010 2011-04-01 01:43:13Z dunn $\n";

#ifndef USER_LIKELIHOOD_CPP
#define USER_LIKELIHOOD_CPP

//############################# USER LIKELIHOOD.cpp ##########################################
#include "development.h"

//////////////////////////////////////////////////////////////////////////////////////////////
template<CDVM>
DOUBLE user_likelihood(std::string& label, const MATRIX& fits, const MATRIX& observations){

/*
   *** TEMPLATE - BRIAN BULL, 23/5/02 ***

   Use this function to implement new likelihood functions.

   This function takes the observations and fits, and returns the negative-log-likelihoods.

   You need to set the 'dist' argument for each set of observations for which you are supplying
    a likelihood to 'user_supplied'.

   You cannot use nuisance q's for relative time series with user-defined likelihoods (use free q's instead).

   The inputs to this function are the text label of a time series and the observations and fits.
     The obs and fits are stored as matrices. There is one row per year. For abundance data, there is one column.
        For all other data, there is one column per age or size class, per sex if they are sexed observations,
         with males before females. This is exactly the same as the format used by CASAL to print the data.
   The output is the corresponding negative-log-likelihood.
   If you want to use user-defined likelihoods for more than one time series, then you may need to put in
     an if-statement based on the 'label' argument, which tells you which time series is currently being dealt with.

   You need to use the DOUBLE, VECTOR, and MATRIX classes which are templates either for double, dvector and dmatrix
     or for dvariable, dvv, and dvm (apart from double, these are Betadiff classes: see betadiff.h) Note that the indices
     of these VECTORs and MATRIXs should always start at 1 (in this particular function)
*/

/*
   Insert your documentation here!
*/

  DEBUG1("user_likelihood");
  return 0;
  // remove the following line
  fatal("You are using the default 'user.likelihood.cpp', but have requested a user-supplied likelihood. You need to modify the CASAL source and recompile.");

/*
   Insert your code here!
*/

}
//############################# END OF USER LIKELIHOOD.cpp ##########################################
#endif
