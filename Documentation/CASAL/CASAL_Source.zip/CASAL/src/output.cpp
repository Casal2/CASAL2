// const char* time_stamp = "$Date: 2012-05-18 09:49:20 +1200 (Fri, 18 May 2012) $\n";
// const char* output_cpp_id = "$Id: output.cpp 4743 2012-05-17 21:49:20Z Dunn $\n";

//############################## REQUESTS FOR PRINTING ##############################
#include "parameter_set.h"
#include "output.h"
#include "estimation_section.h"
#include "observations.h"
#include "likelihoods.h"
#include "population_processes.h"

///////////////////////////////////////////////////////////////////////////////////////
Print_requests::Print_requests(Parameter_set<double,dvector,dmatrix>& o,
                               int suppress_population_printing)
  : print_sizebased_ogives_at(o.get_constant_vector("print_sizebased_ogives_at",dvector("{-1}"))){
  DEBUG2("Print_requests::Print_requests");

  parameters = o.get_bool("print.parameters",0);
  unused_parameters = o.get_bool("print.unused_parameters",0);
  estimation_section = o.get_bool("print.estimation_section",0);
  fits = o.get_bool("print.fits",0);
  fits_every_eval = o.get_bool("print.fits_every_eval",0);
  resids = o.get_bool("print.resids",0);
  pearson_resids = o.get_bool("print.pearson_resids",0);
  normalised_resids = o.get_bool("print.normalised_resids",0);
  objective_every_eval = o.get_bool("print.objective_every_eval",0);
  parameters_every_eval = o.get_bool("print.parameters_every_eval",0);
  parameter_vector_every_eval = o.get_bool("print.parameter_vector_every_eval",0);
  covariance = o.get_bool("print.covariance",0);
  eigenvalues = o.get_bool("print.eigenvalues",0);
  printHessian = o.get_bool("print.hessian",0);
  yield_diagnostic_output = o.get_bool("print.yield_diagnostic_output",0);

  if (!suppress_population_printing){
    population_section = o.get_bool("print.population_section",0);
    if (population_section) every_mean_size = o.get_bool("print.every_mean_size",0);
    requests = o.get_bool("print.requests",0);
    results = o.get_bool("print.results",0);
    initial_state = o.get_bool("print.initial_state",0);
    state_annually = o.get_bool("print.state_annually",0);
    state_every_step = o.get_bool("print.state_every_step",0);
    final_state = o.get_bool("print.final_state",0);
  } else {
    population_section = 0;
    requests = 0;
    results = 0;
    initial_state = 0;
    state_annually = 0;
    state_every_step = 0;
    final_state = 0;
  }
}

//############################## OUTPUT QUANTITIES ##############################
void Quantity_requests::set_request_parameters(Parameter_set<double,dvector,dmatrix>& p){
  // Add any necessary requests for results to the population Parameter_set.
  // Called by Quantity_results::get().
  DEBUG1("Quantity_requests::set_request_parameters");
  if (B0) p.put_int("requests.B0",1);
  if (R0) p.put_int("requests.R0",1);
  if (Binitial) p.put_int("requests.Binitial",1);
  if (Rinitial) p.put_int("requests.Rinitial",1);
  if (Bmean) p.put_int("requests.Bmean",1);
  if (Rmean) p.put_int("requests.Rmean",1);
  if (disease_biomass_loss) p.put_int("requests.disease_biomass_loss",1);
  if (recruitments.size() > 0) p.put_int("requests.recruitments",1);
  if (YCS.size() > 0) p.put_int("requests.YCS",1);
  if (true_YCS.size() > 0) p.put_int("requests.true_YCS",1);
  if (Ts.size() > 0) p.put_int("requests.Ts",1);
  if (migration_annual_variation.size() > 0) p.put_int("requests.migration_annual_variation",1);
  if (SSBs.size() > 0) p.put_int("requests.SSBs",1);
  if (actual_catches.size() > 0){
    if (!(catches_by_stock | catches_by_area)) p.put_int("requests.actual_catches",1);
  else {
    if (catches_by_stock) p.put_int("requests.actual_catches_by_stock",1);
      if (catches_by_area) p.put_int("requests.actual_catches_by_area",1);
  }
    if (removals) p.put_int("requests.removals",1);
    if (discards) p.put_int("requests.discards",1);
  }
  if (fishing_pressures.size() > 0) p.put_int("requests.fishing_pressure",1);
}

Quantity_requests::Quantity_requests(Parameter_set<double,dvector,dmatrix>& o,Estimation_section<double,dvector,dmatrix>& estimation_section, int _projection)
  : print_sizebased_ogives_at(o.get_constant_vector("print_sizebased_ogives_at",dvector("{-1}"))){
  // Construct the Quantity_requests from the output parameter set,
  //  drawing information about model structure from the estimation_section as necessary.
  DEBUG1("Quantity_requests::Quantity_requests");
  initial = estimation_section.population_section->annual_cycle->initial;
  current = estimation_section.population_section->annual_cycle->current;
  final = estimation_section.population_section->annual_cycle->final;
  y_enter = estimation_section.p.get_int("y_enter");
  projection = _projection;
  if (o.get_bool("quantities.all_free_parameters",0)){
    for (int i=0; i<estimation_section.free_parameters->n_scalars; i++){
      scalar_parameters.push_back(estimation_section.free_parameters->scalar_parameter_names[i]);
    }
    for (int i=0; i<estimation_section.free_parameters->n_vectors; i++){
      if (estimation_section.free_parameters->vector_parameter_is_ogive[i]){
        ogive_parameters.push_back(estimation_section.free_parameters->vector_parameter_names[i]);
      } else {
        vector_parameters.push_back(estimation_section.free_parameters->vector_parameter_names[i]);
      }
    }
  }
  std::vector<std::string> scalars;
  scalars.push_back("int");
  scalars.push_back("constant");
  scalars.push_back("estimable");
  if (o.present("quantities.scalar_parameters")){
    std::vector<std::string> parameter_names = o.get_vector_of_strings("quantities.scalar_parameters");
    for (int i=0; i<parameter_names.size(); i++){
                check_parname(parameter_names[i],estimation_section.p,estimation_section.e,"list of scalar parameters in quantities block",scalars);
      if (!in(scalar_parameters,parameter_names[i])){
        scalar_parameters.push_back(parameter_names[i]);}
    }
  }
  std::vector<std::string> vectors;
  vectors.push_back("constant_vector");
  vectors.push_back("estimable_vector");
  if (o.present("quantities.vector_parameters")){
    std::vector<std::string> parameter_names = o.get_vector_of_strings("quantities.vector_parameters");
    for (int i=0; i<parameter_names.size(); i++){
      if (!in(vector_parameters,parameter_names[i])){
                check_parname(parameter_names[i],estimation_section.p,estimation_section.e,"list of vector parameters in quantities block",vectors);
        vector_parameters.push_back(parameter_names[i]);}
    }
  }
  std::vector<std::string> ogives;
  ogives.push_back("ogive");
  if (o.present("quantities.ogive_parameters")){
    std::vector<std::string> parameter_names = o.get_vector_of_strings("quantities.ogive_parameters");
    for (int i=0; i<parameter_names.size(); i++){
      if (!in(ogive_parameters,parameter_names[i])){
                check_parname(parameter_names[i],estimation_section.p,estimation_section.e,"list of ogive parameters in quantities block",ogives);
        ogive_parameters.push_back(parameter_names[i]);}
    }
  }
  if (o.present("quantities.ogive_arguments")){
    std::vector<std::string> ogive_argument_names = o.get_vector_of_strings("quantities.ogive_arguments");
    for (int i=0; i<ogive_argument_names.size(); i++){
      if (!in(ogive_arguments,ogive_argument_names[i])){
                check_parname(ogive_argument_names[i],estimation_section.p,estimation_section.e,"list of ogive arguments in quantities block",ogives);
        ogive_arguments.push_back(ogive_argument_names[i]);}
    }
  }
  nuisance_qs = o.get_bool("quantities.nuisance_qs",0);
  B0 = o.get_bool("quantities.B0",0);
  R0 = o.get_bool("quantities.R0",0);
  Binitial = o.get_bool("quantities.Binitial",0);
  Rinitial = o.get_bool("quantities.Rinitial",0);
  Bmean = o.get_bool("quantities.Bmean",0);
  Rmean = o.get_bool("quantities.Rmean",0);
  if (o.get_bool("quantities.SSBs",0)){
    for (int year=initial; year<=current; year++){
      SSBs.push_back(year);}
    if (projection){
      for (int year=(current+1); year<=final; year++){
        SSBs.push_back(year);}
    }
  }
  if (o.get_bool("quantities.recruitments",0)){
    for (int year=initial; year<=current; year++){
      recruitments.push_back(year);}
    if (projection){
      for (int year=(current+1); year<=final; year++){
        recruitments.push_back(year);}
    }
  }
  if (o.get_bool("quantities.YCS",0)){
    for (int year=initial; year<=current; year++){
      YCS.push_back(year-y_enter);}
    if (projection){
      for (int year=(current+1); year<=final; year++){
        YCS.push_back(year-y_enter);}
    }
  }
  if (o.get_bool("quantities.true_YCS",0)){
    for (int year=initial; year<=current; year++){
      true_YCS.push_back(year-y_enter);}
    if (projection){
      for (int year=(current+1); year<=final; year++){
        true_YCS.push_back(year-y_enter);}
    }
  }
  if (o.get_bool("quantities.Ts",0)){
    for (int year=initial; year<=current; year++){
      Ts.push_back(year-y_enter);}
    if (projection){
      for (int year=(current+1); year<=final; year++){
        Ts.push_back(year-y_enter);}
    }
  }
  if (o.get_bool("quantities.migration_annual_variation",0)){
    for (int year=initial; year<=current; year++){
      migration_annual_variation.push_back(year);}
    if (projection){
      for (int year=(current+1); year<=final; year++){
        migration_annual_variation.push_back(year);}
    }
  }

  if (o.get_bool("quantities.actual_catches",0) || o.get_bool("quantities.actual_catches_by_stock",0) || o.get_bool("quantities.actual_catches_by_area",0)){
    if (o.get_bool("quantities.actual_catches_by_stock",0)){
      if (o.get_bool("quantities.actual_catches",0)){
        fatal("Please ask for either quantities.actual_catches or quantities.actual_catches_by_stock, but not both.");
      } else {
        catches_by_stock = 1;
      }
  } else {
      catches_by_stock = 0;
    }
    if (o.get_bool("quantities.actual_catches_by_area",0)){
      if (o.get_bool("quantities.actual_catches",0)){
        fatal("Please ask for either quantities.actual_catches or quantities.actual_catches_by_stock, but not both.");
      } else {
        catches_by_area = 1;
      }
  } else {
      catches_by_area = 0;
    }
    removals = o.get_bool("quantities.removals",0);
    discards = o.get_bool("quantities.discards",0);
    for (int year=initial; year<=current; year++){
      actual_catches.push_back(year);}
    if (projection){
      for (int year=(current+1); year<=final; year++){
        actual_catches.push_back(year);}
    }
  } else if (o.get_bool("quantities.removals",0) || o.get_bool("quantities.discards",0)){
    fatal("If you ask for quantities.discards or quantities.removals, then you also need to request either quantities.actual_catches or quantities.actual_catches_by_stock");
  }
  fits = o.get_bool("quantities.fits",0);
  resids = o.get_bool("quantities.resids",0);
  pearson_resids = o.get_bool("quantities.pearson_resids",0);
  normalised_resids = o.get_bool("quantities.normalised_resids",0);
  if (projection){
    stock_crash = o.get_bool("quantities.stock_crash",0);
    if (stock_crash && (!o.get_bool("quantities.SSBs",0) || !o.get_bool("quantities.B0",0))){
      fatal("If you ask for quantities.stock_crash, please also ask for quantities.SSBs and quantities.B0.");}
  } else stock_crash = 0;
  if (o.get_bool("quantities.fishing_pressures",0)){
    for (int year=initial; year<=current; year++){
      fishing_pressures.push_back(year);}
    if (projection){
      for (int year=(current+1); year<=final; year++){
        fishing_pressures.push_back(year);}
    }
  }
  tagged_age_distribution = o.get_bool("quantities.tagged_age_distribution",0);
  disease_biomass_loss = o.get_bool("quantities.disease_biomass_loss",0);
  pseudo_observations = new Observations_dataset<double,dvector,dmatrix>(*(estimation_section.population_section),estimation_section.ageing_error,o,1);
  original_observations = estimation_section.observations_dataset;
}

Quantity_requests::~Quantity_requests(){
  // delete the pseudo-observations dataset
  DEBUG2("~Quantity_requests");
  delete pseudo_observations;
}

void Quantity_results::get(Quantity_requests& quantity_requests, Estimation_section<double,dvector,dmatrix>& estimation){
  // Empty the results object. Switch from the original observations
  // to the pseudo-observations, place any necessary requests with the population section, run it,
  // calculate the pseudo-fits, extract the various results, and put back the original observations.
  //
  // When you use this function, MAKE SURE you have already inserted the free parameter values
  // by estimation.free_parameters->set() and estimation.insert_free_parameters().
  //
  // Note, this function does change the population section -
  // you will want to call set_annual_cycle() before running it again afterwards.
  DEBUG0("Quantity_results::get");
  empty();
  Basic_population_section<double,dvector,dmatrix> *population_section = estimation.population_section; // for shorthand
  // Extract nuisance q's, fits, resids if requested
  // (before we ditch the original Observations_dataset)
  // In this case we need to rerun the model
  if (quantity_requests.nuisance_qs || quantity_requests.fits || quantity_requests.resids || quantity_requests.pearson_resids || quantity_requests.normalised_resids){
    population_section->run_model(quantity_requests.current);
        if (quantity_requests.nuisance_qs){
                if (estimation.q_method != "nuisance"){
                fatal("nuisance q's have been requested as an output quantity, but q's are not nuisance parameters");
        }
            estimation.qs->get_nuisance_qs(*population_section);
            nuisance_qs_names = estimation.qs->q_names;
            for (int i=0; i<nuisance_qs_names.size(); i++){
                nuisance_qs.push_back(estimation.qs->q[nuisance_qs_names[i]]);
            }
        }
        if (quantity_requests.fits || quantity_requests.resids || quantity_requests.pearson_resids || quantity_requests.normalised_resids){
                estimation.observations_dataset->calculate_fits(*population_section);
                for (int i=0; i<estimation.observations_dataset->obs.size(); i++){
                        if (estimation.observations_dataset->obs[i]->fits_resids_defined()){
                        if (quantity_requests.fits) fits.push_back(*(estimation.observations_dataset->obs[i]->fits));
                        if (quantity_requests.resids) resids.push_back(estimation.observations_dataset->obs[i]->get_resids());
                        if (quantity_requests.pearson_resids) pearson_resids.push_back(estimation.observations_dataset->obs[i]->get_pearson_resids());
                        if (quantity_requests.normalised_resids){
                                  if (estimation.observations_dataset->obs[i]->objective->normalised_resids_defined()){
                                          normalised_resids.push_back(estimation.observations_dataset->obs[i]->get_normalised_resids());
                                          normalised_resids_exist.push_back(1);
                          } else {
                                          normalised_resids.push_back(dmatrix());
                                          normalised_resids_exist.push_back(0);
                                  }
                        }
                        fits_exist.push_back(1);
                        fits_resids_labels.push_back(estimation.observations_dataset->obs[i]->label);
                        fits_resids_years.push_back(*(estimation.observations_dataset->obs[i]->years));
                        } else { // these observations have no fits or residuals
                                if (quantity_requests.fits) fits.push_back(dmatrix());
                                if (quantity_requests.resids) resids.push_back(dmatrix());
                                if (quantity_requests.pearson_resids) pearson_resids.push_back(dmatrix());
                                if (quantity_requests.normalised_resids){
                                        normalised_resids.push_back(dmatrix());
                                        normalised_resids_exist.push_back(0);
                                }
                                fits_exist.push_back(0);
                                fits_resids_labels.push_back("");
                                fits_resids_years.push_back(dvector());
                        }
                }
        }
  }
  // Switch from the original Observations_dataset to the pseudo-observations
  estimation.observations_dataset = quantity_requests.pseudo_observations;
  // Place any requests for results which will be needed from the Population_section
  quantity_requests.set_request_parameters(estimation.p);
  estimation.observations_dataset->set_request_parameters(estimation.p);
  population_section->set_requests(estimation.p);
  // Run the population section
  if (quantity_requests.projection){
    population_section->run_model(quantity_requests.final);
  } else {
    population_section->run_model(quantity_requests.current);
  }
  int sizebased_model = estimation.p.get_bool("size_based",0);
  // Extract any requested parameter values from the population Parameter_set
  // if they're not in there, look in the free parameters object instead
  for (int i=0; i<quantity_requests.scalar_parameters.size(); i++){
    std::string parname = quantity_requests.scalar_parameters[i];
    if (estimation.p.present(parname)){
      scalar_parameters.push_back(estimation.p.get_estimable(parname));
    } else {
      int index = pos(estimation.free_parameters->scalar_parameter_names,parname);
      if (index < 0) fatal("Failed to find the scalar parameter " + parname + " which should be printed out\n");
      scalar_parameters.push_back(estimation.free_parameters->get_scalar(index));
    }
  }
  for (int i=0; i<quantity_requests.vector_parameters.size(); i++){
    vector_parameters.push_back(estimation.p.get_estimable_vector(quantity_requests.vector_parameters[i]));
  }

  for (int i=0; i<quantity_requests.ogive_parameters.size(); i++){
    std::string ogive_name = quantity_requests.ogive_parameters[i];
    if (!sizebased_model && estimation.p.get_ogive_base(ogive_name)==1){
      // it's a size-based ogive in an age-based model
      if (quantity_requests.print_sizebased_ogives_at[1]==-1){
            cerr << "If you want to print size-based selectivities in an age-based model, you need to provide the output parameter print_sizebased_ogives_at.\n";
        ogive_parameters.push_back(dvector());
        ogives_sizebased_in_agebased.push_back(-99);
      }
      else{
        ogive_parameters.push_back(estimation.p.get_ogive_values(ogive_name,0,0,0,0,0,
                                                       &(quantity_requests.print_sizebased_ogives_at)));
        ogives_sizebased_in_agebased.push_back(1);
      }
    }
    else { // straightforward
      ogive_parameters.push_back(estimation.p.get_ogive_values(ogive_name));
      ogives_sizebased_in_agebased.push_back(0);
    }
  }


  // Extract any requested ogive arguments from the population Parameter_set
  for (int i=0; i<quantity_requests.ogive_arguments.size(); i++){
    ogive_arguments.push_back(estimation.p.get_ogive_free_parameters(quantity_requests.ogive_arguments[i]));
  }
  // get fishery and stock names
  n_stocks = population_section->state.n_stocks;
  if (n_stocks > 1){
    stock_names.resize(n_stocks);
    for (int i=0; i<n_stocks; i++){
      stock_names[i] = population_section->state.stock_names[i+1];}
  }
  n_fisheries = population_section->annual_cycle->fishery_names.size()-1;
  fishery_names.resize(n_fisheries);
  for (int i=0; i<n_fisheries; i++){
    fishery_names[i] = population_section->annual_cycle->fishery_names[i+1];
  }
  n_areas = population_section->state.n_areas;
  if (n_areas > 1){
    area_names.resize(n_areas);
    for (int i=0; i<n_areas; i++){
    area_names[i] = population_section->state.area_names[i+1];}
  }

  // get names of migrations with annual variations
  for (int i=1; i<=population_section->annual_cycle->n_migrations;i++) {
     if(population_section->annual_cycle->migration[i]->annual_varying){
      migration_annual_variation_names.push_back(population_section->annual_cycle->migration_names[i]);
   }
  }

  // Extract B0, R0, Binitial, Rinitial, Bmean, Rmean if requested
  if (quantity_requests.B0){
    for (int i=1; i<=n_stocks; i++){
      B0.push_back((*(population_section->results.B0))[i]);
    }
  }
  if (quantity_requests.R0){
    for (int i=1; i<=n_stocks; i++){
      R0.push_back((*(population_section->results.R0))[i]);
    }
  }
  if (quantity_requests.Binitial){
    for (int i=1; i<=n_stocks; i++){
      Binitial.push_back((*(population_section->results.Binitial))[i]);
    }
  }
  if (quantity_requests.Rinitial){
    for (int i=1; i<=n_stocks; i++){
      Rinitial.push_back((*(population_section->results.Rinitial))[i]);
    }
  }
  if (quantity_requests.Bmean){
    for (int i=1; i<=n_stocks; i++){
      Bmean.push_back((*(population_section->results.Bmean))[i]);
    }
  }
  if (quantity_requests.Rmean){
    for (int i=1; i<=n_stocks; i++){
      Rmean.push_back((*(population_section->results.Rmean))[i]);
    }
  }
  // get SSBs for the requested years for each stock
  if (quantity_requests.SSBs.size() > 0){
    for (int i=1; i<=n_stocks; i++){
      dvector stock_SSBs((*(population_section->results.SSBs))[i]);
      dvector selected_SSBs(1,quantity_requests.SSBs.size());
      for (int j=0; j<quantity_requests.SSBs.size(); j++){
        selected_SSBs[j+1] = stock_SSBs[quantity_requests.SSBs[j]];
      }
      SSBs.push_back(selected_SSBs);
    }
  }
  // get absolute recruitments for the requested years for each stock
  if (quantity_requests.recruitments.size() > 0){
    for (int i=1; i<=n_stocks; i++){
      dvector stock_recruitments((*(population_section->results.recruitments))[i]);
      dvector selected_recruitments(1,quantity_requests.recruitments.size());
      for (int j=0; j<quantity_requests.recruitments.size(); j++){
        selected_recruitments[j+1] = stock_recruitments[quantity_requests.recruitments[j]];
      }
      recruitments.push_back(selected_recruitments);
    }
  }
  // get YCS for the requested years for each stock
  if (quantity_requests.YCS.size() > 0){
    for (int i=1; i<=n_stocks; i++){
      dvector stock_YCS((*(population_section->results.YCS))[i]);
      dvector selected_YCS(1,quantity_requests.YCS.size());
      for (int j=0; j<quantity_requests.YCS.size(); j++){
        selected_YCS[j+1] = stock_YCS[quantity_requests.YCS[j]];
      }
      YCS.push_back(selected_YCS);
    }
  }
  // get true_YCS (YCS * CR * SR) for the requested years for each stock
  if (quantity_requests.true_YCS.size() > 0){
    for (int i=1; i<=n_stocks; i++){
      dvector stock_true_YCS((*(population_section->results.true_YCS))[i]);
      dvector selected_true_YCS(1,quantity_requests.true_YCS.size());
      for (int j=0; j<quantity_requests.true_YCS.size(); j++){
        selected_true_YCS[j+1] = stock_true_YCS[quantity_requests.true_YCS[j]];
      }
      true_YCS.push_back(selected_true_YCS);
    }
  }
  // get climate data T for the requested years for each stock
  if (quantity_requests.Ts.size() > 0){
    for (int i=1; i<=n_stocks; i++){
      dvector stock_Ts((*(population_section->results.Ts))[i]);
      dvector selected_Ts(1,quantity_requests.Ts.size());
      for (int j=0; j<quantity_requests.Ts.size(); j++){
        selected_Ts[j+1] = stock_Ts[quantity_requests.Ts[j]];
      }
      Ts.push_back(selected_Ts);
    }
  }
  // get  annual variation for the requested years for each migration with annual variation defined
  if (quantity_requests.migration_annual_variation.size() > 0){
     dvector annual_variation_by_year(1,quantity_requests.migration_annual_variation.size());
     for (int i=0; i<migration_annual_variation_names.size(); i++){
        std::string migration = migration_annual_variation_names[i];
        for (int j=0; j<quantity_requests.migration_annual_variation.size(); j++){
           int year = quantity_requests.migration_annual_variation[j];
       annual_variation_by_year[j+1] = population_section->results.migration_annual_variation[year][migration];
         }
        migration_annual_variation.push_back(annual_variation_by_year);
     }
  }

  // get actual catches for the requested years for each stock
  if (quantity_requests.actual_catches.size() > 0){
    if (!(quantity_requests.catches_by_stock | quantity_requests.catches_by_area)){
    dvector catches_by_year(1,quantity_requests.actual_catches.size());
    for (int i=0; i<n_fisheries; i++){
      std::string fishery = fishery_names[i];
      for (int j=0; j<quantity_requests.actual_catches.size(); j++){
        int year = quantity_requests.actual_catches[j];
        catches_by_year[j+1] = population_section->results.actual_catches[year][fishery];
      }
      actual_catches.push_back(catches_by_year);
    }
    if (quantity_requests.removals){
      dvector removals_by_year(1,quantity_requests.actual_catches.size());
      for (int i=0; i<n_fisheries; i++){
      std::string fishery = fishery_names[i];
      for (int j=0; j<quantity_requests.actual_catches.size(); j++){
        int year = quantity_requests.actual_catches[j];
        removals_by_year[j+1] = population_section->results.removals[year][fishery];
      }
      removals.push_back(removals_by_year);
      }
    }
    if (quantity_requests.discards){
      dvector discards_by_year(1,quantity_requests.actual_catches.size());
      for (int i=0; i<n_fisheries; i++){
        std::string fishery = fishery_names[i];
        for (int j=0; j<quantity_requests.actual_catches.size(); j++){
          int year = quantity_requests.actual_catches[j];
          discards_by_year[j+1] = population_section->results.discards[year][fishery];
        }
      discards.push_back(discards_by_year);
      }
    }
    } else {
    if (quantity_requests.catches_by_stock){
      actual_catches_by_stock.resize(n_fisheries);
      dvector catches_by_year_stock(1,quantity_requests.actual_catches.size());
      for (int i=0; i<n_fisheries; i++){
        std::string fishery = fishery_names[i];
        for (int k=0; k<n_stocks; k++){
          std::string stock = stock_names[k];
        for (int j=0; j<quantity_requests.actual_catches.size(); j++){
          int year = quantity_requests.actual_catches[j];
          catches_by_year_stock[j+1] = population_section->results.actual_catches_by_stock[year][fishery][stock];
        }
        actual_catches_by_stock[i].push_back(catches_by_year_stock);
        }
      }
      if (quantity_requests.removals){
        removals_by_stock.resize(n_fisheries);
        dvector removals_by_year_stock(1,quantity_requests.actual_catches.size());
        for (int i=0; i<n_fisheries; i++){
          std::string fishery = fishery_names[i];
          for (int k=0; k<n_stocks; k++){
            std::string stock = stock_names[k];
            for (int j=0; j<quantity_requests.actual_catches.size(); j++){
              int year = quantity_requests.actual_catches[j];
              removals_by_year_stock[j+1] = population_section->results.removals_by_stock[year][fishery][stock];
            }
          removals_by_stock[i].push_back(removals_by_year_stock);
          }
        }
      }
      if (quantity_requests.discards){
        discards_by_stock.resize(n_fisheries);
        dvector discards_by_year_stock(1,quantity_requests.actual_catches.size());
        for (int i=0; i<n_fisheries; i++){
        std::string fishery = fishery_names[i];
          for (int k=0; k<n_stocks; k++){
            std::string stock = stock_names[k];
            for (int j=0; j<quantity_requests.actual_catches.size(); j++){
              int year = quantity_requests.actual_catches[j];
              discards_by_year_stock[j+1] = population_section->results.discards_by_stock[year][fishery][stock];
            }
          discards_by_stock[i].push_back(discards_by_year_stock);
          }
        }
      }
    }
    if (quantity_requests.catches_by_area){
      actual_catches_by_area.resize(n_fisheries);
      dvector catches_by_year_area(1,quantity_requests.actual_catches.size());
      for (int i=0; i<n_fisheries; i++){
        std::string fishery = fishery_names[i];
        for (int k=0; k<n_areas; k++){
          std::string area = area_names[k];
        for (int j=0; j<quantity_requests.actual_catches.size(); j++){
          int year = quantity_requests.actual_catches[j];
          catches_by_year_area[j+1] = population_section->results.actual_catches_by_area[year][fishery][area];
        }
        actual_catches_by_area[i].push_back(catches_by_year_area);
        }
      }
      if (quantity_requests.removals){
        removals_by_area.resize(n_fisheries);
        dvector removals_by_year_area(1,quantity_requests.actual_catches.size());
        for (int i=0; i<n_fisheries; i++){
          std::string fishery = fishery_names[i];
          for (int k=0; k<n_areas; k++){
            std::string area = area_names[k];
            for (int j=0; j<quantity_requests.actual_catches.size(); j++){
              int year = quantity_requests.actual_catches[j];
              removals_by_year_area[j+1] = population_section->results.removals_by_area[year][fishery][area];
            }
          removals_by_area[i].push_back(removals_by_year_area);
          }
        }
      }
      if (quantity_requests.discards){
        discards_by_area.resize(n_fisheries);
        dvector discards_by_year_area(1,quantity_requests.actual_catches.size());
        for (int i=0; i<n_fisheries; i++){
        std::string fishery = fishery_names[i];
          for (int k=0; k<n_areas; k++){
            std::string area = area_names[k];
            for (int j=0; j<quantity_requests.actual_catches.size(); j++){
              int year = quantity_requests.actual_catches[j];
              discards_by_year_area[j+1] = population_section->results.discards_by_area[year][fishery][area];
            }
          discards_by_area[i].push_back(discards_by_year_area);
          }
        }
      }
    }
    }
  }
  // get fishing pressures for the requested years for each fishery
  if (quantity_requests.fishing_pressures.size() > 0){
    dvector pressures_by_year(1,quantity_requests.fishing_pressures.size());
    for (int i=0; i<n_fisheries; i++){
      std::string fishery = fishery_names[i];
      for (int j=0; j<quantity_requests.fishing_pressures.size(); j++){
        int year = quantity_requests.fishing_pressures[j];
        pressures_by_year[j+1] = population_section->results.fishing_pressure[year][fishery];
      }
      fishing_pressures.push_back(pressures_by_year);
    }
  }
  // get the projected 'stock_crash' event for each stock
  if (quantity_requests.stock_crash){
    for (int i=1; i<=n_stocks; i++){
      int crash = 0;
      for (int year = quantity_requests.current+1; year <= quantity_requests.final; year++){
        double stock_SSB = (*(population_section->results.SSBs))[i][year];
        if (stock_SSB < (0.2 * B0[i-1])) crash = 1;
      }
      stock_crash.push_back(crash);
    }
  }
  // get age frequencies of tagged fish for each tagging event
  if (quantity_requests.tagged_age_distribution){
    int n_tagging_events = population_section->annual_cycle->tagging.size()-1; // dummy element 0
    for (int i=1; i<=n_tagging_events; i++){
      if (population_section->annual_cycle->tagging[i]->release_type!="deterministic") continue;
      tagging_episode_labels.push_back(population_section->annual_cycle->tagging[i]->episode_label);
      int sexed = population_section->annual_cycle->tagging[i]->sexed;
      dmatrix age_distn(1,sexed+1,population_section->state.col_min,population_section->state.col_max);
      if (sexed){
        age_distn[1] = value(population_section->annual_cycle->tagging[i]->class_props_male);
        age_distn[2] = value(population_section->annual_cycle->tagging[i]->class_props_female);
        tagging_sexed.push_back(1);
      } else if (!sexed){
        age_distn[1] = value(population_section->annual_cycle->tagging[i]->class_props);
        tagging_sexed.push_back(0);
      }
      tagged_age_distributions.push_back(age_distn);
    }
  }
  // Get biomass loss due to disease
  if (quantity_requests.disease_biomass_loss){
   std::map<int,double>::iterator dit;
   for (dit=population_section->results.disease_biomass_loss.begin(); dit!=population_section->results.disease_biomass_loss.end(); dit++){
     disease_biomass_loss.push_back(make_pair(dit->first,value(dit->second)));
   }
  }
  // Extract the pseudo-fits
  estimation.observations_dataset->calculate_fits(*population_section);
  for (int i=0; i<estimation.observations_dataset->obs.size(); i++){
    pseudofits.push_back(*(estimation.observations_dataset->obs[i]->fits));
    pseudofits_labels.push_back(estimation.observations_dataset->obs[i]->label);
    pseudofits_years.push_back(*(estimation.observations_dataset->obs[i]->years));
  }
  // switch back to the original observations dataset
  estimation.observations_dataset = quantity_requests.original_observations;
}

void Quantity_results::empty(){
  DEBUG2("Quantity_results::empty");
  scalar_parameters = std::vector<double>();
  vector_parameters = std::vector<dvector>();
  ogive_parameters = std::vector<dvector>();
  ogive_arguments = std::vector<dvector>();
  nuisance_qs = std::vector<double>();
  nuisance_qs_names = std::vector<std::string>();
  B0 = std::vector<double>();
  R0 = std::vector<double>();
  Binitial = std::vector<double>();
  Rinitial = std::vector<double>();
  Bmean = std::vector<double>();
  Rmean = std::vector<double>();
  SSBs = std::vector<dvector>();
  recruitments = std::vector<dvector>();
  YCS = std::vector<dvector>();
  true_YCS = std::vector<dvector>();
  Ts = std::vector<dvector>();
  migration_annual_variation = std::vector<dvector>();
  migration_annual_variation_names = std::vector<std::string>();
  stock_crash = std::vector<int>();
  actual_catches = std::vector<dvector>();
  actual_catches_by_stock = std::vector<std::vector<dvector> >();
  actual_catches_by_area = std::vector<std::vector<dvector> >();
  removals = std::vector<dvector>();
  removals_by_stock = std::vector<std::vector<dvector> >();
  removals_by_area = std::vector<std::vector<dvector> >();
  discards = std::vector<dvector>();
  discards_by_stock = std::vector<std::vector<dvector> >();
  discards_by_area = std::vector<std::vector<dvector> >();
  fishing_pressures = std::vector<dvector>();
  stock_names = std::vector<std::string>();
  fishery_names = std::vector<std::string>();
  disease_biomass_loss = std::vector<pair<int,double> >();
  fits = std::vector<dmatrix>();
  resids = std::vector<dmatrix>();
  pearson_resids = std::vector<dmatrix>();
  normalised_resids = std::vector<dmatrix>();
  normalised_resids_exist = std::vector<int>();
  fits_exist = std::vector<int>();
  fits_resids_labels = std::vector<std::string>();
  fits_resids_years = std::vector<dvector>();
  tagging_episode_labels = std::vector<std::string>();
  tagged_age_distributions = std::vector<dmatrix>();
  tagging_sexed = std::vector<int>();
  pseudofits = std::vector<dmatrix>();
  pseudofits_labels = std::vector<std::string>();
  pseudofits_years = std::vector<dvector>();
}

std::string Quantity_results::make_header(Quantity_requests& quantity_requests){
  // Create a string containing the header row of a table of quantity values, in which
  // each row is generated by Quantity_results::make_vector(). Should have already called get().
  DEBUG1("Quantity_results::make_header");
  n_quantities = 0;
  std::string result= "";
  for (int i=0; i<scalar_parameters.size(); i++){
    result += (quantity_requests.scalar_parameters[i] + " ");
    n_quantities++;
  }
  for (int i=0; i<vector_parameters.size(); i++){
    for (int j=1; j<=vector_parameters[i].size(); j++){
      result += (quantity_requests.vector_parameters[i] + "[" + itos(j) + "] ");
      n_quantities++;
    }
  }
  for (int i=0; i<ogive_parameters.size(); i++){
    for (int j=ogive_parameters[i].indexmin(); j<=ogive_parameters[i].indexmax(); j++){
      if (ogives_sizebased_in_agebased[i]){
        result += (quantity_requests.ogive_parameters[i] + "[" + dtos(quantity_requests.print_sizebased_ogives_at[j]) + "] ");
      } else {

        result += (quantity_requests.ogive_parameters[i] + "[" + itos(j) + "] ");
      }
      n_quantities++;
    }
  }
  for (int i=0; i<ogive_arguments.size(); i++){
    for (int j=1; j<=ogive_arguments[i].size(); j++){
      result += (quantity_requests.ogive_arguments[i] + ".argument[" + itos(j) + "] ");
      n_quantities++;
    }
  }
  for (int i=0; i<nuisance_qs.size(); i++){
    result += "q[" + nuisance_qs_names[i] + "] ";
    n_quantities++;
  }
  if (B0.size() > 0){
    if (n_stocks == 1){
      result += "B0 ";
      n_quantities++;
    } else {
      for (int i=0; i<n_stocks; i++){
        result += ("B0[" + stock_names[i] + "] ");
        n_quantities++;
      }
    }
  }
  if (R0.size() > 0){
    if (n_stocks == 1){
      result += "R0 ";
      n_quantities++;
    } else {
      for (int i=0; i<n_stocks; i++){
        result += ("R0[" + stock_names[i] + "] ");
        n_quantities++;
      }
    }
  }
  if (Binitial.size() > 0){
    if (n_stocks == 1){
      result += "Binitial ";
      n_quantities++;
    } else {
      for (int i=0; i<n_stocks; i++){
        result += ("Binitial[" + stock_names[i] + "] ");
        n_quantities++;
      }
    }
  }
  if (Rinitial.size() > 0){
    if (n_stocks == 1){
      result += "Rinitial ";
      n_quantities++;
    } else {
      for (int i=0; i<n_stocks; i++){
        result += ("Rinitial[" + stock_names[i] + "] ");
        n_quantities++;
      }
    }
  }
  if (Bmean.size() > 0){
    if (n_stocks == 1){
      result += "Bmean ";
      n_quantities++;
    } else {
      for (int i=0; i<n_stocks; i++){
        result += ("Bmean[" + stock_names[i] + "] ");
        n_quantities++;
      }
    }
  }
  if (Rmean.size() > 0){
    if (n_stocks == 1){
      result += "Rmean ";
      n_quantities++;
    } else {
      for (int i=0; i<n_stocks; i++){
        result += ("Rmean[" + stock_names[i] + "] ");
        n_quantities++;
      }
    }
  }
  if (SSBs.size() > 0){
    if (n_stocks == 1){
      for (int j=0; j<quantity_requests.SSBs.size(); j++){
        result += ("SSB[" + itos(quantity_requests.SSBs[j]) + "] ");
        n_quantities++;
      }
    } else {
      for (int i=0; i<n_stocks; i++){
        for (int j=0; j<quantity_requests.SSBs.size(); j++){
          result += ("SSB[" + stock_names[i] + "][" + itos(quantity_requests.SSBs[j]) + "] ");
          n_quantities++;
        }
      }
    }
  }
  if (recruitments.size() > 0){
    if (n_stocks == 1){
      for (int j=0; j<quantity_requests.recruitments.size(); j++){
        result += ("recruitment[" + itos(quantity_requests.recruitments[j]) + "] ");
        n_quantities++;
      }
    } else {
      for (int i=0; i<n_stocks; i++){
        for (int j=0; j<quantity_requests.recruitments.size(); j++){
          result += ("recruitment[" + stock_names[i] + "][" + itos(quantity_requests.recruitments[j]) + "] ");
          n_quantities++;
        }
      }
    }
  }
  if (YCS.size() > 0){
    if (n_stocks == 1){
      for (int j=0; j<quantity_requests.YCS.size(); j++){
        result += ("YCS[" + itos(quantity_requests.YCS[j]) + "] ");
        n_quantities++;
      }
    } else {
      for (int i=0; i<n_stocks; i++){
        for (int j=0; j<quantity_requests.YCS.size(); j++){
          result += ("YCS[" + stock_names[i] + "][" + itos(quantity_requests.YCS[j]) + "] ");
          n_quantities++;
        }
      }
    }
  }
  if (true_YCS.size() > 0){
    if (n_stocks == 1){
      for (int j=0; j<quantity_requests.true_YCS.size(); j++){
        result += ("true_YCS[" + itos(quantity_requests.true_YCS[j]) + "] ");
        n_quantities++;
      }
    } else {
      for (int i=0; i<n_stocks; i++){
        for (int j=0; j<quantity_requests.true_YCS.size(); j++){
          result += ("true_YCS[" + stock_names[i] + "][" + itos(quantity_requests.true_YCS[j]) + "] ");
          n_quantities++;
        }
      }
    }
  }
  if (Ts.size() > 0){
    if (n_stocks == 1){
      for (int j=0; j<quantity_requests.Ts.size(); j++){
        result += ("Ts[" + itos(quantity_requests.Ts[j]) + "] ");
        n_quantities++;
      }
    } else {
      for (int i=0; i<n_stocks; i++){
        for (int j=0; j<quantity_requests.Ts.size(); j++){
          result += ("Ts[" + stock_names[i] + "][" + itos(quantity_requests.Ts[j]) + "] ");
          n_quantities++;
        }
      }
    }
  }
  if (migration_annual_variation.size() > 0){
     for (int i=0; i<migration_annual_variation.size(); i++){
        for (int j=0; j<quantity_requests.migration_annual_variation.size(); j++){
           result += ("migration_annual_variation[" + migration_annual_variation_names[i] + "][" + itos(quantity_requests.migration_annual_variation[j]) + "] ");
           n_quantities++;
         }
      }
  }
  if (quantity_requests.actual_catches.size() > 0){
    if (!quantity_requests.catches_by_stock){
      if (n_fisheries == 1){
        for (int j=0; j<quantity_requests.actual_catches.size(); j++){
          result += ("catch[" + itos(quantity_requests.actual_catches[j]) + "] ");
          n_quantities++;
        }
      } else {
        for (int i=0; i<n_fisheries; i++){
          for (int j=0; j<quantity_requests.actual_catches.size(); j++){
            result += ("catch[" + fishery_names[i] + "][" + itos(quantity_requests.actual_catches[j]) + "] ");
            n_quantities++;
          }
        }
      }
  } else {
  if (quantity_requests.catches_by_stock){
      if (n_fisheries == 1){
        for (int k=0; k<n_stocks; k++){
          for (int j=0; j<quantity_requests.actual_catches.size(); j++){
            result += ("catch[" + stock_names[k] + "][" + itos(quantity_requests.actual_catches[j]) + "] ");
            n_quantities++;
          }
        }
      } else {
        for (int i=0; i<n_fisheries; i++){
          for (int k=0; k<n_stocks; k++){
            for (int j=0; j<quantity_requests.actual_catches.size(); j++){
              result += ("catch[" + fishery_names[i] + "][" + stock_names[k] + "][" + itos(quantity_requests.actual_catches[j]) + "] ");
              n_quantities++;
            }
          }
        }
      }
  }
  if (quantity_requests.catches_by_area){
      if (n_fisheries == 1){
        for (int k=0; k<n_areas; k++){
          for (int j=0; j<quantity_requests.actual_catches.size(); j++){
            result += ("catch[" + area_names[k] + "][" + itos(quantity_requests.actual_catches[j]) + "] ");
            n_quantities++;
          }
        }
      } else {
        for (int i=0; i<n_fisheries; i++){
          for (int k=0; k<n_areas; k++){
            for (int j=0; j<quantity_requests.actual_catches.size(); j++){
              result += ("catch[" + fishery_names[i] + "][" + area_names[k] + "][" + itos(quantity_requests.actual_catches[j]) + "] ");
              n_quantities++;
            }
          }
        }
      }
  }
  }
  }
  if (fishing_pressures.size() > 0){
    if (n_fisheries == 1){
      for (int j=0; j<quantity_requests.fishing_pressures.size(); j++){
        result += ("fishing_pressure[" + itos(quantity_requests.fishing_pressures[j]) + "] ");
        n_quantities++;
      }
    } else {
      for (int i=0; i<n_fisheries; i++){
        for (int j=0; j<quantity_requests.fishing_pressures.size(); j++){
          result += ("fishing_pressure[" + fishery_names[i] + "][" + itos(quantity_requests.fishing_pressures[j]) + "] ");
          n_quantities++;
        }
      }
    }
  }
  if (stock_crash.size() > 0){
    if (n_stocks == 1){
      result += "stock_crash ";
      n_quantities++;
    } else {
      for (int i=0; i<n_stocks; i++){
        result += ("stock_crash[" + stock_names[i] + "] ");
        n_quantities++;
      }
    }
  }
  for (int i=0; i<fits.size(); i++){
        if (fits_exist[i]){
          for (int j=1; j<=fits[i].rowsize(); j++){
                  int year = (int) fits_resids_years[i][j];
                  if (year <= quantity_requests.current || quantity_requests.projection){
                          for (int k=1; k<=fits[i].colsize(); k++){
                                result += (fits_resids_labels[i] + ".fits[" + itos(year) + "][" + itos(k) + "] ");
                    n_quantities++;
                          }
                  }
          }
    }
  }
  for (int i=0; i<resids.size(); i++){
        if (fits_exist[i]){
          for (int j=1; j<=resids[i].rowsize(); j++){
                  int year = (int) fits_resids_years[i][j];
                  if (year <= quantity_requests.current || quantity_requests.projection){
                          for (int k=1; k<=resids[i].colsize(); k++){
                                result += (fits_resids_labels[i] + ".resids[" + itos(year) + "][" + itos(k) + "] ");
                    n_quantities++;
                          }
                  }
          }
    }
  }
  for (int i=0; i<pearson_resids.size(); i++){
        if (fits_exist[i]){
          for (int j=1; j<=pearson_resids[i].rowsize(); j++){
                  int year = (int) fits_resids_years[i][j];
                  if (year <= quantity_requests.current || quantity_requests.projection){
                          for (int k=1; k<=pearson_resids[i].colsize(); k++){
                                result += (fits_resids_labels[i] + ".pearson_resids[" + itos(year) + "][" + itos(k) + "] ");
                    n_quantities++;
                          }
                  }
          }
     }
  }
  for (int i=0; i<normalised_resids.size(); i++){
        if (normalised_resids_exist[i]){
          for (int j=1; j<=normalised_resids[i].rowsize(); j++){
                  int year = (int) fits_resids_years[i][j];
                  if (year <= quantity_requests.current || quantity_requests.projection){
                          for (int k=1; k<=normalised_resids[i].colsize(); k++){
                                result += (fits_resids_labels[i] + ".normalised_resids[" + itos(year) + "][" + itos(k) + "] ");
                    n_quantities++;
                          }
                  }
          }
    }
  }
  for (int i=0; i<tagging_episode_labels.size(); i++){
    if (tagging_sexed[i]){
    for (int j=tagged_age_distributions[i].colmin(); j<=tagged_age_distributions[i].colmax(); j++){
      result += "tagging_male_ageF["+tagging_episode_labels[i]+"]["+itos(j)+"] ";
      n_quantities++;
    }
    for (int j=tagged_age_distributions[i].colmin(); j<=tagged_age_distributions[i].colmax(); j++){
      result += "tagging_female_ageF["+tagging_episode_labels[i]+"]["+itos(j)+"] ";
      n_quantities++;
    }
    } else {
    for (int j=tagged_age_distributions[i].colmin(); j<=tagged_age_distributions[i].colmax(); j++){
      result += "tagging_ageF["+tagging_episode_labels[i]+"]["+itos(j)+"] ";
      n_quantities++;
    }
    }
  }
  for (int i=0; i<disease_biomass_loss.size(); i++){
    result += "biomass_loss["+itos(disease_biomass_loss[i].first)+"] ";
    n_quantities++;
  }
  for (int i=0; i<pseudofits.size(); i++){
    for (int j=1; j<=pseudofits[i].rowsize(); j++){
      int year = (int) pseudofits_years[i][j];
      if (year <= quantity_requests.current || quantity_requests.projection){
        for (int k=1; k<=pseudofits[i].colsize(); k++){
          result += (pseudofits_labels[i] + "[" + itos(year) + "][" + itos(k) + "] ");
          n_quantities++;
        }
      }
    }
  }
  return result;
}

dvector Quantity_results::make_vector(Quantity_requests& quantity_requests){
  // Create a dvector containing all the quantity values, to be used in a table headed by
  // a string generated by make_header(). get() should have already been called.
  DEBUG1("Quantity_results::make_vector");
  dvector result(1,n_quantities);
  int count = 1;
  for (int i=0; i<scalar_parameters.size(); i++){
    result[count++] = scalar_parameters[i];
  }
  for (int i=0; i<vector_parameters.size(); i++){
    for (int j=1; j<=vector_parameters[i].size(); j++){
      result[count++] = vector_parameters[i][j];
    }
  }
  for (int i=0; i<ogive_parameters.size(); i++){
    for (int j=ogive_parameters[i].indexmin(); j<=ogive_parameters[i].indexmax(); j++){
      result[count++] = ogive_parameters[i][j];
    }
  }
  for (int i=0; i<ogive_arguments.size(); i++){
    for (int j=1; j<=ogive_arguments[i].size(); j++){
      result[count++] = ogive_arguments[i][j];
    }
  }
  if (nuisance_qs.size() > 0){
    for (int i=0; i<nuisance_qs.size(); i++){
      result[count++] = nuisance_qs[i];
    }
  }
  if (B0.size() > 0){
    for (int i=0; i<n_stocks; i++){
      result[count++] = B0[i];
    }
  }
  if (R0.size() > 0){
    for (int i=0; i<n_stocks; i++){
      result[count++] = R0[i];
    }
  }
  if (Binitial.size() > 0){
    for (int i=0; i<n_stocks; i++){
      result[count++] = Binitial[i];
    }
  }
  if (Rinitial.size() > 0){
    for (int i=0; i<n_stocks; i++){
      result[count++] = Rinitial[i];
    }
  }
  if (Bmean.size() > 0){
    for (int i=0; i<n_stocks; i++){
      result[count++] = Bmean[i];
    }
  }
  if (Rmean.size() > 0){
    for (int i=0; i<n_stocks; i++){
      result[count++] = Rmean[i];
    }
  }
  if (SSBs.size() > 0){
    for (int i=0; i<n_stocks; i++){
      for (int j=SSBs[i].indexmin(); j<=SSBs[i].indexmax(); j++){
        result[count++] = SSBs[i][j];
      }
    }
  }
  if (recruitments.size() > 0){
    for (int i=0; i<n_stocks; i++){
      for (int j=recruitments[i].indexmin(); j<=recruitments[i].indexmax(); j++){
        result[count++] = recruitments[i][j];
      }
    }
  }
  if (YCS.size() > 0){
    for (int i=0; i<n_stocks; i++){
      for (int j=YCS[i].indexmin(); j<=YCS[i].indexmax(); j++){
        result[count++] = YCS[i][j];
      }
    }
  }
  if (true_YCS.size() > 0){
    for (int i=0; i<n_stocks; i++){
      for (int j=true_YCS[i].indexmin(); j<=true_YCS[i].indexmax(); j++){
        result[count++] = true_YCS[i][j];
      }
    }
  }
  if (Ts.size() > 0){
    for (int i=0; i<n_stocks; i++){
      for (int j=Ts[i].indexmin(); j<=Ts[i].indexmax(); j++){
        result[count++] = Ts[i][j];
      }
    }
  }
  if (migration_annual_variation.size() > 0){
    for (int i=0; i<migration_annual_variation.size(); i++){
        for (int j=migration_annual_variation[i].indexmin(); j<=migration_annual_variation[i].indexmax(); j++){
          result[count++] = migration_annual_variation[i][j];
        }
      }
  }

  if (actual_catches.size() > 0){
    if (!quantity_requests.catches_by_stock){
      for (int i=0; i<n_fisheries; i++){
        for (int j=actual_catches[i].indexmin(); j<=actual_catches[i].indexmax(); j++){
          result[count++] = actual_catches[i][j];
        }
      }
    }
  }
  if (actual_catches_by_stock.size() > 0){
    if (quantity_requests.catches_by_stock){
      for (int i=0; i<n_fisheries; i++){
        for (int k=0; k<n_stocks; k++){
          for (int j=actual_catches_by_stock[i][k].indexmin(); j<=actual_catches_by_stock[i][k].indexmax(); j++){
            result[count++] = actual_catches_by_stock[i][k][j];
          }
        }
      }
    }
  }
  if (actual_catches_by_area.size() > 0){
    if (quantity_requests.catches_by_area){
      for (int i=0; i<n_fisheries; i++){
        for (int k=0; k<n_areas; k++){
          for (int j=actual_catches_by_area[i][k].indexmin(); j<=actual_catches_by_area[i][k].indexmax(); j++){
            result[count++] = actual_catches_by_area[i][k][j];
          }
        }
      }
    }
  }

  if (fishing_pressures.size() > 0){
    for (int i=0; i<n_fisheries; i++){
      for (int j=fishing_pressures[i].indexmin(); j<=fishing_pressures[i].indexmax(); j++){
        result[count++] = fishing_pressures[i][j];
      }
    }
  }
  if (stock_crash.size() > 0){
    for (int i=0; i<n_stocks; i++){
      result[count++] = stock_crash[i];
    }
  }
  for (int i=0; i<fits.size(); i++){
   if (fits_exist[i]){
    for (int j=1; j<=fits[i].rowsize(); j++){
      int year = (int) fits_resids_years[i][j];
      if (year <= quantity_requests.current || quantity_requests.projection){
        for (int k=1; k<=fits[i].colsize(); k++){
          result[count++] = fits[i][j][k];
        }
      }
    }
   }
  }
  for (int i=0; i<resids.size(); i++){
   if (fits_exist[i]){
    for (int j=1; j<=resids[i].rowsize(); j++){
      int year = (int) fits_resids_years[i][j];
      if (year <= quantity_requests.current || quantity_requests.projection){
        for (int k=1; k<=resids[i].colsize(); k++){
          result[count++] = resids[i][j][k];
        }
      }
    }
   }
  }
  for (int i=0; i<pearson_resids.size(); i++){
   if (fits_exist[i]){
    for (int j=1; j<=pearson_resids[i].rowsize(); j++){
      int year = (int) fits_resids_years[i][j];
      if (year <= quantity_requests.current || quantity_requests.projection){
        for (int k=1; k<=pearson_resids[i].colsize(); k++){
          result[count++] = pearson_resids[i][j][k];
        }
      }
    }
   }
  }
  for (int i=0; i<normalised_resids.size(); i++){
          if (normalised_resids_exist[i]){
    for (int j=1; j<=normalised_resids[i].rowsize(); j++){
      int year = (int) fits_resids_years[i][j];
      if (year <= quantity_requests.current || quantity_requests.projection){
        for (int k=1; k<=normalised_resids[i].colsize(); k++){
          result[count++] = normalised_resids[i][j][k];
        }
      }
    }
      }
  }
  for (int i=0; i<tagging_episode_labels.size(); i++){
    if (tagging_sexed[i]){
    for (int j=tagged_age_distributions[i].colmin(); j<=tagged_age_distributions[i].colmax(); j++){
      result[count++] = tagged_age_distributions[i][1][j];
    }
    for (int j=tagged_age_distributions[i].colmin(); j<=tagged_age_distributions[i].colmax(); j++){
      result[count++] = tagged_age_distributions[i][2][j];
    }
    } else {
    for (int j=tagged_age_distributions[i].colmin(); j<=tagged_age_distributions[i].colmax(); j++){
      result[count++] = tagged_age_distributions[i][1][j];
    }
    }
  }
  for (int i=0; i<disease_biomass_loss.size(); i++){
    result[count++] = disease_biomass_loss[i].second;
  }
  for (int i=0; i<pseudofits.size(); i++){
    for (int j=1; j<=pseudofits[i].rowsize(); j++){
      int year = (int) pseudofits_years[i][j];
      if (year <= quantity_requests.current || quantity_requests.projection){
        for (int k=1; k<=pseudofits[i].colsize(); k++){
          result[count++] = pseudofits[i][j][k];
        }
      }
    }
  }
  return result;
}

void Quantity_results::print(Quantity_requests& quantity_requests, ostream& out){
  DEBUG2("Quantity_results::print");
  if (quantity_requests.scalar_parameters.size() > 0){
    out << "* Scalar parameter values\n";
    for (int i=0; i<scalar_parameters.size(); i++){
      out << quantity_requests.scalar_parameters[i] << ' ' << scalar_parameters[i] << '\n';}
    out << '\n';
  }
  if (quantity_requests.vector_parameters.size() > 0){
    out << "* Vector parameter values\n";
    for (int i=0; i<vector_parameters.size(); i++){
      out << quantity_requests.vector_parameters[i] << ' ' << vector_parameters[i] << '\n';}
    out << '\n';
  }
  if (quantity_requests.ogive_parameters.size() > 0){
    out << "* Ogive parameter values\n";
    for (int i=0; i<ogive_parameters.size(); i++){
      // Only print out a size-based ogive, in an age-based model, if there is the command @print_sizebased_ogives_at
      if (ogives_sizebased_in_agebased[i] != -99){
         out << quantity_requests.ogive_parameters[i] << ' ' << ogive_parameters[i] << '\n';
         if (ogives_sizebased_in_agebased[i]){
           out << quantity_requests.ogive_parameters[i] << "_sizes " << quantity_requests.print_sizebased_ogives_at << '\n';
         }
      }
    }
    out << '\n';
  }
  if (quantity_requests.ogive_arguments.size() > 0){
    out << "* Ogive arguments\n";
    for (int i=0; i<ogive_arguments.size(); i++){
      out << quantity_requests.ogive_arguments[i] << ' ' << ogive_arguments[i] << '\n';}
    out << '\n';
  }
  if (quantity_requests.nuisance_qs){
    out << "* Nuisance q's\n";
    for (int i=0; i<nuisance_qs.size(); i++){
      out << nuisance_qs_names[i] << ' ' << nuisance_qs[i] << '\n';
    }
    out << '\n';
  }
  if (quantity_requests.B0){
    out << "* B0\n";
    if (n_stocks == 1){
      out << B0[0] << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << B0[stock] << '\n';
      }
    }
    out << '\n';
  }
  if (quantity_requests.R0){
    out << "* R0\n";
    if (n_stocks == 1){
      out << R0[0] << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << R0[stock] << '\n';
      }
    }
    out << '\n';
  }
  if (quantity_requests.Binitial){
    out << "* Binitial\n";
    if (n_stocks == 1){
      out << Binitial[0] << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << Binitial[stock] << '\n';
      }
    }
    out << '\n';
  }
  if (quantity_requests.Rinitial){
    out << "* Rinitial\n";
    if (n_stocks == 1){
      out << Rinitial[0] << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << Rinitial[stock] << '\n';
      }
    }
    out << '\n';
  }
  if (quantity_requests.Bmean){
    out << "* Bmean\n";
    if (n_stocks == 1){
      out << Bmean[0] << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << Bmean[stock] << '\n';
      }
    }
    out << '\n';
  }
  if (quantity_requests.Rmean){
    out << "* Rmean\n";
    if (n_stocks == 1){
      out << Rmean[0] << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << Rmean[stock] << '\n';
      }
    }
    out << '\n';
  }
  if (quantity_requests.SSBs.size() > 0){
    out << "* SSBs\n";
    if (n_stocks == 1){
      out << "SSB " << SSBs[0] << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << SSBs[stock] << '\n';
      }
    }
    out << "year ";
    for (int i=0; i<quantity_requests.SSBs.size(); i++){
      out << quantity_requests.SSBs[i] << ' ';}
    out << "\n\n";
  }
  if (quantity_requests.recruitments.size() > 0){
    out << "* recruitments\n";
    if (n_stocks == 1){
      out << "recruitment " << recruitments[0] << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << recruitments[stock] << '\n';
      }
    }
    out << "year ";
    for (int i=0; i<quantity_requests.recruitments.size(); i++){
      out << quantity_requests.recruitments[i] << ' ';}
    out << "\n\n";
  }
  if (quantity_requests.YCS.size() > 0){
    out << "* YCS\n";
    if (n_stocks == 1){
      out << "YCS " << YCS[0] << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << YCS[stock] << '\n';
      }
    }
    out << "year ";
    for (int i=0; i<quantity_requests.YCS.size(); i++){
      out << quantity_requests.YCS[i] << ' ';}
    out << "\n\n";
  }
  if (quantity_requests.true_YCS.size() > 0){
    out << "* true_YCS\n";
    if (n_stocks == 1){
      out << "true_YCS " << true_YCS[0] << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << true_YCS[stock] << '\n';
      }
    }
    out << "year ";
    for (int i=0; i<quantity_requests.true_YCS.size(); i++){
      out << quantity_requests.true_YCS[i] << ' ';}
    out << "\n\n";
  }
  if (quantity_requests.Ts.size() > 0){
    out << "* Climate_variable_T\n";
    if (n_stocks == 1){
      out << "Ts " << Ts[0] << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << Ts[stock] << '\n';
      }
    }
    out << "year ";
    for (int i=0; i<quantity_requests.Ts.size(); i++){
      out << quantity_requests.Ts[i] << ' ';}
    out << "\n\n";
  }
  if (quantity_requests.migration_annual_variation.size() > 0){
     out << "* migration_annual_variation\n";
   for (int i=0; i<this->migration_annual_variation_names.size(); i++){
        out << migration_annual_variation_names[i] << ' ' << migration_annual_variation[i] << '\n';
     }
    out << "year ";
    for (int i=0; i<quantity_requests.migration_annual_variation.size(); i++){
      out << quantity_requests.migration_annual_variation[i] << ' ';}
    out << "\n\n";
  }

  if (quantity_requests.actual_catches.size() > 0){
  if (!(quantity_requests.catches_by_stock | quantity_requests.catches_by_area)){
      out << "* actual_catches\n";
      if (n_fisheries == 1){
        out << "catch " << actual_catches[0] << '\n';
      } else {
        for (int fishery=0; fishery<n_fisheries; fishery++){
          out << fishery_names[fishery] << ' ' << actual_catches[fishery] << '\n';
        }
      }
      out << "year ";
      for (int i=0; i<quantity_requests.actual_catches.size(); i++){
        out << quantity_requests.actual_catches[i] << ' ';}
      out << "\n\n";
      if(quantity_requests.discards){
        out << "* discards\n";
        if (n_fisheries == 1){
          out << "discards " << discards[0] << '\n';
        } else {
          for (int fishery=0; fishery<n_fisheries; fishery++){
            out << fishery_names[fishery] << ' ' << discards[fishery] << '\n';
          }
        }
        out << "year ";
        for (int i=0; i<quantity_requests.actual_catches.size(); i++){
          out << quantity_requests.actual_catches[i] << ' ';}
        out << "\n\n";
      }
      if(quantity_requests.removals){
        out << "* removals\n";
        if (n_fisheries == 1){
          out << "removals " << removals[0] << '\n';
        } else {
          for (int fishery=0; fishery<n_fisheries; fishery++){
            out << fishery_names[fishery] << ' ' << removals[fishery] << '\n';
          }
        }
        out << "year ";
        for (int i=0; i<quantity_requests.actual_catches.size(); i++){
          out << quantity_requests.actual_catches[i] << ' ';}
        out << "\n\n";
      }
    } else {
    if(quantity_requests.catches_by_stock){
      for (int stock=0; stock<n_stocks; stock++){
        out << "* actual_catches by stock: " << stock_names[stock] << "\n";
        if (n_fisheries == 1){
          out << "catch " << actual_catches_by_stock[0][stock] << '\n';
        } else {
        for (int fishery=0; fishery<n_fisheries; fishery++){
          out << fishery_names[fishery] << ' ' << actual_catches_by_stock[fishery][stock] << '\n';}
        }
      out << "year ";
      for (int i=0; i<quantity_requests.actual_catches.size(); i++){
        out << quantity_requests.actual_catches[i] << ' ';}
      out << "\n\n";
      }
      if(quantity_requests.discards) {
        for (int stock=0; stock<n_stocks; stock++){
          out << "* discards by stock: " << stock_names[stock] << "\n";
        if (n_fisheries == 1){
          out << "discards " << discards_by_stock[0][stock] << '\n';
        } else {
          for (int fishery=0; fishery<n_fisheries; fishery++){
            out << fishery_names[fishery] << ' ' << discards_by_stock[fishery][stock] << '\n';}
        }
        out << "year ";
        for (int i=0; i<quantity_requests.actual_catches.size(); i++){
          out << quantity_requests.actual_catches[i] << ' ';}
        out << "\n\n";
        }
      }
      if(quantity_requests.removals) {
        for (int stock=0; stock<n_stocks; stock++){
          out << "* removals by stock: " << stock_names[stock] << "\n";
          if (n_fisheries == 1){
            out << "removals " << removals_by_stock[0][stock] << '\n';
          } else {
          for (int fishery=0; fishery<n_fisheries; fishery++){
            out << fishery_names[fishery] << ' ' << removals_by_stock[fishery][stock] << '\n';}
        }
        out << "year ";
        for (int i=0; i<quantity_requests.actual_catches.size(); i++){
          out << quantity_requests.actual_catches[i] << ' ';}
        out << "\n\n";
        }
      }
    }
    if(quantity_requests.catches_by_area){
      for (int area=0; area<n_areas; area++){
        out << "* actual_catches by area: " << area_names[area] << "\n";
        if (n_fisheries == 1){
          out << "catch " << actual_catches_by_area[0][area] << '\n';
        } else {
        for (int fishery=0; fishery<n_fisheries; fishery++){
          out << fishery_names[fishery] << ' ' << actual_catches_by_area[fishery][area] << '\n';}
        }
      out << "year ";
      for (int i=0; i<quantity_requests.actual_catches.size(); i++){
        out << quantity_requests.actual_catches[i] << ' ';}
      out << "\n\n";
      }
      if(quantity_requests.discards) {
        for (int area=0; area<n_areas; area++){
          out << "* discards by area: " << area_names[area] << "\n";
        if (n_fisheries == 1){
          out << "discards " << discards_by_area[0][area] << '\n';
        } else {
          for (int fishery=0; fishery<n_fisheries; fishery++){
            out << fishery_names[fishery] << ' ' << discards_by_area[fishery][area] << '\n';}
        }
        out << "year ";
        for (int i=0; i<quantity_requests.actual_catches.size(); i++){
          out << quantity_requests.actual_catches[i] << ' ';}
        out << "\n\n";
        }
      }
      if(quantity_requests.removals) {
        for (int area=0; area<n_areas; area++){
          out << "* removals by area: " << area_names[area] << "\n";
          if (n_fisheries == 1){
            out << "removals " << removals_by_area[0][area] << '\n';
          } else {
          for (int fishery=0; fishery<n_fisheries; fishery++){
            out << fishery_names[fishery] << ' ' << removals_by_area[fishery][area] << '\n';}
        }
        out << "year ";
        for (int i=0; i<quantity_requests.actual_catches.size(); i++){
          out << quantity_requests.actual_catches[i] << ' ';}
        out << "\n\n";
        }
      }
    }
  }
  }
  if (quantity_requests.fishing_pressures.size() > 0){
    out << "* fishing_pressures\n";
    if (n_fisheries == 1){
      out << "pressure " << fishing_pressures[0] << '\n';
    } else {
      for (int fishery=0; fishery<n_fisheries; fishery++){
        out << fishery_names[fishery] << ' ' << fishing_pressures[fishery] << '\n';
      }
    }
    out << "year ";
    for (int i=0; i<quantity_requests.fishing_pressures.size(); i++){
      out << quantity_requests.fishing_pressures[i] << ' ';}
    out << "\n\n";
  }
  if (quantity_requests.stock_crash){
    out << "* 'Stock crash' event (i.e. SSB falls below 20% B0 in projection period):\n";
    if (n_stocks == 1){
      out << (stock_crash[0] ? "yes" : "no") << '\n';
    } else {
      for (int stock=0; stock<n_stocks; stock++){
        out << stock_names[stock] << ' ' << (stock_crash[0] ? "yes" : "no") << '\n';
      }
    }
    out << '\n';
  }
  if (fits.size() > 0){
    for (int i=0; i<fits.size(); i++){
     if (fits_exist[i]){
      out << "* " << fits_resids_labels[i] << ".fits" << '\n';
      for (int j=1; j<=fits_resids_years[i].size(); j++){
        int year = (int) fits_resids_years[i][j];
        if (year <= quantity_requests.current || quantity_requests.projection){
          out << fits_resids_years[i][j] << "  " << fits[i][j] << '\n';
        }
      }
      out << "\n";
     }
    }
  }
  if (resids.size() > 0){
    for (int i=0; i<resids.size(); i++){
     if (fits_exist[i]){
      out << "* " << fits_resids_labels[i] << ".resids" << '\n';
      for (int j=1; j<=fits_resids_years[i].size(); j++){
        int year = (int) fits_resids_years[i][j];
        if (year <= quantity_requests.current || quantity_requests.projection){
          out << fits_resids_years[i][j] << "  " << resids[i][j] << '\n';
        }
      }
      out << "\n";
    }
   }
  }
  if (pearson_resids.size() > 0){
    for (int i=0; i<pearson_resids.size(); i++){
     if (fits_exist[i]){
      out << "* " << fits_resids_labels[i] << ".pearson_resids" << '\n';
      for (int j=1; j<=fits_resids_years[i].size(); j++){
        int year = (int) fits_resids_years[i][j];
        if (year <= quantity_requests.current || quantity_requests.projection){
          out << fits_resids_years[i][j] << "  " << pearson_resids[i][j] << '\n';
        }
      }
      out << "\n";
    }
   }
  }
  if (normalised_resids.size() > 0){
    for (int i=0; i<normalised_resids.size(); i++){
                if (normalised_resids_exist[i]){
      out << "* " << fits_resids_labels[i] << ".normalised_resids" << '\n';
      for (int j=1; j<=fits_resids_years[i].size(); j++){
        int year = (int) fits_resids_years[i][j];
        if (year <= quantity_requests.current || quantity_requests.projection){
          out << fits_resids_years[i][j] << "  " << normalised_resids[i][j] << '\n';
        }
      }
      out << "\n";
        }
    }
  }
  for (int i=0; i<tagging_episode_labels.size(); i++){
    out << "* " << tagging_episode_labels[i] << ".age_breakdown\n";
    if (tagging_sexed[i]){
      out << "Age:    ";
      for (int j=tagged_age_distributions[i].colmin(); j<=tagged_age_distributions[i].colmax(); j++){
        out << j << ' ';}
      out << '\n';
      out << "Male:   " << tagged_age_distributions[i][1] << '\n';
      out << "Female: " << tagged_age_distributions[i][2] << '\n';;
    } else {
      out << "Age:    ";
      for (int j=tagged_age_distributions[i].colmin(); j<=tagged_age_distributions[i].colmax(); j++){
        out << j << ' ';}
      out << '\n';
      out << "Tagged: " << tagged_age_distributions[i] << '\n';
      }
      out << '\n';
  }
  if (disease_biomass_loss.size()>0){
   out << "* disease_biomass_loss\n";
   out << "Year Biomass_loss_from_disease\n";
   for (int i=0; i<disease_biomass_loss.size(); i++){
     out << disease_biomass_loss[i].first << " " << disease_biomass_loss[i].second << '\n';;
   }
   out << '\n';
  }
  if (pseudofits.size() > 0){
    for (int i=0; i<pseudofits.size(); i++){
      out << "* " << pseudofits_labels[i] << '\n';
      for (int j=1; j<=pseudofits_years[i].size(); j++){
        int year = (int) pseudofits_years[i][j];
        if (year <= quantity_requests.current || quantity_requests.projection){
          out << pseudofits_years[i][j] << "  " << pseudofits[i][j] << '\n';
        }
      }
      out << "\n";
    }
  }
}

Quantity_results::Quantity_results(){
  // Construct the Quantity_results object. Nothing to do so far.
  DEBUG2("Quantity_results::Quantity_results");
}

template class TaggingFish<double,dvector,dmatrix>;

//############################## END OF OPUTPUT.cpp ##############################

