// const char* time_stamp = "$Date: 2012-02-28 11:18:21 +1300 (Tue, 28 Feb 2012) $\n";
// const char* population_processes_cpp_id = "$Id: population_processes.cpp 4586 2012-02-27 22:18:21Z Dunn $\n";

//############################## RECRUITMENT ##############################
#include "population_processes.h"

//////////////////////////////////////////////////////////////////////////
template<CDVM>
int Basic_recruitment<DVM>::apply(Basic_state<DVM>& s, int year,
                                  Basic_requests<DVM>* requests, Basic_results<DVM>* results){
  // Add recruitment to the partition of s for year: the number of fish
  // added is given by R0 * (*YCS)[year-y_enter] * (*CR)[year-y_enter]),
  // multiplied by stock_recruit->SR(s.SSBs[year-y_enter]) unless (stock_recruit == NULL).
  // The proportion added to partition element [i,j] is proportions[i][j].
  // Fill in results.recruitments[year] and recruits.YCS[year-y_enter] if requested.
  // Return 1.
  // BB: Now use Rmean instead of R0 if (use_mean_YCS=1).
  DEBUG1("Basic_recruitment::apply");
  DOUBLE recruits;
  if (!use_mean_YCS){
          recruits = R0;
  } else if (use_mean_YCS){
          recruits = Rmean;
  }
  recruits *= (*YCS)[year-y_enter];
  if (climate_recruit!=0){
    recruits *= (*CR)[year-y_enter];
  }
  if (stock_recruit != 0){
    recruits *= stock_recruit->SR(s.SSBs[stock][year-y_enter]);
  }
  if (recruits < 0){
    fatal("Negative recruitment for year " + itos(year));}
  for (int i=1; i<=s.n_rows; i++){
    for (int j=proportions[i].indexmin(); j<=proportions[i].indexmax(); j++){
      s.partition[i][j] += recruits * proportions[i][j];
    }
  }
  if (requests){
    if (requests->recruitments){
      (*(results->recruitments))[stock][year] = recruits;}
    if (requests->YCS){
      (*(results->YCS))[stock][year-y_enter] = (*YCS)[year-y_enter];}
    if (requests->true_YCS){
      (*(results->true_YCS))[stock][year-y_enter] = recruits / R0;}
    if (requests->Ts){
      if (climate_recruit != 0){
        (*(results->Ts))[stock][year-y_enter] = (*Ts)[year-y_enter];
      } else {
        (*(results->Ts))[stock][year-y_enter] = 0; // no climate-recruit: put a dummy value
      }
    }
  }
  return 1;
}

template<CDVM>
int Basic_recruitment<DVM>::apply_constant(Basic_state<DVM>& s, const DOUBLE& SSB,
                                           Basic_requests<DVM>* requests, Basic_results<DVM>* results){
  // Add recruitment to the partition of s.
  // This is for constant recruitment in deterministic simulations,
  //   and 'R0 * YCS * SR * CR' is replaced by 'R0', or by 'R0 * SR' if SSB is provided.
  // Fill in results.recruitments[0] and .YCS[-y_enter] if requested
  //   (deterministic sims always use year 0)
  // Return 1.
  // BB: Now use Rmean instead of R0 if (use_mean_YCS=1).
  DEBUG1("Basic_recruitment::apply_constant");
  DOUBLE recruits;
  if (!use_mean_YCS){
          recruits = R0;
  } else if (use_mean_YCS){
          recruits = Rmean;
  }
  if (stock_recruit != 0 && SSB > 0){
    recruits *= stock_recruit->SR(SSB);}
  for (int i=1; i<=s.n_rows; i++){
    for (int j=proportions[i].indexmin(); j<=proportions[i].indexmax(); j++){
      s.partition[i][j] += recruits * proportions[i][j];
    }
  }
  if (requests){
    if (requests->recruitments){
      (*(results->recruitments))[stock][0] = recruits;} // used in YPR calculations
    if (requests->YCS){
      (*(results->YCS))[stock][-y_enter] = 1; }
    if (requests->true_YCS){
      (*(results->true_YCS))[stock][-y_enter] = recruits / R0;}
  }
  return 1;
}

template<CDVM>
void Basic_recruitment<DVM>::set_R0(const DOUBLE& R0_val){
  // The value of R0 will not be known when Basic_recruitment::Basic_recruitment is called.
  // In which case it will need to be entered later (from set_initial_state())
  DEBUG1("Basic_recruitment::set_R0");
  R0 = R0_val;
}

template<CDVM>
void Basic_recruitment<DVM>::set_Rinitial(const DOUBLE& Rinitial_val){
  // This is used when the first few recruitments are set to Rinitial (as in the UW hoki model).
  // The value of Rinitial will not be known when Basic_recruitment::Basic_recruitment is called.
  // It needs to be entered later (from set_initial_state()).
  // The first n_rinitial YCS are then set to Rinitial / R0, so as to get absolute
  //   recruitments of Rinitial.
  // If n_rinitial<=0, nothing is done.
  DEBUG1("Basic_recruitment::set_Rinitial");
  if (Rinitial_val == 0 && n_rinitial>0){
    fatal("If you use the n_rinitial recruitment feature, you should specify Rinitial (>0)");}
  if (!use_mean_YCS){
    for (int year=initial; year<=initial+n_rinitial-1; year++){
      (*YCS)[year-y_enter] = Rinitial_val / R0;}
  } else if (use_mean_YCS){
    for (int year=initial; year<=initial+n_rinitial-1; year++){
      (*YCS)[year-y_enter] = Rinitial_val / Rmean;}
  }
}

template<CDVM>
void Basic_recruitment<DVM>::set_B0(const DOUBLE& B0_val){
  // The value of B0 will not be known when Basic_recruitment::Basic_recruitment is called.
  // In which case it will need to be entered later (from set_initial_state())
  // The B0 is passed on to the stock-recruit relationship,
  // unless stock_recruit==NULL, in which case nothing is done.
  DEBUG1("Basic_recruitment::set_B0");
  if (stock_recruit!=0)
    stock_recruit->set_B0(B0_val);
}

template<CDVM>
void Basic_recruitment<DVM>::set_Rmean(const DOUBLE& Rmean_val){
  // The value of Rmean will not be known when Basic_recruitment::Basic_recruitment is called.
  // In which case it will need to be entered later (from set_initial_state())
  // (providing use_mean_YCS is set)
  DEBUG1("Basic_recruitment::set_Rmean");
  Rmean = Rmean_val;
}

template<CDVM>
DOUBLE Basic_recruitment<DVM>::ybar(){
  // Get the mean YCS between (initial-y_enter+n_rinitial) and (current-y_enter) inclusive.
  // Used for calculating B0 from Bmean or R0 from Rmean.
  // Be aware of how this is being calculated if you are doing simulations!
  DEBUG2("Basic_recruitment::ybar");
  return ybar_val;
}

template<CDVM>
void Basic_recruitment<DVM>::randomise(long seed){
  // Randomise the YCS and T's for projections.
  // Just calls Randomiser::apply() twice.
  DEBUG0("Basic_recruitment::randomise");
  randomise_YCS->apply(*YCS,first_random_year,seed);
  if (randomise_Ts != 0){
    randomise_Ts->apply(*Ts,first_random_T_year,seed);
    for (int i=first_random_T_year; i<=Ts->indexmax(); i++){
      (*CR)[i] = climate_recruit->CR((*Ts)[i]);
    }
  }
}

template<CDVM>
void Basic_recruitment<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Basic_recruitment::print");
  if (s.n_stocks==1){
    out << '\n';
  } else {
    out << " for stock " << s.stock_names[stock] << '\n';
  }
  if (use_mean_YCS){
    out << "Use Rmean in the recruitment equation\n";}
  out << "  R0: " << R0 << '\n';
  if (use_mean_YCS){
    out << "  Rmean: " << Rmean << '\n';}
  out << "  YCS (by year of spawning):\n  ";
  for (int i = YCS->indexmin(); i<=YCS->indexmax(); i++){
    out << setw(6);
    out << i << ' ';
  }
  out << "\n  ";
  for (int i = YCS->indexmin(); i<=YCS->indexmax(); i++){
    out << setw(6);
    out << (*YCS)[i] << ' ';
  }
  out << '\n';
  if (n_rinitial > 0){
    out << "  n_rinitial = " << n_rinitial << '\n';
  }
  out << "  Stock-recruit relationship: ";
  if (stock_recruit==0){
    out << "none\n";
  } else {
    stock_recruit->print(out);
  }
  out << "  Climate-recruit relationship: ";
  if (climate_recruit==0){
    out << "none\n";
  } else {
    climate_recruit->print(out);
    out << "  T and CR(T) by year:\n  ";
    for (int i = Ts->indexmin(); i<=Ts->indexmax(); i++){
      out << setw(6);
      out << i << ' ';
    }
    out << "\n  ";
    for (int i = Ts->indexmin(); i<=Ts->indexmax(); i++){
      out << setw(6);
      out << (*Ts)[i] << ' ';
    }
    out << "\n  ";
    for (int i = Ts->indexmin(); i<=Ts->indexmax(); i++){
      out << setw(6);
      out << (*CR)[i] << ' ';
    }
    out << '\n';
  }
  out << "  Fish enter the partition in the year " << y_enter;
  out << " years after their cohort is spawned.\n";
  out << "  Proportions recruiting into each element of the partition:\n";
  s.print_matrix(out,proportions);
  out << "  In projections and stochastic simulations, the YCS are randomised using the following method:\n  ";
  randomise_YCS->print(out);
  out << '\n';
  if (climate_recruit != 0){
    out << "  and the T's are randomised using the following method:\n";
    randomise_Ts->print(out);
    out << '\n';
  }
  out << '\n';
};

template<CDVM>
Basic_recruitment<DVM>::Basic_recruitment(Parameter_set<DVM>& p, Basic_state<DVM>& s,
                                          int step, int _stock, int area, int _y_enter){
  // Construct the recruitment process for 'stock' from p, s, and step.
  //
  // We don't know the value of B0 and/or R0 at this stage,
  //  they need to be set later from set_initial_state,
  //  using set_R0() and set_B0().
  // As written, this function assumes there is no more than 1 row of the partition
  //  per area/sex/growthpath/tag/stock/maturity combination. If this ceases to be the case,
  //  it will complain and error out.
  //
  // A major complication arises if we are doing a stochastic simulation. In this case,
  //  the Parameter_set is set up for the simulation period, which is the period
  //  for which we need to be able to generate recruitments,
  //  but we need to start by extracting the data for the actual historical period, because
  //  this can influence the distribution of simulated recruitments. The original 'initial',
  //  'current', and 'final' parameters have been shifted to 'original_initial', 'original_current',
  //  'original_final'.
  DEBUG1("Basic_recruitment::Basic_recruitment");
  command = ((s.n_stocks>1) ? ("recruitment[" + s.stock_names[_stock] + "].") : ("recruitment."));
  initial = p.get_int("initial");
  current = p.get_int("current");
  final = p.get_int("final");
  y_enter = _y_enter;
  stock = _stock;
  n_rinitial = p.get_int(command+"n_rinitial",0);
  int simulation = p.get_int("simulation",0);
  use_mean_YCS = p.get_bool("use_mean_YCS",0);
  std::string sr_type;
  DOUBLE steepness;
  sr_type = p.get_string(command+"SR","none");
  if (sr_type != "none"){
    steepness = p.get_estimable(command+"steepness");}
  if (sr_type=="none"){
    stock_recruit = 0;
  } else if (sr_type=="BH"){
    stock_recruit = new Beverton_Holt<DVM>(steepness);
    // we don't know B0 yet, will enter it later
  } else if (sr_type=="Ricker"){
    stock_recruit = new Ricker<DVM>(steepness);
    // we don't know B0 yet, will enter it later
  } else {
    fatal("Unknown stock-recruit relationship:" + sr_type);
  }
  std::string cr_type = (p.get_string(command+"CR","none"));
  if (cr_type=="none"){
    climate_recruit = 0;
  } else if (cr_type=="exponential"){
    climate_recruit = new Exponential<DVM>(p.get_estimable(command+"CR_alpha"),
                                           p.get_estimable(command+"CR_beta"));
  } else if (cr_type=="arctan"){
    climate_recruit = new Arctan<DVM>(p.get_estimable(command+"CR_alpha"),
                                      p.get_estimable(command+"CR_beta"));
  } else if (cr_type=="logistic"){
    climate_recruit = new Logistic<DVM>(p.get_estimable(command+"CR_alpha"),
                                        p.get_estimable(command+"CR_beta"),
                                        p.get_estimable(command+"CR_beta2"));
  } else if (cr_type=="identity"){
    climate_recruit = new Identity<DVM>();
  } else if (cr_type=="linear-combination"){
    climate_recruit = new Linear_combination<DVM>(p.get_estimable(command+"CR_p"));
  } else {
    fatal("Unknown climate-recruit relationship:" + cr_type);
  }
  R0 = 1; // actual value not known yet, will enter it later
  Rmean = 1; // actual value not known yet, will enter it later
  if (!simulation){
    // normal case
    YCS = new VECTOR(initial-y_enter,final-y_enter);
    if (climate_recruit != 0){
      Ts = new VECTOR(initial-y_enter,final-y_enter);
      CR = new VECTOR(initial-y_enter,final-y_enter);
    } else {
      Ts = CR = 0;
    }
  } else if (simulation) {
    // We are working in a simulation period.
    // We don't use the recruitments over the (initial, current) period directly,
    //  but we may need to use them to determine the distribution of simulated recruitments,
    //  so we extract them. Later we will throw them away.
    initial = p.get_int("original_initial");
    current = p.get_int("original_current");
    final = p.get_int("original_final");
    YCS = new VECTOR(initial-y_enter,final-y_enter);
    if (climate_recruit != 0){
      Ts = new VECTOR(initial-y_enter,final-y_enter);
      CR = new VECTOR(initial-y_enter,final-y_enter);
    } else {
      Ts = CR = 0;
    }
  }
  // fill in the vector of YCS
  // assume any unspecified YCS are 1
  (*YCS) = 1;
  dvector extracted_YCS_years(p.get_constant_vector(command+"YCS_years"));
  for (int i=2; i<=extracted_YCS_years.indexmax(); i++){
    if (extracted_YCS_years[i] != (extracted_YCS_years[i-1]+1)){
      fatal(command+"YCS_years should be consecutive integers");
    }
  }
  VECTOR extracted_YCS(p.get_estimable_vector(command+"YCS"));
  extracted_YCS.shift((int)(extracted_YCS_years[1]));
  if (extracted_YCS.indexmax() < current - y_enter && !use_mean_YCS){
    fatal("YCS do not extend up to (current - y_enter)");
  } else if (extracted_YCS.indexmax() > current - y_enter){
    fatal("YCS go past (current - y_enter)");
  }
  if (extracted_YCS.indexmin() < initial - y_enter + n_rinitial){
    fatal("YCS extend back before (initial - y_enter + n_rinitial)");
  } else if (extracted_YCS.indexmin() > initial - y_enter + n_rinitial && !use_mean_YCS){
    fatal("YCS do not go back to (initial - y_enter + n_rinitial)");
  }
// Changed the standardise_YCS subcommand into a command, to be compatible with use_mean_YCS
//  if (p.get_bool("standardise_YCS",0))
//    fatal("The '@standardise_YCS' command has been superseeded in this version of CASAL. Please refer to the manual for assistance");
//  if (p.get_bool(command+"standardise_YCS",0)){
  if (p.get_bool("standardise_YCS",0)) {
    // alternate YCS parameterization
    // standardise YCS for years initial - y_enter + n_rinitial to current - y_enter
    // by division by their mean. Do not change YCS which are fixed, and do not include them
    // in the calculation of the mean.
    // (first_free and last_free now defined by stock, rather than globally)
    if (use_mean_YCS){
      error("Don't use standardise_YCS with use_mean_YCS");}
    int first_free = p.get_int(command+"first_free",initial-y_enter+n_rinitial);
    int last_free = p.get_int(command+"last_free",current-y_enter);
    if (first_free < initial-y_enter+n_rinitial){
      fatal("first_free is too early, should be at least " + itos(initial-y_enter+n_rinitial));}
    if (last_free > current-y_enter){
      fatal("last_free is too late, should be at most " + itos(current-y_enter));}
    if (first_free > last_free){
      fatal("first_free is more than last_free");}
    DOUBLE sum = 0;
    if(p.present(command+"exclude_free")) {
    // allow some uears to be excluded from the range of years used to determine the mean
      dvector exclude_free(p.get_constant_vector(command+"exclude_free"));
      //add in error check for exclude free years
      for (int y=first_free; y<=last_free; y++){
        bool year_isin = false;
        for(int k = 1; k <= exclude_free.size(); k++) if(y==(int)exclude_free[k]) year_isin = true;
        if(!year_isin) sum += extracted_YCS[y];
      }
      DOUBLE mean_Y = sum / (last_free - first_free - exclude_free.size() + 1);
      for (int y=first_free; y<=last_free; y++){
        bool year_isin = false;
        for(int k = 1; k <= exclude_free.size(); k++) if(y==(int)exclude_free[k]) year_isin = true;
        if(!year_isin) extracted_YCS[y] /= mean_Y;
      }
    } else {
      for (int y=first_free; y<=last_free; y++){
        sum += extracted_YCS[y];
      }
      DOUBLE mean_Y = sum / (last_free - first_free + 1);
      for (int y=first_free; y<=last_free; y++){
        extracted_YCS[y] /= mean_Y;
      }
    }
  }
 if (!use_mean_YCS){
    for (int i=extracted_YCS.indexmin(); i<=extracted_YCS.indexmax(); i++){
      (*YCS)[i] = extracted_YCS[i];
    }
  } else if (use_mean_YCS){  // not necessary to provide YCS right back to initial - y_enter + n_rinitial or forward to current-y_enter,
                             // use the mean if not provided
    int first_free = p.get_int(command+"first_free",initial-y_enter+n_rinitial);
    int last_free = p.get_int(command+"last_free",current-y_enter);
    if (first_free < initial-y_enter+n_rinitial){
      fatal("The value of " + command + "first_free is too early, should be at least " + itos(initial-y_enter+n_rinitial));}
    if (last_free > current-y_enter){
      fatal("The value of " + command + "last_free is too late, should be at most " + itos(current-y_enter));}
    if (first_free > last_free){
      fatal("The value of " + command + "first_free is more than " + command + "last_free");}
    if(first_free < extracted_YCS.indexmin()) fatal("The value of " + command + "first_free must be greater than or equal to the earliest supplied YCS");
    if(last_free > extracted_YCS.indexmax()) fatal("The value of " + command + "first_free must be less than or equal to the latest supplied YCS");
    // calculate the value of ybar (mean YCS between first_free and last_free, which default to initial-y_enter+n_rinitial and current-y_enter respectively)
    DOUBLE total=0;
    for (int i=first_free; i<=last_free; i++){
      total += (extracted_YCS)[i];
    }
    ybar_val=total / (last_free - first_free + 1);
    for (int i=initial - y_enter + n_rinitial; i<=current - y_enter; i++){
      if (extracted_YCS.indexmin()>i || extracted_YCS.indexmax()<i){
        (*YCS)[i] = ybar_val;
      } else {
        (*YCS)[i] = extracted_YCS[i];
      }
    }
  }
  if (climate_recruit != 0){
    // fill in the vectors of T's and CR(T)'s
    // put a dummy '0' value for unspecified T's, and the corresponding CR = 1
    (*Ts) = 0;
    (*CR) = 1;
    // get the initial-to-final Ts
    dvector extracted_Ts_years(p.get_constant_vector(command+"Ts_years"));
    for (int i=2; i<=extracted_Ts_years.indexmax(); i++){
      if (extracted_Ts_years[i] != (extracted_Ts_years[i-1]+1)){
        fatal(command+"Ts_years should be consecutive integers");
      }
    }
    dvector extracted_Ts(p.get_constant_vector(command+"Ts"));
    extracted_Ts.shift((int)(extracted_Ts_years[1]));
    if (extracted_Ts.indexmax() < current - y_enter){
      fatal("Ts do not extend up to (current - y_enter)");
    } else if (extracted_Ts.indexmax() > final - y_enter){
      fatal("Ts go past (final - y_enter)");
    }
    if (extracted_Ts.indexmin() < initial - y_enter){
      fatal("Ts extend back before (initial - y_enter)");
    } else if (extracted_Ts.indexmin() > initial - y_enter){
      fatal("Ts do not go back to (initial - y_enter)");
    }
    for (int i=extracted_Ts.indexmin(); i<=extracted_Ts.indexmax(); i++){
      (*Ts)[i] = extracted_Ts[i];
      (*CR)[i] = climate_recruit->CR(extracted_Ts[i]);
    }
    last_T_provided = extracted_Ts.indexmax();
  }
  // build the objects to randomise YCS and Ts in stochastic simulation and projection
  std::string randomisation_method = p.get_string("randomisation_method");
  std::string stock_name;
  if (s.n_stocks > 1){
    stock_name = s.stock_names[stock];
  } else {
    stock_name = "";
  }
  if (n_rinitial > 0 &&
      (randomisation_method=="lognormal-empirical" || randomisation_method=="empirical")){
    if (!p.present(command + "year_range") ||
        p.get_constant_vector(command + "year_range")[1] < (initial - y_enter + n_rinitial)){
      fatal("You have tried to use an empirical recruitment randomiser with n_rinitial > 0, and a year range including years which are filled in with R_initial. This is not currently allowed.");
      // It could be, but the big hassle is that we do not know the value of R_initial at this stage.
      // So actually I think it would involve a quite big code change.
    }
  }
  if (randomisation_method=="lognormal"){
    randomise_YCS = new Lognormal_randomiser<DVM>(p,"YCS",command,*YCS);
  } else if (randomisation_method=="lognormal-empirical"){
    randomise_YCS = new Lognormal_empirical_randomiser<DVM>(p,"YCS",command,*YCS);
  } else if (randomisation_method=="empirical"){
    randomise_YCS = new Empirical_randomiser<DVM>(p,"YCS",command,*YCS);
  } else if (randomisation_method=="none"){
    if(simulation) fatal("You cannot use the recruitment randomisation method 'none' if you are calculating yields");
    randomise_YCS = new No_randomiser<DVM>(p,"YCS",command,*YCS);
  } else {
    fatal("Unknown randomisation method: " + randomisation_method);
  }
  if (climate_recruit != 0){
    if (randomisation_method=="lognormal"){
      randomise_Ts = new Lognormal_randomiser<DVM>(p,"Ts",command,*Ts);
    } else if (randomisation_method=="lognormal-empirical"){
      randomise_Ts = new Lognormal_empirical_randomiser<DVM>(p,"Ts",command,*Ts);
    } else if (randomisation_method=="empirical"){
      randomise_Ts = new Empirical_randomiser<DVM>(p,"Ts",command,*Ts);
    } else if (randomisation_method=="none"){
      randomise_Ts = new No_randomiser<DVM>(p,"Ts",command,*Ts);
    }
  } else randomise_Ts = 0;
  if (!simulation){
    // normal case - what is the start of the period of stochastic recruitment?
    first_random_year = p.get_int("first_random_year",current-y_enter+1);
    if (first_random_year < initial-y_enter){
      fatal("In your population file, first_random_year must be at least " + itos(initial-y_enter));}
    if (climate_recruit != 0){
      first_random_T_year = (int) fmax(first_random_year,last_T_provided+1);}
  } else if (simulation){
    // This is a stochastic simulation.
    // We need to throw away these YCS and T's, now that they have been used
    // to set up the randomisers, and construct the YCS and T's which will
    // actually be used.
    //if (p.get_int("first_random_year") > current-y_enter){
    //  fatal("In your population file, first_random_year must not be greater than " + itos(current-y_enter));}
    delete YCS;
    if (Ts != 0){
      delete Ts;
      delete CR;
    }
    // Restore the time period which will actually be used
    initial = p.get_int("initial");
    current = p.get_int("current");
    final = p.get_int("final");
  int upper=(n_rinitial>final-y_enter)? n_rinitial:final-y_enter;
    YCS = new VECTOR(initial-y_enter,upper);
    (*YCS) = 0;  // actual values will be filled in by randomise() later
    if (climate_recruit != 0){
      Ts = new VECTOR(initial-y_enter,final-y_enter);
      CR = new VECTOR(initial-y_enter,final-y_enter);
      (*Ts) = 0;
      (*CR) = 0;
    } else {
      Ts = CR = 0;
    }
    // what is the start of the period of stochastic recruitment?
    first_random_T_year = first_random_year = initial - y_enter;
  }
  // calculate the proportion of recruits going to each cell of the partition
  DOUBLE p_male;
  if (s.sex_partition){
    p_male = p.get_estimable(command+"p_male",0.5);
  }
  VECTOR growthpaths(1,s.n_growthpaths);
  if (!s.size_based && s.n_growthpaths>1){
    if (p.present(command+"growthpaths")){
      growthpaths = p.get_estimable_vector(command+"growthpaths");
    } else {
      for (int i=1; i<=growthpaths.indexmax(); i++){
        growthpaths[i] = 1.0 / s.n_growthpaths;
      }
    }
  }
  DOUBLE sum_of_row_proportions = 0;
  int sex_char = s.character_numbers("sex");
  int maturity_char = s.character_numbers("maturity");
  int growthpath_char = s.character_numbers("growthpath");
  int area_char = s.character_numbers("area");
  int tag_char = s.character_numbers("tag");
  proportions.push_back(VECTOR("{-1}"));
  DOUBLE proportion_in_row;
  VECTOR *size_dist_male = 0, *size_dist_female = 0, *size_dist_all = 0;
  if (s.size_based){
    // determine the initial size distribution
    DOUBLE initial_size_mean, initial_size_cv, initial_size_stdev;
    if (p.present(command+"initial_size_mean_male")){
      // the initial size depends on sex
      size_dist_male = new VECTOR(1,s.n_cols);
      initial_size_mean = p.get_estimable(command+"initial_size_mean_male");
      initial_size_cv = p.get_estimable(command+"initial_size_cv_male");
      initial_size_stdev = initial_size_mean * initial_size_cv;
      (*size_dist_male) = distribution<DVM>(s.class_mins,s.plus_group,
                                            "normal",initial_size_mean, initial_size_stdev);
      size_dist_female = new VECTOR(1,s.n_cols);
      initial_size_mean = p.get_estimable(command+"initial_size_mean_female");
      initial_size_cv = p.get_estimable(command+"initial_size_cv_female");
      initial_size_stdev = initial_size_mean * initial_size_cv;
      (*size_dist_female) = distribution<DVM>(s.class_mins,s.plus_group,
                                         "normal",initial_size_mean, initial_size_stdev);
    } else {
      // the initial size does not depend on sex
      size_dist_all = new VECTOR(1,s.n_cols);
      initial_size_mean = p.get_estimable(command+"initial_size_mean");
      initial_size_cv = p.get_estimable(command+"initial_size_cv");
      initial_size_stdev = initial_size_mean * initial_size_cv;
      (*size_dist_all) = distribution<DVM>(s.class_mins,s.plus_group,
                                      "normal",initial_size_mean, initial_size_stdev);
    }
  }
  for (int i = 1; i<=s.n_rows; i++){
    VECTOR* temp;
    if (!s.size_based){
      temp = new VECTOR(s.min_age,s.min_age);
      (*temp)[s.min_age] = 1;
    } else {
      temp = new VECTOR(1,s.n_cols);
      if (p.present(command+"initial_size_mean_male")){
        if (s.character_value(i,sex_char)==1){
          (*temp) = (*size_dist_male);
        } else {
          (*temp) = (*size_dist_female);
        }
      } else {
        (*temp) = (*size_dist_all);
      }
      (*temp)[1] += 1-sum(*temp); // first size class is a minus group
    }
    // determine the proportion recruiting into each row
    proportion_in_row = 1;
    int this_stock;
    if (s.n_stocks>1){
      this_stock = s.character_value(i,s.character_numbers("stock"));
      if (this_stock!=stock){
        proportion_in_row = 0;
      }
    }
    if (maturity_char != -1){
      proportion_in_row *= ((s.character_value(i,maturity_char)==1) ? 1 : 0);
      // 1 = immature, 2 = mature
    }
    if (area_char != -1){
      proportion_in_row *= ((s.character_value(i,area_char)==area) ? 1 : 0);
    }
    if (sex_char != -1){
      proportion_in_row *= ((s.character_value(i,sex_char)==2) ? (1-p_male) : p_male);
    }
    if (growthpath_char != -1){
      proportion_in_row *= growthpaths[s.character_value(i,growthpath_char)];
    }
    if (tag_char != -1){
      proportion_in_row *= ((s.character_value(i,tag_char)==1) ? 1 : 0);
      // 1 = "no tag"
        }
    sum_of_row_proportions += proportion_in_row;
    (*temp) *= proportion_in_row;
    proportions.push_back(*temp);
    delete temp;
  }
  if (fabs(sum_of_row_proportions-1) > 1e-10){
    fatal("Row proportions do not sum to 1 in Basic_recruitment::Basic_recruitment\n");}
  if (size_dist_male!=0) delete size_dist_male;
  if (size_dist_female!=0) delete size_dist_female;
  if (size_dist_all!=0) delete size_dist_all;
};

template<CDVM>
Basic_recruitment<DVM>::~Basic_recruitment(){
  DEBUG2("~Basic_recruitment");
  if (YCS != 0) delete YCS;
  if (Ts != 0) delete Ts;
  if (CR != 0) delete CR;
  if (stock_recruit != 0) delete stock_recruit;
  if (climate_recruit != 0) delete climate_recruit;
  if (randomise_YCS != 0) delete randomise_YCS;
  if (randomise_Ts != 0) delete randomise_Ts;
}

template<CDVM>
DOUBLE Ricker<DVM>::SR(const DOUBLE& SSB){
  // Return SR(SSB).
  DEBUG2("Ricker::SR");
  return (SSB/B0) * pow((1/(5*h)),(1.25*(SSB/B0-1)));
}

template<CDVM>
void Ricker<DVM>::set_B0(const DOUBLE& B0_val){
  // Set B0.
  DEBUG2("Ricker::set_B0");
  B0 = B0_val;
}

template<CDVM>
void Ricker<DVM>::print(ostream& out){
  DEBUG1("Ricker::print");
  out << "Ricker: steepness = " << h << ", B0 = " << B0 << '\n';
};

template<CDVM>
Ricker<DVM>::Ricker(const DOUBLE& h_val, const DOUBLE& B0_val){
  // Construct the Stock_recruit process from h and B0.
  // B0 may be omitted since the real value may not be known yet.
  DEBUG1("Ricker::Ricker");
  h = h_val;
  B0 = B0_val;
}

template<CDVM>
DOUBLE Beverton_Holt<DVM>::SR(const DOUBLE& SSB){
  // Return SR(SSB).
  DEBUG2("Beverton_Holt::SR");
  return (SSB/B0) / (1-((5*h-1)/(4*h))*(1-SSB/B0));
}

template<CDVM>
void Beverton_Holt<DVM>::set_B0(const DOUBLE& B0_val){
  // Set B0.
  DEBUG2("Beverton_Holt::set_B0");
  B0 = B0_val;
}

template<CDVM>
void Beverton_Holt<DVM>::print(ostream& out){
  DEBUG1("Beverton_Holt::print");
  out << "Beverton-Holt: steepness = " << h << ", B0 = " << B0 << '\n';
};

template<CDVM>
Beverton_Holt<DVM>::Beverton_Holt(const DOUBLE& h_val, const DOUBLE& B0_val){
  // Construct the Stock_recruit process from h and B0.
  // B0 may be omitted since the real value may not be known yet.
  DEBUG1("Beverton_Holt::Beverton_Holt");
  h = h_val;
  B0 = B0_val;
}

template<CDVM>
DOUBLE Exponential<DVM>::CR(const DOUBLE& T){
  // Return CR(T).
  DEBUG2("Exponential::CR");
  if (beta*T > 10){
          fatal("Fatal error in Exponential<DVM>::CR: exp(beta*T) is enormous. Your bounds on the climate-recruitment parameter beta are probably too broad.");}
  return alpha * exp(beta*T);
}

template<CDVM>
void Exponential<DVM>::print(ostream& out){
  DEBUG1("Exponential::print");
  out << "exponential: alpha = " << alpha << " beta = " << beta << '\n';
};

template<CDVM>
Exponential<DVM>::Exponential(const DOUBLE& alpha_val, const DOUBLE& beta_val){
  // Construct the Climate_recruit process from alpha, beta.
  DEBUG1("Exponential::Exponential");
  alpha = alpha_val;
  beta = beta_val;
}

template<CDVM>
DOUBLE Arctan<DVM>::CR(const DOUBLE& T){
  // Return CR(T).
  DEBUG2("Arctan::CR");
  return alpha*(0.5+atan(beta*T) / PI);
}

template<CDVM>
void Arctan<DVM>::print(ostream& out){
  DEBUG1("Arctan::print");
  out << "arctan: alpha = " << alpha << " beta = " << beta << '\n';
};

template<CDVM>
Arctan<DVM>::Arctan(const DOUBLE& alpha_val, const DOUBLE& beta_val){
  // Construct the Climate_recruit process from alpha, beta.
  DEBUG1("Arctan::Arctan");
  alpha = alpha_val;
  beta = beta_val;
}

template<CDVM>
DOUBLE Logistic<DVM>::CR(const DOUBLE& T){
  // Return CR(T).
  DEBUG2("Logistic::CR");
  if (beta2*T > 10){
          fatal("Fatal error in Exponential<DVM>::CR: exp(beta2*T) is enormous. Your bounds on the climate-recruitment parameter beta2 are probably too broad.");}
  return alpha/(1+beta*exp(beta2*T));
}

template<CDVM>
void Logistic<DVM>::print(ostream& out){
  DEBUG1("Logistic::print");
  out << "logistic: alpha = " << alpha << " beta = " << beta << " beta2 = " << beta2 << '\n';
};

template<CDVM>
Logistic<DVM>::Logistic(const DOUBLE& alpha_val, const DOUBLE& beta_val, const DOUBLE& beta2_val){
  // Construct the Climate_recruit process from alpha, beta, beta2.
  DEBUG1("Logistic::Logistic");
  alpha = alpha_val;
  beta = beta_val;
  beta2 = beta2_val;
}

template<CDVM>
DOUBLE Identity<DVM>::CR(const DOUBLE& T){
  // Return CR(T).
  DEBUG2("Identity::CR");
  return T;
}

template<CDVM>
void Identity<DVM>::print(ostream& out){
  DEBUG1("Identity::print");
  out << "identity\n";
};

template<CDVM>
Identity<DVM>::Identity(){
  // Construct the Climate_recruit process - nothing to do
  DEBUG1("Identity::Identity");
}

template<CDVM>
DOUBLE Linear_combination<DVM>::CR(const DOUBLE& T){
  // Return CR(T).
  DEBUG2("Linear_combination::CR");
  return p*T + (1-p);
}

template<CDVM>
void Linear_combination<DVM>::print(ostream& out){
  DEBUG1("Linear_combination::print");
  out << "linear-combination: p = " << p << '\n';
};

template<CDVM>
Linear_combination<DVM>::Linear_combination(const DOUBLE& p_val){
  // Construct the Climate_recruit process from p.
  DEBUG1("Linear_combination::Linear_combination");
  p = p_val;
}

template<CDVM>
void Lognormal_randomiser<DVM>::apply(VECTOR& v, int first_random_year, long seed){
  // replace the elements of v to be randomised by (possibly autocorrelated)
  // standard normal random variables
  DEBUG1("Lognormal_randomiser::apply");
  if (first_random_year >= v.indexmax()){
    fatal("No years to randomise in Lognormal_randomiser::apply. Have you set the 'final' or 'first_random_year' parameters correctly?");}
  dvector rands(first_random_year, v.indexmax());
  rands.fill_randn(seed);
  if (first_random_year == v.indexmin() || rho==0){
    v[first_random_year] = rands[first_random_year];
  } else {
    if (sigma_r == 0){
      fatal("last nonrandom year has implausible value: try increasing sigma_r or making rho=0 or moving to the 'none' randomisation method");}
    if (fabs((log(v[first_random_year - 1]) - mean_on_log_scale) / sigma_r) > 5){
      fatal("last nonrandom year has implausible value: try increasing sigma_r or making rho=0 or moving to the 'none' randomisation method");}
    DOUBLE previous_year = (log(v[first_random_year - 1]) - mean_on_log_scale) / sigma_r;
    v[first_random_year] = rho * previous_year + sqrt(1-rho*rho) * rands[first_random_year];
  }
  for (int i=first_random_year+1; i<=v.indexmax(); i++){
    v[i] = rho * v[i-1] + sqrt(1-rho*rho) * rands[i];
  }
  // convert the standard normal deviates back into YCS or T's
  for (int i=first_random_year; i<=v.indexmax(); i++){
        if (v[i]*sigma_r + mean_on_log_scale > 10){
                fatal("Fatal error in Lognormal_randomiser<DVM>::apply: calculated YCS is enormous. Your T_mean or sigma_r parameter is probably wrong/");}
    v[i] = exp(v[i]*sigma_r + mean_on_log_scale);
  }
};

template<CDVM>
void Lognormal_randomiser<DVM>::print(ostream& out){
  DEBUG2("Lognormal_randomiser::print");
  out << "lognormal with mean of " << mean_on_linear_scale;
  if(multiplier!=1) out << " (i.e., using recruitment_multiplier = " << multiplier << ")";
  out << ", standard deviation on the log-scale of " << sigma_r;
  if (rho != 0) out << " and autocorrelation on the log-scale of " << rho;
};

template<CDVM>
Lognormal_randomiser<DVM>::Lognormal_randomiser(Parameter_set<DVM>& p,
                                                const std::string& what_it_is,
                                                const std::string& command,
                                                const VECTOR& original_values){
  // Construct the randomiser from the Parameter_set (from which get sigma_r and rho)
  //   and the first year to be randomised.
  DEBUG1("Lognormal_randomiser::Lognormal_randomiser");
  /*
  std::string command;
  if (stock==""){
    command = "recruitment.";
  } else {
    command = "recruitment[" + stock + "].";
  }
  */
  if (what_it_is == "YCS"){
    sigma_r = p.get_constant(command + "sigma_r");
    rho = p.get_constant(command + "rho",0);
    multiplier = p.get_constant(command + "recruitment_multiplier",1);
    if(multiplier <=ZERO || multiplier > 100)
      fatal("The value of " + command + "recruitment_multiplier is either less than or equal to zero, or an implausibly high number (>100). Please use a more sensible value.");
    mean_on_linear_scale = 1 * multiplier;
  } else if (what_it_is == "Ts"){
    sigma_r = p.get_constant(command + "T_sigma_r");
    rho = p.get_constant(command + "T_rho",0);
    mean_on_linear_scale = p.get_constant(command + "T_mean");
  }
  mean_on_log_scale = log(mean_on_linear_scale) - sigma_r*sigma_r*0.5;
};

template<CDVM>
void Lognormal_empirical_randomiser<DVM>::apply(VECTOR& v, int first_random_year, long seed){
  // replace the elements of v to be randomised by (possibly autocorrelated)
  // standard normal random variables
  DEBUG1("Lognormal_empirical_randomiser::apply");
  if (first_random_year >= v.indexmax()){
    fatal("No years to randomise in Lognormal_empirical_randomiser::apply. Have you set the 'final' parameter correctly?");}
  dvector rands(first_random_year, v.indexmax());
  rands.fill_randn(seed);
  if (first_random_year == v.indexmin() || rho==0){
    v[first_random_year] = rands[first_random_year];
  } else {
    if (sigma_r == 0){
      fatal("last nonrandom year has implausible value: try increasing sigma_r or making rho=0 or moving to the 'none' randomisation method");}
    if (fabs((log(v[first_random_year - 1]) - mean_on_log_scale) / sigma_r) > 5){
      fatal("last nonrandom year has implausible value: try increasing sigma_r or making rho=0 or moving to the 'none' randomisation method");}
    DOUBLE previous_year = (log(v[first_random_year - 1]) - mean_on_log_scale) / sigma_r;
    v[first_random_year] = rho * previous_year + sqrt(1-rho*rho) * rands[first_random_year];
  }
  for (int i=first_random_year+1; i<=v.indexmax(); i++){
    v[i] = rho * v[i-1] + sqrt(1-rho*rho) * rands[i];
  }
  // convert the standard normal deviates back into YCS or T's
  for (int i=first_random_year; i<=v.indexmax(); i++){
    v[i] = exp(v[i]*sigma_r + mean_on_log_scale);
  }
};

template<CDVM>
void Lognormal_empirical_randomiser<DVM>::print(ostream& out){
  DEBUG2("Lognormal_empirical_randomiser::print");
  out << "lognormal with mean of " << mean_on_linear_scale;
  if(multiplier!=1) out << " (i.e., using recruitment_multiplier = " << multiplier << ")";
  out << ", standard deviation on the log-scale of " << sigma_r;
  if (rho != 0) out << " and autocorrelation on the log-scale of " << rho;
};

template<CDVM>
Lognormal_empirical_randomiser<DVM>::Lognormal_empirical_randomiser(
                                                Parameter_set<DVM>& p,
                                                const std::string& what_it_is,
                                                const std::string& command,
                                                const VECTOR& original_values){
  // Construct the randomiser from the Parameter_set (from which get rho)
  //   and the original values (from which get sigma_r).
  DEBUG1("Lognormal_empirical_randomiser::Lognormal_empirical_randomiser");
  /*
  std::string command;
  if (stock==""){
    command = "recruitment.";
  } else {
    command = "recruitment[" + stock + "].";
  }
  */
  dvector year_range(1,2);
  if (what_it_is == "YCS"){
    if (p.present(command + "year_range")){
      if(p.get_constant_vector(command + "year_range").size()!=2)
        fatal("In " + command + "year_range, you must supply exactly 2 values\n");
      year_range = p.get_constant_vector(command + "year_range");
    } else {
      year_range[1] = original_values.indexmin();
      year_range[2] = original_values.indexmax();
    }
    rho = p.get_constant(command + "rho",0);
    multiplier = p.get_constant(command + "recruitment_multiplier",1);
    if(multiplier <=ZERO || multiplier > 100)
      fatal("The value of " + command + "recruitment_multiplier is either less than or equal to zero, or an implausibly high number (>100). Please use a more sensible value.");
  } else if (what_it_is == "Ts"){
    if (p.present(command + "T_year_range")){
      if(p.get_constant_vector(command + "T_year_range").size()!=2)
        fatal("In " + command + "T_year_range, you must supply exacly 2 values\n");
      year_range = p.get_constant_vector(command + "T_year_range");
    } else {
      year_range[1] = original_values.indexmin();
      year_range[2] = original_values.indexmax();
    }
    rho = p.get_constant(command + "T_rho",0);
  }
  if(year_range[1] < original_values.indexmin() || year_range[2] > original_values.indexmax())
    fatal("In " + command + "year_range, the values must be in the range between " + itos(original_values.indexmin()) + " and " + itos(original_values.indexmax()) + "\n");
  if(year_range[1] > year_range[2])
    fatal("In " + command + "year_range, the values must be in increasing order\n");
  dvector original_values_in_range((int)(year_range[1]),(int)(year_range[2]));
  for (int i=(int)year_range[1]; i<=(int)year_range[2]; i++){
    original_values_in_range[i] = value(original_values[i]);
  }
  sigma_r = std_dev(log(original_values_in_range));
  mean_on_linear_scale = mean(original_values_in_range) * multiplier;
  mean_on_log_scale = log(mean_on_linear_scale) - sigma_r*sigma_r*0.5;
};

template<CDVM>
void Empirical_randomiser<DVM>::apply(VECTOR& v, int first_random_year, long seed){
  // Sampling with replacement
  DEBUG1("Empirical_randomiser::apply");
  if (first_random_year >= v.indexmax()){
    fatal("No years to randomise in Empirical_randomiser::apply. Have you set the 'final' parameter correctly?");}
  dvector rands(first_random_year,v.indexmax());
  // Generate random indices from 1 to (resample_from->size())
  // but that could produce indices of 0, with very small prob... check for these later
  rands.fill_randu(seed);
  rands = ceil(rands * resample_from->size());
  for (int i=first_random_year; i<=v.indexmax(); i++){
    v[i] = (*resample_from)[fmax(rands[i],1)];
  }
};

template<CDVM>
void Empirical_randomiser<DVM>::print(ostream& out){
  DEBUG2("Empirical_randomiser::print");
  out << "resample from these values";
  if(multiplier!=1) out << " (i.e., using recruitment_multiplier = " << multiplier << ") ";
  out << (*resample_from);
};

template<CDVM>
Empirical_randomiser<DVM>::Empirical_randomiser(Parameter_set<DVM>& p,
                                              const std::string& what_it_is,
                                              const std::string& command,
                                              const VECTOR& original_values){
  // Construct the randomiser from the original values,
  //   the Parameter_set (from which get the range of years to be resampled from)
  //   and the first year to be randomised.
  DEBUG1("Empirical_randomiser::Empirical_randomiser");
  /*
  std::string command;
  if (stock==""){
    command = "recruitment.";
  } else {
    command = "recruitment[" + stock + "].";
  }
  */
  dvector year_range(1,2);
  if (what_it_is == "YCS"){
    if (p.present(command + "year_range")){
      if(p.get_constant_vector(command + "year_range").size()!=2)
        fatal("In " + command + "year_range, you must supply exactly 2 values\n");
      year_range = p.get_constant_vector(command + "year_range");
    } else {
      year_range[1] = original_values.indexmin();
      year_range[2] = original_values.indexmax();
    }
    multiplier = p.get_constant(command + "recruitment_multiplier",1);
    if(multiplier <=ZERO || multiplier > 100)
      fatal("The value of " + command + "recruitment_multiplier is either less than or equal to zero, or an implausibly high number (>100). Please use a more sensible value.");
  } else if (what_it_is == "Ts"){
    if (p.present(command + "T_year_range")){
      if(p.get_constant_vector(command + "T_year_range").size()!=2)
        fatal("In " + command + "T_year_range, you must supply exacly 2 values\n");
      year_range = p.get_constant_vector(command + "T_year_range");
    } else {
      year_range[1] = original_values.indexmin();
      year_range[2] = original_values.indexmax();
    }
  } else if(what_it_is=="migration_annual_variation"){
    if (p.present(command + "annual_variation_year_range")){
      if(p.get_constant_vector(command + "annual_variation_year_range").size()!=2)
        fatal("In " + command + "annual_variation_year_range, you must supply exactly 2 values\n");
      year_range = p.get_constant_vector(command + "annual_variation_year_range");
    } else {
     dvector annual_variation_years= p.get_constant_vector(command + "annual_variation_year_range");
       year_range[1] = original_values.indexmin();
       year_range[2] = original_values.indexmax();
    }
  multiplier = 1;
  }

  if(year_range[1] < original_values.indexmin() || year_range[2] > original_values.indexmax())
    fatal("In " + command + ", the values of year_range must be in the range between " + itos(original_values.indexmin()) + " and " + itos(original_values.indexmax()) + "\n");
  if(year_range[1] > year_range[2])
    fatal("In " + command + ", the values of year_range must be in increasing order\n");
  resample_from = new dvector(1,(int)year_range[2]-(int)year_range[1]+1);
  for (int i=(int)year_range[1]; i<=(int)year_range[2]; i++){
    (*resample_from)[i-year_range[1]+1] = value(original_values[i]) * multiplier;
  }
};

template<CDVM>
Empirical_randomiser<DVM>::~Empirical_randomiser(){
  DEBUG2("~Empirical_randomiser()");
  delete resample_from;
}

template<CDVM>
void No_randomiser<DVM>::apply(VECTOR& v, int first_random_year, long seed){
  DEBUG1("No_randomiser::apply");
  // Error out, instead of proceeding
  // fatal("You are running a stochastic simulation, but you have not specified a recruitment randomisation method for one or more of your stocks (or you specified 'none')");
  // Reinstated, and moved the error check for simulations to elsewhere
  for (int i=first_random_year; i<=v.indexmax(); i++){
    v[i] = level;
  }
}

template<CDVM>
void No_randomiser<DVM>::print(ostream& out){
  DEBUG2("No_randomiser::print");
  out << "constant at";
  if(multiplier!=1) out << " (i.e., using recruitment_multiplier = " << multiplier << ") ";
  out << level;
}

template<CDVM>
No_randomiser<DVM>::No_randomiser(Parameter_set<DVM>& p,
                                  const std::string& what_it_is,
                                  const std::string& command,
                                  const VECTOR& _original_values){
  // find the constant level
  DEBUG1("No_randomiser::No_randomiser");
  /*
  std::string command;
  if (stock==""){
    command = "recruitment.";
  } else {
    command = "recruitment[" + stock + "].";
  }
  */
  if (what_it_is == "YCS"){
    multiplier = p.get_constant(command + "recruitment_multiplier",1);
    if(multiplier <=ZERO || multiplier > 100)
      fatal("The value of " + command + "recruitment_multiplier is either less than or equal to zero, or an implausibly high number (>100). Please use a more sensible value.");
    level = multiplier;
  } else if (what_it_is == "Ts"){
    level = p.get_constant(command+"T_mean");
  } else if (what_it_is == "migration_annual_variation") {
    // set the annual variation to be the average within the specified range
     int first=p.get_int(command+"annual_variation_first_free",(int) _original_values.indexmin());
     int last=p.get_int(command+"annual_variation_last_free",(int) _original_values.indexmax());
   if(first >= _original_values.indexmin() && last <= _original_values.indexmax()){
      level=1;
      for (int i=first;i<=last;i++){
       level = level+value(_original_values[i]/(last-first+1));
      }
   } else {
      level = 1;
   }
  }
}

//############################## AGEING ##############################
template<CDVM>
int Basic_ageing<DVM>::apply(Basic_state<DVM>& s, int year){
  // Age all fish in the partition by 1 year. Return 1.
  // Need to be careful of the trivial case with only one age/size class.
  DEBUG1("Basic_ageing::apply");
  for (int i=1; i<=s.n_rows; i++){
    if (s.plus_group){
      if (s.n_cols > 1){
        s.partition[i][s.col_max] += s.partition[i][s.col_max-1];
        for (int j=s.col_max-1; j>s.col_min; j--){
          s.partition[i][j] = s.partition[i][j-1];
        }
        s.partition[i][s.col_min] = 0;
      }
    } else {
      for (int j=s.col_max; j>s.col_min; j--){
        s.partition[i][j] = s.partition[i][j-1];
      }
      s.partition[i][s.col_min] = 0;
    }
  }
  return 1;
};

template<CDVM>
void Basic_ageing<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Basic_ageing::print");
  out << "  basic\n\n";
};

//############################## GROWTH (SIZE-BASED MODELS) ##############################
template<CDVM>
int Growth_years_same<DVM>::apply(Basic_state<DVM>& s, int year){
  // Apply a growth episode to the partition of s, by postmultiplying
  // each row i by transition_matrices[matrix_by_row[i]]. 'year' is ignored.
  // Return 1.
  DEBUG1("Growth_years_same::apply");
  for (int i=1; i<=s.n_rows; i++){
    if (matrix_by_row[i]!=-1){
      s.partition[i] = (s.partition[i] * transition_matrices[matrix_by_row[i]])[1];
      // the subscript converts a matrix with 1 row to a row vector
    }
  }
  return 0;
}

template<CDVM>
void Growth_years_same<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Growth_years_same::print");
  if (stock>0){
    out << "  For stock " << s.stock_names[stock] << '\n';}
  if (by_sex && !by_maturity){
    out << "  Transition matrix for males: \n";
    for (int i=1; i<=s.n_cols; i++) out << "  " << transition_matrices[0][i] << '\n';
    out << "\n  Transition matrix for females: \n";
    for (int i=1; i<=s.n_cols; i++) out << "  " << transition_matrices[1][i] << '\n';
  } else if (by_sex && by_maturity){
    out << "  Transition matrix for immature males: \n";
    for (int i=1; i<=s.n_cols; i++) out << "  " << transition_matrices[0][i] << '\n';
    out << "\n  Transition matrix for immature females: \n";
    for (int i=1; i<=s.n_cols; i++) out << "  " << transition_matrices[1][i] << '\n';
    out << "\n  Transition matrix for mature males: \n";
    for (int i=1; i<=s.n_cols; i++) out << "  " << transition_matrices[2][i] << '\n';
    out << "\n  Transition matrix for mature females: \n";
    for (int i=1; i<=s.n_cols; i++) out << "  " << transition_matrices[3][i] << '\n';
  } else if (!by_sex && by_maturity){
    out << "  Transition matrix for matures: \n";
    for (int i=1; i<=s.n_cols; i++) out << "  " << transition_matrices[0][i] << '\n';
    out << "\n  Transition matrix for immatures: \n";
    for (int i=1; i<=s.n_cols; i++) out << "  " << transition_matrices[1][i] << '\n';
  } else if (!by_sex && !by_maturity){
    out << "  Transition matrix: \n";
    for (int i=1; i<=s.n_cols; i++) out << "  " << transition_matrices[0][i] << '\n';
  }
  out << "\n";
};

template<CDVM>
Growth_years_same<DVM>::Growth_years_same(Parameter_set<DVM>& p,
                                          Basic_state<DVM>& s, int step, int i){
  // Construct growth process 'i' from p, s, and step.
  DEBUG1("Growth_years_same::Growth_years_same");
  matrix_by_row.push_back(-1);
  string temp = "growth["+itos(i)+"].";
  std::string stock_name = p.get_string(temp+"stock","");
  int stock_was_specified = 0;
  if (p.get_string(temp+"stock","")!="") stock_was_specified=1;
  if (s.n_stocks==1 && p.get_string(temp+"stock","")!="")
    fatal("You cannot supply the stock subcommand for growth (in growth block number " + itos(i) + ") in a single stock model");
  if (stock_name=="") stock=-1;
  else {
    if (!s.n_stocks==1){
      fatal("You cannot supply the stock subcommand in growth block number " + itos(i));}
    if (!s.valid_stock(stock_name)){
      fatal("You entered the invalid stock " + stock_name + " in growth block number " + itos(i));}
    stock=s.stock_numbers[stock_name];
  }
  int stock_char = s.character_numbers("stock");
  if (p.present(temp+"g_male_mature")){
    // Growth rates are specified by sex and maturity
    by_sex = 1;
    by_maturity = 1;
    int sex_char = s.character_numbers("sex");
    int maturity_char = s.character_numbers("maturity");
    if (sex_char == -1) fatal("You have used sex-based growth rates in an unsexed model");
    if (maturity_char == -1) fatal("You have used maturity-based growth rates in a model where maturity is not in the partition.");
    for (int i=1; i<=s.n_rows; i++){
      if (s.n_stocks>1){
        if (stock_was_specified && s.character_value(i,stock_char)!=stock){
          matrix_by_row.push_back(-1);
          continue;
        }
      }
      if (s.character_value(i,sex_char)==1 && s.character_value(i,maturity_char)==1){
        matrix_by_row.push_back(0);
      } else if (s.character_value(i,sex_char)==2 && s.character_value(i,maturity_char)==1){
        matrix_by_row.push_back(1);
      } else if (s.character_value(i,sex_char)==1 && s.character_value(i,maturity_char)==2){
        matrix_by_row.push_back(2);
      } else if (s.character_value(i,sex_char)==2 && s.character_value(i,maturity_char)==2){
        matrix_by_row.push_back(3);
      }
    }
    transition_matrices.push_back(make_matrix(s,p.get_estimable_vector(temp+"g"+"_male_immature"),
                                                p.get_estimable_vector(temp+"l"+"_male_immature"),
                                                p.get_estimable(temp+"cv"+"_male_immature"),
                                                p.get_estimable(temp+"minsigma"+"_male_immature"),
                                                p.get_string(temp+"type")));
    transition_matrices.push_back(make_matrix(s,p.get_estimable_vector(temp+"g"+"_female_immature"),
                                                p.get_estimable_vector(temp+"l"+"_female_immature"),
                                                p.get_estimable(temp+"cv"+"_female_immature"),
                                                p.get_estimable(temp+"minsigma"+"_female_immature"),
                                                p.get_string(temp+"type")));
    transition_matrices.push_back(make_matrix(s,p.get_estimable_vector(temp+"g"+"_male_mature"),
                                                p.get_estimable_vector(temp+"l"+"_male_mature"),
                                                p.get_estimable(temp+"cv"+"_male_mature"),
                                                p.get_estimable(temp+"minsigma"+"_male_mature"),
                                                p.get_string(temp+"type")));
    transition_matrices.push_back(make_matrix(s,p.get_estimable_vector(temp+"g"+"_female_mature"),
                                                p.get_estimable_vector(temp+"l"+"_female_mature"),
                                                p.get_estimable(temp+"cv"+"_female_mature"),
                                                p.get_estimable(temp+"minsigma"+"_female_mature"),
                                                p.get_string(temp+"type")));
  } else if (p.present(temp+"g_male")){
    // Growth rates are specified by sex
    by_sex = 1;
    by_maturity = 0;
    int sex_char = s.character_numbers("sex");
    if (sex_char == -1) fatal("You have used sex-based growth rates in an unsexed model");
    for (int i=1; i<=s.n_rows; i++){
      if (s.n_stocks>1){
        if (stock_was_specified && s.character_value(i,stock_char)!=stock){
          matrix_by_row.push_back(-1);
          continue;
        }
      }
      if (s.character_value(i,sex_char)==1){
        matrix_by_row.push_back(0);
      } else {
        matrix_by_row.push_back(1);
      }
    }
    transition_matrices.push_back(make_matrix(s,p.get_estimable_vector(temp+"g"+"_male"),
                                                p.get_estimable_vector(temp+"l"+"_male"),
                                                p.get_estimable(temp+"cv"+"_male"),
                                                p.get_estimable(temp+"minsigma"+"_male"),
                                                p.get_string(temp+"type")));
    transition_matrices.push_back(make_matrix(s,p.get_estimable_vector(temp+"g"+"_female"),
                                                p.get_estimable_vector(temp+"l"+"_female"),
                                                p.get_estimable(temp+"cv"+"_female"),
                                                p.get_estimable(temp+"minsigma"+"_female"),
                                                p.get_string(temp+"type")));
  } else if (p.present(temp+"g_mature")){
    // Growth rates are specified by maturity
    by_sex = 0;
    by_maturity = 1;
    int maturity_char = s.character_numbers("maturity");
    if (maturity_char == -1) fatal("You have used maturity-based growth rates in a model where maturity is not in the partition.");
    for (int i=1; i<=s.n_rows; i++){
      if (s.n_stocks>1){
        if (s.character_value(i,stock_char)!=stock){
          matrix_by_row.push_back(-1);
          continue;
        }
      }
      if (s.character_value(i,maturity_char)==1){
        matrix_by_row.push_back(0);
      } else {
        matrix_by_row.push_back(1);
      }
    }
    transition_matrices.push_back(make_matrix(s,p.get_estimable_vector(temp+"g"+"_immature"),
                                                p.get_estimable_vector(temp+"l"+"_immature"),
                                                p.get_estimable(temp+"cv"+"_immature"),
                                                p.get_estimable(temp+"minsigma"+"_immature"),
                                                p.get_string(temp+"type")));
    transition_matrices.push_back(make_matrix(s,p.get_estimable_vector(temp+"g"+"_mature"),
                                                p.get_estimable_vector(temp+"l"+"_mature"),
                                                p.get_estimable(temp+"cv"+"_mature"),
                                                p.get_estimable(temp+"minsigma"+"_mature"),
                                                p.get_string(temp+"type")));
  } else if (p.get_string(temp+"type")=="matrix") {
    // one transition matrix does it all
    by_sex = 0;
    by_maturity = 0;
    for (int i=1; i<=s.n_rows; i++){
      if (s.n_stocks>1){
        if (stock_was_specified && s.character_value(i,stock_char)!=stock){
          matrix_by_row.push_back(-1);
          continue;
        }
      }
      matrix_by_row.push_back(0);
    }
    // grab the matrix; check row lengths and sums
    dvector *row;
    MATRIX transition(1,s.n_cols,1,s.n_cols);
    transition.initialize();
    for (int i=1; i<=s.n_cols; i++){
      row = new dvector(p.get_constant_vector(temp + itos(i)));
      if (row->size() != s.n_cols){
        fatal("Row " + itos(i) + " of the growth transition matrix has the wrong length (" + itos(row->size()) + ", should be " + itos(s.n_cols) + ")");}
      // three decimals places lower bound for error of sum
      if (fabs(sum(*row) - 1.0) >= 5e-4){
        fatal("Row " + itos(i) + " of the growth transition matrix adds up to " + dtos(sum(*row)) + ". It should sum to 1");}
      for(int k=1; k<=s.n_cols; k++) {
        if((*row)[k]<0) fatal("Row " + itos(i) + " of the growth transition matrix has a negative value in column " + itos(k) + ". Values must be >= 0 and <= 1.");}
      transition[i] = (*row);
      delete row;
    }
    transition_matrices.push_back(transition);
  } else if (p.get_string(temp+"type")=="matrix_by_sex") {
    fatal("Definition of the growth transition type 'matrix_by_sex' has not yet been implemented");
  } else if (p.get_string(temp+"type")=="matrix_by_maturity") {
    fatal("Definition of the growth transition type 'matrix_by_maturity' has not yet been implemented");
  } else if (p.get_string(temp+"type")=="matrix_by_sex_and_maturity") {
    fatal("Definition of the growth transition type 'matrix_by_sex_and_maturity' has not yet been implemented");
  } else {
    // One set of growth rates fits all
    by_sex = 0;
    by_maturity = 0;
    for (int i=1; i<=s.n_rows; i++){
      if (s.n_stocks>1){
        if (stock_was_specified && s.character_value(i,stock_char)!=stock){
          matrix_by_row.push_back(-1);
          continue;
        }
      }
      matrix_by_row.push_back(0);
    }
    transition_matrices.push_back(make_matrix(s,p.get_estimable_vector(temp+"g"),
                                                p.get_estimable_vector(temp+"l"),
                                                p.get_estimable(temp+"cv"),
                                                p.get_estimable(temp+"minsigma"),
                                                p.get_string(temp+"type")));
  }
}

template<CDVM>
MATRIX Growth_years_same<DVM>::make_matrix(Basic_state<DVM>& s, const VECTOR& g, const VECTOR& l,
                                           const DOUBLE& cv, const DOUBLE& minsigma,
                                           const std::string growth_type_name){
  // This function is used to make a transition matrix for the basic growth method.
  // It is called by Growth_years_same<DVM>::Growth_years_same()
  DEBUG2("Growth_years_same::make_matrix");
  DOUBLE mu, stdev, sum_so_far;
  dvector l_c(1,s.n_cols);
  for (int i=1; i<s.n_cols; i++){
    l_c[i] = (s.class_mins[i]+s.class_mins[i+1])*0.5;
  }
  if (!s.plus_group){
    l_c[s.n_cols] = (s.class_mins[s.n_cols]+s.class_mins[s.n_cols+1])*0.5;
  }
  MATRIX transition(1,s.n_cols,1,s.n_cols);
  transition.initialize();
  for (int i=1; i<=s.n_cols; i++){
    // set the ith row, which is the transitions from the ith column.
    for (int j=1; j<i; j++){
      transition[i][j] = 0; // no negative growth
    }
    if (s.plus_group && i==s.n_cols){
      transition[i][i] = 1; // plus group can't grow any more
    } else {
      //mu = g[1] + (g[2]-g[1])*(l_c[i]-l[1])/(l[2]-l[1]);
      //stdev = fmax(cv*mu, minsigma);
      if(growth_type_name=="basic"){
        mu = g[1] + (g[2]-g[1])*(l_c[i]-l[1])/(l[2]-l[1]);
        stdev = fmax(cv*mu, minsigma);
      } else if (growth_type_name=="exponential"){
        mu = g[1] * pow(g[2]/g[1],(l_c[i]-l[1])/(l[2]-l[1]));
        stdev = fmax(cv*mu, minsigma);
      } else fatal("Unknown growth type: " + growth_type_name);
      transition[i][i] = pnorm<DOUBLE>(s.class_mins[i+1]-l_c[i],mu,stdev);
      sum_so_far = transition[i][i];
      for (int j=i+1;j<s.n_cols; j++){
        transition[i][j] = pnorm<DOUBLE>(s.class_mins[j+1]-l_c[i],mu,stdev) - sum_so_far;
        sum_so_far += transition[i][j];
      }
      if (s.plus_group){
        transition[i][s.n_cols] = 1 - sum_so_far;
      } else {
        transition[i][s.n_cols] = pnorm<DOUBLE>(s.class_mins[s.n_cols+1]-l_c[i],mu,stdev) - sum_so_far;
      }
    }
  }
  return transition;
}

//############################## SELECTIVITIES ##############################
template<CDVM>
MATRIX& Selectivity<DVM>::get_selectivity(int year, int step){
  // returns the values of the selectivity for the current year and step
  DEBUG2("Selectivity::get_selectivity");
  int changed_step = step != last_step_calculated;
  int changed_year = year != last_year_calculated;
  last_year_calculated = year;
  last_step_calculated = step;
  if (changed_step && changes_between_steps && !changes_between_years){
    // The selectivity has potentially changed since last time step
    // But we have calculated and stored the selectivity for this step,
    // which does not change between years.
       selectivities = sel_by_step[step];
       return selectivities;
  } else if ((changed_step && changes_between_steps) ||
             (changed_year && changes_between_years)){
    // Need to recalculate the selectivity.
    for (int i=1; i<=n_rows; i++){
      if (do_shift && year >= shift_E.indexmin() && year <= shift_E.indexmax()){
        DOUBLE shift = shift_a * (shift_E[year] - mean(shift_E));
        selectivities[i] = p->get_ogive_values(ogives[i],size_at_age,year,step,i,shift);
      } else {
        selectivities[i] = p->get_ogive_values(ogives[i],size_at_age,year,step,i);
      }
    }
    return selectivities;
  } else {
    // The selectivity has not changed since we calculated it last
     return selectivities;
  }
}

template<CDVM>
DOUBLE Selectivity<DVM>::get_val_by_size_in_agebased(int year,int step,int row,DOUBLE size){
  // Calculates the value of this size-based selectivity, used in an age-based model, but by size rather than by age.
  // Only used by Age_size observations at this stage - generally the selectivity would be converted to age-based before being used or queried.
  //
  // no DEBUG - used too frequently
  if (!sizebased_ogive_used){
          fatal("get_val_by_size_in_agebased has been called for an age-based ogive");}
  VECTOR sizes(1);
  sizes[1]=size;
  if (do_shift && year >= shift_E.indexmin() && year <= shift_E.indexmax()){
    DOUBLE shift = shift_a * (shift_E[year] - mean(shift_E));
    return p->get_ogive_values(ogives[row],size_at_age,year,step,row,shift,&sizes)[1];
  } else {
    return p->get_ogive_values(ogives[row],size_at_age,year,step,row,-999,&sizes)[1]; // -999 is code for 'no ogive shift'
  }
}

template<CDVM>
void Selectivity<DVM>::print(Basic_state<DVM>& s, ostream& out,
                             dvector& print_sizebased_ogives_at){
  // Prints the selectivity. If a size-based selectivity in an age-based model,
  // the third argument indicates the sizes for which the ogive is to be printed.
  DEBUG2("Selectivity::print");
  VECTOR print_at = print_sizebased_ogives_at;
  if (do_shift) out << "Values pre shift:\n  ";
  if (!(sizebased_ogive_used && !s.size_based)){
    // easy
    s.print_matrix(out,get_selectivity(p->get_int("initial"),1));
  } else {
    for (int step=0; step<sel_by_step.size(); step++){
      out << "in step " << step << " selectivity vals " << sel_by_step[step] << '\n';
    } /* sel_by_step */
    // the ogives are size-based in an age-based model: printing will be more complicated
    if (print_sizebased_ogives_at[1]==-1)
      cerr << "If you want to print size-based selectivities in an age-based model, you need to provide the output parameter print_sizebased_ogives_at.\n\n";
    else{
      out << "\nsize: " << print_at << '\n';
      for (int i=0; i<ogive_parameter_names.size(); i++){
        out << ogive_parameter_names[i] << " ";
        out << p->get_ogive_values(ogive_parameter_names[i],size_at_age,0,0,0,0,&print_at);
        out << '\n';
      }
    }
  }
  if (do_shift){
    out << "  Selectivities are shifted: the selectivity shift parameter a = " << shift_a;
    out << "  and the exogenous shift variable E is as follows:\n";
    out << "  E ";
    for (int year = shift_E.indexmin(); year <= shift_E.indexmax(); year++){
      out << shift_E[year] << ' ';}
    out << "\n  year ";
    for (int year = shift_E.indexmin(); year <= shift_E.indexmax(); year++){
      out << year << ' ';}
    out << '\n';
  }
  out << '\n';
}

template<CDVM>
Selectivity<DVM>::Selectivity(Parameter_set<DVM>& _p, Basic_state<DVM>& s, const std::string& _label,
                              Size_at_age< DVM>* _size_at_age)
  : label(_label)
  , command("selectivity["+label+"].")
  , selectivities(1,s.n_rows,s.col_min,s.col_max)
  , shift_E(_p.get_estimable_vector(command+"shift_E",VECTOR("{-1}"))){
  // Construct the selectivity object called 'name' from the Parameter_set.
  // Keep a pointer to the size-at-age object, and to the parameter set (the latter so we
  //   can call get_ogive_values from within get_selectivity)
  DEBUG1("Selectivity::selectivity");
  size_at_age = _size_at_age;
  p = &_p;
  n_rows = s.n_rows;
  changes_between_steps = changes_between_years = 0;
  do_shift = _p.present(command+"shift_a");
  if (do_shift){
    shift_a = _p.get_estimable(command+"shift_a",0);
    dvector shift_years(_p.get_constant_vector(command+"shift_years"));
    for (int k=2; k<=shift_years.indexmax(); k++){
      if (shift_years[k] != (shift_years[k-1]+1)){
        fatal(command + "shift_years should be consecutive integers");
      }
    }
    if (shift_E.size() != shift_years.size()){
      fatal(command +"shift_E should be the same size as " + command + "shift_years");}
    shift_E.shift((int)(shift_years[1])); // sorry about all the 'shift's!
    changes_between_years = 1;
  }
  // extract the ogives
  ogives.resize(s.n_rows+1);
  int sex_char = s.character_numbers("sex");
  int maturity_char = s.character_numbers("maturity");
  if (_p.present(command + "male")){
    // ogive is specified by sex
    sel_depends_on_sex = 1;
    if (sex_char == -1) fatal("You have used sex-based selectivities in an unsexed model.");
    for (int i=1; i<=s.n_rows; i++){
      if (s.character_value(i,sex_char) == 1){
        ogives[i] = command + "male";
      } else {
        ogives[i] = command + "female";
      }
    }
    ogive_parameter_names.resize(2);
    ogive_parameter_names[0] = command + "male";
    ogive_parameter_names[1] = command + "female";

  } else if (_p.present(command + "mature")){
    // ogive is specified by maturity (1 - immature, 2 - mature)
    sel_depends_on_sex = 0;
    if (maturity_char == -1) fatal("You have used maturity-based selectivities in a model where maturity is not in the partition.");
    for (int i=1; i<=s.n_rows; i++){
      if (s.character_value(i,maturity_char) == 1){
        ogives[i] = command + "immature";
      } else {
        ogives[i] = command + "mature";
      }
    }
    ogive_parameter_names.resize(2);
    ogive_parameter_names[0] = command + "immature";
    ogive_parameter_names[1] = command + "mature";
  } else if (_p.present(command + "male_mature")){
    // ogive is specified by sex and maturity  (1 - immature, 2 - mature &  1 - male, 2 - female)
    sel_depends_on_sex = 1;
    if (sex_char == -1) fatal("You have used sex-based selectivities in an unsexed model.");
    if (maturity_char == -1) fatal("You have used maturity-based selectivities in a model where maturity is not in the partition.");
    for (int i=1; i<=s.n_rows; i++){
      if (s.character_value(i,maturity_char) == 1 && s.character_value(i,sex_char) == 1){
        ogives[i] = command + "male_immature";
      } else if (s.character_value(i,maturity_char) == 1 && s.character_value(i,sex_char) == 2){
        ogives[i] = command + "female_immature";
      } else if (s.character_value(i,maturity_char) == 2 && s.character_value(i,sex_char) == 1){
        ogives[i] = command + "male_mature";
      } else if (s.character_value(i,maturity_char) == 2 && s.character_value(i,sex_char) == 2){
        ogives[i] = command + "female_mature";
      }
    }
    ogive_parameter_names.resize(4);
    ogive_parameter_names[0] = command + "male_immature";
    ogive_parameter_names[1] = command + "female_immature";
    ogive_parameter_names[2] = command + "male_mature";
    ogive_parameter_names[3] = command + "female_mature";

  } else {
    // ogive is specified by neither sex nor maturity
    sel_depends_on_sex = 0;
    for (int i=1; i<=s.n_rows; i++){
      ogives[i] = command + "all";
    }
    ogive_parameter_names.resize(1);
    ogive_parameter_names[0] = command + "all";
  }
  // If size-based ogives in an age-based model, do they change between years and/or time steps?
  if (!s.size_based){
    sizebased_ogive_used = -1;
    for (int i=0; i<ogive_parameter_names.size(); i++){
      if (_p.get_ogive_base(ogive_parameter_names[i])==1){
        if (sizebased_ogive_used == 0){
          fatal("Don't use a mixture of size-based and age-based ogives in the same selectivity");}
        sizebased_ogive_used = 1;
      } else {
        if (sizebased_ogive_used == 1){
          fatal("Don't use a mixture of size-based and age-based ogives in the same selectivity");}
        sizebased_ogive_used = 0;
      }
    }
    if (sizebased_ogive_used){
      if (_p.present("annual_cycle.growth_props")){
        dvector growth_props(_p.get_constant_vector("annual_cycle.growth_props"));
        if (max(growth_props) > 0){
          changes_between_steps = 1;
        }
      }
      if (size_at_age->varies_between_years()){
        changes_between_years = 1;
      }
    }
  }
  // calculate selectivities
  last_year_calculated = -1;
  last_step_calculated = 1;
  for (int i=1; i<=s.n_rows; i++){
    selectivities[i] = _p.get_ogive_values(ogives[i],size_at_age,
                                           last_year_calculated,last_step_calculated,i);
  }
  if (changes_between_steps && !changes_between_years){
    // calculate and store the values in each step
    int steps = _p.get_int("annual_cycle.time_steps");
    sel_by_step.push_back(dmatrix(1,1));
    for (int step=1; step<=steps; step++){
      last_step_calculated = step;
      for (int i=1; i<=s.n_rows; i++){
        selectivities[i] = _p.get_ogive_values(ogives[i],size_at_age,
                                               last_year_calculated,last_step_calculated,i);
      }
      sel_by_step.push_back(selectivities);
    }
  }
}

//############################## MORTALITY ##############################
template<CDVM>
int No_mortality<DVM>::apply(Basic_state<DVM>& s, int year,
                             Basic_requests<DVM>* requests, Basic_results<DVM>* results,
                             double F_to_use, std::map<std::string,double> *catches_this_year){
  // Do nothing.
  // Ignore the 'requests' and 'results' arguments.
  // Return 1.
  DEBUG1("No_mortality::apply");
  return 1;
};

template<CDVM>
void No_mortality<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("No_mortality::print");
  out << "  none" << "\n\n";
};

template<CDVM>
No_mortality<DVM>::No_mortality(Parameter_set<DVM>& p, Basic_state<DVM>& s, int step){
  // Nothing to do
  DEBUG1("No_mortality<DVM>::no_mortality");
}

template<CDVM>
int Natural_only_by_row<DVM>::apply(Basic_state<DVM>& s, int year,
                                    Basic_requests<DVM>* requests, Basic_results<DVM>* results,
                                    double F_to_use, std::map<std::string,double> *catches_this_year){
  // Apply a time step's natural mortality to the partition of s in year.
  // Multiply each row i of the partition by exp(-Mt_by_row[i]).
  // Ignore the 'year', 'requests', 'results', 'F_to_use', and 'catches_this_year' arguments.
  // Return 1.
  DEBUG1("Natural_only_by_row::apply");
  for (int i=1; i<=s.n_rows; i++){
    s.partition[i] *= exp_minus_Mt_by_row[i];
  }
  return 1;
};

template<CDVM>
void Natural_only_by_row<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Natural_only_by_row::print");
  out << "  natural only: \n";
  s.print_vector(out,Mt_by_row,"M*t");
  out << '\n';
};

template<CDVM>
Natural_only_by_row<DVM>::Natural_only_by_row(Parameter_set<DVM>& p, Basic_state<DVM>& s, int step,
                                              const dvector& M_props)
  : Mt_by_row(1,s.n_rows)
  , exp_minus_Mt_by_row(1,s.n_rows){
  // Construct the mortality process for 'step' from p and s.
  DEBUG1("Natural_only_by_row::Natural_only_by_row");
  // extract the M's from the parameter set
  get_Mt_by_row(Mt_by_row,p,s,step,M_props);
  exp_minus_Mt_by_row = exp(-Mt_by_row);
}

template<CDVM>
void get_Mt_by_row(VECTOR& Mt_by_row, Parameter_set<DVM>& p,Basic_state<DVM>& s, int step,
                   const dvector& M_props, int mort_block = 1){
  // I pulled this code out into a separate function because multiple Mortality methods
  // use it. It extracts the instantaneous natural mortality rates for 'step'
  // from the Parameter_set into Mt_by_row, where Mt_by_row[i] is the M*t for the ith
  // row of the partition.
  //
  // If the number of @natural_mortality blocks is greater than one (mort_block > 1)
  // then only the mortality rates for the stock corresponding to that mortality
  // block are changed. Note if there is more than one @natural_mortality block then
  // each of them has to be labelled with a stock; if there is only one block it
  // should be unlabelled.

  DEBUG2("get_Mt_by_row");

  std::string command;
  vector<int> rows_to_change;
  rows_to_change.push_back(-99);  // skip the 0th index

  int stock_code = s.character_numbers("stock");
  int num_mort_blocks =  p.get_command_count("natural_mortality");

  if (num_mort_blocks == 1){
    command = "natural_mortality.";
    for (int j =1; j<=s.n_rows ; j++) rows_to_change.push_back(j);
  }
  else if(num_mort_blocks > 1){
    // There's a stock corresponding to each @natural mortality block
    command = "natural_mortality[" + s.stock_names[mort_block] + "].";
    dvector temp = s.rows_with(stock_code,mort_block);
    for (int k = 1; k<=temp.size() ; k++) rows_to_change.push_back((int)(temp[k]));
  }

  // first go through and get M for each row
  int sex_char = s.character_numbers("sex");
  int maturity_char = s.character_numbers("maturity");

  if (p.present(command + "male")){
    // M's specified by sex
    if (sex_char == -1) fatal("You have specified M by sex in an unsexed model.");
    VECTOR Ms(1,2);
    Ms[1] = p.get_estimable(command + "male");
    Ms[2] = p.get_estimable(command + "female");
    for (int k=1; k<=rows_to_change.size()-1; k++){
      int i = rows_to_change[k];
      Mt_by_row[i] = Ms[s.character_value(i,sex_char)];
    }
  }

  else if (p.present(command + "avg")){
    // M's specified by sex, as 'avg' ((male + female)/2) and 'diff' (male - female)
    if (sex_char == -1) fatal("You have specified M by sex in an unsexed model.");
    VECTOR Ms(1,2);
    DOUBLE avg, diff;
    avg = p.get_estimable(command + "avg");
    diff = p.get_estimable(command + "diff");
    Ms[1] = avg + (diff*0.5);
    Ms[2] = avg - (diff*0.5);
    for (int k=1; k<=rows_to_change.size()-1; k++){
      int i = rows_to_change[k];
      Mt_by_row[i] = Ms[s.character_value(i,sex_char)];
    }
  }

  else if (p.present(command + "mature")){
    // M's specified by maturity
    if (maturity_char == -1) fatal("You have specified M by maturity status in a model where maturity is not a character in the partition.");
    VECTOR Ms(1,2);
    Ms[1] = p.get_estimable(command + "immature");
    Ms[2] = p.get_estimable(command + "mature");
    for (int k=1; k<=rows_to_change.size()-1; k++){
      int i = rows_to_change[k];
      Mt_by_row[i] = Ms[s.character_value(i,maturity_char)];
    }
  }

  else if (p.present(command + "male_mature")){
    // M's specified by sex and maturity
    if (sex_char == -1) fatal("You have specified M by sex in an unsexed model.");
    if (maturity_char == -1) fatal("You have specified M by maturity status in a model where maturity is not a character in the partition.");
    VECTOR Ms(1,4);
    Ms[1] = p.get_estimable(command + "male_immature");
    Ms[2] = p.get_estimable(command + "female_immature");
    Ms[3] = p.get_estimable(command + "male_mature");
    Ms[4] = p.get_estimable(command + "female_mature");
    for (int k=1; k<=rows_to_change.size()-1; k++){
      int i = rows_to_change[k];
      Mt_by_row[i] = Ms[s.character_value(i,maturity_char)*2 + s.character_value(i,sex_char) - 2];
    }
  }

  else if (p.present(command + "all")){
    // one set of M's fit all
    VECTOR Ms(1,1);
    Ms[1] = p.get_estimable(command + "all");
    for (int k=1; k<=rows_to_change.size()-1; k++){
      int i = rows_to_change[k];
      Mt_by_row[i] = Ms[1];
    }
  }

  else {
     fatal("You haven't specified a valid set of natural mortality rates. Check your syntax.");
  }

  DOUBLE min_m =  1E6;
  DOUBLE max_m = -1E6;
  for (int k=1; k<=rows_to_change.size()-1; k++){
    int i = rows_to_change[k];
    DOUBLE const temp_value = Mt_by_row[i];
    if ( value(temp_value) < value(min_m) ) min_m = temp_value;
    if ( value(temp_value) > value(max_m) ) max_m = temp_value;
  }

    if (min_m<0){
          if(p.get_bool("natural_mortality.allow_negative_M",0)==0){
            cerr << "You have specified a negative natural mortality rate of " << min_m;
            fatal(" - this must be an error.");
          } else {
            static int negative_M_print_message=1;
            if(negative_M_print_message) {
              cerr << "Warning: you have specified a negative natural mortality rate of " << min_m << " - this may be an error." << endl;
              negative_M_print_message=0;
            }
          }
    } else if (max_m>5){
          cerr << "You have specified an enormous natural mortality rate of " << max_m;
          fatal(" - this must be an error.");
    }

  // lastly multiply M up by t
  DOUBLE t = M_props[step];
  for (int k=1; k<=rows_to_change.size()-1; k++){
    int i = rows_to_change[k];
    Mt_by_row[i] *= t;
  }
}

template<CDVM>
int Natural_only_by_element<DVM>::apply(Basic_state<DVM>& s, int year,
                                        Basic_requests<DVM>* requests, Basic_results<DVM>* results,
                                        double F_to_use,
                                        std::map<std::string,double> *catches_this_year){
  // Apply a time step's natural mortality to the partition of s in year.
  // Multiply each row i of the partition by exp(-Mt_by_element[i][j]).
  // Ignore the 'year', 'requests', 'results', 'F_to_use', and 'catches_this_year' arguments.
  // Return 1.
  DEBUG1("Natural_only_by_element::apply");
  for (int i=1; i<=s.n_rows; i++){
    s.partition[i] *= exp_minus_Mt_by_element[i];
  }
  return 1;
};

template<CDVM>
void Natural_only_by_element<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Natural_only_by_element::print");
  out << "  natural only: M*t = \n";
  s.print_matrix(out,Mt_by_element);
  out << '\n';
};

template<CDVM>
Natural_only_by_element<DVM>::Natural_only_by_element
  (Parameter_set<DVM>& p,Basic_state<DVM>& s, int step, const dvector& M_props,
   Size_at_age<DVM>* size_at_age)
  : Mt_by_element(1,s.n_rows,s.col_min,s.col_max)
  , exp_minus_Mt_by_element(1,s.n_rows,s.col_min,s.col_max){
  // Construct the mortality process for 'step' from p and s,
  // using size-at-age if necessary to make age-based ogives from size-based.
  DEBUG1("Natural_only_by_element::Natural_only_by_element");
  // extract the M's from the parameter set
  get_Mt_by_element(Mt_by_element,p,s,step,M_props,size_at_age);
  for (int i=Mt_by_element.rowmin(); i<=Mt_by_element.rowmax(); i++){
    exp_minus_Mt_by_element[i] = exp(-Mt_by_element[i]);
  }
}

template<CDVM>
void get_Mt_by_element(MATRIX& Mt_by_element,Parameter_set<DVM>& p,Basic_state<DVM>& s, int step,
                       const dvector& M_props, Size_at_age<DVM>* size_at_age){
  // I pulled this code out into a separate function because multiple Mortality methods
  // use it. It extracts the instantaneous natural mortality rates for 'step'
  // from the Parameter_set into Mt_by_element, where Mt_by_element[i][j] is the M*t for the
  // [i,j]th row of the partition. Size_at_age may be needed to convert size-based ogives
  // into age-based.
  //
  // The function loops over each @natural_mortality block, changing the natural mortality
  // just for the stock that labels the @natural_mortality block. Note if there is more than
  // one @natural_mortality block then each of them has to be labelled with a stock; if there
  // is only one block it should be unlabelled.

DEBUG2("get_Mt_by_element");

int stock_code = s.character_numbers("stock");
int num_mort_blocks =  p.get_command_count("natural_mortality");

for(int mort_block = 1; mort_block<=num_mort_blocks; mort_block++){

    std::string command;
    vector<int> rows_to_change;   // rows for a given stock (that labels a @natural_mortality block)
    rows_to_change.push_back(-99);   // Skip the 0th index

    if (num_mort_blocks == 1){
       command = "natural_mortality.ogive_";
       for (int j = 1; j<=s.n_rows ; j++) rows_to_change.push_back(j);
    }
    else if(num_mort_blocks > 1){
       // There's a stock corresponding to each @natural mortality block
       command = "natural_mortality[" + s.stock_names[mort_block] + "].ogive_";
       dvector temp = s.rows_with(stock_code,mort_block);
       for (int k = 1; k<=temp.size() ; k++) rows_to_change.push_back((int)(temp[k]));
    }
    else fatal("The number of @natural_mortality blocks is not a positive integer");

    if (!p.present(command + "all") &&
        !p.present(command + "male") &&
        !p.present(command + "avg") &&
        !p.present(command + "mature") &&
        !p.present(command + "male_mature") ) {

        // natural mortality doesn't appear to depend on age/size class (it's not given as an ogive):
        // call the simpler get_Mt_by_row.
        VECTOR Mt_by_row(1,s.n_rows);
        get_Mt_by_row(Mt_by_row,p,s,step,M_props, mort_block);

        for (int k=1; k<=rows_to_change.size()-1; k++){
          int i = rows_to_change[k];
          for (int j=s.col_min; j<=s.col_max; j++){
            Mt_by_element[i][j] = Mt_by_row[i];
          }
        }

     }


  // Otherwise use the Mt_by_element function
  else {
    // extract the M's from the Parameter_set
    int sex_char = s.character_numbers("sex");
    int maturity_char = s.character_numbers("maturity");
    VECTOR zeros(s.col_min,s.col_max);
    zeros.initialize();
    int sizebased_ogive_used = 0;

        if (p.present(command + "male")){
          // ogive is specified by sex
          if (sex_char == -1) fatal("You have specified M by sex in an unsexed model.");
          sizebased_ogive_used = (p.get_ogive_base(command + "male") || p.get_ogive_base(command + "female"));
          for (int k=1; k<=rows_to_change.size()-1; k++){
            int i = rows_to_change[k];
            if (s.character_value(i,sex_char) == 1){
              Mt_by_element[i] = p.get_ogive_values(command + "male",size_at_age,-1,step,i);
            } else {
              Mt_by_element[i] = p.get_ogive_values(command + "female",size_at_age,-1,step,i);
            }
          }
        } else if (p.present(command + "mature")){
          // ogive is specified by maturity
          if (maturity_char == -1) fatal("You have specified M by maturity status in a model where maturity is not a character in the partition.");
          sizebased_ogive_used = (p.get_ogive_base(command + "mature") ||
                                  p.get_ogive_base(command + "immature"));
          for (int k=1; k<=rows_to_change.size()-1; k++){
            int i = rows_to_change[k];
            if (s.character_value(i,maturity_char) == 1){
              Mt_by_element[i] = p.get_ogive_values(command + "immature",size_at_age,-1,step,i);
            } else {
              Mt_by_element[i] = p.get_ogive_values(command + "mature",size_at_age,-1,step,i);
            }
          }
        } else if (p.present(command + "male_mature")){
          // ogive is specified by sex and maturity
          if (sex_char == -1) fatal("You have specified M by sex in an unsexed model.");
          if (maturity_char == -1) fatal("You have specified M by maturity status in a model where maturity is not a character in the partition.");
          sizebased_ogive_used = (p.get_ogive_base(command + "male_mature") ||
                                  p.get_ogive_base(command + "male_immature") ||
                                  p.get_ogive_base(command + "female_mature") ||
                                  p.get_ogive_base(command + "female_immature"));
          for (int k=1; k<=rows_to_change.size()-1; k++){
            int i = rows_to_change[k];
            if (s.character_value(i,maturity_char) == 1 && s.character_value(i,sex_char) == 1){
              Mt_by_element[i] = p.get_ogive_values(command + "male_immature",size_at_age,-1,step,i);
            } else if (s.character_value(i,maturity_char) == 1 && s.character_value(i,sex_char) == 2){
              Mt_by_element[i] = p.get_ogive_values(command + "female_immature",size_at_age,-1,step,i);
            } else if (s.character_value(i,maturity_char) == 2 && s.character_value(i,sex_char) == 1){
              Mt_by_element[i] = p.get_ogive_values(command + "male_mature",size_at_age,-1,step,i);
            } else if (s.character_value(i,maturity_char) == 2 && s.character_value(i,sex_char) == 2){
              Mt_by_element[i] = p.get_ogive_values(command + "female_mature",size_at_age,-1,step,i);
            }
          }
        } else if (p.present(command + "avg")){
          // M's specified by sex, as 'avg' ((male + female)/2) and 'diff' (male - female)
          // 1 -> male, 2 -> female  is the character coding
          if (sex_char == -1) fatal("You have specified natural mortality by sex in an unsexed model.");
          sizebased_ogive_used = (p.get_ogive_base(command + "avg" ) || p.get_ogive_base(command + "diff") );
          for (int k=1; k<=rows_to_change.size()-1; k++){
            int i = rows_to_change[k];
            VECTOR avg  = p.get_ogive_values(command + "avg", size_at_age,-1,step,i);
            VECTOR diff = p.get_ogive_values(command + "diff",size_at_age,-1,step,i);
            VECTOR M1 = avg + (diff*0.5);
            VECTOR M2 = avg - (diff*0.5);
            if (s.character_value(i,sex_char) == 1)
              Mt_by_element[i] = M1;
            else if (s.character_value(i,sex_char) == 2)
              Mt_by_element[i] = M2;
            else
                fatal("Sex code can only take values -1,1,2");
          }
        } else {
          // ogive is specified by neither sex nor maturity
          sizebased_ogive_used = (p.get_ogive_base(command + "all"));
          for (int k=1; k<=rows_to_change.size()-1; k++){
            int i = rows_to_change[k];
            Mt_by_element[i] = p.get_ogive_values(command + "all",size_at_age,-1,step,i);
          }
        }

        for (int k=1; k<=rows_to_change.size()-1; k++){
          int i = rows_to_change[k];
          if (min(Mt_by_element[i])<0){
                if(p.get_bool("natural_mortality.allow_negative_M",0)==0){
                  cerr << "You have specified a negative natural mortality rate of " << min(Mt_by_element[i]);
                  fatal(" - this must be an error.");
                } else {
                  static int negative_M_print_message=1;
                  if(negative_M_print_message) {
                    cerr << "Warning: you have specified a negative natural mortality rate of " << min(Mt_by_element[i]) << " - this may be an error." << endl;
                    negative_M_print_message=0;
                  }
                }
          } else if (max(Mt_by_element[i])>5){
                cerr << "You have specified an enormous natural mortality rate of " << max(Mt_by_element[i]);
                fatal(" - this must be an error.");
          }
            }
        if (sizebased_ogive_used && !s.size_based && size_at_age->varies_between_years()){
          fatal("You have requested size-based natural mortality rates in an age-based model where fish size varies between years. This combination of options is not implemented yet - sorry.");}

        // Multiply up by t:
        DOUBLE t = M_props[step];
        for (int k=1; k<=rows_to_change.size()-1; k++){
          int i = rows_to_change[k];
          Mt_by_element[i] *= t;
        }


  }  // end of if block: extract M's from the Parameter_set

}    // end of loop over number of @natural_mortality blocks

}

template<CDVM>
int Basic_fisheries<DVM>::apply(Basic_state<DVM>& s, int year,
                                Basic_requests<DVM>* requests, Basic_results<DVM>* results,
                                double F_to_use, std::map<std::string,double> *catches_this_year){
  // Apply a time step's natural and fishing mortality to the partition of s in 'year'.
  // If 'catches_this_year' is supplied, then use it in place of the catches stored
  //  in the mortality object (this happens in simulation). Error out if 'F_to_use' is supplied.
  // For each fishery f {
  //  for each i in rows[f], calculate selected biomass as the sum of
  //  mean_weight->get_row(s,i) * selectivity(f,i,year) * partition[i] * exp(-0.5*Mt_by_element[i]).
  //  Sum selected biomass over rows, calculate Uf as catches[f][year] over selected biomass.
  // }
  // For each row i of the partition {
  //  calculate Ri = sum over fisheries f for which i is in rows[f] of (selectivity(f,i,year)*Uf)
  // }
  // For each fishery f {
  //  Calculate Uobs_f =  maximum over rows i in rows[f] of Rij
  //  If Uobs_f > Umax, set results->fishing_pressure_limit_exceeded=1.
  //  Multiply Uf by fmin(1,Uf*Umax/Uobs_f)
  // }
  // If any exploitation rate constraint was exceeded, recalculate the Ri's.
  //
  // Requests for results:
  // For each fishery f {
  //  If requests->fishing_pressure, fill in fishing pressures:
  //   results->fishing_pressure[year][fishery_names[f]] = Uobs_f as above.
  //  If requests->actual_catches, fill in actual catches:
  //    results->actual_catch[year][fishery_names[f]] = Uf * selected biomass.
  //   and specified catches.
  //  If requests->actual_catches_by_stock, recalculate selected biomass by stock
  //    and fill in actual catch for each stock as Uf * selected biomass.
  //  Fill in catch-at if requested (or increment it, if it covers 2 or more fisheries of which
  //                                 1 or more have already been filled in for this year):
  //   it is Uf * sum over rows[f] of (selectivity(f,i,year) * partition[i] * exp(-0.5*Mt_by_element[i]));
  //   if sexed, the summation is restricted accordingly,
  //   and if catch-at-size in an age-based model,
  //   multiply the term within the summation by the current size-at-age distribution matrix,
  //      size_at_age->get_size_dist(i,requests->catch_at[label].plus_group,
  //                                     requests->catch_at[label].class_mins)
  // }
  //
  // Apply mortality:
  // For each row i of the partition {
  //  multiply row i by exp(-Mt_by_element[i])*(1-Ri).
  // }
  // Return 1 if the catch was successfully taken or 0 if the fishing_pressure limit was breached.
  DEBUG1("Basic_fisheries::apply");
  if (F_to_use != 0) fatal("F_to_use should not be supplied to Basic_fisheries::apply");
  VECTOR selected_biomass(0,n_fisheries_this_step-1), removals_selected_biomass(0,n_fisheries_this_step-1);
  selected_biomass.initialize();
  removals_selected_biomass.initialize();

  VECTOR U(0,n_fisheries_this_step-1);
  for (int f=0; f<n_fisheries_this_step; f++){
    if (catches_this_year){
      this_catch = (*catches_this_year)[names[f]];
    }
    else if (year < catches[f].indexmin() || year > catches[f].indexmax()){
      this_catch = 0;
    }
    else {
      this_catch = catches[f][year];
    }

    if (this_catch < 0){
      fatal("You have provided a negative catch for one or more fisheries.");
    }
    else if (this_catch==0){
      U[f] = 0;
    }
    else {
      for (int i=1; i<=s.n_rows; i++){
        if (rows[f][i]){
          if(selectivities[f]==retention_selectivities[f]) {
            selected_biomass[f] += s.partition[i] * elem_prod(mean_weight->get_row(s,i),
                                                              selectivities[f]->get_selectivity(year,step)[i],
                                                              exp_minus_half_Mt_by_element[i]);
          } else {
            removals_selected_biomass[f] += s.partition[i] * elem_prod(mean_weight->get_row(s,i),
                                                              selectivities[f]->get_selectivity(year,step)[i],
                                                              exp_minus_half_Mt_by_element[i]);
            selected_biomass[f] += s.partition[i] * elem_prod(mean_weight->get_row(s,i),
                                                              elem_prod(selectivities[f]->get_selectivity(year,step)[i],retention_selectivities[f]->get_selectivity(year,step)[i]),
                                                              exp_minus_half_Mt_by_element[i]);
          }
        }
      }
      if (selected_biomass[f]==0){
        //fatal("Selected biomass in fishery " + names[f] + " in year " + itos(year) + " is zero.");
    //richard test
        cerr<<("Selected biomass in fishery " + names[f] + " in year " + itos(year) + " is zero.");
    selected_biomass[f]=zerofun(selected_biomass[f],ZERO);
    } else {
        U[f] = this_catch / selected_biomass[f];
      }
    }

    // Projecting using future_Us. If future_Us is used then no catch can be provided
    // for the projection years. If future_Us is not supplied then it is set to -1 (with
    //  index -1 for this entry)
    if(this_catch==0 &&  year >= future_Us[f].indexmin() && year <= future_Us[f].indexmax() && future_Us[f].indexmax() != -1){
      U[f] = future_Us[f][year];
       for (int i=1; i<=s.n_rows; i++){ // we need to calculate this, it is used below - BB, Dec 04
        if (rows[f][i]){
          if(selectivities[f]==retention_selectivities[f]) {
            selected_biomass[f] += s.partition[i] * elem_prod(mean_weight->get_row(s,i),
                                                            selectivities[f]->get_selectivity(year,step)[i],
                                                            exp_minus_half_Mt_by_element[i]);
          } else {
            removals_selected_biomass[f] += s.partition[i] * elem_prod(mean_weight->get_row(s,i),
                                                            selectivities[f]->get_selectivity(year,step)[i],
                                                            exp_minus_half_Mt_by_element[i]);
            selected_biomass[f] += s.partition[i] * elem_prod(mean_weight->get_row(s,i),
                                                              elem_prod(selectivities[f]->get_selectivity(year,step)[i],retention_selectivities[f]->get_selectivity(year,step)[i]),
                                                              exp_minus_half_Mt_by_element[i]);
          }
        }
      }
    }
  }

  R.initialize();
  for (int f=0; f<n_fisheries_this_step; f++){
    for (int i=1; i<=s.n_rows; i++){
      if (rows[f][i]){
        R[i] += U[f] * selectivities[f]->get_selectivity(year,step)[i];
      }
    }
  }

  for (int f=0; f<n_fisheries_this_step; f++){
    Uobs_f = 0;
    for (int i=1; i<=s.n_rows; i++){
      if (rows[f][i]){
        Uobs_f = fmax(Uobs_f,max(R[i]));
      }
    }
    if (Uobs_f > U_max[f]){
      limit_exceeded = 1;
      if (results != 0) results->fishing_pressure_limit_exceeded = 1;
      U[f] *= U_max[f]/Uobs_f;
    }
    /*U[f] *= fmin(1,U_max[f]/Uobs_f); Causes NaNs in Betadiff. Why?? Above alternative works, anyway.*/
  }

  if (limit_exceeded){
    R.initialize();
    for (int f=0; f<n_fisheries_this_step; f++){
      for (int i=1; i<=s.n_rows; i++){
        if (rows[f][i]){
          R[i] += U[f] * selectivities[f]->get_selectivity(year,step)[i];
        }
      }
    }
  }

  if (requests != 0){
    // now record results
    for (int f=0; f<n_fisheries_this_step; f++){
      if (requests->fishing_pressure){
        Uobs_f = 0;
        for (int i=1; i<=s.n_rows; i++){
          if (rows[f][i]){
            Uobs_f = fmax(Uobs_f,max(R[i]));
          }
        }
        results->fishing_pressure[year][names[f]] = Uobs_f;
      }
      if (requests->actual_catches){
        results->actual_catches[year][names[f]] = U[f] * selected_biomass[f];
        if ((year < catches[f].indexmin() || year > catches[f].indexmax()) && catches_this_year==0){
          this_catch = 0;
        } else if (catches_this_year!=0){
          this_catch = (*catches_this_year)[names[f]];
        } else {
          this_catch = catches[f][year];
        }
        results->specified_catches[year][names[f]] = this_catch;
        if (requests->removals || requests->discards) {
          if(selectivities[f]==retention_selectivities[f]) {
            if (requests->removals) results->removals[year][names[f]] = results->specified_catches[year][names[f]];
            if (requests->discards) results->discards[year][names[f]] = 0.0;
          } else {
            if (requests->removals) results->removals[year][names[f]] = U[f] * removals_selected_biomass[f];
            if(requests->discards) results->discards[year][names[f]] = (U[f] * removals_selected_biomass[f]) - results->actual_catches[year][names[f]];
          }
        }
      }
      if (requests->actual_catches_by_stock){
        VECTOR selected_biomass_by_stock(1,s.n_stocks);
        selected_biomass_by_stock.initialize();
        int stock_char = s.character_numbers("stock");
        if (stock_char == -1){
          fatal("Please don't ask for actual catches by stock in a single-stock model");}
        for (int i=1; i<=s.n_rows; i++){
          if (rows[f][i]){
            int this_stock = s.character_value(i,stock_char);
            if(selectivities[f]==retention_selectivities[f]) {
              selected_biomass_by_stock[this_stock] += s.partition[i] * elem_prod(
                                                          mean_weight->get_row(s,i),
                                                          selectivities[f]->get_selectivity(year,step)[i],
                                                          exp_minus_half_Mt_by_element[i]);
            } else {
              selected_biomass_by_stock[this_stock] += s.partition[i] * elem_prod(
                                                          mean_weight->get_row(s,i),
                                                          elem_prod(selectivities[f]->get_selectivity(year,step)[i],retention_selectivities[f]->get_selectivity(year,step)[i]),
                                                          exp_minus_half_Mt_by_element[i]);
            }
          }
        }
        for (int i=1; i<=s.n_stocks; i++){
          std::string stock = s.stock_names[i];
          results->actual_catches_by_stock[year][names[f]][stock] = U[f] * selected_biomass_by_stock[i];
        }
        if (requests->removals || requests->discards){
          VECTOR selected_biomass_by_stock(1,s.n_stocks);
          selected_biomass_by_stock.initialize();
          int stock_char = s.character_numbers("stock");
          if (stock_char == -1){
            fatal("Please don't ask for discards/removals by stock in a single-stock model");}
          for (int i=1; i<=s.n_rows; i++){
            if (rows[f][i]){
              int this_stock = s.character_value(i,stock_char);
              selected_biomass_by_stock[this_stock] += s.partition[i] * elem_prod(
                                                          mean_weight->get_row(s,i),
                                                          selectivities[f]->get_selectivity(year,step)[i],
                                                          exp_minus_half_Mt_by_element[i]);
            }
          }
          for (int i=1; i<=s.n_stocks; i++){
            std::string stock = s.stock_names[i];
            if (requests->removals) results->removals_by_stock[year][names[f]][stock] = U[f] * selected_biomass_by_stock[i];
            if (requests->discards) results->discards_by_stock[year][names[f]][stock] = (U[f] * selected_biomass_by_stock[i]) - results->actual_catches_by_stock[year][names[f]][stock];
          }
        }
      }

      if (requests->actual_catches_by_area){
      VECTOR selected_biomass_by_area(1,s.n_areas);
        selected_biomass_by_area.initialize();
        int area_char = s.character_numbers("area");
        if (area_char == -1){
          fatal("Please don't ask for actual catches by area in a single-area model");}
        for (int i=1; i<=s.n_rows; i++){
          if (rows[f][i]){
            int this_area = s.character_value(i,area_char);
            if(selectivities[f]==retention_selectivities[f]) {
              selected_biomass_by_area[this_area] += s.partition[i] * elem_prod(
                                                          mean_weight->get_row(s,i),
                                                          selectivities[f]->get_selectivity(year,step)[i],
                                                          exp_minus_half_Mt_by_element[i]);
            } else {
              selected_biomass_by_area[this_area] += s.partition[i] * elem_prod(
                                                          mean_weight->get_row(s,i),
                                                          elem_prod(selectivities[f]->get_selectivity(year,step)[i],retention_selectivities[f]->get_selectivity(year,step)[i]),
                                                          exp_minus_half_Mt_by_element[i]);
            }
          }
    }
        for (int i=1; i<=s.n_areas; i++){
          std::string area = s.area_names[i];
          results->actual_catches_by_area[year][names[f]][area] = U[f] * selected_biomass_by_area[i];
        }
        if (requests->removals || requests->discards){
          VECTOR selected_biomass_by_area(1,s.n_areas);
          selected_biomass_by_area.initialize();
          int area_char = s.character_numbers("area");
          if (area_char == -1){
            fatal("Please don't ask for discards/removals by area in a single-area model");}
          for (int i=1; i<=s.n_rows; i++){
            if (rows[f][i]){
              int this_area = s.character_value(i,area_char);
              selected_biomass_by_area[this_area] += s.partition[i] * elem_prod(
                                                          mean_weight->get_row(s,i),
                                                          selectivities[f]->get_selectivity(year,step)[i],
                                                          exp_minus_half_Mt_by_element[i]);
            }
          }
          for (int i=1; i<=s.n_areas; i++){
            std::string area = s.area_names[i];
            if (requests->removals) results->removals_by_area[year][names[f]][area] = U[f] * selected_biomass_by_area[i];
            if (requests->discards) results->discards_by_area[year][names[f]][area] = (U[f] * selected_biomass_by_area[i]) - results->actual_catches_by_area[year][names[f]][area];
          }
        }
    }
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
// major edit of the following is required to account for discards
// Here we may be able to start to introduce the ability to record: catch_at, removals_at, and discards_at requests for later use in observations
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      for (int entry=0; entry<requests->catch_at.size(); entry++){
        std::string label = requests->catch_at_labels[entry];
        if (in(requests->catch_at[label].years,year) && in(requests->catch_at[label].fishery_names,names[f])){
          if (!(requests->catch_at[label].at_size && !s.size_based)){
            if (requests->catch_at[label].sexed){
              int sex_char = s.character_numbers("sex");
              MATRIX catch_at(1,2,s.col_min,s.col_max);
              catch_at.initialize();
              for (int i=1; i<=s.n_rows; i++){
                if (rows[f][i]){
                  if(selectivities[f]==retention_selectivities[f]) {
                    catch_at[s.character_value(i,sex_char)] += elem_prod(s.partition[i],
                                                          selectivities[f]->get_selectivity(year,step)[i],
                                                          exp_minus_half_Mt_by_element[i]);
                  } else {
                    catch_at[s.character_value(i,sex_char)] += elem_prod(s.partition[i],
                                                          elem_prod(selectivities[f]->get_selectivity(year,step)[i],retention_selectivities[f]->get_selectivity(year,step)[i]),
                                                          exp_minus_half_Mt_by_element[i]);
                  }
                }
              }
              catch_at *= U[f];
              // there could be multiple fisheries contributing to this catch-at, in which case
              // we may need to increment an existing entry rather than entering a new one
              if (in(results->catch_at[label],year)){
                results->catch_at[label][year] += catch_at;
              } else {
                results->catch_at[label].insert(make_pair(year,catch_at));
              }
            } else { // unsexed
              MATRIX catch_at(1,1,s.col_min,s.col_max);
              catch_at.initialize();
              for (int i=1; i<=s.n_rows; i++){
                if (rows[f][i]){
                  if(selectivities[f]==retention_selectivities[f]) {
                    catch_at[1] += elem_prod(selectivities[f]->get_selectivity(year,step)[i],
                                             s.partition[i],
                                             exp_minus_half_Mt_by_element[i]);
                  } else {
                    catch_at[1] += elem_prod(elem_prod(selectivities[f]->get_selectivity(year,step)[i],retention_selectivities[f]->get_selectivity(year,step)[i]),
                                             s.partition[i],
                                             exp_minus_half_Mt_by_element[i]);
                  }
                }
              }
              catch_at *= U[f];
              if (in(results->catch_at[label],year)){
                results->catch_at[label][year] += catch_at;
              } else {
                results->catch_at[label].insert(make_pair(year,catch_at));
              }
            }
          } else { // catch-at-size in an age-based model
            if (requests->catch_at[label].sexed){
              int sex_char = s.character_numbers("sex");
              MATRIX catch_at_size(1,2,1,requests->catch_at[label].class_mins.size()
                                   - (requests->catch_at[label].plus_group ? 0 : 1));
              catch_at_size.initialize();
              for (int i=1; i<=s.n_rows; i++){
                if (rows[f][i]){
                  if(selectivities[f]==retention_selectivities[f]) {
                    catch_at_size[s.character_value(i,sex_char)] +=
                                       size_at_age->get_size_dist(i, requests->catch_at[label].plus_group,requests->catch_at[label].class_mins)
                                       * elem_prod(selectivities[f]->get_selectivity(year,step)[i],
                                       s.partition[i],
                                       exp_minus_half_Mt_by_element[i]);
                  } else {
                    catch_at_size[s.character_value(i,sex_char)] +=
                                       size_at_age->get_size_dist(i, requests->catch_at[label].plus_group,requests->catch_at[label].class_mins)
                                       * elem_prod(elem_prod(selectivities[f]->get_selectivity(year,step)[i],retention_selectivities[f]->get_selectivity(year,step)[i]),
                                       s.partition[i],
                                       exp_minus_half_Mt_by_element[i]);
                  }
                }
              }
              catch_at_size *= U[f];
              if (in(results->catch_at[label],year)){
                results->catch_at[label][year] += catch_at_size;
              } else {
                results->catch_at[label].insert(make_pair(year,catch_at_size));
              }
            } else { // unsexed
              MATRIX catch_at_size(1,1,1,requests->catch_at[label].class_mins.size()
                                   - (requests->catch_at[label].plus_group ? 0 : 1));
              catch_at_size.initialize();
              for (int i=1; i<=s.n_rows; i++){
                if (rows[f][i]){
                  if(selectivities[f]==retention_selectivities[f]) {
                    catch_at_size[1] += size_at_age->get_size_dist(i, requests->catch_at[label].plus_group,requests->catch_at[label].class_mins)
                                        * elem_prod(selectivities[f]->get_selectivity(year,step)[i],
                                        s.partition[i],
                                        exp_minus_half_Mt_by_element[i]);
                  } else {
                    catch_at_size[1] += size_at_age->get_size_dist(i, requests->catch_at[label].plus_group,requests->catch_at[label].class_mins)
                                        * elem_prod(elem_prod(selectivities[f]->get_selectivity(year,step)[i],retention_selectivities[f]->get_selectivity(year,step)[i]),
                                        s.partition[i],
                                        exp_minus_half_Mt_by_element[i]);
                  }
                }
              }
              catch_at_size *= U[f];
              if (in(results->catch_at[label],year)){
                results->catch_at[label][year] += catch_at_size;
              } else {
                results->catch_at[label].insert(make_pair(year,catch_at_size));
              }
            }
          }
        }
      }
    }
  }
  // finally remove the mortality
  for (int i=1; i<=s.n_rows; i++){
    s.partition[i] *= elem_prod(exp_minus_Mt_by_element[i],ones-R[i]);
  }
  return limit_exceeded;
}



template<CDVM>
void Basic_fisheries<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Basic_fisheries::print");
  if (n_fisheries_this_step == 1){
    out << "  1 fishery (without Baranov)\n";
  } else {
    out << "  " + itos(n_fisheries_this_step) + " fisheries (without Baranov)\n";
  }
  for (int i=0; i<n_fisheries_this_step; i++){
    out << "\n  Fishery '" + names[i] + "'";
    if (s.n_areas > 1){
      int area_char = s.character_numbers("area");
    out << " in area ";
    for (int j=0; j<areas[names[i]].size();j++){
    std::string area_name = s.area_names[areas[names[i]][j]];
    out << " '" + area_name + "'";
    }
  }

    out << '\n';
    out << "  Catch : ";
    for (int j = catches[i].indexmin(); j<=catches[i].indexmax(); j++){
      out << setw(7);
      out << setprecision(3);
      out << catches[i][j] << ' ';
    }

    out << "\n  Year  : ";
    for (int j = catches[i].indexmin(); j<=catches[i].indexmax(); j++){
      out << setw(7);
      out << j << ' ';
    }
    out << '\n';

    if(future_Us[i].indexmax() != -1){
      out << "  Future_Us : ";
      for (int j = future_Us[i].indexmin(); j<=future_Us[i].indexmax(); j++){
        out << setw(7);
        out << setprecision(3);
        out << future_Us[i][j] << ' ';
      }
      out << "\n";
      out << "  future_years : ";
      for (int j = future_Us[i].indexmin(); j<=future_Us[i].indexmax(); j++){
        out << j << " ";
      }
      out << "\n";
    }

    out << "  Selectivity: " << selectivities[i]->label;
    if(retention_selectivities[i]->label != selectivities[i]->label) out << " (and with retention selectivity: " << retention_selectivities[i]->label << ")";
    out << '\n';
    out << "  Fishing pressure limit Umax = " << U_max[i] << '\n';
  }
  out << "\n  plus natural mortality: M*t = \n";
  s.print_matrix(out,Mt_by_element);
  out << '\n';
}

template<CDVM>
Basic_fisheries<DVM>::Basic_fisheries(Parameter_set<DVM>& p, Basic_state<DVM>& s, int _step,
                                      Mean_weight<DVM>* _mean_weight,
                                      Size_at_age<DVM>* _size_at_age,
                                      const dvector& M_props, const dvector& fishery_times,
                    const dvector& fishery_areas,
                                      const std::vector<std::string>& fishery_names,
                                      std::map<std::string, Selectivity<DVM>*>& all_selectivities)
  : Mt_by_element(1,s.n_rows,s.col_min,s.col_max)
  , exp_minus_Mt_by_element(1,s.n_rows,s.col_min,s.col_max)
  , exp_minus_half_Mt_by_element(1,s.n_rows,s.col_min,s.col_max)
  , R(1,s.n_rows,s.col_min,s.col_max)
  , ones(s.col_min,s.col_max){
  // Construct the mortality process for 'step' from p. There may be several fisheries
  // in this step.
  DEBUG1("Basic_fisheries::Basic_fisheries");
  step = _step;
  // extract the M's from the parameter set
  get_Mt_by_element(Mt_by_element,p,s,step,M_props,_size_at_age);
  for (int i=Mt_by_element.rowmin(); i<=Mt_by_element.rowmax(); i++){
    exp_minus_Mt_by_element[i] = exp(-Mt_by_element[i]);
    exp_minus_half_Mt_by_element[i] = exp(-0.5*Mt_by_element[i]);
  }
  int count = -1;
  std::string command;
  dvector* years;
  dvector* future_years;
  int area_char = s.character_numbers("area");
  dvector all_rows(1,s.n_rows);
  all_rows = 1;
  dvector some_rows(1,s.n_rows);

  for (int i=1; i<=fishery_times.size(); i++){
    if (fishery_times[i]==step){
      // we have found a fishery which is in this time step: get its details
      count++;
      names.push_back(fishery_names[i]);
      command = "fishery[" + fishery_names[i] + "].";
      if(p.present(command + "Fs") || p.present(command + "future_Fs") || p.present(command+"future_constant_Fs")){
        fatal("Only supply \"Fs\" or \"future_Fs\" or \"future_constant_Fs\" for the fishery " + fishery_names[i] +
        " if you are using the Baranov catch equation.");
      } else {
        int subcommand_counter=0;
        if(p.present(command+"future_Us")) subcommand_counter++;
        if(p.present(command+"future_catches")) subcommand_counter++;
        if(p.present(command+"future_constant_Us")) subcommand_counter++;
        if(p.present(command+"future_constant_catches")) subcommand_counter++;
        if(subcommand_counter>1) fatal("You should supply only one of the subcommands \"future_Us\", \"future_catches\", \"future_constant_Us\""
                                       ", or \"future_constant_catches\" for the fishery " + fishery_names[i] + ".");
      }
      if ( p.present(command + "future_years") && !( p.present(command + "future_catches") || p.present(command + "future_Us") ) ){
        fatal("For the fishery " + fishery_names[i] + ", if you supply \"future_years\", you also need to supply either \"future_catches\" or \"future_Us\".");
      }

      if (p.present(command + "future_catches")){
        catches.push_back(p.get_constant_vector(command + "catches") & p.get_constant_vector(command + "future_catches"));
        years = new dvector(p.get_constant_vector(command+"years") & p.get_constant_vector(command+"future_years"));
      } else if(p.present(command + "future_constant_catches")) {
        int number_future_years=p.get_int("final")-p.get_int("current");
        if(number_future_years>0) {
          dvector fyears(1,number_future_years);
          dvector fcatches(1,number_future_years);
          for(int k=1; k<=number_future_years; k++) {
            fyears[k]=p.get_int("current")+k;
            fcatches[k]=p.get_constant(command + "future_constant_catches");
          }
          catches.push_back(p.get_constant_vector(command + "catches") & fcatches);
          years = new dvector(p.get_constant_vector(command+"years") & fyears);
        } else {
          catches.push_back(p.get_constant_vector(command + "catches"));
          years = new dvector(p.get_constant_vector(command+"years"));
        }
      } else {
        catches.push_back(p.get_constant_vector(command + "catches"));
        years = new dvector(p.get_constant_vector(command+"years"));
      }
      if (min(catches[catches.size()-1])<0){
        fatal("You have provided a negative catch for " + fishery_names[i]);}
      for (int k=2; k<=years->indexmax(); k++){
        if ((*years)[k] != ((*years)[k-1]+1)){
          fatal(command + "years should be consecutive integers (check also .future_years: the two should be consecutive when combined)");
        }
      }
      catches[count].shift((int)((*years)[1]));
      if (catches[count].size() != years->size()){
        fatal("For fishery " + fishery_names[i] + ", the number of catches supplied ( " + itos(catches[count].size()) + " ) is not the same as the number of years ( " + itos(years->size()) + " ).");
      }
      delete years;

      if (p.present(command + "future_Us") || p.present(command + "future_constant_Us")){
        if (p.present(command + "future_Us")) {
          future_Us.push_back(p.get_constant_vector(command + "future_Us"));
          future_years = new dvector(p.get_constant_vector(command+"future_years"));
        } else {
          if(p.get_constant(command + "future_constant_Us")<0 || p.get_constant(command + "future_constant_Us")>1)
            fatal("The value of \"future_constant_Us\" in the fishery " + fishery_names[i] + " should be in the range 0 to 1.");
          int number_future_years=p.get_int("final")-p.get_int("current");
          dvector fyears(1,number_future_years);
          dvector fcatches(1,number_future_years);
          for(int k=1; k<=number_future_years; k++) {
            fyears[k]=p.get_int("current")+k;
            fcatches[k]=p.get_constant(command + "future_constant_Us");
          }
          future_Us.push_back(fcatches);
          future_years = new dvector(fyears);
        }
        if (min(future_Us[future_Us.size()-1]) < 0 || max(future_Us[future_Us.size()-1]) > 1 ){
          fatal("future_Us values in the fishery " + fishery_names[i] + " should be in the range 0 to 1.");
        }
        for (int k=1; k<=future_years->indexmax(); k++){
            if ( (*future_years)[k] <= p.get_int("current") || (*future_years)[k] > p.get_int("final") ){
              fatal(command + "future_years should be in the range \"current\" + 1 to \"final\" ");
            }
        }
        for (int k=2; k<=future_years->indexmax(); k++){
          if ((*future_years)[k] != ((*future_years)[k-1]+1)){
            fatal(command + "future_years should be consecutive integers");
          }
        }
        if (future_Us[count].size() != future_years->size()){
          fatal("For fishery " + fishery_names[i] + ", the number of future_Us supplied ( " + itos(future_Us[count].size()) +
          " ) is not the same as the number of future_years ( " + itos(future_years->size()) + " ).");
        }
        future_Us[count].shift((int)((*future_years)[1]));
        delete future_years;
      }
      else{
        future_Us.push_back("{-1}");
        future_Us[count].shift(-1);
      }

    if (s.n_areas > 1){
    std::vector<int> these_fishery_areas;
    some_rows.initialize();
    if((&fishery_areas) == 0){
      std::vector<std::string>  fishery_area_names = p.get_vector_of_strings("fishing_grounds["+fishery_names[i]+"].areas");
      for (int j=0; j<fishery_area_names.size(); j++){
        if (!s.valid_area(fishery_area_names[j])){
          fatal("Unknown fishery area " + fishery_area_names[j]+"for the fishery "+fishery_names[i]+".");
        }
        these_fishery_areas.push_back(s.area_numbers[fishery_area_names[j]]);
        for (int k=1; k<=s.n_rows; k++){
          if (s.character_value(k,area_char)==these_fishery_areas[j]){
            some_rows[k]=1;
          }
        }
      }
      rows.push_back(some_rows);
      areas.insert(make_pair(fishery_names[i], these_fishery_areas));
    } else {
      these_fishery_areas.push_back((int)(fishery_areas[i]));
      some_rows.initialize();
      for (int k=1; k<=s.n_rows; k++){
        if (s.character_value(k,area_char)==fishery_areas[i]){
          some_rows[k]=1;
        }
      }
      rows.push_back(some_rows);
      areas.insert(make_pair(fishery_names[i], these_fishery_areas));
    }
    } else {
        rows.push_back(all_rows);
      }
      std::string sel_name = p.get_string(command+"selectivity");
      if (!in(all_selectivities,sel_name)){
        fatal("Unrecognised selectivity " + sel_name + " in the fishery with label " + fishery_names[i]);}
      selectivities.push_back(all_selectivities[sel_name]);
      if(p.present(command+"retention_selectivity")) {
        if(p.get_string(command+"retention_selectivity")==p.get_string(command+"selectivity")) {
          fatal("The retention selectivity cannot be the same as the fishing selectivity (" + sel_name + ") in the fishery with label " + fishery_names[i]);}
        std::string retention_sel_name = p.get_string(command+"retention_selectivity");
        if (!in(all_selectivities,retention_sel_name)){
          fatal("Unrecognised retention selectivity " + retention_sel_name + " in the fishery with label " + fishery_names[i]);}
        retention_selectivities.push_back(all_selectivities[retention_sel_name]);
      } else {
        retention_selectivities.push_back(all_selectivities[sel_name]); // just use the fishing selctivity as a filler
      }
      U_max.push_back(p.get_constant(command + "U_max"));
      // check the exploitation rate limits for validity in range
      if (U_max[count] < 0 || U_max[count] >= 1){
        fatal("The subcommand " + command + "U_max must be between 0 and 1 (i.e., 0 <= U_max < 1)");
      }
      // check the exploitation rate limits for validity across areas
      for (int k=0; k<count; k++){
        if (U_max[k]!=U_max[count] && intersection(areas[names[k]],areas[names[count]]).size()>0){
          fatal("Fisheries in the same area must have the same Umax");
        }
      }
  }
  }
  n_fisheries_this_step = names.size();
  mean_weight = _mean_weight;
  size_at_age = _size_at_age;
  for (int j=s.col_min; j<=s.col_max; j++){
    ones[j] = 1;}
}

template<CDVM>
int Baranov_fisheries<DVM>::apply(Basic_state<DVM>& s, int year,
                                  Basic_requests<DVM>* requests, Basic_results<DVM>* results,
                                  double F_to_use, std::map<std::string,double> *catches_this_year){
  // Apply a time step's natural and fishing mortality to the partition of s in year.
  // If 'catches_this_year' is supplied, then use it in place of the catches stored
  //  in the mortality object (this happens in simulation).
  // If 'F_to_use' is supplied, use fmin(F_to_use,F_max) in place of the calculated F value.
  //  In this case there must be only one fishery.
  // If Fs were provided in the datafile, for years in which no catch was available,
  //  use them instead of the F's calculated from catches below.
  // For each fishery f {
  //  solve the Baranov equation iteratively for F, using
  //  Ff = catches[f][year]/(sum over i in rows[f] and j in columns of the partition of
  //   (selectivity(f,i,year)[j] / (Mt_by_element[i][j]+Ff*selectivity(f,i,year)[j])
  //    * mean_weight->get_row(s,i)[j] * partition[i][j]
  //    * (1-exp(-Mt_by_element[i][j])*exp(-Ff*selectivity(f,i,year)[j]))))
  //  If Ff*max(selectivity) > F_max, set results->fishing_pressure_limit_exceeded=1.
  //  Set Ff = fmin(Ff, F_max/max(selectivity))
  //  Requests for results (1):
  //  If (requests->fishing_pressure), fill in fishing_pressures:
  //    results->fishing_pressure[year][fishery_names[f]] = Ff*max(selectivity).
  //  (If the fishing_pressure_without_S flag is set, don't use the max(selectivity) term on the
  //   lines above.)
  // }
  //
  // For each row i of the partition {
  //  get the removals by multiplying the row by
  //   (1-exp(-(Mt_by_element[i][j]+Ff*selectivity(f,i,year)[j]))),
  //  where f is the fishery affecting that row,
  //  or by (1-exp(-(Mt_by_element[i][j]))) if there is none.
  //  Subtract the removals from the row.
  //
  //  Requests for results (2):
  //  Calculate fishing_removals = removals * (Ff * selectivity(f,i,year)[j]) /
  //                                          (Mt_by_element[i][j]+Ff*selectivity(f,i,year)[j]).
  //
  //  If (requests->actual_catches), add fishing_removals * mean_weight->get_row(s,i)
  //  to results->actual_catches[year][fishery_names[f]].
  //  Fill in catch-at if requested:
  //   if unsexed, increment it by fishing_removals,
  //   or if sexed, increment the row for the appropriate sex,
  //   and if catch-at-size in an age-based model,
  //   multiply the term within the summation by the current size-at-age distribution matrix,
  //      size_at_age->get_size_dist(i,requests->catch_plus_groups[fishery_names[f]],
  //                                 requests->catch_class_mins[fishery_names[f]]).
  // }
  // If (requests->actual_catches), fill in the specified catches in results->
  // Return 1 if the catch is successfully taken or 0 if the fishing_pressure limit was breached.
  DEBUG1("Baranov_fisheries::apply");
  if (n_fisheries_this_step > 1 && F_to_use != 0){
    fatal("F_to_use should not be supplied to Baranov_fisheries::apply when there is more than one fishery");}
  VECTOR F(0,n_fisheries_this_step-1);
  F.initialize();
  dvector ones(s.col_min,s.col_max);
  for (int j=s.col_min; j<=s.col_max; j++){
    ones[j]=1;}
  VECTOR these_catches(0,n_fisheries_this_step-1);
  DOUBLE temp, old_F;
  for (int f=0; f<n_fisheries_this_step; f++){
    // N.B. If values are not supplied then Fs and future_Fs are set to -1, as is the index of the
    // entry which contains -1.
    if (year >= Fs[f].indexmin() && year <= Fs[f].indexmax() && Fs[f].indexmax() > 0){
      F_to_use = Fs[f][year];
    }
    else if (year >= future_Fs[f].indexmin() && year <= future_Fs[f].indexmax() && future_Fs[f].indexmax() > 0){
      F_to_use = future_Fs[f][year];
    }
    if (F_to_use == 0){
      old_F = -1;
      if (catches_this_year){
        these_catches[f] = (*catches_this_year)[names[f]];
      } else if (year < catches[f].indexmin() || year > catches[f].indexmax()){
        these_catches[f] = 0;
      } else {
        these_catches[f] = catches[f][year];
      }
      if (these_catches[f] < 0){
        fatal("Negative catch in Baranov_fisheries::apply");
      } else if (these_catches[f]==0){
        F[f] = 0;
      } else {
        while (fabs(F[f]-old_F)>0.001){
          temp = 0;
          for (int i=1; i<=s.n_rows; i++){
            if (rows[f][i]){
              temp += elem_prod(elem_div(selectivities[f]->get_selectivity(year,step)[i],
                                   Mt_by_element[i]+F[f]*selectivities[f]->get_selectivity(year,step)[i]),
                                mean_weight->get_row(s,i),
                                s.partition[i]) *
                (ones-elem_prod(exp_minus_Mt_by_element[i],
                                exp(-F[f]*selectivities[f]->get_selectivity(year,step)[i])));
            }
          }
          old_F = F[f];
          if (temp==0){
            //fatal("Selected biomass in fishery " + names[f] + " in year " + itos(year) + " is zero.");
      //richard test
      cerr<<("Selected biomass in fishery " + names[f] + " in year " + itos(year) + " is zero.");
      temp=zerofun(temp,ZERO);
          }
          F[f] = these_catches[f] / temp;
          if (F[f]>10) break;
        }
      }
    } else if (F_to_use != 0){
      F[f] = F_to_use;
    }
    DOUBLE max_selectivity;
    if (fishing_pressure_without_S){
      max_selectivity = 1;
    } else {
      max_selectivity = 0;
      for (int i=1; i<=s.n_rows; i++){
        if (rows[f][i]){
          max_selectivity = fmax(max_selectivity,max(selectivities[f]->get_selectivity(year,step)[i]));
        }
      }
    }
    if (F[f]*max_selectivity > F_max[f]){
      limit_exceeded = 0;
      if (results != 0) results->fishing_pressure_limit_exceeded = 1;
    }
    F[f] = fmin(F[f], F_max[f]/max_selectivity);
    if (results != 0){
      if (requests->fishing_pressure){
        results->fishing_pressure[year][names[f]] = F[f]*max_selectivity;
      }
    }
  }
  VECTOR actual_catches(0,n_fisheries_this_step-1);
  actual_catches.initialize();
  MATRIX actual_catches_by_stock(0,n_fisheries_this_step-1,1,s.n_stocks);
  actual_catches_by_stock.initialize();
  VECTOR removals(s.col_min,s.col_max);
  VECTOR fishing_removals(s.col_min,s.col_max);
  int sex_char = s.character_numbers("sex");
  int this_fishery;
  std::string fishery_name;
  if (requests != 0){
    for (int f=0; f<n_fisheries_this_step; f++){
      // set up the catch-at results objects if necessary
      // if a single catch-at spans multiple fisheries, we only need to set it up once
      for (int entry=0; entry<requests->catch_at.size(); entry++){
        std::string label = requests->catch_at_labels[entry];
        if (in(requests->catch_at[label].years,year) &&
            in(requests->catch_at[label].fishery_names,names[f])){
          if (in(results->catch_at[label],year)) continue;
          if (requests->catch_at[label].at_size && !s.size_based){
            results->catch_at[label].insert(make_pair(year,
                                                   MATRIX(1,(requests->catch_at[label].sexed ? 2:1),
                                                   1,requests->catch_at[label].class_mins.size()
                                                     - (requests->catch_at[label].plus_group ? 0 : 1))));
          } else {
            results->catch_at[label].insert(make_pair(year,
                                                      MATRIX(1,(requests->catch_at[label].sexed ? 2:1),
                                                             s.col_min,s.col_max)));
          }
          results->catch_at[label][year].initialize();
        }
      }
    }
  }
  // now loop through rows, record catch-at and remove mortality
  for (int i=1; i<=s.n_rows; i++){
    // what fishery operates on this row?
    this_fishery = -1;
    for (int f=0; f<n_fisheries_this_step; f++){
      if (rows[f][i]){
        this_fishery = f;
        fishery_name = names[this_fishery];
        break;
      }
    }
    if (this_fishery > -1){
      removals = elem_prod(s.partition[i],
                     ones - elem_prod(exp_minus_Mt_by_element[i],
                     exp(-F[this_fishery] * selectivities[this_fishery]->get_selectivity(year,step)[i])));
      fishing_removals = elem_prod(removals,
                    elem_div(F[this_fishery]*selectivities[this_fishery]->get_selectivity(year,step)[i],
                             F[this_fishery]*selectivities[this_fishery]->get_selectivity(year,step)[i]
                               + Mt_by_element[i]));
      if (requests != 0){
        if (requests->actual_catches){
          actual_catches[this_fishery] += fishing_removals * mean_weight->get_row(s,i);
        }
        if (requests->actual_catches_by_stock){
          int stock_char = s.character_numbers("stock");
          int this_stock = s.character_value(i,stock_char);
          actual_catches_by_stock[this_fishery][this_stock] += fishing_removals *
                                                               mean_weight->get_row(s,i);
        }
        for (int entry=0; entry<requests->catch_at.size(); entry++){
          std::string label = requests->catch_at_labels[entry];
          if (in(requests->catch_at[label].years,year) &&
              in(requests->catch_at[label].fishery_names,fishery_name)){
            if (!(requests->catch_at[label].at_size && !s.size_based)){
              if (requests->catch_at[label].sexed){
                int sex_char = s.character_numbers("sex");
                results->catch_at[label][year][s.character_value(i,sex_char)] += fishing_removals;
              } else {
                results->catch_at[label][year][1] += fishing_removals;
              }
            } else { // catch-at-size in an age-based model
              if (requests->catch_at[label].sexed){
                int sex_char = s.character_numbers("sex");
                results->catch_at[label][year][s.character_value(i,sex_char)] +=
                                                    size_at_age->get_size_dist(i,
                                                 requests->catch_at[label].plus_group,
                                                 requests->catch_at[label].class_mins)
                                                    * fishing_removals;
              } else {
                results->catch_at[label][year][1] +=
                                                    size_at_age->get_size_dist(i,
                                                 requests->catch_at[label].plus_group,
                                                 requests->catch_at[label].class_mins)
                                                    * fishing_removals;
              }
            }
          }
        }
      }
      s.partition[i] -= removals;
    } else {
      s.partition[i] *= exp_minus_Mt_by_element[i];
    }
  }
  if (requests != 0){
    if (requests->actual_catches){
      for (int f=0; f<n_fisheries_this_step; f++){
        results->actual_catches[year][names[f]] = actual_catches[f];
        if (F_to_use != 0){
          // a catch was not specified - put down the specified catch equal to the actual catch
          results->specified_catches[year][names[f]] = actual_catches[f];
        } else {
          results->specified_catches[year][names[f]] = these_catches[f];
        }
      }
    }
    if (requests->actual_catches_by_stock){
      for (int i=1; i<=s.n_stocks; i++){
        std::string stock = s.stock_names[i];
        for (int f=0; f<n_fisheries_this_step; f++){
          results->actual_catches_by_stock[year][names[f]][stock] = actual_catches_by_stock[f][i];
        }
      }
    }
  }
  return limit_exceeded;
}

template<CDVM>
void Baranov_fisheries<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Baranov_fisheries::print");
  if (n_fisheries_this_step == 1){
    out << "  1 fishery (with Baranov)\n";
  } else {
    out << "  " + itos(n_fisheries_this_step) + " fisheries (with Baranov)\n";
  }
  for (int i=0; i<n_fisheries_this_step; i++){
    out << "\n  Fishery '" + names[i] + "'";
    if (s.n_areas > 1){
      int area_char = s.character_numbers("area");
    out << " in area ";
    for (int j=0; j<areas[names[i]].size();j++){
    std::string area_name = s.area_names[areas[names[i]][j]];
    out << " '" + area_name + "'";
    }
  }
    out << '\n';
    out << "  Catch : ";
    for (int j = catches[i].indexmin(); j<=catches[i].indexmax(); j++){
      out << setw(7);
      out << setprecision(3);
      out << catches[i][j] << ' ';
    }
    out << "\n  Year  : ";
    for (int j = catches[i].indexmin(); j<=catches[i].indexmax(); j++){
      out << setw(7);
      out << j << ' ';
    }
    out << '\n';


    if (Fs[i][Fs[i].indexmin()] >= 0){
      // some instantaneous F values have been provided
      out << "  F : ";
      for (int j = Fs[i].indexmin(); j<=Fs[i].indexmax(); j++){
        out << setw(7);
        out << setprecision(3);
        out << Fs[i][j] << ' ';
      }
      out << "\n  Year  : ";
      for (int j = Fs[i].indexmin(); j<=Fs[i].indexmax(); j++){
        out << setw(7);
        out << j << ' ';
      }
      out << '\n';
    }

    if (future_Fs[i][future_Fs[i].indexmin()] >= 0){
      // some instantaneous future F values have been provided
      out << "  future F : ";
      for (int j = future_Fs[i].indexmin(); j<=future_Fs[i].indexmax(); j++){
        out << setw(7);
        out << setprecision(3);
        out << future_Fs[i][j] << ' ';
      }
      out << "\n  Year  : ";
      for (int j = future_Fs[i].indexmin(); j<=future_Fs[i].indexmax(); j++){
        out << setw(7);
        out << j << ' ';
      }
      out << '\n';
    }

    out << "  Selectivity: " << selectivities[i]->label << '\n';
    if (fishing_pressure_without_S){
      out << " , and fishing pressures are calculated as the Baranov F, not F * max(selectivity).";
    }
    out << '\n';
  }
  out << "\n  plus natural mortality: M*t = \n";
  s.print_matrix(out,Mt_by_element);
  out << '\n';
};

template<CDVM>
Baranov_fisheries<DVM>::Baranov_fisheries(Parameter_set<DVM>& p, Basic_state<DVM>& s, int _step,
                                          Mean_weight<DVM>* _mean_weight,
                                          Size_at_age<DVM>* _size_at_age,
                                          const dvector& M_props, const dvector& fishery_times,
                                          const dvector& fishery_areas,
                                          const std::vector<std::string>& fishery_names,
                                          std::map<std::string,Selectivity<DVM>*>& all_selectivities)
  : Mt_by_element(1,s.n_rows,s.col_min,s.col_max)
  , exp_minus_Mt_by_element(1,s.n_rows,s.col_min,s.col_max){
  // Construct the mortality process for 'step' from p, s, and the address of the
  //  Basic_annual_cycle.mean_weight. There may be more than one fishery in this step (but
  //  they have to be in different areas).
  DEBUG1("Baranov_fisheries::Baranov_fisheries");
  step = _step;
  // extract the M's from the parameter set
  get_Mt_by_element(Mt_by_element,p,s,step,M_props,_size_at_age);
  for (int i=Mt_by_element.rowmin(); i<=Mt_by_element.rowmax(); i++){
    // zero values can cause divide by zero errors: we replace them by a small number here.
    for (int j=Mt_by_element.colmin(); j<=Mt_by_element.colmax(); j++){
      Mt_by_element[i][j] = fmax(Mt_by_element[i][j],1e-8);}
    exp_minus_Mt_by_element[i] = exp(-Mt_by_element[i]);
  }
  int count = -1;
  std::string command;
  dvector* years;
  dvector* future_years;
  int area_char = s.character_numbers("area");
  dvector all_rows(1,s.n_rows);
  for (int j=1; j<=s.n_rows; j++){
    all_rows[j] = 1;
  }
  dvector some_rows(1,s.n_rows);
  for (int i=1; i<=fishery_times.size(); i++){
    if (fishery_times[i]==step){
      // we have found a fishery which is in this time step: get its details
      count++;
      names.push_back(fishery_names[i]);
      command = "fishery[" + fishery_names[i] + "].";
      if(p.present(command + "future_Us") || p.present(command + "future_constant_Us" )){
        fatal("You cannot use \"future_Us\" or \"future_constant_Us\" for the fishery " + fishery_names[i] + " if you are using the Baranov equation.");
      } else {
        int subcommand_counter=0;
        if(p.present(command+"future_Fs")) subcommand_counter++;
        if(p.present(command+"future_catches")) subcommand_counter++;
        if(p.present(command+"future_constant_Fs")) subcommand_counter++;
        if(p.present(command+"future_constant_catches")) subcommand_counter++;
        if(subcommand_counter>1) fatal("You should supply only one of the subcommands \"future_Fs\", \"future_catches\", \"future_constant_Fs\", or \"future_constant_catches\" for the fishery " + fishery_names[i] + ".");
      }
      if(p.present(command + "future_years") && !( p.present(command + "future_catches") || p.present(command + "future_Fs"))){
        fatal("For the fishery " + fishery_names[i] + ", if you supply \"future_years\", you also need to supply either \"future_catches\" or \"future_Fs\".");
      }
      if(p.present(command + "future_catches")){
        catches.push_back(p.get_constant_vector(command + "catches") & p.get_constant_vector(command + "future_catches"));
        years = new dvector(p.get_constant_vector(command+"years") & p.get_constant_vector(command+"future_years"));
      } else if(p.present(command + "future_constant_catches")) {
        int number_future_years=p.get_int("final")-p.get_int("current");
        if(number_future_years>0) {
          dvector fyears(1,number_future_years);
          dvector fcatches(1,number_future_years);
          for(int k=1; k<=number_future_years; k++) {
            fyears[k]=p.get_int("current")+k;
            fcatches[k]=p.get_constant(command + "future_constant_catches");
          }
          catches.push_back(p.get_constant_vector(command + "catches") & fcatches);
          years = new dvector(p.get_constant_vector(command+"years") & fyears);
        } else {
        catches.push_back(p.get_constant_vector(command + "catches"));
        years = new dvector(p.get_constant_vector(command+"years"));
        }
      } else {
        catches.push_back(p.get_constant_vector(command + "catches"));
        years = new dvector(p.get_constant_vector(command+"years"));
      }
      if (min(catches[catches.size()-1])<0){
         fatal("You have provided a negative catch for " + fishery_names[i]);}
      for (int k=2; k<=years->indexmax(); k++){
        if ((*years)[k] != ((*years)[k-1]+1)){
          fatal(command + "years should be consecutive integers (check also .future_years: the two should be consecutive when combined)");
        }
      }
      if (catches[count].size() != years->size()){
        fatal("For fishery " + fishery_names[i] + ", the number of catches supplied ( " + itos(catches[count].size()) + " ) is not the same as the number of years ( " + itos(years->size()) + " ).");
      }
      catches[count].shift((int)((*years)[1]));
      delete years;

      // may need to input instantaneous F's as well
      dvector no_Fs("{-1}");
      no_Fs.shift(-1);
      if (p.present(command + "Fs")){
        Fs.push_back(p.get_constant_vector(command + "Fs"));
        years = new dvector(p.get_constant_vector(command+"Fs_years"));
        for (int k=2; k<=years->indexmax(); k++){
          if ((*years)[k] != ((*years)[k-1]+1)){
            fatal(command + "years should be consecutive integers");
          }
        }
        if (Fs[count].size() != years->size()){
          fatal("For fishery " + fishery_names[i] + ", the number of Fs supplied ( " + itos(Fs[count].size()) + " ) is not the same as the number of years ( " + itos(years->size()) + " ).");}
        Fs[count].shift((int)((*years)[1]));
        delete years;
        if ((Fs[count].indexmax() >= catches[count].indexmin() && Fs[count].indexmax() <= catches[count].indexmax()) ||
            (Fs[count].indexmin() >= catches[count].indexmin() && Fs[count].indexmin() <= catches[count].indexmax())){
          fatal("For a Baranov fishery, you have supplied both F and catch for at least one year. Avoid doing this.");}
      } else {
        Fs.push_back(no_Fs);
      }

      // And instantaneous F's for projections
      dvector no_future_Fs("{-1}");
      no_future_Fs.shift(-1);
      if (p.present(command + "future_Fs") || p.present(command + "future_constant_Fs")){
        if (p.present(command + "future_catches")){
          fatal("For fishery " + fishery_names[i] + " you should supply only one of \"future_catches\", \"future_Fs\" or \"future_constant_Fs\".");
        }
        if(p.present(command+"future_Fs")) {
          future_Fs.push_back(p.get_constant_vector(command + "future_Fs"));
          future_years = new dvector(p.get_constant_vector(command+"future_years"));
        } else {
          int number_future_years=p.get_int("final")-p.get_int("current");
          dvector fyears(1,number_future_years);
          dvector fcatches(1,number_future_years);
          for(int k=1; k<=number_future_years; k++) {
            fyears[k]=p.get_int("current")+k;
            fcatches[k]=p.get_constant(command + "future_constant_Fs");
          }
          future_Fs.push_back(fcatches);
          future_years = new dvector(fyears);
        }
        for (int k=1; k<=future_years->indexmax(); k++){
          if ( (*future_years)[k] <= p.get_int("current") || (*future_years)[k] > p.get_int("final") ){
            fatal(command + "future_years should be in the range \"current\" + 1 to \"final\" ");
          }
        }
        for (int k=2; k<=future_years->indexmax(); k++){
          if ((*future_years)[k] != ((*future_years)[k-1]+1)){
            fatal(command + "future_years should be consecutive integers");
          }
        }
        if (future_Fs[count].size() != future_years->size()){
          fatal("For fishery " + fishery_names[i] + ", the number of future_Fs supplied ( " + itos(future_Fs[count].size()) + " ) is not the same as the number of future_years ( " + itos(future_years->size()) + " ).");
        }
        future_Fs[count].shift((int)((*future_years)[1]));
        delete future_years;
      } else {
        future_Fs.push_back(no_future_Fs);
      }
      if (s.n_areas > 1){
        std::vector<int> these_fishery_areas;
        some_rows.initialize();
        if((&fishery_areas) == 0){
          std::vector<std::string>  fishery_area_names = p.get_vector_of_strings("fishing_grounds["+fishery_names[i]+"].areas");
          for (int j=0; j<fishery_area_names.size(); j++){
            if (!s.valid_area(fishery_area_names[j])){
              fatal("Unknown fishery area " + fishery_area_names[j]+"for the fishery "+fishery_names[i]+".");
            }
            these_fishery_areas.push_back(s.area_numbers[fishery_area_names[j]]);
            for (int k=1; k<=s.n_rows; k++){
              if (s.character_value(k,area_char)==these_fishery_areas[j]){
                some_rows[k]=1;
              }
            }
          }
          rows.push_back(some_rows);
          areas.insert(make_pair(fishery_names[i], these_fishery_areas));
        } else {
          these_fishery_areas.push_back((int)(fishery_areas[i]));
          some_rows.initialize();
          for (int k=1; k<=s.n_rows; k++){
            if (s.character_value(k,area_char)==fishery_areas[i]){
              some_rows[k]=1;
            }
          }
          rows.push_back(some_rows);
          areas.insert(make_pair(fishery_names[i], these_fishery_areas));
        }
      } else {
        rows.push_back(all_rows);
      }
      if(s.n_areas == 1) {
        if(count > 0) {
          fatal("You cannot have more than one fishery in the same area and time step when using Baranov fisheries");
        }
      } else {
        for (int k=0; k<count; k++){
          for(int j=0;j<areas[names[k]].size();j++){
            if (in(areas[names[count]],areas[names[k]][j])){
              fatal("You cannot have more than one fishery in the same area and time step when using Baranov fisheries");
            }
          }
        }
      }
      F_max.push_back(p.get_constant(command + "F_max"));
      std::string sel_name = p.get_string(command+"selectivity");
      if (!in(all_selectivities,sel_name)){
        fatal("Unrecognised selectivity " + sel_name + " in fishery block");}
      selectivities.push_back(all_selectivities[sel_name]);
      if(p.present(command+"retention_selectivity")) {
        fatal("Retention selectivities have not yet been implemented for Baranov fisheries");
      }
    }
  }
  fishing_pressure_without_S = p.get_int("fishing_pressure_without_S",0);
  n_fisheries_this_step = names.size();
  mean_weight = _mean_weight;
  size_at_age = _size_at_age;
}

//################################ DISEASE MORTALITY #################################
template<CDVM>
void DiseaseMortality<DVM>::apply(Basic_state<DVM>& s, int year,
    Mean_weight<DVM>* mean_weight, Basic_requests<DVM>* requests, Basic_results<DVM>* results){
  // Applies the disease mortalty (a scaler) modified by the disease mortality selectivity
  // and proportional to the scaler in @disease_mortality.index
  // Now also can supply results to the disease_biomass_loss request
  DEBUG1("DiseaseMortality::apply");
  // test if year is in some valid range.
  DOUBLE year_effect = 0;
  if (year >= index->indexmin() && year <= index->indexmax()){
    year_effect = (*index)[year];}
  else if (year >= future_index->indexmin() && year <=future_index->indexmax()){
    year_effect = (*future_index)[year];
  } else {
   // this is a simulation year - no disease
   return;
 }
  MATRIX Sel(selectivity->get_selectivity(year,step));
  for (int i=Sel.rowmin(); i<=Sel.rowmax(); i++){
        if (max(-(year_effect * DM * Sel[i])) > 10){
            fatal("Fatal error in DiseaseMortality<DVM>::apply: exp(-(year_effect * DM * Sel[i])) is huge. Your disease parameters are probably wrong.");}
                VECTOR rates(year_effect * DM * Sel[i]);
                if (requests!=0){
                        if (requests->disease_biomass_loss){
                                // fill in the tonnage lost
                                dvector ones(s.col_min,s.col_max);
                                ones = 1.0;
                                DOUBLE loss = elem_prod(s.partition[i],ones - exp(-rates)) * mean_weight->get_row(s,i);
                                results->disease_biomass_loss.insert(make_pair(year,loss));
                        }
                }
                s.partition[i] *= exp(-rates);
  }
};

template<CDVM>
void DiseaseMortality<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("DiseaseMortality::print");

// print out the scaler DM; then the selectivity; then the index by year
  out << "  Disease mortality scalar = " << DM << '\n';
  out << "  Unscaled selectivity : " << selectivity->label << '\n';
  out << "  Annual disease mortality : \n";
  for (int j = index->indexmin(); j<=index->indexmax(); j++){
    out << setprecision(3);
    out << j << ' ';
  }
  out << "\n";
  for (int j = index->indexmin(); j<=index->indexmax(); j++){
    out << setprecision(3);
    out << (*index)[j] << ' ';
  }

// print out index used for projections
  if( (*future_index)[future_index->indexmin()] != -1 ){
    out << "\n";
    out << "  Annual disease mortality for projections : \n";
    for (int j = future_index->indexmin(); j<=future_index->indexmax(); j++){
      out << setprecision(3);
      out << j << ' ';
    }
    out << "\n";
    for (int j = future_index->indexmin(); j<=future_index->indexmax(); j++){
      out << setprecision(3);
      out << (*future_index)[j] << ' ';
    }
  }

  out << "\n\n";
};

template<CDVM>
DiseaseMortality<DVM>::DiseaseMortality(Parameter_set<DVM>& p, Basic_state<DVM>& s,
                                std::map<std::string, Selectivity<DVM>*>& all_selectivities){
  DEBUG1("DiseaseMortality::DiseaseMortality");

  int simulation = p.get_int("simulation",0);

  // years and index for initial to current years in the model
  DM = p.get_estimable("disease_mortality.DM");
  step = p.get_int("annual_cycle.disease_mortality_time");
  index = new VECTOR(p.get_estimable_vector("disease_mortality.index"));
  years = new dvector(p.get_constant_vector("disease_mortality.years"));
  for (int k=2; k<=years->indexmax(); k++){
    if ((*years)[k] != ((*years)[k-1]+1)){
      fatal("disease_mortality.years should be consecutive integers");
    }
  }
  if((*years)[1] < p.get_int("initial") || (*years)[years->indexmax()] > p.get_int("current")) {
    if (!simulation) fatal("disease_mortality.years should be within the range 'initial' to 'current'");}
  index->shift((int)((*years)[1]));
  if (index->size() != years->size()){
  fatal("Wrong length: disease_mortality.index");}
  delete years;

  // The years and index for projections (years: current + 1 to final)
  future_index = new VECTOR(p.get_estimable_vector("disease_mortality.future_index", dvector("{-1}")) );
  future_years = new dvector(p.get_constant_vector("disease_mortality.future_years", dvector("{-1}")) );
  for (int k=2; k<=future_years->indexmax(); k++){
    if ((*future_years)[k] != ((*future_years)[k-1]+1)){
      fatal("disease_mortality.future_years should be consecutive integers");
    }
  }
  if( (*future_years)[1] != -1 ){    // i.e. future years have been supplied
    if( (*future_years)[1] < p.get_int("current") + 1 || (*future_years)[future_years->indexmax()] > p.get_int("final") ){
       if (!simulation) fatal("You need to supply disease_mortality.future_years within the range 'current' + 1  to 'final'");
    }
  }
  future_index->shift((int)((*future_years)[1]));
  if (future_index->size() != future_years->size()){
     fatal("Wrong length: disease_mortality.future_index");
  }
  delete future_years;

  std::string sel_name = p.get_string("disease_mortality.selectivity");
  if (!in(all_selectivities,sel_name)){
  fatal("Unrecognised selectivity " + sel_name + " for disease mortality");}
  selectivity = all_selectivities[sel_name];
}

template<CDVM>
DiseaseMortality<DVM>::~DiseaseMortality(){
  if (index!=0) delete index;
  if (future_index!=0) delete future_index;
}

//################################ TAGGING #################################
template<CDVM>
void TaggingFish<DVM>::apply(Basic_state<DVM>& s, int _year,int _step, Basic_annual_cycle<DVM>* annual_cycle,
                             Basic_requests<DVM>* requests, Basic_results<DVM>* results){
  DEBUG1("TaggingFish::apply");
  if (year==_year && step==_step){
    std::vector<VECTOR> fish_moved; // record how many fish are tagged,
                                    // element [i][j] corresponds to the movement from source_rows[i] of age/size class j
    if (release_type=="deterministic"){
      // Before we appy tagging, we have to convert the supplied size frequency to
      //  an age frequency. This function will fill in the class_props or
      //  class_props_male and class_props_female vectors (depending on the value of 'sexed').
      sizefreq_to_agefreq(s,_year,_step,annual_cycle);
    }
    if (!sexed){
      // move fish (don't apply tagging mortality yet)
      // but first, find out if there are enough to tag!
      VECTOR fish_to_tag(number*class_props);
      fish_to_tag.shift(s.col_min);
      VECTOR available_fish(s.col_min,s.col_max);
      available_fish=0;
      for (int i=0; i<source_rows.size(); i++){
        available_fish += s.partition[source_rows[i]];
      }
      if (min(available_fish - fish_to_tag)<=0){
        // we will not be able to tag as many fish as we designated - this should be rare
        for (int j=s.col_min; j<=s.col_max; j++){
          if (available_fish[j]==0 && fish_to_tag[j]>0) fatal("Tagging episode " + episode_label + " attempts to apply tags to fish in column " + itos(j) + " of the partition, yet there are no eligible fish in that column?");
          if (available_fish[j] - fish_to_tag[j]<0){
            fish_to_tag[j] = available_fish[j];
          }
        }
      }
      VECTOR tag_rates(elem_div(fish_to_tag,available_fish));
      tag_rates.shift(s.col_min);
      for (int j=s.col_min; j<=s.col_max; j++){
        if (available_fish[j]==0 && fish_to_tag[j]==0) tag_rates[j]=0;// else 0/0 error
      }
     // right, now go ahead and put the tags on
      for (int i=0; i<source_rows.size(); i++){
        fish_moved.push_back(elem_prod(tag_rates,s.partition[source_rows[i]]));
        s.move(tag_rates,source_rows[i],destination_rows[i]);
      }
    } else if (sexed){
      // move fish (don't apply tagging mortality yet)
      // but first, find out if there are enough to tag!
      VECTOR male_fish_to_tag(number*class_props_male);
      VECTOR female_fish_to_tag(number*class_props_female);
      male_fish_to_tag.shift(s.col_min);
      female_fish_to_tag.shift(s.col_min);
      VECTOR male_available_fish(s.col_min,s.col_max);
      VECTOR female_available_fish(s.col_min,s.col_max);
      male_available_fish=0;
      female_available_fish=0;
      int sex_char = s.character_numbers("sex");
      for (int i=0; i<source_rows.size(); i++){
        if (s.character_value(source_rows[i],sex_char)==1){
          male_available_fish += s.partition[source_rows[i]];
        } else {
          female_available_fish += s.partition[source_rows[i]];
        }
      }
      if (min(male_available_fish - male_fish_to_tag)<0){
        // we will not be able to tag as many male fish as we designated - this should be rare
        for (int j=s.col_min; j<=s.col_max; j++){
          //if (male_available_fish[j]==0 && male_fish_to_tag[j]>0) fatal("Tagging episode " + episode_label + " attempts to apply tags to male fish in column " + itos(j) + " of the partition, yet there are no eligible male fish in that column?");
          if (male_available_fish[j] - male_fish_to_tag[j]<0){
            male_fish_to_tag[j] = male_available_fish[j];
          }
        }
      }
      if (min(female_available_fish - female_fish_to_tag)<0){
        // we will not be able to tag as many female fish as we designated - this should be rare
        for (int j=s.col_min; j<=s.col_max; j++){
          //if (female_available_fish[j]==0 && female_fish_to_tag[j]>0) fatal("Tagging episode " + episode_label + " attempts to apply tags to female fish in column " + itos(j) + " of the partition, yet there are no eligible female fish in that column?");
          if (female_available_fish[j] - female_fish_to_tag[j]<0){
            female_fish_to_tag[j] = female_available_fish[j];
          }
        }
      }
      VECTOR male_tag_rates(elem_div(male_fish_to_tag,male_available_fish));
      VECTOR female_tag_rates(elem_div(female_fish_to_tag,female_available_fish));
      male_tag_rates.shift(s.col_min);
      female_tag_rates.shift(s.col_min);
      for (int j=s.col_min; j<=s.col_max; j++){
        if (male_available_fish[j]==0 && male_fish_to_tag[j]==0) male_tag_rates[j]=0;
        if (female_available_fish[j]==0 && female_fish_to_tag[j]==0) female_tag_rates[j]=0;
       }
      // right, now go ahead and put the tags on
      for (int i=0; i<source_rows.size(); i++){
        if (s.character_value(source_rows[i],sex_char)==1){
          fish_moved.push_back(elem_prod(male_tag_rates,s.partition[source_rows[i]]));
          s.move(male_tag_rates,source_rows[i],destination_rows[i]);
        } else {
          fish_moved.push_back(elem_prod(female_tag_rates,s.partition[source_rows[i]]));
          s.move(female_tag_rates,source_rows[i],destination_rows[i]);
        }
      }
    }
    if (requests!=0){
      // now get results if requested
      if (requests->numbers_tagged){
        DOUBLE total_moved = 0;
        for (int i=0; i<fish_moved.size(); i++){
          total_moved += sum(fish_moved[i]);
        }
        results->numbers_tagged.insert(make_pair(episode_label,total_moved));
      }
      for (int entry=0; entry<requests->numbers_at.size(); entry++){
        std::string label = requests->numbers_at_labels[entry];
        if (requests->numbers_at[label].tagging_episode == episode_label){
          results->numbers_at[label].insert(make_pair(year,requests->numbers_at[label].get_result(s,*annual_cycle,year,0)));
        }
      }
    }
    // now apply tagging mortality
    // later this may depend on sex, age/size, etc...?
    for (int i=0; i<destination_rows.size(); i++){
      fish_moved[i].shift(s.col_min);
      s.partition[destination_rows[i]] -= fish_moved[i]*mortality;
    }
  }
}

template<CDVM>
void TaggingFish<DVM>::sizefreq_to_agefreq(Basic_state<DVM>& s, int year, int step, Basic_annual_cycle<DVM>* annual_cycle){
  // If sexed=1, use length_props_male, length_props_female to fill in class_props_male, class_props_female.
  // If sexed=0, use length_props to fill in class_props.
  // Do this by calculating the current age vs (sex&)length matrix from the relevant parts of the partition,
  //  scaling columns to sum to 1, and multiplying the resulting matrix by the size frequency.
  DEBUG1("TaggingFish::sizefreq_to_agefreq");
  int min_length_class=1;
  int max_length_class=class_mins.size()-1+plus_group;
  int n_length_classes = max_length_class-min_length_class+1;
  int min_age_class=s.col_min;
  int max_age_class=s.col_max;
  int n_age_classes = max_age_class-min_age_class+1;
  dvector sexlength(1,n_length_classes*(sexed?2:1));
  if (sexed){
    for (int i=1; i<=n_length_classes; i++){
      sexlength[i]=length_props_male[i];
      sexlength[i+n_length_classes]=length_props_female[i];
    }
  } else {
    sexlength=length_props;
  }
  MATRIX sexage_sexlength(1,n_age_classes*(sexed?2:1),1,n_length_classes*(sexed?2:1));
  sexage_sexlength=0.0;
  std::vector<MATRIX> size_dists;
  for (int r=0; r<source_rows.size(); r++){
    int row = source_rows[r];
    size_dists.push_back(annual_cycle->size_at_age->get_size_dist(row,plus_group,class_mins));
    if (selectivity != 0){
      VECTOR temp_sel=(selectivity->get_selectivity(year,step)[row]);
      for(int i=1; i<=n_length_classes; i++) {
        for(int j=1; j<=n_age_classes; j++) {
          size_dists[size_dists.size()-1][i][j] *= temp_sel[j];
        }
      }
    }
  }
  for (int i=1; i<=n_age_classes; i++){
    int age = i+min_age_class-1;
    if (sexed){
      // fill in row i with numbers-at-length of males of 'age'
      // and row i+n_age_classes with numbers-at-length of females of 'age'
      int sex_char = s.character_numbers("sex");
      for (int r=0; r<source_rows.size(); r++){
        int row = source_rows[r];
        int matrix_row, matrix_first_col;
        if (s.character_value(row,sex_char)==1){
          // male fish
          matrix_row = i;
          matrix_first_col = 1;
        } else {
          // female fish
          matrix_row = i+n_age_classes;
          matrix_first_col = 1+n_length_classes;
        }
        DOUBLE n_fish = s.partition[row][age];
        VECTOR sexage_sexlength_entries(n_fish*extract_column(size_dists[r],age));
        for (int j=1; j<=n_length_classes; j++){
          sexage_sexlength[matrix_row][j+matrix_first_col-1]+=sexage_sexlength_entries[j];
        }
      }
    } else if (!sexed){
      // fill in row i with numbers-at-length of fish of 'age'
      for (int r=0; r<source_rows.size(); r++){
        DOUBLE n_fish = s.partition[source_rows[r]][age];
        sexage_sexlength[i]+=n_fish*extract_column(size_dists[r],age);
      }
    }
  }
  VECTOR sexage(1,n_age_classes*(sexed?2:1));
  sexage=0.0;
  for (int i=1; i<=n_length_classes*(sexed?2:1); i++){
    VECTOR col(extract_column(sexage_sexlength,i));
    //sexage += sexlength[i]*col/sum(col);
    sexage += sexlength[i]*col/(sum(col)>0?sum(col):1);
  }
  int class_props_debug=0;
  if (sexed){
    for (int i=1; i<=n_age_classes; i++){
      class_props_male[i+min_age_class-1]=sexage[i];
      class_props_female[i+min_age_class-1]=sexage[i+n_age_classes];
    }
    if (class_props_debug) cerr << "In TaggingFish, class_props_male = \n" << class_props_male << "\n and class_props_female = \n" << class_props_female << '\n';
  } else if (!sexed){
    class_props = sexage;
    if (class_props_debug) cerr << "In TaggingFish, class_props = \n" << class_props << "\n";
  }
}

template<CDVM>
void TaggingFish<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("TaggingFish::print");
  out << "  Fish tagged with tag " + tag_name + " in year " << year << ", step " << step;
  if (s.n_areas>1){
    out << ", area " << area;
  }
  if (stock!=""){
    out << ", stock " << stock;
  }
  out << '\n';
  if (s.sex_partition){
    if (sex=="both"){
      out << "  Fish of both sexes are tagged.\n";
    } else {
      out << "  Only "+sex+" fish are tagged.\n";
    }
  }
  if (s.mature_partition && mature_only){
    out << "  Only mature fish are tagged.\n";
  }
  out << "  Tagging moves fish as follows:\n";
  for (int i=0; i<source_rows.size(); i++){
    out << "fish from row " << source_rows[i] << " to row " << destination_rows[i] << "\n";
  }
  out << "  to tag " << number << " fish with the following breakdown over ";
  if (release_type=="free"){
    out << "partition classes:\n";
    if (!sexed){
      out << "  " << class_props << '\n';
    } else {
      out << "  male: " << class_props_male << '\n';
      out << "  female: " << class_props_female << '\n';
    }
  } else if (release_type=="deterministic"){
    out << "size classes with class_mins " << class_mins << " and " << (plus_group?"a":"no") << " plus group:\n";
    if (!sexed){
      out << "  " << length_props << '\n';
    } else {
      out << "  male: " << length_props_male << '\n';
      out << "  female: " << length_props_female << '\n';
    }
    out << "  (This length frequency is converted into an age frequency using the age/length distribution in the partition at the time";
    if (selectivity_name!="none") out << ", using the selectivity ogive " << selectivity_name;
    else out << ", using no selectivity ogive";
    out << ".)\n";
  }
  if (mortality>0){
    out << "  and then applies a mortality of " << 100*mortality << "% of tagged fish.\n";
  }
  out << '\n';
}

template<CDVM>
TaggingFish<DVM>::TaggingFish(Parameter_set<DVM>& p, Basic_state<DVM>& s,
              std::string& _episode_label,std::map<std::string,Selectivity<DVM>*>& selectivities):
prefix("tag["+_episode_label+"]."),
release_type(s.size_based?"free":p.get_string(prefix+"release_type","deterministic")),
class_props(s.col_min,s.col_max),
class_props_male(s.col_min,s.col_max),
class_props_female(s.col_min,s.col_max),
plus_group(p.get_bool(prefix+"plus_group",s.plus_group)),
class_mins((release_type=="deterministic")?p.get_constant_vector(prefix+"class_mins"):dvector("{1,2}")),
length_props(1,((release_type=="deterministic")?p.get_constant_vector(prefix+"class_mins"):dvector("{1,2}")).size()-1+plus_group),
length_props_male(1,((release_type=="deterministic")?p.get_constant_vector(prefix+"class_mins"):dvector("{1,2}")).size()-1+plus_group),
length_props_female(1,((release_type=="deterministic")?p.get_constant_vector(prefix+"class_mins"):dvector("{1,2}")).size()-1+plus_group),
selectivity(0)
  {
  DEBUG1("TaggingFish::TaggingFish");
  episode_label = _episode_label;
  tag_name = p.get_string(prefix+"tag_name");
  if (!s.valid_tag(tag_name)){
    fatal("tag_name " + tag_name + " in tagging block " + episode_label + " should be in @tag_names but is not...");
  }
  if (!s.size_based){
    if (release_type=="free"){
      // Specify proportions-by-age of tagged fish. If only a length frequency is available, provide it as a Tag_release observation and make the proportions-by-age free parameters.
    } else if (release_type=="deterministic"){
      // Specify proportions-by-size of tagged fish, will be converted into proportions-by-age via the age/length matrix of the partition
    } else fatal("Unknown release_type of "+release_type+" in tagging block - use free or deterministic");
  }
  step = p.get_int(prefix+"step");
  year = p.get_int(prefix+"year");
  if (s.n_areas>1){
    area = p.get_string(prefix+"area");
    if (!s.valid_area(area)){
      fatal("You have entered an invalid area of "+area+" in the tagging block for "+tag_name);}
  }
  if (s.sex_partition){
    sex = p.get_string(prefix+"sex","both");
    if (sex!="male" && sex!="female" && sex!="both"){
      fatal("You have entered an invalid sex of "+sex+" in the tagging block for "+tag_name+" - use 'male', 'female', or 'both'");}
  }
  if (s.mature_partition){
    mature_only = p.get_bool(prefix+"mature_only",0);
  } else if (p.get_bool(prefix+"mature_only",0)){
    fatal("Your tagging block "+tag_name+" specifies that only mature fish can be tagged, this option is only allowed if maturity is a character in the partition.");
  }
  if (s.n_stocks>1){
    stock = p.get_string(prefix+"stock","");
    if (stock!=""){
      if (!s.valid_stock(stock)){
        fatal("You have entered an invalid stock of "+stock+" in the tagging block for "+tag_name);}
    }
  }
  number = p.get_int(prefix+"number");
  mortality = p.get_estimable(prefix+"mortality",0);
  if (s.sex_partition){
    if (!p.present(prefix+"props_all") && !((sex=="female"||p.present(prefix+"props_male"))&&(sex=="male"||p.present(prefix+"props_female")))){
      fatal("In the tagging block "+tag_name+", you need to supply tagging rates, either for both genders combined, or for each specific gender (omitting any genders which have been specified as not tagged)");
    }
  } else {
    if (!p.present(prefix+"props_all")){
      fatal("In the tagging block "+tag_name+", you need to supply tagging rates.");
    }
  }
  sexed=p.present(prefix+"props_male") || p.present(prefix+"props_female");
  if (release_type=="free"){
    if (sexed){
      if (p.present(prefix+"props_male")){
        VECTOR test(p.get_estimable_vector(prefix+"props_male"));
        if (test.size()!=s.col_max-s.col_min+1) fatal("props_male is the wrong size in @tag block " + episode_label + " - it should have one entry for each of the " + itos(s.col_max-s.col_min+1) + " columns of the partition.");
        if(p.get_bool(prefix+"log_props",0)) {
          class_props_male = exp(p.get_estimable_vector(prefix+"props_male"));
        } else {
          class_props_male = p.get_estimable_vector(prefix+"props_male");
        }
      } else class_props_male = 0;
      if (p.present(prefix+"props_female")){
        VECTOR test(p.get_estimable_vector(prefix+"props_female"));
        if (test.size()!=s.col_max-s.col_min+1) fatal("props_female is the wrong size in @tag block " + episode_label + " - it should have one entry for each of the " + itos(s.col_max-s.col_min+1) + " columns of the partition.");
        if(p.get_bool(prefix+"log_props",0)) {
          class_props_female = exp(p.get_estimable_vector(prefix+"props_female"));
        } else {
          class_props_female = p.get_estimable_vector(prefix+"props_female");
        }
      } else class_props_female = 0;
      if (sum(class_props_male)+sum(class_props_female) == 0){
        fatal("divide by zero error in TaggingFish::apply");}
      DOUBLE total = (sum(class_props_male) + sum(class_props_female));
      class_props_male /= total;
      class_props_female /= total;
    } else {
      VECTOR test(p.get_estimable_vector(prefix+"props_all"));
      if (test.size()!=s.col_max-s.col_min+1) fatal("props_all is the wrong size in @tag block " + episode_label + " - it should have one entry for each of the " + itos(s.col_max-s.col_min+1) + " columns of the partition.");
      if(p.get_bool(prefix+"log_props",0)) {
        class_props = exp(p.get_estimable_vector(prefix+"props_all"));
      } else {
        class_props = p.get_estimable_vector(prefix+"props_all");
      }
      if (sum(class_props) == 0){
        fatal("divide by zero error in TaggingFish::apply");}
      class_props /= sum(class_props);
    }
  } else if (release_type=="deterministic"){
    if (sexed){
      if (p.present(prefix+"props_male")){
        dvector test(p.get_constant_vector(prefix+"props_male"));
        if (test.size()!=class_mins.size()-1+plus_group) fatal("props_male is the wrong size in @tag block " + episode_label + " - it should have one entry for each of the " + itos(class_mins.size()-1+plus_group) + " size classes specified.");
        length_props_male = p.get_constant_vector(prefix+"props_male");
      } else length_props_male = 0;
      if (p.present(prefix+"props_female")){
        dvector test(p.get_constant_vector(prefix+"props_female"));
        if (test.size()!=class_mins.size()-1+plus_group) fatal("props_female is the wrong size in @tag block " + episode_label + " - it should have one entry for each of the " + itos(class_mins.size()-1+plus_group) + " size classes specified.");
        length_props_female = p.get_constant_vector(prefix+"props_female");
      } else length_props_female = 0;
      if (sum(length_props_male)+sum(length_props_female) == 0){
        fatal("divide by zero error in TaggingFish::apply");}
      double total = (sum(length_props_male) + sum(length_props_female));
      length_props_male /= total;
      length_props_female /= total;
    } else {
      dvector test(p.get_constant_vector(prefix+"props_all"));
      if (test.size()!=class_mins.size()-1+plus_group) fatal("props_all is the wrong size in @tag block " + episode_label + " - it should have one entry for each of the " + itos(class_mins.size()-1+plus_group) + " size classes specified.");
      length_props = p.get_constant_vector(prefix+"props_all");
      if (sum(length_props) == 0){
        fatal("divide by zero error in TaggingFish::apply");}
      length_props /= sum(length_props);
    }
    selectivity_name = p.get_string(prefix+"ogive","none"); // ogive for deterministic method
    if(selectivity_name!="none") {
      if(selectivities.find(selectivity_name) != selectivities.end()){
        selectivity=selectivities[selectivity_name];
      } else fatal("Unrecognised selectivity '" + selectivity_name + "' in " + prefix + "ogive");
    }
    class_props = 0.0; // we'll fill these age frequencies in later
    class_props_male = 0.0;
    class_props_female = 0.0;
  }
  int sex_char = s.character_numbers("sex");
  int area_char = s.character_numbers("area");
  int stock_char = s.character_numbers("stock");
  int maturity_char = s.character_numbers("maturity");
  int tag_char = s.character_numbers("tag");
  dvector source(1,1), destination(1,1);
  for (int j=1; j<=s.n_rows; j++){
    if (s.character_value(j,tag_char)==1){ // not already tagged
      if (s.n_areas>1){
        if (area != s.area_names[s.character_value(j,area_char)]){
          continue;}}
      if (s.n_stocks>1){
        if ((stock != s.stock_names[s.character_value(j,stock_char)]) && (stock != "")){
          continue;}}
      if (s.mature_partition && mature_only){
        if (s.character_value(j,maturity_char)!=2){
          continue;}}
      if (s.sex_partition){
        if ((sex=="female" && s.character_value(j,sex_char)==1) || (sex=="male" && s.character_value(j,sex_char)==2)){
          continue;}}
      source_rows.push_back(j);
      source[1] = j;
      destination = s.corresponding_rows(source,tag_char,s.tag_numbers[tag_name]);
      destination_rows.push_back((int)(destination[1]));
      if (destination[1]==0){
        s.print(cerr);
        fatal("Tag " + tag_name + " attempts to migrate fish from row " + itos(j) + " to a nonexistent row??\n");
      }
    }
  }
}

template<CDVM>
TaggingFish<DVM>::~TaggingFish(){
  DEBUG1("TaggingFish::~TaggingFish");
  // nothing to do yet
}

//################################ TAG LOSS #################################

template<CDVM>
void TagLoss<DVM>::apply(Basic_state<DVM>& s, int _year, int _step){
        DEBUG1("TagLoss::apply");
        if (shedding_rate==0) return;
        DOUBLE loss_prop = 1-exp(-shedding_rate*tag_loss_props[_step]);
        for (int i=0; i<tagged_rows.size(); i++){
                s.move(loss_prop,tagged_rows[i]);
        }
}

template<CDVM>
void TagLoss<DVM>::print(Basic_state<DVM>& s, ostream& out){
        DEBUG1("TagLoss::print");
        if (shedding_rate==0){
                out << "  No tag loss.\n\n";
                return;
        }
        out << "  Remove tagged fish with annual rate " << shedding_rate << ". Proportions per time step: ";
        for (int i=1; i<=time_steps; i++){
                out << " (" << itos(i) << "): " << dtos(tag_loss_props[i]);
        }
        out << '\n';
}

template<CDVM>
TagLoss<DVM>::TagLoss(Parameter_set<DVM>& p, Basic_state<DVM>& s,std::string& _tag_name){
  // this process governs the loss of a single type of tag
  DEBUG1("TagLoss::TagLoss");
  tag_name = _tag_name;
  time_steps = p.get_int("annual_cycle.time_steps");
  if (p.present("tag_shedding_rate")){
    // Check that the correct number of tag_shedding_rate values have been supplied
    if(p.get_estimable_vector("tag_shedding_rate").size()!=p.get_int("n_tags")) {
      fatal("@tag_shedding_rate is the wrong length - there should be " + itos(p.get_int("n_tags")) + " entries.");}
    //check the length of tag_shedding_rate, RB
    //dvector shedding(p.get_constant_vector("tag_shedding_rate"));
    //int sheddingSize=shedding.size();
    //int numTags=p.get_int("n_tags");
    //if (numTags!=sheddingSize){
    //  fatal("wrong length of @tag_shedding_rate="+itos(sheddingSize)+", n_tags="+itos(numTags));
    //}
    //
    int tag_num = s.tag_numbers[tag_name];
    shedding_rate = p.get_estimable_vector("tag_shedding_rate")[tag_num-1];
    tag_loss_props.resize(time_steps+1); // dummy element 0
    if (p.present("tag_loss_props")){
      dvector loss_props(p.get_constant_vector("tag_loss_props"));
      if (loss_props.size()!=tag_loss_props.size()-1){
        fatal("@tag_loss_props is the wrong length - there should be " + itos(loss_props.size()) + " entries.");
      }
      for (int i=1; i<tag_loss_props.size(); i++){
        tag_loss_props[i] = loss_props[i];
      }
      if (fabs(1.0-sum(loss_props))>0.01){
        fatal("@tag_loss_props sums to " + dtos(sum(loss_props)) + " - these should sum to 1.0");
      }
    } else {
      dvector loss_props(p.get_constant_vector("annual_cycle.M_props"));
      for (int i=1; i<tag_loss_props.size(); i++){
        tag_loss_props[i] = loss_props[i];
      }
    }
    int tag_char = s.character_numbers("tag");
    for (int j=1; j<=s.n_rows; j++){
      if (s.character_value(j,tag_char)==tag_num){
        tagged_rows.push_back(j);
      }
    }
  } else {
    // no shedding
    shedding_rate = 0;
    // we won't bother to redimension the other elements
  }
}

//################################ MIGRATION #################################
template<CDVM>
int Migration_by_constant<DVM>::apply(Basic_state<DVM>& s, int year,Basic_requests<DVM>* requests, Basic_results<DVM>* results){
  // Apply a migration to the partition of s in year. For each i, migration_p
  // is the proportion of fish moving from each partition[source_rows[i]][j]
  // to each partition[destination_rows[i]][j].
  // Apply density-dependence to migration_p if it is included.
  DEBUG1("Migration_by_constant::apply");
  if (!(this->density_dependent)){
    for (int i=0; i<source_rows.size(); i++){
      s.move(migration_p[i],source_rows[i],destination_rows[i]);
    }
  } else if (this->density_dependent){
    for (int i=0; i<source_rows.size(); i++){
      DOUBLE rate = this->density_dependence->apply(migration_p[i],s,year,requests,results);
    if(year!=-1)
      cerr<<year<<" "<<rate<<"\n";
      s.move(rate,source_rows[i],destination_rows[i]);
    }
  }
  return 1;
}

template<CDVM>
void Migration_by_constant<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Migration_by_constant::print");
  if (this->stock>0){
    out << "  stock " << s.stock_names[this->stock] << '\n';}
  out << "  from area " << source_area_name << " to area " << destination_area_name << '\n';
  for (int i=0; i<source_rows.size(); i++){
    if (migration_p[i]==1){
      out << "  all ";
    } else {
      out << "  proportion " << migration_p[i] << " of ";
    }
    out << "fish from row " << source_rows[i] << " to row " << destination_rows[i] << "\n";
  }
  if (wave==1){
    out << "  (this is a 1st wave migration)\n";}
  else if (wave==2){
    out << "  (this is a 2nd wave migration)\n";}
  if (this->density_dependent){
    this->density_dependence->print(out);}
  out << '\n';
};

template<CDVM>
Migration_by_constant<DVM>::Migration_by_constant(Parameter_set<DVM>& p,
                                                  Basic_state<DVM>& s, int step,
                                                  const std::string& _label,
                                                  int source_area, int destination_area,
                          Mean_weight<DVM> *mean_weight):label(_label){
  // Construct migration process named 'label' from p, s, and step.
  DEBUG1("Migration_by_constant::Migration_by_constant");
  source_area_name = s.area_names[source_area];
  destination_area_name = s.area_names[destination_area];
  std::string command = "migration[" + label + "].";
  std::string stock_name = p.get_string(command+"stock","");
  if (stock_name=="") this->stock=-1;
  else {
          if (!s.valid_stock(stock_name)){
                  fatal("You entered the invalid stock " + stock_name + " in migration labelled " + label);}
          this->stock=s.stock_numbers[stock_name];
  }
  std::string migrators = p.get_string(command+"migrators","all");
  if (migrators != "all" && migrators != "mature" && migrators != "immature"){
          fatal("Bad 'migrators' subcommand for migration labelled " + label + " - should be 'all', 'mature', or 'immature'");
  }
  if (migrators!="all" && !s.mature_partition){
    fatal("If you want to migrate " + migrators + " fish when maturity is not in the partition, you need to specify the migration rates as an ogive (step " + itos(step) + ").");
  }
  wave = p.get_int(command+"wave",0);
  if (wave<0 || wave>2) fatal(command+"wave should be 1 or 2");
  if (wave>0) pwave = p.get_estimable(command+"pwave");
  DOUBLE prop = p.get_estimable(command+"prop",1);
  if (wave==1) prop = pwave*prop;
  else if (wave==2){
    if (pwave==1){
      prop = 0;
    } else {
      prop = (1-pwave)*prop / (1-(pwave*prop));
    }
  }
  int area_char = s.character_numbers("area");
  int maturity_char = s.character_numbers("maturity");
  int stock_char = s.character_numbers("stock");
  dvector source(1,1), destination(1,1);
  for (int j=1; j<=s.n_rows; j++){
    if (source_area == s.character_value(j,area_char)){
      if ((migrators=="immature" && s.character_value(j,maturity_char)==1) ||
          (migrators=="mature" && s.character_value(j,maturity_char)==2) ||
          migrators=="all"){
        if (s.n_stocks>1 && this->stock>0){
          if (s.character_value(j,stock_char)!=this->stock) continue;}
        source[1] = j;
        destination = s.corresponding_rows(source,area_char,destination_area);
        if (destination[1]==0){
          s.print(cerr);
          fatal("Migration " + label + " attempts to migrate fish from row " + itos(j) + " to a nonexistent row. Try being more specific about which fish migrate?\n");
        } else {
          source_rows.push_back(j);
          destination_rows.push_back((int)(destination[1]));
          migration_p.push_back(prop);
        }
      }
    }
  }
  if(p.present(command+"S") || p.present(command+"D") || p.present(command+"annual_variation_years") || p.present(command+"annual_variation_values")) {
    this->density_dependent = 1;
    this->density_dependence = new Density_dependence<DVM>(s,p,command,source_area,destination_area, step, label,mean_weight);
  if(p.present(command+"annual_variation_years") && p.present(command+"annual_variation_values"))
    this->annual_varying = 1;
  else
    this->annual_varying = 0;
  } else {
    this->density_dependent = 0;
    this->density_dependence = 0;
  this->annual_varying = 0;
  }
}

template<CDVM>
Migration_by_constant<DVM>::~Migration_by_constant(){
  DEBUG2("~Migration_by_constant");
  if (this->density_dependence != 0) delete this->density_dependence;
}

template<CDVM>
int Migration_by_ogive<DVM>::apply(Basic_state<DVM>& s, int year,Basic_requests<DVM>* requests, Basic_results<DVM>* results){
  // Apply a migration to the partition of s in year. For each i, each
  // migration_rates[i][j] is the proportion of fish moving from
  // partition[source_rows[i]][j] to partition[destination_rows[i]][j]. Return 1.
  // Apply density-dependence to migration_p if it is included.
  DEBUG1("Migration_by_ogive::apply");
  if (!this->density_dependent){
    for (int i=0; i<source_rows.size(); i++){
      s.move(migration_rates[i],source_rows[i],destination_rows[i]);
    }
  } else if (this->density_dependent){
    for (int i=0; i<source_rows.size(); i++){
      rates = this->density_dependence->apply(migration_rates[i],s,year,requests,results);
     s.move(rates,source_rows[i],destination_rows[i]);
    }
  }
  return 1;
}

template<CDVM>
void Migration_by_ogive<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Migration_by_ogive::print");
  if (this->stock>0){
    out << "  stock " << s.stock_names[this->stock] << '\n';}
  out << "  from area " << source_area_name << " to area " << destination_area_name << '\n';
  for (int i=0; i<source_rows.size(); i++){
    out << "  proportions ";
    out << migration_rates[i];
    out << "of fish from row " << source_rows[i] << " to row " << destination_rows[i] << "\n";
  }
  if (wave==1){
    out << "  (this is a first wave migration)\n";}
  else if (wave==2){
    out << "  (this is a second wave migration)\n";}
  if (this->density_dependent){
    this->density_dependence->print(out);}
  out << '\n';
};

template<CDVM>
Migration_by_ogive<DVM>::Migration_by_ogive(Parameter_set<DVM>& p,
                                            Basic_state<DVM>& s, int step, const std::string& _label,
                                            int source_area, int destination_area,
                                            Size_at_age<DVM>* size_at_age,
                                            Mean_weight<DVM> *mean_weight)
  : rates(s.col_min,s.col_max),label(_label){
  // Construct migration process named 'label' from p, s, and step.
  // The size-at-age object is used when size-based migration rates are specified
  // in an age-based model.
  DEBUG1("Migration_by_ogive::Migration_by_ogive");
  source_area_name = s.area_names[source_area];
  destination_area_name = s.area_names[destination_area];
  std::string command = "migration[" + label + "].";
  std::string stock_name = p.get_string(command+"stock","");
  if (stock_name=="") this->stock=-1;
  else {
          if (!s.valid_stock(stock_name)){
                  fatal("You entered the invalid stock " + stock_name + " in migration block labelled " + label);}
          this->stock=s.stock_numbers[stock_name];
  }
  std::string migrators = p.get_string(command+"migrators","all");
  wave = p.get_int(command+"wave",0);
  if (wave<0 || wave>2) fatal(command+"wave should be 1 or 2");
  if (wave>0) pwave = p.get_estimable(command+"pwave");
  int sexed, ogive_size_based;
  if (p.present(command+"rates_male")){
    sexed = 1;
    ogive_size_based = p.get_ogive_base(command+"rates_male") || p.get_ogive_base(command+"rates_female");
  } else {
    sexed = 0;
    ogive_size_based = p.get_ogive_base(command+"rates_all");
  }
  if (ogive_size_based && !s.size_based && size_at_age->varies_between_years()){
    fatal("You may not specify size-based migration ogives in an age-based model when size-at-age varies between years.");}
  int sex_char = s.character_numbers("sex");
  int area_char = s.character_numbers("area");
  int stock_char = s.character_numbers("stock");
  int maturity_char = s.character_numbers("maturity");
  dvector source(1,1), destination(1,1);
  if (s.mature_partition || migrators=="all"){
    for (int j=1; j<=s.n_rows; j++){
      if (source_area == s.character_value(j,area_char)){
        if ((migrators=="immature" && s.character_value(j,maturity_char)==1) ||
            (migrators=="mature"   && s.character_value(j,maturity_char)==2) ||
            migrators=="all"){
          if (s.n_stocks>1 && this->stock>0){
            if (s.character_value(j,stock_char)!=this->stock){
              continue;}}
          source_rows.push_back(j);
          source[1] = j;
          destination = s.corresponding_rows(source,area_char,destination_area);
          destination_rows.push_back((int)(destination[1]));
          if (destination[1]==0){
            s.print(cerr);
            fatal("Migration " + label + " attempts to migrate fish from row " + itos(j) + " to a nonexistent row. Try being more specific about which fish migrate?\n");
          } else if (sexed){
            if (s.character_value(j,sex_char)==1){
              migration_rates.push_back(p.get_ogive_values(command+"rates_male",size_at_age,-1,step,j));
            } else {
              migration_rates.push_back(p.get_ogive_values(command+"rates_female",size_at_age,-1,step,j));
            }
          } else {
            migration_rates.push_back(p.get_ogive_values(command+"rates_all",size_at_age,-1,step,j));
          }
          if (wave==1){
            migration_rates[migration_rates.size()-1] *= pwave;
          } else if (wave==2) {
            if (pwave==1){
              migration_rates[migration_rates.size()-1]=0;
            } else for (int j=s.col_min; j<=s.col_max; j++){
              migration_rates[migration_rates.size()-1][j] *= (1-pwave) / (1-(pwave*migration_rates[migration_rates.size()-1][j]));
            }
          }
        }
      }
    }
  }
  if(p.present(command+"S") || p.present(command+"D") || p.present(command+"annual_variation_years") || p.present(command+"annual_variation_values")) {
    this->density_dependent = 1;
    this->density_dependence = new Density_dependence<DVM>(s,p,command,source_area,destination_area, step,label, mean_weight);
  if(p.present(command+"annual_variation_years") && p.present(command+"annual_variation_values"))
    this->annual_varying = 1;
  else
    this->annual_varying = 0;
  } else {
    this->density_dependent = 0;
    this->density_dependence = 0;
  this->annual_varying = 0;
  }

}

template<CDVM>
Migration_by_ogive<DVM>::~Migration_by_ogive(){
  DEBUG2("~Migration_by_ogive");
  if (this->density_dependence != 0) delete this->density_dependence;
}

template<CDVM>
DOUBLE Density_dependence<DVM>::apply(const DOUBLE& rate, Basic_state<DVM>& s, int year,Basic_requests<DVM>* requests, Basic_results<DVM>* results){
  // Calculate the density dependence factor and apply it to the rate.
  DEBUG2("Density_dependence::apply(DOUBLE)");
  DOUBLE result;
  if (year==-1){
    // This is the unfished equilibrium period.
    // Do not apply density dependence; but it may be necessary to record the virgin abundance.
    if (record_virgin_abundance){
      initial_source_abundance = s.abundance("biomass", year, step, mean_weight, source_chars, source_vals);
      initial_destination_abundance = s.abundance("biomass", year, step, mean_weight, destination_chars, destination_vals);
    }
    //Do not apply density dependence, but still need to consider the annual_variation_mean
    if(annual_variation==0) {
      // Do nothing, bevcause its hard to define the mean rate with density dependance
      result = rate;
    } else { // rates are user-defined, and hence we can calculate a mean
      DOUBLE odds = rate / (1.0-rate);
      DOUBLE dd_factor = exp(annual_variation_bar_val);
      result = (dd_factor*odds / (1.0+dd_factor*odds));
    }
  } else {
     DOUBLE odds = rate / (1.0-rate);
     DOUBLE dd_factor = get_dd_factor(s,year);
     result = (dd_factor*odds / (1.0+dd_factor*odds));
  }
  if(requests){
    if(requests->migration_annual_variation && annual_variation){
      results->migration_annual_variation[year][label] = (*annual_variation)[year];
    }
  }
  return result;


}

template<CDVM>
VECTOR Density_dependence<DVM>::apply(const VECTOR& rates, Basic_state<DVM>& s, int year,Basic_requests<DVM>* requests, Basic_results<DVM>* results){
  // Calculate the density dependence factor and apply it to the vector of rates.
  // Never use density dependence in the unfished equilibrium period (year=-1)
  DEBUG2("Density_dependence::apply(VECTOR)");
  VECTOR result(rates);
  if (year==-1){
    // This is the unfished equilibrium period.
    // Do not apply density dependence; but it may be necessary to record the virgin abundance.
    if (record_virgin_abundance){
      initial_source_abundance = s.abundance("biomass", year, step, mean_weight, source_chars, source_vals);
      initial_destination_abundance = s.abundance("biomass", year, step, mean_weight, destination_chars, destination_vals);
    }
    // Do not apply density dependence, but still need to consider the annual_variation_mean
    if(annual_variation==0) {
      // Do nothing, bevcause its hard to define the mean rate with density dependance
      result = rates;
    } else { // rates are user-defined, and hence we can calculate a mean
      DOUBLE one = 1;
      VECTOR odds(elem_div(rates,one-rates));
      DOUBLE dd_factor = exp(annual_variation_bar_val);
      result = elem_div(dd_factor*odds,one+dd_factor*odds);
    }
  } else {
    DOUBLE one = 1;
    VECTOR odds(elem_div(rates,one-rates));
    DOUBLE dd_factor = get_dd_factor(s,year);
    result = elem_div(dd_factor*odds,one+dd_factor*odds);
  }
  if(requests){
     if(requests->migration_annual_variation && annual_variation){
      results->migration_annual_variation[year][label] = (*annual_variation)[year];
    }
  }
  return result;
}

template<CDVM>
DOUBLE Density_dependence<DVM>::get_dd_factor(Basic_state<DVM>& s, int year){
  // Calculate the density-dependence factor.
  DEBUG2("Density_dependence::get_dd_factor");
  if (initial_source_abundance < 0 || initial_destination_abundance < 0){
    fatal("In Density_dependence::get_dd_factor, initial abundances have not been set.");}
  DOUBLE source_abundance = s.abundance("biomass", year, step, mean_weight, source_chars, source_vals);
  DOUBLE destination_abundance = s.abundance("biomass", year, step, mean_weight, destination_chars, destination_vals);
  DOUBLE F = 0;
  if(annual_variation==0) {
    F += -S * (source_abundance - initial_source_abundance) / initial_source_abundance;
    F += -D * (destination_abundance - initial_destination_abundance) / initial_destination_abundance;
    if (F>10){
      fatal("Fatal error in the migration density dependence relationship. The value of exp(F) is enormous. Probably your S and/or D parameters are wrong.");}
  } else {
    //The year should always in the index range of annual_variation at this moment
      F +=(*annual_variation)[year];
    if (F>10){
      fatal("Fatal error in the migration annual variation relationship. The value of exp(F) is enormous. Check the annual_variation_values.");}
  }
  F = exp(F);
  return F;
}

template<CDVM>
void Density_dependence<DVM>::print(ostream& out){
  DEBUG2("Density_dependence::print");
  if(annual_variation==0) {
    out << "  Density dependent:\n";
    out << "    S (dependence on source area density) = " << S << "\n";
    out << "    D (dependence on destination area density) = " << D << '\n';
    out << "    Note that a dependence parameter of k means that the odds of a fish migrating are increased by a factor of exp(-k * (abundance - virgin_abundance) / virgin_abundance). A negative S means that fish are encouraged to leave an overpopulated area: a positive D means that fish are encouraged to move to an underpopulated area.\n";
  } else {
    /*
    out << "  Migration annual variation (by year):\n";
  for (int i = annual_variation->indexmin(); i<=annual_variation->indexmax(); i++){
       out << setw(6);
       out << i << ' ';
    }
    out << "\n  ";
    for (int i = annual_variation->indexmin(); i<=annual_variation->indexmax(); i++){
       out << setw(6);
       out << (*annual_variation)[i] << ' ';
    }
    out << "    Note that an annual variation parameter of k means that the odds of a fish migrating are increased by a factor of exp(k).\n";
  */
    out << "  Annual variation:\n";
    out << "    annual variation years = " << annual_variation_years << '\n';
    out << "    annual variation values = " << annual_variation_values << '\n';
    out << "    Note that an annual variation parameter of k means that the odds of a fish migrating are increased by a factor of exp(k).\n";
  }
}

template<CDVM>
void Density_dependence<DVM>::randomise(long seed){
  // Randomise the annual_variation.
  DEBUG0("Density_dependence::randomise");
  if (randomise_annual_variation != 0){
    randomise_annual_variation->apply(*annual_variation,first_random_year,seed);
  }
}

template<CDVM>
Density_dependence<DVM>::Density_dependence(Basic_state<DVM>& s,
                                            Parameter_set<DVM>& p, const std::string& command,
                                            int _source_area, int _destination_area,
                      int _step, const std::string& _label,Mean_weight<DVM> *_mean_weight)
  : annual_variation_years(p.get_constant_vector(command+"annual_variation_years",dvector("{-1}")))
  , annual_variation_values(p.get_estimable_vector(command+"annual_variation_values",VECTOR("{-1}")))
  , label(_label)
   // Construct the density-dependence object. The _chars and _vals members are used by
  // Basic_state::abundance calls.
{
  DEBUG1("Density_dependence::Density_dependence");
  source_area = _source_area;
  destination_area = _destination_area;
  step = _step;
  annual_variation=0;
  randomise_annual_variation=0;
  int simulation = p.get_int("simulation",0);
  int initial = p.get_int("initial");
  int current = p.get_int("current");
  int final = p.get_int("final");


  if(p.present(command+"S") || p.present(command+"D")) {
    if(p.present(command+"annual_variation_years") || p.present(command+"annual_variation_values")) {
      fatal("You cannot define both a density dependent migration and annual variation of migration in " + command);}
    S = p.get_estimable(command+"S");
    D = p.get_estimable(command+"D");
  }

   if(p.present(command+"annual_variation_years") || p.present(command+"annual_variation_values")) {
      if (!simulation){
       // normal case
       annual_variation = new VECTOR(initial,final);
      } else if (simulation) {
     // We  error out for any deterministic or stochastic simulation
     // because we haven't got something like Basic_Recruitment::apply_constant for Density_dependence,
     // therefore in a deterministic simulation CASAL won't know what to do with annual_variation.
     fatal("You have defined  annual variation for migration "+label+", but this hasn't been implemented for any deterministic or stochastic simulation. If you need this feature for any yield estimates (e.g. CSP), let us know and we can fix it for you");
     // The stuff below is reserved for stochastic simulation, it won't work for MCY_CAY which does deterministic
       // simulation anyway, but it should work for CSP calculation.

     // We are working in a simulation period.
       // We don't use the annual_variation over the (initial, current) period directly,
       //  but we may need to use them to determine the distribution of simulated annual_variation,
       //  so we extract them. Later we will throw them away.
       initial = p.get_int("original_initial");
       current = p.get_int("original_current");
       final = p.get_int("original_final");
       annual_variation = new VECTOR(initial,final);
    }
      (*annual_variation) = 0;

    for (int k=2; k<=annual_variation_years.indexmax(); k++){
         if (annual_variation_years[k] != (annual_variation_years[k-1]+1)){
       fatal(command + "annual_variation_years should be consecutive integers");}}
      if(annual_variation_years[annual_variation_years.indexmin()] < initial) fatal(command+"annual_variation_years must be in the range 'initial' to 'current'");
      if(annual_variation_years[annual_variation_years.indexmax()] > current) fatal(command+"annual_variation_years must be in the range 'initial' to 'current'");
      if (annual_variation_years.size() != annual_variation_values.size()){
      fatal(command + "annual_variation_values should be the same size as " + command + "annual_variation_years.");}
      annual_variation_values.shift((int)(annual_variation_years[1]));

    int first_year=p.get_int(command+"annual_variation_first_free",(int) annual_variation_years[annual_variation_years.indexmin()]);
      int last_year=p.get_int(command+"annual_variation_last_free",(int) annual_variation_years[annual_variation_years.indexmax()]);
      if (first_year <annual_variation_years[annual_variation_years.indexmin()] || first_year > annual_variation_years[annual_variation_years.indexmax()]){
         fatal(command + "annual_variation_first_free should be within the range of annual_variation_years");}
      if (last_year <annual_variation_years[annual_variation_years.indexmin()] || last_year > annual_variation_years[annual_variation_years.indexmax()]){
         fatal(command + "annual_variation_last_free should be within the range of annual_variation_years");}
      if(first_year > last_year){
         fatal(command + "annual_variation_first_free should be less than or equal to annual_variation_last_free");}
      annual_variation_bar_val = 0.0;
      for (int k=first_year; k<=last_year; k++){
        annual_variation_bar_val+=annual_variation_values[k];
      }
       annual_variation_bar_val/=(last_year-first_year+1);
      for (int i=annual_variation_values.indexmin(); i<=annual_variation_values.indexmax(); i++){
         (*annual_variation)[i] = annual_variation_values[i];
    }

    std::string randomisation_method = p.get_string(command+"annual_variation_randomisation_method");
    if (randomisation_method=="empirical"){
         randomise_annual_variation = new Empirical_randomiser<DVM>(p,"migration_annual_variation",command,annual_variation_values);
    } else if (randomisation_method=="none"){
    if(simulation) fatal("You cannot use "+command+"annual_variation_randomisation_method  'none' if you are calculating yields");
    randomise_annual_variation = new No_randomiser<DVM>(p,"migration_annual_variation",command,annual_variation_values);
    } else {
    fatal("Unknown "+command+".annual_variation_randomisation_method: " + randomisation_method);
    }
    if (!simulation){
         // normal case - what is the start of the period of stochastic migration annual variation?
       first_random_year = current+1;
    } else if (simulation){
      // This is for stochastic simulation.
        // We need to throw away these annual_variations, now that they have been used to set up the randomisers,
    delete annual_variation;
    initial = p.get_int("initial");
    current = p.get_int("current");
    final = p.get_int("final");
        annual_variation = new VECTOR(initial,final);
    (*annual_variation)=0; //Set to 1 so that they can be used in deterministic simulation
        first_random_year = initial;
    }
   }



   mean_weight = _mean_weight;
   source_chars.resize(1);
   source_vals.resize(1);
   destination_chars.resize(1);
   destination_vals.resize(1);
   int area_char = s.character_numbers("area");
   source_chars[0] = area_char;
   source_vals[0] = source_area;
   destination_chars[0] = area_char;
   destination_vals[0] = destination_area;
   initial_source_abundance = initial_destination_abundance = 0;
   record_virgin_abundance = 0;
}

template<CDVM>
Density_dependence<DVM>::~Density_dependence(){
  DEBUG1("~Density_dependence");
  if(annual_variation !=0) delete annual_variation;
  if(randomise_annual_variation!=0) delete randomise_annual_variation;
}
// ########################### MATURATION (IN THE PARTITION) ############################
template<CDVM>
int Basic_partition_maturity<DVM>::apply(Basic_state<DVM>& s, int year){
  // Apply maturation to the partition of s in year. For each i, each
  // maturation_rates[i][j] is the proportion of fish moving from
  // partition[source_rows[i]][j] to partition[destination_rows[i]][j]. Return 1.
  DEBUG1("Basic_partition_maturity::apply");
  for (int i=0; i<source_rows.size(); i++){
    s.move(maturation_rates[i],source_rows[i],destination_rows[i]);
  }
  return 1;
}

template<CDVM>
void Basic_partition_maturity<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Basic_partition_maturity::print");
  out << "  rates of maturation:\n";
  if (stock>0){
    out << "  for stock " << s.stock_names[stock] << '\n';}
  if (area>0){
    out << "  for area " << s.area_names[area] << '\n';}
  for (int i=0; i<source_rows.size(); i++){
    out << "  proportions ";
    out << maturation_rates[i];
    out << " of fish from row " << source_rows[i] << " to row " << destination_rows[i] << "\n";
  }
  out << '\n';
};

template<CDVM>
VECTOR Basic_partition_maturity<DVM>::get(Basic_state<DVM>& s, int sex, std::string stock){
        // kick out the maturation-probability-at-age vector
        // for the specified sex (ignored if an unsexed model)
        // and the specified stock (ignored if a single-stock model)
        // get(s,sex,stock)[a] = proportion of fish of age a which will mature.
        // Only to be used by the age-at-maturity observations type!
    int stock_char = s.character_numbers("stock");
    int stock_no;
    if (stock=="" || s.n_stocks==1) stock_no=-1;
    else {
        if (!s.valid_stock(stock)){
                fatal("You entered the invalid stock " + stock + " in an age-at-maturity block");}
        stock_no=s.stock_numbers[stock];
        }
        int sex_char = s.character_numbers("sex");
        int found_row = 0;
        VECTOR result(s.col_min, s.col_max);
        for (int i=0; i<source_rows.size(); i++){
                int this_row = source_rows[i];
                int stock_match = 0, sex_match = 0;
                if (s.n_stocks==1) stock_match=1;
                else if (s.character_value(this_row,stock_char)==stock_no) stock_match = 1;
                if (s.sex_partition==0 || sex==-1) sex_match = 1;
                else if (s.character_value(this_row,sex_char)==sex) sex_match = 1;
                if (stock_match && sex_match){
                        // this row matches the stock and sex criteria, if they apply
                        if (!found_row){
                                // this is the first such row we are encountering
                                result = maturation_rates[i];
                                found_row = 1;
                        } else if (found_row){
                                // there is more than 1 such row - check that they have the same maturation rates, otherwise ambiguous
                                for (int j=s.col_min; j<=s.col_max; j++){
                                        if (maturation_rates[i][j] != result[j]){
                                                fatal("Fatal error in Basic_partition_maturity<DVM>::get: more than one rows match criteria. Have you asked for unsexed age-at-maturation observations in a sexed model where maturation depends on sex? This is illegal.");
                                        }
                                }
                        }
                }
        }
        if (!found_row){
                fatal("Fatal error in Basic_partition_maturity<DVM>::get: no rows match");}
        return result;
}

template<CDVM>
Basic_partition_maturity<DVM>::Basic_partition_maturity(Parameter_set<DVM>& p, Basic_state<DVM>& s,
                                                      int step, int i,
                                                      Size_at_age<DVM>* size_at_age){
  // Construct maturation process 'i' from p, s, and step.
  DEBUG1("Basic_partition_maturity::Basic_partition_maturity");
  std::string command = "maturation[" + itos(i) + "].";
  if (s.n_stocks<=1) stock=-1;
  else {
    std::string stock_name = p.get_string(command+"stock","");
    if (!s.valid_stock(stock_name)){
      fatal("You entered the invalid stock " + stock_name + " in maturation block number " + itos(i));}
    stock=s.stock_numbers[stock_name];
  }
  std::string area_name = p.get_string(command+"area","");
  if (area_name=="") area = -1;
  else{
    if (!s.valid_area(area_name)){
      fatal("Bad area name " + area_name + " in @maturation block");}
    area = s.area_numbers[area_name];
  }
  int sexed, ogive_size_based;
  int stock_char = s.character_numbers("stock");
  int area_char = s.character_numbers("area");
  if (p.present(command+"rates_male")){
    sexed = 1;
    ogive_size_based = p.get_ogive_base(command+"rates_male") || p.get_ogive_base(command+"rates_female");
  } else {
    sexed = 0;
    ogive_size_based = p.get_ogive_base(command+"rates_all");
  }
  if (ogive_size_based && !s.size_based && size_at_age->varies_between_years()){
    fatal("You may not specify size-based maturation ogives in an age-based model when size-at-age varies between years.");}
  int sex_char = s.character_numbers("sex");
  int maturity_char = s.character_numbers("maturity");
  dvector source(1,1), destination(1,1);
  for (int j=1; j<=s.n_rows; j++){
    if (s.n_stocks>1 && stock>0){
      if (s.character_value(j,stock_char)!=stock) continue;}
    if (s.n_areas>1 && area>0){
      if (s.character_value(j,area_char)!=area) continue;}
    if (s.character_value(j,maturity_char)==1){
      source[1] = j;
      destination = s.corresponding_rows(source,maturity_char,2);
      if (destination[1] != 0){
        source_rows.push_back(j);
        destination_rows.push_back((int)(destination[1]));
        if (sexed){
          if (s.character_value(j,sex_char)==1){
            maturation_rates.push_back(p.get_ogive_values(command+"rates_male",size_at_age,0,step,j));
          } else {
            maturation_rates.push_back(p.get_ogive_values(command+"rates_female",size_at_age,0,step,j));
          }
        } else {
          maturation_rates.push_back(p.get_ogive_values(command+"rates_all",size_at_age,0,step,j));
        }
        if (sum(maturation_rates[maturation_rates.size()-1])<0.1) cerr<<"Warning: Very low maturation rates - is this intended?\n";
      } else cout << "Some parts of the partition can only contain immature fish. If immature fish are here during maturation, they cannot be matured. You can safely proceed providing you have made sure there are never immature fish in these parts of the partition during maturation.\n";
    }
  }
}

//########################## GROWTH (IN AN AGE-BASED MODEL) ##########################
template<CDVM>
void Size_at_age<DVM>::set_time(int _year, int _step){
  // Set year and step. This should be called at the start of each time step,
  // it is in the basic model.
  DEBUG2("Size_at_age::set_time");
  year = _year;
  step = _step;
}

template<CDVM>
MATRIX Size_at_age<DVM>::get_size_dist(int row, const int _plus_group, const dvector& _class_mins){
  // Return the current size/age distribution of fish in 'row' of the partition.
  // size_dist(i)[c][j] = P(class_mins[c] < size < class_mins[c+1])
  // where size is distributed with mean get_mean_sizes(row)[j] and
  // c.v. cv_by_row[i], normally if dist=="normal" and lognormally if "lognormal".
  // Except for the last size class if plus_group==1, in which case it's P(...< infinity).
  // If _plus_group and _class_mins are supplied as arguments, use
  // them instead of the default values.
  // Updated to modify the cv/sd for cv's/sd's distributed by length rather than age
  DEBUG2("Size_at_age::get_size_dist");
  VECTOR means(get_mean_sizes(row));
  dvector use_class_mins(_class_mins.size()==1 && _class_mins[1]==-1 ? class_mins : _class_mins);
  int use_plus_group = (_plus_group==-1 ? plus_group : _plus_group);
  int first_class = use_class_mins.indexmin();
  int last_class = use_class_mins.indexmax() - (use_plus_group ? 0 : 1);
  MATRIX result(first_class,last_class,col_min,col_max);
  VECTOR cvs(cv_by_element[row]);
  if (dist=="none"){
    fatal("CASAL needs more information to calculate the size distribution of fish. Set @size_at_age_dist to normal or lognormal and provide cvs or standard deviations.");}
  VECTOR temp=cvs;
  if(cvs_by_length) { // cvs are actually defined by length, not age. Hence need to re-calcuate the cvs
    for (int i=col_min; i<=col_min; i++){
      temp[i]=(means[i]-means[col_min])*(cvs[cvs.size()]-cvs[col_min])/(means[means.size()]-means[col_min]) + cvs[col_min];
      if(temp[i]<0) temp[i]=0;
    }
  }
  for (int j = col_min; j<=col_max; j++){
    DOUBLE cv = temp[j];
    if (cvs_actually_stdevs){
    // this is really a standard deviation, convert it to a cv
      cv /= means[j];}
    result.colfill(j,distribution<DVM>(use_class_mins, use_plus_group, dist, means[j], cv*means[j]));
  }
  return result;
}

template<CDVM>
MATRIX Size_at_age<DVM>::get_size_dist_at(int _year, int _step, int row,
                                          const int _plus_group, const dvector& _class_mins){
  // Return size distribution of fish in 'row' of the partition in '_step'.
  // '_year' is ignored.
  // See ::get_size_dist.
  DEBUG2("Size_at_age::get_size_dist_at");
  VECTOR means(get_mean_sizes_at(_year,_step,row));
  dvector use_class_mins(_class_mins.size()==1 && _class_mins[1]==-1 ? class_mins : _class_mins);
  int use_plus_group = (_plus_group==-1 ? plus_group : _plus_group);
  int first_class = use_class_mins.indexmin();
  int last_class = use_class_mins.indexmax() - (use_plus_group ? 0 : 1);
  MATRIX result(first_class,last_class,col_min,col_max);
  VECTOR cvs(cv_by_element[row]);
  if (dist=="none"){
    fatal("CASAL needs more information to calculate the size distribution of fish. Set @size_at_age_dist to normal or lognormal and provide cvs or standard deviations.");}
  VECTOR temp=cvs;
  if(cvs_by_length) { // cvs are actually defined by length, not age. Hence need to re-calcuate the cvs
    for (int i=col_min; i<=col_max; i++){
      temp[i]=(means[i]-means[col_min])*(cvs[cvs.size()]-cvs[col_min])/(means[means.size()]-means[col_min]) + cvs[col_min];
      if(temp[i]<0) temp[i]=0;
    }
  }
  for (int j = col_min; j<=col_max; j++){
    DOUBLE cv = temp[j];
    if (cvs_actually_stdevs){
    // this is really a standard deviation, convert it to a cv
      cv /= means[j];}
    result.colfill(j,distribution<DVM>(use_class_mins, use_plus_group, dist, means[j], cv*means[j]));
  }
  return result;
}

template<CDVM>
MATRIX Size_at_age<DVM>::get_all_cvs(){
  // May actually be standard deviations, depending on the value of cvs_actually_stdevs
  DEBUG2("Size_at_age::get_all_cvs");
  return cv_by_element;
}

template<CDVM>
std::string Size_at_age<DVM>::get_dist(){
  // get_dist() = "normal", "lognormal", or "none"
  DEBUG2("Size_at_age::get_dist");
  return dist;
}

template<CDVM>
DOUBLE Size_at_age<DVM>::get_pdf(int year, int step, int row, int age, double size){
  // at the specified time, figure the pdf of the size-at-age
  // distribution for partition element [row,age]
  // DEBUG2("Size_at_age::get_pdf"); - too much output
  DOUBLE x = size;
  DOUBLE mean_size = get_mean_sizes_at(year,step,row)[age];
  DOUBLE cv = get_all_cvs()[row][age];
  if(cvs_by_length) {
    // cvs actually specified by length .. need to convert them
    VECTOR mean_sizes = get_mean_sizes_at(year,step,row);
    VECTOR cvs = get_all_cvs()[row];
    VECTOR temp=cvs;
    for (int i=col_min; i<=col_max; i++){
      temp[i]=(mean_sizes[i]-mean_sizes[col_min])*(cvs[cvs.size()]-cvs[col_min])/(mean_sizes[mean_sizes.size()]-mean_sizes[col_min]) + cvs[col_min];
      if(temp[i]<0) temp[i]=0;
    }
    cv=temp[age];
  }
  if (cvs_actually_stdevs){
    // this is really a standard deviation, get the cv
    cv /= mean_size;}
  if (dist=="none"){
    fatal("You have asked for the pdf of the size-at-age distribution but no distribution was specified");
  } else if (dist=="normal"){
    DOUBLE stdev = mean_size*cv;
    return dnorm(x,mean_size,stdev);
  } else if (dist=="lognormal"){
    DOUBLE sigma = sqrt(log(1+cv*cv));
    DOUBLE mu = log(mean_size) - sigma*sigma*0.5;
    return dlognorm(x,mu,sigma);
  }
}

template<CDVM>
VECTOR Size_at_age<DVM>::get_cdf_inverse(int year, int step, int row, int age, dvector &quantiles){
  // at the specified time, figure the inverse cdf of the size-at-age
  // distribution for partition element [row,age]
  // used by get_pdf_with_sizebased_sel
  // DEBUG2("Size_at_age::get_cdf_inverse"); - too much output
  DOUBLE mean_size = get_mean_sizes_at(year,step,row)[age];
  DOUBLE cv = get_all_cvs()[row][age];
  if(cvs_by_length) {
    // cvs actually specified by length .. need to convert them
    VECTOR mean_sizes = get_mean_sizes_at(year,step,row);
    VECTOR cvs = get_all_cvs()[row];
    VECTOR temp=cvs;
    for (int i=col_min; i<=col_max; i++){
      temp[i]=(mean_sizes[i]-mean_sizes[col_min])*(cvs[cvs.size()]-cvs[col_min])/(mean_sizes[mean_sizes.size()]-mean_sizes[col_min]) + cvs[col_min];
      if(temp[i]<0) temp[i]=0;
    }
    cv=temp[age];
  }
  if (cvs_actually_stdevs){
    // this is really a standard deviation, get the cv
    cv /= mean_size;}
  VECTOR inverse(quantiles.indexmin(),quantiles.indexmax());
  for (int i=quantiles.indexmin(); i<=quantiles.indexmax(); i++){
    DOUBLE q = quantiles[i];
    if (dist=="normal"){
      DOUBLE stdev = mean_size*cv;
      inverse[i] = qnorm(q,mean_size,stdev);
    } else if (dist=="lognormal"){
      DOUBLE sigma = sqrt(log(1+cv*cv));
      DOUBLE mu = log(mean_size) - sigma*sigma*0.5;
      inverse[i] = qlognorm(q,mu,sigma);
    }
  }
  return inverse;
}

template<CDVM>
DOUBLE Size_at_age<DVM>::get_pdf_with_sizebased_sel(int year, int step, int row, int age, double size, Selectivity<DVM>* selectivity){
  // at the specified time, figure the pdf of the size-at-age
  // distribution for partition element [row,age]
  //
  // The pdf is modified by a size-based selectivity.
  // f_new(size) = Sel(size)f_old(size) / integral_over_size=s of Sel(s)f_old(s).
  // We approximate the integral by a discrete approximation over 5 appropriately spaced points.
  //
  // DEBUG2("Size_at_age::get_pdf_with_sizebased_sel"); - too much output
  DOUBLE num=get_pdf(year,step,row,age,size) * selectivity->get_val_by_size_in_agebased(year,step,row,size);
  if (num==0) return 0;
  dvector quantiles(1,5);
  quantiles[1]=0.1;
  quantiles[2]=0.3;
  quantiles[3]=0.5;
  quantiles[4]=0.7;
  quantiles[5]=0.9;
  VECTOR size_points = get_cdf_inverse(year,step,row,age,quantiles);
  DOUBLE den = 0.2*(
         selectivity->get_val_by_size_in_agebased(year,step,row,size_points[1])+
         selectivity->get_val_by_size_in_agebased(year,step,row,size_points[2])+
         selectivity->get_val_by_size_in_agebased(year,step,row,size_points[3])+
         selectivity->get_val_by_size_in_agebased(year,step,row,size_points[4])+
         selectivity->get_val_by_size_in_agebased(year,step,row,size_points[5])
  );
  return num/den;
}

template<CDVM>
void Size_at_age<DVM>::print_every_mean_size(Basic_state<DVM>&s, ostream& out){
  DEBUG2("Size_at_age::print_every_mean_size");
  // Not something you'd want to do often, but good for checking that your
  // size-at-age section is doing exactly what you want it to.
  dmatrix mean_mat(1,s.n_rows,s.col_min,s.col_max);
  for (int year=initial; year<=final; year++){
          out << "*** Year " << year << " ***\n\n";
          for (int step=1; step<=time_steps; step++){
                out << "* Step " << step << " *\n";
                for (int row=1; row<=s.n_rows; row++){
                        mean_mat[row] = value(get_mean_sizes_at(year,step,row));
                }
                s.print_matrix(out,mean_mat);
          }
  }
}

template<CDVM>
Size_at_age<DVM>::Size_at_age(Parameter_set<DVM>& p, Basic_state<DVM>& s)
  : cv_by_element(1,s.n_rows,s.col_min,s.col_max)
  , class_mins(p.get_constant_vector("class_mins",dvector("{-1}"))){
  DEBUG1("Size_at_age::Size_at_age");
  initial = p.get_int("initial");
  current = p.get_int("current");
  final = p.get_int("final");
  time_steps = p.get_int("annual_cycle.time_steps");
}

template<CDVM>
VECTOR Size_at_age_years_same<DVM>::get_mean_sizes(int row){
  // Return current mean sizes of fish in 'row' of the partition, which are in
  // mean_sizes[mean_size_entry_by_step[step]][row]
  DEBUG2("Size_at_age_years_same::get_mean_sizes");
  return mean_sizes[(int)(mean_size_entry_by_step[this->step])][row];
}

template<CDVM>
VECTOR Size_at_age_years_same<DVM>::get_mean_sizes_at(int _year, int _step, int row){
  // Return mean sizes of fish in 'row' of the partition in '_step'.
  // '_year' is ignored.
  // See ::get_mean_sizes.
  DEBUG2("Size_at_age_years_same::get_mean_sizes_at");
  return mean_sizes[(int)(mean_size_entry_by_step[_step])][row];
}

template<CDVM>
void Size_at_age_years_same<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Size_at_age_years_same::print");
  int i=1;
  while (i<=mean_size_entry_by_step.indexmax()){
    out << "  Time step " << i;
    while (i<mean_size_entry_by_step.indexmax() &&
           mean_size_entry_by_step[i+1]==mean_size_entry_by_step[i]){
      i++;
      out << " " << i;
    }
    out << ": mean sizes = \n";
    s.print_matrix(out,mean_sizes[(int)(mean_size_entry_by_step[i])]);
    i++;
    out << '\n';
  }
  if(this->cvs_by_length) {
    if (this->dist=="normal"){
      out << "  Sizes-at-age are normally distributed with " << (this->cvs_actually_stdevs?"standard deviations":"c.v.s") << " defined as a linear function of mean length.\n";
    } else if (this->dist=="lognormal"){
      out << "  Sizes-at-age are lognormally distributed with " << (this->cvs_actually_stdevs?"standard deviations":"c.v.s") << " defined as a linear function of mean length.\n";
    }
  } else if (!(this->cvs_actually_stdevs)){
    if (this->dist=="normal"){
      out << "  Sizes-at-age are normally distributed with c.v.s as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    } else if (this->dist=="lognormal"){
      out << "  Sizes-at-age are lognormally distributed with c.v.s as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    }
  } else {
    if (this->dist=="normal"){
      out << "  Sizes-at-age are normally distributed with standard deviations as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    } else if (this->dist=="lognormal"){
      out << "  Sizes-at-age are lognormally distributed with standard deviations as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    }
  }
};

template<CDVM>
Size_at_age_years_same<DVM>::Size_at_age_years_same(Parameter_set<DVM>& p,Basic_state<DVM>& s,
                                                    const dvector& _growth_props)
  : Size_at_age<DVM>(p,s)
  , growth_props(_growth_props)
  , mean_size_entry_by_step(1,_growth_props.size())
  , curve_by_row(1,s.n_rows){
  // Construct the size-at-age object from p and s.
  DEBUG1("Size_at_age_years_same::Size_at_age_years_same");
  this->type = "years_same";
  this->col_min = s.col_min;
  this->col_max = s.col_max;
  // Extract the growth curve parameters and make the growth curve objects
  // and figure which rows of the partition use which growth curves
  get_growth_curves(p,s,growth_curves,curve_by_row);
  // Now fill in the mean-sizes-by-age-and-step object;
  MATRIX entry(1,s.n_rows,s.col_min,s.col_max);
  int entry_no = 0;
  int done;
  for (int step=1; step<=growth_props.size(); step++){
    done = 0;
    if (step>1){
      if (growth_props[step-1]==growth_props[step]){
        mean_size_entry_by_step[step] = entry_no-1;
        done = 1;
      }
    }
    if (!done) {
      for (int i=1; i<=s.n_rows; i++){
        for (int j=s.col_min; j<=s.col_max; j++){
          entry[i][j] = growth_curves[(int)(curve_by_row[i])]->mean_size(j+growth_props[step]);
        }
      }
      mean_sizes.push_back(entry);
      mean_size_entry_by_step[step] = entry_no;
      entry_no++;
    }
  }
  // And, optionally, set up distributions of size at age.
  get_size_at_age_dist(p,s,this->dist,this->plus_group,this->cv_by_element,this->cvs_actually_stdevs,this->any_nonpositive_cvs,this->cvs_by_length);
}

template<CDVM>
void get_size_at_age_dist(Parameter_set<DVM>& p,Basic_state<DVM>& s, std::string& dist,
                          int& plus_group, MATRIX& cv_by_element,
                          int& cvs_actually_stdevs, int& any_nonpositive_cvs,
                          int& cvs_by_length){
  // This function is called by size-at-age object constructors;
  // it extracts distributions of size at age from the parameter file.
  // The results are passed back via the last five arguments.
  DEBUG1("get_size_at_age_dist");
  int sex_char = s.character_numbers("sex");
  int stock_char = s.character_numbers("stock");
  int growthpath_char = s.character_numbers("growthpath");
  if (p.present("size_at_age_dist")){
    dist = p.get_string("size_at_age_dist");
    if (dist != "normal" && dist != "lognormal"){
      fatal("size_at_age_dist should be 'normal', 'lognormal', or omitted");}
    plus_group = s.plus_group;
    std::string command;
    int by_stock;
    if (s.n_stocks == 1) by_stock = 0;
    else by_stock = (p.get_command_count("size_at_age")>1);
    for (int stock=1; stock<=s.n_stocks; stock++){
      if (by_stock) command = "size_at_age[" + s.stock_names[stock] +"].";
      else command = "size_at_age.";
      // is the variation in cvs by length, not age?. If so, carry on as normal, but correct the actual cvs/sds
      // when extracting with get_size_dist and get_size_dist_at (where we know about the mean_sizes)
      cvs_by_length=p.get_bool(command+"by_length",0);
      if (p.present(command + "cv_male")){
        // c.v.s are specified by sex, but do not vary between age classes
        cvs_actually_stdevs = 0;
        if (sex_char==-1){
          fatal("You have specified c.v.s of length-at-age by sex, but this is an unsexed model");}
        VECTOR cv_male(p.get_estimable_vector(command+"cv_male"));
        VECTOR cv_female(p.get_estimable_vector(command+"cv_female"));
        if (cv_male.size()!=s.n_growthpaths) fatal("Size-at-age subcommand cv_male is the wrong size, should be "+itos(s.n_growthpaths));
        if (cv_female.size()!=s.n_growthpaths) fatal("Size-at-age subcommand cv_female is the wrong size, should be "+itos(s.n_growthpaths));
        for (int path=1; path<=s.n_growthpaths; path++){
          // one cv per growth path per sex
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            if (s.character_value(i,sex_char)==1) cv_by_element[i]=cv_male[path];
            else if (s.character_value(i,sex_char)==2) cv_by_element[i]=cv_female[path];
          }
        }
      } else if (p.present(command + "cv")){
        // c.v.s do not vary between sexes or age classes
        cvs_actually_stdevs = 0;
        VECTOR cv(p.get_estimable_vector(command+"cv"));
        if (cv.size()!=s.n_growthpaths) fatal("Size-at-age subcommand cv is the wrong size, should be "+itos(s.n_growthpaths));
        for (int path=1; path<=s.n_growthpaths; path++){
          // one cv per growth path
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            cv_by_element[i]=cv[path];
          }
        }
      } else if (p.present(command + "cv1")){
        // c.v.s vary between age classes but do not depend on sex
        cvs_actually_stdevs = 0;
        VECTOR cv1(p.get_estimable_vector(command+"cv1"));
        VECTOR cv2(p.get_estimable_vector(command+"cv2"));
        if (cv1.size()!=s.n_growthpaths && cv1.size()!=1) fatal("Size-at-age subcommand cv1 is the wrong size, should be "+itos(s.n_growthpaths)+(s.n_growthpaths==1 ? "" : "or 1"));
        else if (cv2.size()!=cv1.size()) fatal("Size-at-age subcommand cv2 is the wrong size, should be the same as cv1");
        int same_for_all_growthpaths = 0;
        if (s.n_growthpaths > 1 && cv1.size() == 1){
                        same_for_all_growthpaths = 1;}
        for (int path=1; path<=s.n_growthpaths; path++){
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            if (same_for_all_growthpaths){
                                cv_by_element[i]=stretch<DVM>(cv1[1],cv2[1],s.col_min,s.col_max);
                        } else {
                                cv_by_element[i]=stretch<DVM>(cv1[path],cv2[path],s.col_min,s.col_max);
                        }
          }
        }
          } else if (p.present(command + "cv1_male")){
        // c.v.s vary between age classes and sexes
        cvs_actually_stdevs = 0;
        if (sex_char==-1){
          fatal("You have specified c.v.s of length-at-age by sex, but this is an unsexed model");}
        VECTOR cv1_male(p.get_estimable_vector(command+"cv1_male"));
        VECTOR cv2_male(p.get_estimable_vector(command+"cv2_male"));
        VECTOR cv1_female(p.get_estimable_vector(command+"cv1_female"));
        VECTOR cv2_female(p.get_estimable_vector(command+"cv2_female"));
        if (cv1_male.size()!=s.n_growthpaths && cv1_male.size()!=1) fatal("Size-at-age subcommand cv1_male is the wrong size, should be "+itos(s.n_growthpaths)+(s.n_growthpaths==1 ? "" : "or 1"));
        else if (cv2_male.size()!=cv1_male.size()) fatal("Size-at-age subcommand cv2_male is the wrong size, should be the same as cv1_male");
        else if (cv1_female.size()!=cv1_male.size()) fatal("Size-at-age subcommand cv1_female is the wrong size, should be the same as cv1_male");
        else if (cv2_female.size()!=cv1_male.size()) fatal("Size-at-age subcommand cv2_female is the wrong size, should be the same as cv1_male");
        int same_for_all_growthpaths = 0;
        if (s.n_growthpaths > 1 && cv1_male.size() == 1){
                        same_for_all_growthpaths = 1;}
        for (int path=1; path<=s.n_growthpaths; path++){
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            if (same_for_all_growthpaths){
                                if (s.character_value(i,sex_char)==1){
                                        cv_by_element[i]=stretch<DVM>(cv1_male[1],cv2_male[1],s.col_min,s.col_max);
                                } else if (s.character_value(i,sex_char)==2){
                                        cv_by_element[i]=stretch<DVM>(cv1_female[1],cv2_female[1],s.col_min,s.col_max);
                                }
                        } else {
                                if (s.character_value(i,sex_char)==1){
                                        cv_by_element[i]=stretch<DVM>(cv1_male[path],cv2_male[path],s.col_min,s.col_max);
                                } else if (s.character_value(i,sex_char)==2){
                                        cv_by_element[i]=stretch<DVM>(cv1_female[path],cv2_female[path],s.col_min,s.col_max);
                                }
                        }
          }
        }
          } else if (p.present(command + "sd1")){
        // variation is expressed in terms of standard deviation
        // s.d.s vary between age classes but do not depend on sex
        cvs_actually_stdevs = 1;
        VECTOR sd1(p.get_estimable_vector(command+"sd1"));
        VECTOR sd2(p.get_estimable_vector(command+"sd2"));
        if (sd1.size()!=s.n_growthpaths && sd1.size()!=1) fatal("Size-at-age subcommand sd1 is the wrong size, should be "+itos(s.n_growthpaths)+(s.n_growthpaths==1 ? "" : "or 1"));
        else if (sd2.size()!=sd1.size()) fatal("Size-at-age subcommand sd2 is the wrong size, should be the same as sd1");
        int same_for_all_growthpaths = 0;
        if (s.n_growthpaths > 1 && sd1.size() == 1){
                        same_for_all_growthpaths = 1;}
        for (int path=1; path<=s.n_growthpaths; path++){
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            if (same_for_all_growthpaths){
                                cv_by_element[i]=stretch<DVM>(sd1[1],sd2[1],s.col_min,s.col_max);
                        } else {
                                cv_by_element[i]=stretch<DVM>(sd1[path],sd2[path],s.col_min,s.col_max);
                        }
          }
        }
          } else if (p.present(command + "sd1_male")){
        // variation is expressed in terms of standard deviation
        // s.d.s vary between age classes and sexes
        cvs_actually_stdevs = 1;
        VECTOR sd1_male(p.get_estimable_vector(command+"sd1_male"));
        VECTOR sd2_male(p.get_estimable_vector(command+"sd2_male"));
        VECTOR sd1_female(p.get_estimable_vector(command+"sd1_female"));
        VECTOR sd2_female(p.get_estimable_vector(command+"sd2_female"));
        if (sd1_male.size()!=s.n_growthpaths && sd1_male.size()!=1) fatal("Size-at-age subcommand sd1_male is the wrong size, should be "+itos(s.n_growthpaths)+(s.n_growthpaths==1 ? "" : "or 1"));
        else if (sd2_male.size()!=sd1_male.size()) fatal("Size-at-age subcommand sd2_male is the wrong size, should be the same as sd1_male");
        else if (sd1_female.size()!=sd1_male.size()) fatal("Size-at-age subcommand sd1_female is the wrong size, should be the same as sd1_male");
        else if (sd2_female.size()!=sd1_male.size()) fatal("Size-at-age subcommand sd2_female is the wrong size, should be the same as sd1_male");
        int same_for_all_growthpaths = 0;
        if (s.n_growthpaths > 1 && sd1_male.size() == 1){
                        same_for_all_growthpaths = 1;}
        for (int path=1; path<=s.n_growthpaths; path++){
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            if (same_for_all_growthpaths){
                                if (s.character_value(i,sex_char)==1){
                                        cv_by_element[i]=stretch<DVM>(sd1_male[1],sd2_male[1],s.col_min,s.col_max);
                                } else if (s.character_value(i,sex_char)==2){
                                        cv_by_element[i]=stretch<DVM>(sd1_female[1],sd2_female[1],s.col_min,s.col_max);
                                }
                        } else {
                                if (s.character_value(i,sex_char)==1){
                                        cv_by_element[i]=stretch<DVM>(sd1_male[path],sd2_male[path],s.col_min,s.col_max);
                                } else if (s.character_value(i,sex_char)==2){
                                        cv_by_element[i]=stretch<DVM>(sd1_female[path],sd2_female[path],s.col_min,s.col_max);
                                }
                        }
          }
        }
          } else {
                  fatal("CASAL has not found a valid specification of cvs or sds of size-at-age for "+command+".");
          }
    }
  } else dist = "none";
  DOUBLE min_cv = 1;
  for (int i=1; i<s.n_rows; i++){
          for (int j=s.col_min; j<=s.col_max; j++){
                  if (cv_by_element[i][j] < min_cv){
                          min_cv = cv_by_element[i][j];
                  }
          }
  }
  if (min_cv<=0) any_nonpositive_cvs = 1;
  else any_nonpositive_cvs = 0;
}

template<CDVM>
VECTOR stretch(DOUBLE v1, DOUBLE v2, int n1, int n2){
  VECTOR result(n1,n2);
  for (int i=n1; i<=n2; i++){
    result[i] = v1 + (v2-v1)*((double)(i-n1))/((double)(n2-n1));
  }
  return result;
}

template<CDVM>
void get_growth_curves(Parameter_set<DVM>& p,Basic_state<DVM>& s, std::vector<Growth_curve<DVM>*>& growth_curves, dvector& curve_by_row){
  // This function is called by constructors of methods of Size_at_age;
  // it extracts growth curves from the parameter file,
  // and for each row of the partition, specifies which growth curve it uses.
  DEBUG1("get_growth_curves");
  growth_curves.push_back(0); // dummy entry
  int sex_char = s.character_numbers("sex");
  int stock_char = s.character_numbers("stock");
  int growthpath_char = s.character_numbers("growthpath");
  int tag_char = s.character_numbers("tag");
  int tags_stunt_growth = 0;
  if (p.get_command_count("tag_growth_loss")>0) tags_stunt_growth = 1;
  vector<DOUBLE> stunt_periods;
  stunt_periods.resize(s.n_tag_states+1);
  if (tags_stunt_growth){
    for (int i=1; i<=s.n_tag_states; i++){
      stunt_periods[i] = p.get_estimable("tag_growth_loss["+s.tag_names[i]+"].nogrowth_period",0);
    }
  }

  std::string command;
  int count=1;
  std::string type = p.get_string("size_at_age_type");
  int by_stock;
  if (s.n_stocks == 1) by_stock = 0;
  else by_stock = (p.get_command_count("size_at_age")>1);
  for (int stock=1; stock<=s.n_stocks; stock++){
    if (by_stock) command = "size_at_age[" + s.stock_names[stock] +"].";
    else command = "size_at_age.";
    if (type=="von_Bert"){
      // von Bert mean-size-at-age
      if (p.present(command+"k_male")){
        VECTOR k_male(p.get_estimable_vector(command+"k_male"));
        VECTOR t0_male(p.get_estimable_vector(command+"t0_male"));
        VECTOR Linf_male(p.get_estimable_vector(command+"Linf_male"));
        VECTOR k_female(p.get_estimable_vector(command+"k_female"));
        VECTOR t0_female(p.get_estimable_vector(command+"t0_female"));
        VECTOR Linf_female(p.get_estimable_vector(command+"Linf_female"));
        for (int path=1; path<=s.n_growthpaths; path++){
                 for (int tag_state=1; tag_state<=(tags_stunt_growth?s.n_tag_states:1); tag_state++){
          // one curve per growth path per sex, and per tag if tags_stunt_growth=1
          DOUBLE stunt_period = tags_stunt_growth ? stunt_periods[tag_state] : 0;
          growth_curves.push_back(new von_Bert<DVM>(k_male.size()==1    ? k_male[1]    : k_male[path],
                                                    (t0_male.size()==1   ? t0_male[1]   : t0_male[path])+stunt_period,
                                                    Linf_male.size()==1 ? Linf_male[1] : Linf_male[path]));
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            if (tag_char!=-1 && tags_stunt_growth){
              if (s.character_value(i,tag_char)!=tag_state) continue;}
            if (s.character_value(i,sex_char)==1) curve_by_row[i]=count;
          }
          count++;
          growth_curves.push_back(new von_Bert<DVM>(
                               k_female.size()==1    ? k_female[1]    : k_female[path],
                               (t0_female.size()==1   ? t0_female[1]   : t0_female[path])+stunt_period,
                               Linf_female.size()==1 ? Linf_female[1] : Linf_female[path]));
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            if (tag_char!=-1 && tags_stunt_growth){
              if (s.character_value(i,tag_char)!=tag_state) continue;}
            if (s.character_value(i,sex_char)==2) curve_by_row[i]=count;
          }
          count++;
             }
        }
      } else {
        VECTOR k(p.get_estimable_vector(command+"k"));
        VECTOR t0(p.get_estimable_vector(command+"t0"));
        VECTOR Linf(p.get_estimable_vector(command+"Linf"));
        for (int path=1; path<=s.n_growthpaths; path++){
                 for (int tag_state=1; tag_state<=(tags_stunt_growth?s.n_tag_states:1); tag_state++){
          // one curve per growth path, and per tag state if tags_stunt_growth=1
          DOUBLE stunt_period = tags_stunt_growth ? stunt_periods[tag_state] : 0;
          growth_curves.push_back(new von_Bert<DVM>
                                  (k.size()==1    ? k[1]    : k[path],
                                   (t0.size()==1   ? t0[1]   : t0[path])+stunt_period,
                                   Linf.size()==1 ? Linf[1] : Linf[path]));
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            if (tag_char!=-1 && tags_stunt_growth){
              if (s.character_value(i,tag_char)!=tag_state) continue;}
            curve_by_row[i]=count;
          }
          count++;
             }
        }
      }
    } else if (type=="Schnute"){
      // Schnute mean-size-at-age
      if (tags_stunt_growth) fatal("Tagging growth loss (@tag_growth_loss) can only be used with a von Bertalanffy growth curve");
      if (p.present(command+"y1_male")){
        VECTOR y1_male(p.get_estimable_vector(command+"y1_male"));
        VECTOR y2_male(p.get_estimable_vector(command+"y2_male"));
        VECTOR a_male(p.get_estimable_vector(command+"a_male"));
        VECTOR b_male(p.get_estimable_vector(command+"b_male"));
        VECTOR tau1_male(p.get_estimable_vector(command+"tau1_male"));
        VECTOR tau2_male(p.get_estimable_vector(command+"tau2_male"));
        VECTOR y1_female(p.get_estimable_vector(command+"y1_female"));
        VECTOR y2_female(p.get_estimable_vector(command+"y2_female"));
        VECTOR a_female(p.get_estimable_vector(command+"a_female"));
        VECTOR b_female(p.get_estimable_vector(command+"b_female"));
        VECTOR tau1_female(p.get_estimable_vector(command+"tau1_female"));
        VECTOR tau2_female(p.get_estimable_vector(command+"tau2_female"));
        for (int path=1; path<=s.n_growthpaths; path++){
          // one curve per growth path per sex
          growth_curves.push_back(new Schnute<DVM>(y1_male.size()==1   ? y1_male[1]   : y1_male[path],
                                                   y2_male.size()==1   ? y2_male[1]   : y2_male[path],
                                                   a_male.size()==1    ? a_male[1]    : a_male[path],
                                                   b_male.size()==1    ? b_male[1]    : b_male[path],
                                                   tau1_male.size()==1 ? tau1_male[1] : tau1_male[path],
                                                   tau2_male.size()==1 ? tau2_male[1] : tau2_male[path]));
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            curve_by_row[i]=count;
          }
          count++;
          growth_curves.push_back(new Schnute<DVM>(
                                            y1_female.size()==1   ? y1_female[1]   : y1_female[path],
                                            y2_female.size()==1   ? y2_female[1]   : y2_female[path],
                                            a_female.size()==1    ? a_female[1]    : a_female[path],
                                            b_female.size()==1    ? b_female[1]    : b_female[path],
                                            tau1_female.size()==1 ? tau1_female[1] : tau1_female[path],
                                            tau2_female.size()==1 ? tau2_female[1] : tau2_female[path]));
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            curve_by_row[i]=count;
          }
          count++;
        }
      } else {
        VECTOR y1(p.get_estimable_vector(command+"y1"));
        VECTOR y2(p.get_estimable_vector(command+"y2"));
        VECTOR a(p.get_estimable_vector(command+"a"));
        VECTOR b(p.get_estimable_vector(command+"b"));
        VECTOR tau1(p.get_estimable_vector(command+"tau1"));
        VECTOR tau2(p.get_estimable_vector(command+"tau2"));
        for (int path=1; path<=s.n_growthpaths; path++){
          // one curve per growth path
          growth_curves.push_back(new Schnute<DVM>(y1.size()==1   ? y1[1]   : y1[path],
                                                   y2.size()==1   ? y2[1]   : y2[path],
                                                   a.size()==1    ? a[1]    : a[path],
                                                   b.size()==1    ? b[1]    : b[path],
                                                   tau1.size()==1 ? tau1[1] : tau1[path],
                                                   tau2.size()==1 ? tau2[1] : tau2[path]));
          for (int i=1; i<=s.n_rows; i++){
            if (stock_char!=-1){
              if (s.character_value(i,stock_char)!=stock) continue;}
            if (growthpath_char!=-1){
              if (s.character_value(i,growthpath_char)!=path) continue;}
            curve_by_row[i]=count;
          }
          count++;
        }
      }
    } else fatal("Unknown size-at-age type: " + type);
  }
}

template<CDVM>
Size_at_age_years_same<DVM>::~Size_at_age_years_same(){
  DEBUG2("~Size_at_age_years_same()");
  for (int i=1; i<growth_curves.size(); i++){
    delete growth_curves[i];}
}

template<CDVM>
VECTOR Size_at_age_effective_age<DVM>::get_mean_sizes(int row){
  // Return current mean sizes of fish in row of the partition.
  // get_mean_sizes(row)[j] = growth_curves[curve_by_row[row]]->mean_size(effective_age[step][year][j])
  // except that for all years before the first year covered in effective_age[step],
  //  we use the first row of effective_age[step]
  DEBUG2("Size_at_age_effective_age::get_mean_sizes");
  if (this->year > effective_age[this->step].rowmax()){
    fatal("Size_at_age_effective_age::effective_age does not cover year " + itos(this->year));
  }
  int use_year = this->year;
  if (this->year < effective_age[this->step].rowmin()){
    use_year = effective_age[this->step].rowmin();
  }
  VECTOR mean_sizes(this->col_min,this->col_max);
  for (int j=this->col_min; j<=this->col_max; j++){
    mean_sizes[j] = growth_curves[(int)(curve_by_row[row])]->mean_size(effective_age[this->step][use_year][j]);
  }
  return mean_sizes;
}

template<CDVM>
VECTOR Size_at_age_effective_age<DVM>::get_mean_sizes_at(int _year, int _step, int row){
  // Return mean sizes of fish in 'row' of the partition in 'step' of 'year'.
  // See ::get_mean_sizes.
  DEBUG1("Size_at_age_effective_age::get_mean_sizes_at");
  if (_year > effective_age[_step].rowmax()){
    fatal("Size_at_age_effective_age::effective_age does not cover year " + itos(_year));
  }
  int use_year = _year;
  if (_year < effective_age[_step].rowmin()){
    use_year = effective_age[_step].rowmin();
  }
  VECTOR mean_sizes(this->col_min,this->col_max);
  for (int j=this->col_min; j<=this->col_max; j++){
    mean_sizes[j] = growth_curves[(int)(curve_by_row[row])]->mean_size(effective_age[_step][use_year][j]);
  }
  return mean_sizes;
}

template<CDVM>
void Size_at_age_effective_age<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Size_at_age_effective_age::print");
  out << "  Mean size by effective age:\n";
  MATRIX mean_size(1,s.n_rows,s.col_min,s.col_max);
  for (int i=1; i<=s.n_rows; i++){
    for (int j=s.col_min; j<=s.col_max; j++){
      mean_size[i][j] = growth_curves[(int)(curve_by_row[i])]->mean_size(j);
    }
  }
  s.print_matrix(out,mean_size);
  out << '\n';
  for (int this_step=1; this_step<effective_age.size(); this_step++){
    out << "  Effective age by year and true age in step " + itos(this_step) << ":\n";
    out << "  Year  ";
    for (int this_age=effective_age[this_step].colmin();
         this_age<=effective_age[this_step].colmax(); this_age++){
      out << setw(5);
      out << this_age << " ";
    }
    out << '\n';
    for (int this_year=effective_age[this_step].rowmin();
         this_year<=effective_age[this_step].rowmax(); this_year++){
      out << "  " << this_year << "  ";
      for (int this_age=effective_age[this_step].colmin();
           this_age<=effective_age[this_step].colmax(); this_age++){
        out << setw(5);
        out << setprecision(4);
        out << effective_age[this_step][this_year][this_age] << " ";
      }
      out << '\n';
    }
    out << '\n';
  }
  if(this->cvs_by_length) {
    if (this->dist=="normal"){
      out << "  Sizes-at-age are normally distributed with " << (this->cvs_actually_stdevs?"standard deviations":"c.v.s") << " defined as a linear function of mean length.\n";
    } else if (this->dist=="lognormal"){
      out << "  Sizes-at-age are lognormally distributed with " << (this->cvs_actually_stdevs?"standard deviations":"c.v.s") << " defined as a linear function of mean length.\n";
    }
  } else if (!(this->cvs_actually_stdevs)){
    if (this->dist=="normal"){
      out << "  Sizes-at-age are normally distributed with c.v.s as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    } else if (this->dist=="lognormal"){
      out << "  Sizes-at-age are lognormally distributed with c.v.s as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    }
  } else {
    if (this->dist=="normal"){
      out << "  Sizes-at-age are normally distributed with standard deviations as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    } else if (this->dist=="lognormal"){
      out << "  Sizes-at-age are lognormally distributed with standard deviations as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    }
  }
};

template<CDVM>
Size_at_age_effective_age<DVM>::Size_at_age_effective_age(Parameter_set<DVM>& p,Basic_state<DVM>& s,
                                                          const dvector& growth_props)
  : Size_at_age<DVM>(p,s)
  , curve_by_row(1,s.n_rows){
  // Construct the size-at-age object from p and s.
  DEBUG1("Size_at_age_effective_age::Size_at_age_effective_age");
  this->type = "effective_age";
  this->col_min = s.col_min;
  this->col_max = s.col_max;
  // Extract the growth curve parameters and make the growth curve objects
  // and figure which rows of the partition use which growth curves
  get_growth_curves(p,s,growth_curves,curve_by_row);
  int time_steps = growth_props.size();
  // calculate effective age of fish in each column of the partition, in each step of each year
  // using growths (as effective years) in each year:
  VECTOR annual_growths(p.get_estimable_vector("annual_growths"));
  if (annual_growths[1]!=1){
    fatal("The first entry of annual_growths must be 1, i.e. a year of ordinary growth.");}
  dvector annual_growth_years(p.get_constant_vector("annual_growth_years"));
  for (int i=2; i<=annual_growth_years.indexmax(); i++){
    if (annual_growth_years[i] != (annual_growth_years[i-1]+1)){
      fatal("size_at_age.annual_growth_years should be consecutive integers");
    }
  }
  if (annual_growths.size() != annual_growth_years.size()){
    fatal("annual_growths should be the same size as annual_growth_years and isn't");}
  if (min(annual_growth_years)<p.get_int("initial") || max(annual_growth_years)>p.get_int("current")){
    fatal("annual growth years should be in the range of 'initial' to 'current'");}
  annual_growths.shift((int)(annual_growth_years[1]));
  int first_year = int(annual_growth_years[1]);
  int last_year = p.get_int("final");
  int aged_by_this_step = 0;
  DOUBLE increment;
  int growth_year;
  effective_age.push_back(MATRIX(1,1,1,1)); // dummy entry
  for (int this_step=1; this_step<=time_steps; this_step++){
    int ageing_time;
    if(p.present("annual_cycle.aging_time")) {
      if(p.present("annual_cycle.ageing_time")) fatal("You have used both annual_cycle.aging_time and annual_cycle.ageing_time. Note that the subcommand aging_time will be deprecated in a future version. Use ageing_time instead.");
      ageing_time = p.get_int("annual_cycle.aging_time");
    } else ageing_time = p.get_int("annual_cycle.ageing_time");
    if (this_step>=ageing_time){
      aged_by_this_step = 1;
    }
    effective_age.push_back(MATRIX(first_year,last_year,s.col_min,s.col_max));
    effective_age[this_step].initialize();
    for (int this_year=first_year; this_year<=last_year; this_year++){
      for (int age=s.col_min; age<=s.col_max; age++){
        for (growth_year=this_year-age+aged_by_this_step;
             growth_year<=this_year-1+aged_by_this_step; growth_year++){
          if (growth_year > annual_growths.indexmax() || growth_year < annual_growths.indexmin()){
            effective_age[this_step][this_year][age] += 1;
          } else {
            effective_age[this_step][this_year][age] += annual_growths[growth_year];
          }
        }
        if (growth_props[this_step]>0){
          growth_year = this_year+aged_by_this_step;
          if (growth_year > annual_growths.indexmax() || growth_year < annual_growths.indexmin()){
            effective_age[this_step][this_year][age] += growth_props[this_step];
          } else {
            effective_age[this_step][this_year][age] += growth_props[this_step] *
                                                        annual_growths[growth_year];
          }
        }
      }
    }
  }
  // And, optionally, set up distributions of size at age.
  get_size_at_age_dist(p,s,this->dist,this->plus_group,this->cv_by_element,this->cvs_actually_stdevs,this->any_nonpositive_cvs,this->cvs_by_length);
}

template<CDVM>
Size_at_age_effective_age<DVM>::~Size_at_age_effective_age(){
  DEBUG2("~Size_at_age_effective_age()");
  for (int i=1; i<growth_curves.size(); i++){
    delete growth_curves[i];}
}

template<CDVM>
VECTOR Size_at_age_from_data<DVM>::get_mean_sizes(int row){
  // Return current mean sizes of fish in 'row' of the partition.
  DEBUG2("Size_at_age_from_data::get_mean_sizes");
  if (this->year < this->initial || this->year > this->final || simulation){
    return mean_sizes[row_for_mean][(int)col_by_step[this->step]][row]; // average of years for which data is provided
  } else {
    return mean_sizes[this->year][(int)col_by_step[this->step]][row];
  }
}

template<CDVM>
VECTOR Size_at_age_from_data<DVM>::get_mean_sizes_at(int _year, int _step, int row){
  // Return mean sizes of fish in 'row' of the partition in '_year'.
  // See ::get_mean_sizes.
  DEBUG2("Size_at_age_from_data::get_mean_sizes_at");
  if (_year < this->initial || _year > this->final || simulation){
    return mean_sizes[row_for_mean][(int)col_by_step[_step]][row]; // average of years for which data is provided
  } else {
    return mean_sizes[_year][(int)col_by_step[_step]][row];
  }
}

template<CDVM>
void Size_at_age_from_data<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Size_at_age_from_data::print");
  out << "  Years " << supplied_years << " were supplied.\n";
  out << "  Other years (if any) were filled in using the " << fillin_method << " method (see the CASAL manual for details).\n";
  out << "  Figures below are for time step " << supplied_step << " in each year:\n";
  for (int y = this->initial; y <= this->final; y++){
    out << "  Year " << y << '\n';
    s.print_matrix(out,mean_sizes[y][(int)col_by_step[supplied_step]]);
    out << '\n';
  }
  out << "  Average of all supplied years is:\n";
  s.print_matrix(out,mean_sizes[row_for_mean][(int)col_by_step[supplied_step]]);
  out << '\n';
  if(this->cvs_by_length) {
    if (this->dist=="normal"){
      out << "  Sizes-at-age are normally distributed with " << (this->cvs_actually_stdevs?"standard deviations":"c.v.s") << " defined as a linear function of mean length.\n";
    } else if (this->dist=="lognormal"){
      out << "  Sizes-at-age are lognormally distributed with " << (this->cvs_actually_stdevs?"standard deviations":"c.v.s") << " defined as a linear function of mean length.\n";
    }
  } else if (!(this->cvs_actually_stdevs)){
    if (this->dist=="normal"){
      out << "  Sizes-at-age are normally distributed with c.v.s as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    } else if (this->dist=="lognormal"){
      out << "  Sizes-at-age are lognormally distributed with c.v.s as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    }
  } else {
    if (this->dist=="normal"){
      out << "  Sizes-at-age are normally distributed with standard deviations as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    } else if (this->dist=="lognormal"){
      out << "  Sizes-at-age are lognormally distributed with standard deviations as follows:\n";
      s.print_matrix(out,this->cv_by_element);
      out << '\n';
    }
  }
}

template<CDVM>
Size_at_age_from_data<DVM>::Size_at_age_from_data(Parameter_set<DVM>& p,Basic_state<DVM>& s,
                                                  const dvector& _growth_props)
  : Size_at_age<DVM>(p,s)
  , supplied_years(p.get_constant_vector("size_at_age_years"))
  , col_by_step(1,this->time_steps){
  // Construct the size-at-age object from p and s.
  DEBUG1("Size_at_age_from_data::Size_at_age_from_data");
  this->type = "data";
  this->col_min = s.col_min;
  this->col_max = s.col_max;
  simulation = p.get_int("simulation",0); // if it's a simulation then we use the mean provided values for every year
  fillin_method = p.get_string("size_at_age_miss","mean");
  if (fillin_method!="mean" && fillin_method!="interp" && fillin_method!="interp.mean" && fillin_method!="mean.interp"){
    fatal("You have specified a @size_at_age_miss which is not one of the following values: mean, interp, interp.mean, mean.interp.\n");
  }
  dvector growth_props(_growth_props);
  supplied_step = p.get_int("size_at_age_step"); // no default
  int birthday;
  if(p.present("annual_cycle.aging_time")) {
    if(p.present("annual_cycle.ageing_time")) fatal("You have used both annual_cycle.aging_time and annual_cycle.ageing_time. Note that the subcommand aging_time will be deprecated in a future version. Use ageing_time instead.");
    birthday = p.get_int("annual_cycle.aging_time");
  } else birthday = p.get_int("annual_cycle.ageing_time");
  // Grab the mean size data provided from the parameter file.
  int data_year;
  int entry_no=0;
  dmatrix entry(1,s.n_rows,s.col_min,s.col_max);
  std::map<int,dmatrix> mean_sizes_provided;
  // so that each entry mean_sizes_provided[i] corresponds to year supplied_years[i]
  // we'll pad it out later with inter/extrapolated data
  for (int i=1; i<=supplied_years.size(); i++){
    data_year = (int)supplied_years[i];
    get_mean_size_data(p,s,data_year,entry);
    mean_sizes_provided.insert(make_pair(data_year,entry));
  }
  // We'll set up the mean_sizes object next.
  // At first we just fill it up with zero values,
  // to get the dimensions right.
  // Later we'll put in the actual numbers.
  std::vector<dmatrix> blank_year;
  entry = 0;
  std::vector<int> steps_to_figure; // ignoring duplicates where the sizes are the same
  int figure_this_step;
  for (int i=1; i<=(this->time_steps); i++){
    figure_this_step=0;
    if (i==1) figure_this_step=1;
    else if (growth_props[i]!=growth_props[i-1]) figure_this_step=1;
    else if (i==birthday) figure_this_step=1;
    if (figure_this_step){
      steps_to_figure.push_back(i);
      blank_year.push_back(entry);
    }
    col_by_step[i] = blank_year.size()-1;
  }
  mean_sizes.insert(make_pair(0,blank_year));
  row_for_mean = 0;
  if (simulation){
   // we only need to hold one matrix - the average of the years provided
  } else {
    // we also need to hold the data for each calendar year from 'initial' to 'final'
    for (int y=this->initial; y<=this->final; y++){
      mean_sizes.insert(make_pair(y,blank_year));
    }
  }
  // Now fill in the entries of mean_sizes, based on the data in mean_sizes_provided, etc.
  // First calculate the average of the mean sizes, over provided years
  dmatrix average_mean_sizes(1,s.n_rows,s.col_min,s.col_max);
  average_mean_sizes = 0;
  for (int i=1; i<=supplied_years.size(); i++){
    average_mean_sizes += mean_sizes_provided[(int)supplied_years[i]];
  }
  average_mean_sizes /= supplied_years.size();
  // Now we need to work with average_mean_sizes, using interpolation
  // to fill in mean_sizes[0], which is used in the pre-initial period
  // and for simulation years.
  // We only have to figure sizes for steps j in steps_to_figure:
  // the sizes for step j are stored in mean_sizes[0][col_by_step[j]].
  int a1, a2;
  double w1, w2;
  for (int j=1; j<=(this->time_steps); j++){
    if (in(steps_to_figure,j)){
      for (int a=s.col_min; a<=s.col_max; a++){
        if ((supplied_step<j && j<birthday) || (j<birthday && birthday<supplied_step)
           || (birthday<supplied_step && supplied_step<j) || (birthday==supplied_step)
           || (j==supplied_step)) a1 = a;
        else a1=a-1;
        a2 = a1+1;
        if (a1==a) w1 = 1 + growth_props[supplied_step] - growth_props[j];
        else w1 = growth_props[supplied_step] - growth_props[j];
        w2 = 1.0-w1;
        if (a2 > s.col_max){
          a1 -= 1;
          a2 -= 1;
          w1 -= 1;
          w2 += 1;
        }
        if (a1 < s.col_min){
          a1 += 1;
          a2 += 1;
          w1 += 1;
          w2 -= 1;
        }
        mean_sizes[0][(int)col_by_step[j]].colfill(a, w1*extract_column(average_mean_sizes,a1)
                                                   +w2*extract_column(average_mean_sizes,a2));
      }
    }
  }
  if (!simulation){
    // Next fill in missing years in mean_sizes_provided
    // using inter/extrapolation as specified by fillin_method
    int first_provided = (int)min(supplied_years);
    int last_provided = (int)max(supplied_years);
    double wl, wu;
    for (int y=this->initial; y<=this->final; y++){
      if (!in(mean_sizes_provided,y)){  // need to fill in year y
        if (y < first_provided){ // low external gap
          if (fillin_method=="interp" || fillin_method=="mean.interp"){ // fill in with the closest year
            mean_sizes_provided.insert(make_pair(y,mean_sizes_provided[first_provided]));
          } else { // fill in with the mean
            mean_sizes_provided.insert(make_pair(y,average_mean_sizes));
          }
        } else if (y > last_provided){ // high external gap
          if (fillin_method=="interp" || fillin_method=="mean.interp"){ // fill in with the closest year
            mean_sizes_provided.insert(make_pair(y,mean_sizes_provided[last_provided]));
          } else { // fill in with the mean
            mean_sizes_provided.insert(make_pair(y,average_mean_sizes));
          }
        } else { // internal gap
          if (fillin_method=="interp" || fillin_method=="interp.mean"){
            // fill in with linear interpolation from the two bracketing years
            // first find bracketing years
            int cl = first_provided, cu = last_provided;
            for (int y2=first_provided; y2<last_provided; y2++){
              if (in(supplied_years,y2)){
                if (y2 > cl && y2 < y){
                   cl = y2;
                } else if (y2 < cu && y2 > y){
                   cu = y2;
                }
              }
            }
            // find and apply linear interpolating weights
            wl = (cu - y) / (double)(cu - cl);
            wu = (y - cl) / (double)(cu - cl);
            mean_sizes_provided.insert(make_pair(y,wl * mean_sizes_provided[cl] + wu * mean_sizes_provided[cu]));
          } else { // fill in with the mean
            mean_sizes_provided.insert(make_pair(y,average_mean_sizes));
          }
        }
      }
    }
    // Right, mean_sizes_provided should be populated for every year from initial to final.
    // Now go on to use inter/extrapolation to fill in mean_sizes
    // for each year from initial to final.
    // We only have to figure sizes for steps j in steps_to_figure:
    //  the sizes for step j are stored in mean_sizes[year][col_by_step[j]].
    for (int i=this->initial; i<=this->final; i++){
      int y1, y2, a1, a2;
      double w1, w2;
      for (int j=1; j<=(this->time_steps); j++){
        if (in(steps_to_figure,j)){
          for (int a=s.col_min; a<=s.col_max; a++){
            y1 = (j>=supplied_step ? i : i-1);
            y2 = y1+1;
            if ((supplied_step<j && j<birthday) || (j<birthday && birthday<supplied_step)
               || (birthday<supplied_step && supplied_step<j) || (birthday==supplied_step)
               || (j==supplied_step)) a1 = a;
            else a1=a-1;
            a2 = a1+1;
            if (a1==a) w1 = 1 + growth_props[supplied_step] - growth_props[j];
            else w1 = growth_props[supplied_step] - growth_props[j];
            w2 = 1.0-w1;
            if (a2 > s.col_max || y2 > this->final){
              a1 -= 1;
              a2 -= 1;
              if((y1-1) > this->initial) y1 -= 1;  //Quick fix. Needs checking. Seems to work. Suggest fuller checking on case by case basis
              y2 -= 1;
              w1 -= 1;
              w2 += 1;
            }
            if (a1 < s.col_min || y1 < this->initial){
              a1 += 1;
              a2 += 1;
              y1 += 1;
              y2 += 1;
              w1 += 1;
              w2 -= 1;
            }
            if (a2 > s.col_max || y2 > this->final || a1 < s.col_min || y1 < this->initial){
              // unusual case - very little info on this cohort - just use averages
              mean_sizes[i][(int)col_by_step[j]].colfill(a, extract_column(mean_sizes[0][(int)col_by_step[j]],a));
            } else {
              mean_sizes[i][(int)col_by_step[j]].colfill(a, w1*extract_column(mean_sizes_provided[y1],a1)
                                                         +w2*extract_column(mean_sizes_provided[y2],a2));
            }
          }
        }
      }
    }
  }
  // And, optionally, set up distributions of size at age.
  get_size_at_age_dist(p,s,this->dist,this->plus_group,this->cv_by_element,this->cvs_actually_stdevs,this->any_nonpositive_cvs,this->cvs_by_length);
}

template<CDVM>
void get_mean_size_data(Parameter_set<DVM>& p, Basic_state<DVM>& s, int data_year, dmatrix& result){
  // Called by the Size_at_age_from_data constructor.
  // Extracts mean size data for year 'data_year' from p.
  // Fills in 'result'.
  DEBUG2("get_mean_size_data");
  int sex_char = s.character_numbers("sex");
  int stock_char = s.character_numbers("stock");
  std::string command;
  int count=1;
  int by_stock;
  if (s.n_stocks == 1) by_stock = 0;
  else by_stock = (p.get_command_count("size_at_age")>1);
  for (int stock=1; stock<=s.n_stocks; stock++){
    if (by_stock) command = "size_at_age[" + s.stock_names[stock] +"].";
    else command = "size_at_age.";
    if (p.present(command+"male_"+itos(data_year))){
      // data are sexed
      dvector data_male(s.col_min,s.col_max);
      dvector data_female(s.col_min,s.col_max);
      dvector male_data_from_file(p.get_constant_vector(command+"male_"+itos(data_year)));
      if (male_data_from_file.size() != data_male.size()){
        fatal("Wrong amount of mean-size-at-age data for males in year " + itos(data_year));
      } else {
        data_male = male_data_from_file;
      }
      dvector female_data_from_file(p.get_constant_vector(command+"female_"+itos(data_year)));
      if (female_data_from_file.size() != data_female.size()){
        fatal("Wrong amount of mean-size-at-age data for females in year " + itos(data_year));
      } else {
        data_female = female_data_from_file;
      }
      for (int i=1; i<=s.n_rows; i++){
        if (stock_char!=-1){
          if (s.character_value(i,stock_char)!=stock) continue;}
        if (s.character_value(i,sex_char)==1) result[i]=data_male;
        else result[i]=data_female;
      }
    } else {
      // data are unsexed
      dvector data(s.col_min,s.col_max);
      dvector data_from_file(p.get_constant_vector(command+"all_"+itos(data_year)));
      if (data_from_file.size() != data.size()){
        fatal("Wrong amount of mean-size-at-age data in year " + itos(data_year));
      } else {
        data = data_from_file;
      }
      for (int i=1; i<=s.n_rows; i++){
        if (stock_char!=-1){
          if (s.character_value(i,stock_char)!=stock) continue;}
        result[i]=data;
      }
    }
  }
}

template<CDVM>
Size_at_age_from_data<DVM>::~Size_at_age_from_data(){
  // nothing to do
  DEBUG2("~Size_at_age_effective_age()");
}

template<CDVM>
DOUBLE von_Bert<DVM>::mean_size(const DOUBLE& age){
  // Return mean size at age (may be effective age).
  DEBUG2("von_Bert::mean_size");
  if (-k*(age-t0) > 10){
          fatal("Fatal error in von_Bert<DVM>::mean_size: exp(-k*(age-t0)) is enormous. Your k or t0 parameters are probably wrong.");}
  DOUBLE result = Linf*(1 - exp(-k*(age - t0)));
  if (result<0) {
    static int mean_size_error_message=0;
    if(mean_size_error_message==0) {
      cerr << "Warning: Negative mean size found in von_Bert::mean_size, at age = " << age << ".\n";
      mean_size_error_message=1;
    }
    result=0.0;
  }
  return result;
}

template<CDVM>
void von_Bert<DVM>::print(ostream& out){
  DEBUG1("von_Bert::print");
  out << "  von Bertalanffy: k = " << k << " t0 = " << t0 << " Linf = " << Linf << "\n";
};

template<CDVM>
von_Bert<DVM>::von_Bert(const DOUBLE& _k, const DOUBLE& _t0, const DOUBLE& _Linf){
  // Construct the Growth_curve from k, t0, and Linf.
  DEBUG1("von_Bert::von_Bert");
  k = _k;
  t0 = _t0;
  Linf = _Linf;
  if (k<0){
         cerr << "You have supplied an invalid von Bertalanffy k parameter of " << k;
         fatal(" - the k parameter should never be negative.");
  }
  if (Linf<0){
         cerr << "You have supplied an invalid von Bertalanffy Linf parameter of " << Linf;
         fatal(" - the Linf parameter should never be negative.");
  }
}

template<CDVM>
DOUBLE Schnute<DVM>::mean_size(const DOUBLE& age){
  // Return mean size at age (may be effective age).
  DEBUG2("Schnute::mean_size");
  DOUBLE last_term;
  if (a != 0){
    last_term = (1-exp(-a*(age-tau1)))/(1-exp(-a*(tau2-tau1)));
  } else {
    last_term = (age-tau1)/(tau2-tau1);
  }
  DOUBLE result;
  if (b!=0){
    result = pow((pow(y1,b)+(pow(y2,b)-pow(y1,b))*last_term),1/b);
  } else {
    result = y1*exp(log(y2/y1)*last_term);
  }
  if (result<0) {
    static int mean_size_error_message=0;
    if(mean_size_error_message==0) {
      cerr << "Warning: Negative mean size found in Schnute::mean_size, at age = " << age << ".\n";
      mean_size_error_message=1;
    }
    result=0.0;
  }
  return result;
}

template<CDVM>
void Schnute<DVM>::print(ostream& out){
  DEBUG1("Schnute::print");
  out << "  Schnute: y1 = " << y1 << " y2 = " << y2 << " a = " << a << " b = " << b << " tau1 = " << tau1 << " tau2 = " << tau2 << "\n";
};

template<CDVM>
Schnute<DVM>::Schnute(const DOUBLE& _y1, const DOUBLE& _y2, const DOUBLE& _a, const DOUBLE& _b, const DOUBLE& _tau1, const DOUBLE& _tau2){
  // Construct the Growth_curve from y1, y2, a, b, tau1, tau2.
  DEBUG1("Schnute::Schnute");
  y1 = _y1;
  y2 = _y2;
  a = _a;
  b = _b;
  tau1 = _tau1;
  tau2 = _tau2;
}

// ############################# WEIGHT ################################
template<CDVM>
void check_units_for_size_weight(const double a, const double b, const int stock_number,
Parameter_set<DVM>& p, Basic_state<DVM>& s, const string sex){
  // weight = a*size^b
  // stock_number -> counter from one up to the number of stocks in the model
  // p -> Parameter_set object
  // s -> Basic_state object
  // sex -> sex of fish (male/female, or by default an empty string if both)
  //
  // If you provide your catch in tonnes, and your growth curve in centimetres, then the
  // parameter a should be on the right scale to convert a length in centimetres to a weight in tonnes.
  //
  // By default, the function checks this by finding the weight of a fish that has a length of 25 centimetres
  // and issues a warning if the weight seems to be unreasonable (it is assumed in the check that the growth curve is
  // in centimetres and that the catch is in tonnes).
  //
  // Alternatively, for the command @size_weight, the subcommand verify_size_weight  fish_size lower_bound upper_bound
  // can be supplied which checks if a fish of size fish_size (in cm) has a weight inside the
  // given lower_bound and upper_bound values (in kg). If it is outside the bounds then a message is
  // issued and the program stops. If the weight is inside the bounds then this size and weight are
  // given as part of the standard output.
  //
  DEBUG1("check_units_for_size_weight");

  // The purpose of the static variables is to  ensure that a stock is checked just once
  static vector<int> already_checked_units_male(s.n_stocks + 1);    // initialised automatically to zero
  static vector<int> already_checked_units_female(s.n_stocks + 1);

  // OPTIM: substituted operator[] for at().
  //if( already_checked_units_male.at(stock_number) && sex=="male" ||
  //    already_checked_units_female.at(stock_number) && sex=="female"  ||
  //    already_checked_units_male.at(stock_number) && sex=="" ) return;
  if( already_checked_units_male[stock_number] && sex=="male" ||
      already_checked_units_female[stock_number] && sex=="female"  ||
      already_checked_units_male[stock_number] && sex=="" ) return;
  if( p.get_bool("weightless_model",0) ) return;

  std::string command;
  if (s.n_stocks==1)
    command = "size_weight.";
  else
    command = "size_weight[" + s.stock_names[stock_number] + "].";

  // The unit check only works for the "basic" size-weight relationship
  if (p.get_string(command + "type","basic") != "basic"){
    cerr << "The function check_units_for_size_weight only works for the basic size-weight relationship" << endl;
    return;
  }

  // Some basic checks to start
  if (a <= 0) fatal("Mean-weight parameter a should be positive.");
  if (b < 1)  fatal("Mean-weight parameter b should be at least 1.");
  if (b > 6)  cerr << "Your size-weight parameter b seems to be rather large." << endl;

  double size;
  double lower_bound;
  double upper_bound;
  int verify = p.present(command + "verify_size_weight");

  if(verify){
    dvector temp(p.get_constant_vector(command + "verify_size_weight"));
    if(temp.size() != 3)
      fatal("The subcommand verify_size_weight takes three arguments (size, lower bound, upper bound).");
    size = temp[1];
    lower_bound = temp[2];
    upper_bound = temp[3];
  }
  else{
    size = 25.0;
    lower_bound =  0.05;  // 0.05 kg = 50 gram for default
    upper_bound =  5.0;   // 5 kg for default
  }

  // convert weight from what model commonly uses (tonnes) to kg
  double weight = a*pow(size,b)*1000;

  string sex_label;
  if(sex != "") sex_label = sex + " ";
  string temp1;
  if(s.n_stocks==1)
    temp1 = "A " + sex_label + "fish of size " + dtos(size) + " cm "
    "has a weight of " + dtos(weight) + " kg in your model. ";
  else
    temp1 = "A " + sex_label + "fish of size " + dtos(size) + " cm, for the stock labelled " +
    s.stock_names[stock_number] +  ", has a weight of " + dtos(weight) + " kg in your model. ";
  string temp2 = "This is outside your weight bounds (in kg) of [" + dtos(lower_bound) + "," + dtos(upper_bound) + "]. ";
  string temp3 = "You should check that your @size_weight parameter a has the right units. ";
  string temp4 = "This size-weight scale check assumes that the growth curve is in centimetres, and that the catch is in tonnes.\n\n";

  if (verify){
     if (weight < lower_bound || weight > upper_bound)
        fatal(temp1 + temp2 + temp4);
     else
        cout << temp1 << temp4;
  }
  else{
     if (weight < lower_bound || weight > upper_bound)
        cerr << "Warning: " << temp1 << temp3 << temp4;
  }

  // OPTIM: substituted operator[] for at().
  //if(sex == "male")
  //  already_checked_units_male.at(stock_number) = 1;
  //else if (sex == "female")
  //  already_checked_units_female.at(stock_number) = 1;
  //else if (sex == ""){
  //  already_checked_units_male.at(stock_number) = 1;
  //  already_checked_units_female.at(stock_number) = 1;
  //}
  if(sex == "male")
    already_checked_units_male[stock_number] = 1;
  else if (sex == "female")
    already_checked_units_female[stock_number] = 1;
  else if (sex == ""){
    already_checked_units_male[stock_number] = 1;
    already_checked_units_female[stock_number] = 1;
  }
  else
    fatal("The argument " + sex + " for the function check_units_for_size_weight is not allowed.");

  return;
}

template<CDVM>
VECTOR Sizebased_mean_weight<DVM>::get_row(Basic_state<DVM>& s, int row){
  // Return mean weights of fish in row of the partition, which are stored
  // as mean_weight_at_size[row].
  DEBUG2("Sizebased_mean_weight::get_row");
  return mean_weight_at_size[row];
}

template<CDVM>
void Sizebased_mean_weight<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Sizebased_mean_weight::print");
  out << "  mean weight at size:\n";
  s.print_matrix(out,mean_weight_at_size);
  out << '\n';
};

template<CDVM>
Sizebased_mean_weight<DVM>::Sizebased_mean_weight(Parameter_set<DVM>& p,Basic_state<DVM>& s)
  : mean_weight_at_size(1,s.n_rows,s.col_min,s.col_max){
  // Construct the mean-weight object from p and s.
  DEBUG1("Sizebased_mean_weight::Sizebased_mean_weight");
  int stock_char = s.character_numbers("stock");
  int sex_char = s.character_numbers("sex");
  if (p.get_bool("weightless_model",0)){
    // All fish are assigned a nominal weight of 1.
    if (p.present("size_weight.type") || p.present("size_weight.a") || p.present("size_weight.a_male")){
      fatal("You cannot specify @weightless_model and supply size-weight parameters at the same time");}
    static int weightless_print_message=1;
    if(weightless_print_message) {
      cout << "Note, this is a weightless model. 'Biomass' and 'weight in tons' should be read as numbers of fish throughout.\n";
      weightless_print_message=0;
    }
    mean_weight_at_size = 1;
    return;
  }
  std::string command;
  for (int stock=1; stock<=s.n_stocks; stock++){
    if (s.n_stocks==1 || p.present("size_weight.type") || p.present("size_weight.a") || p.present("size_weight.a_male")){
      command = "size_weight.";
    } else {
      command = "size_weight[" + s.stock_names[stock] + "].";
    }
    dvector class_sizes(s.col_min,s.col_max);
    for (int j=s.col_min; j<s.col_max; j++){
      class_sizes[j] = (s.class_mins[j]+s.class_mins[j+1]) * 0.5;
    }
    if (s.plus_group){
      class_sizes[s.col_max] = s.plus_group_size;
    } else {
      class_sizes[s.col_max] = (s.class_mins[s.col_max]+s.class_mins[s.col_max+1]) * 0.5;
    }
    if (p.present(command+"a")){
      double a_all(p.get_constant(command+"a"));
      double b_all(p.get_constant(command+"b"));
      check_units_for_size_weight(a_all, b_all, stock, p, s);
      for (int i=1; i<=s.n_rows; i++){
        if (s.n_stocks>1){
          if (s.character_value(i,stock_char)!=stock) continue;}
        for (int j=s.col_min; j<=s.col_max; j++){
          mean_weight_at_size[i][j] = a_all*pow(class_sizes[j],b_all);
        }
      }
    } else {
      double a_male(p.get_constant(command+"a_male"));
      double b_male(p.get_constant(command+"b_male"));
      double a_female(p.get_constant(command+"a_female"));
      double b_female(p.get_constant(command+"b_female"));
      check_units_for_size_weight(a_male, b_male, stock, p, s, "male");
      check_units_for_size_weight(a_female, b_female, stock, p, s, "female");
      for (int i=1; i<=s.n_rows; i++){
        if (s.n_stocks>1){
          if (s.character_value(i,stock_char)!=stock) continue;}
        double a_val, b_val;
        a_val = s.character_value(i,sex_char)==1 ? a_male : a_female;
        b_val = s.character_value(i,sex_char)==1 ? b_male : b_female;
        for (int j=s.col_min; j<=s.col_max; j++){
          mean_weight_at_size[i][j] = a_val*pow(class_sizes[j],b_val);
        }
      }
    }
  }
}

template<CDVM>
VECTOR Agebased_mean_weight<DVM>::get_row(Basic_state<DVM>& s, int row){
  // Return current mean weights of fish in row of the partition,
  // calculated from the mean sizes at age which are from size_at_age->get_mean_sizes(row),
  // using mean weight = a[row] * mean size ^ b[row],
  // and if a distribution of sizes at age is specified,
  // using a bias correction of (1+cv^2)^(b*(b-1)/2).
  DEBUG2("Agebased_mean_weight::get_row");
  VECTOR mean_size(size_at_age->get_mean_sizes(row));
  double a_val = a[row];
  double b_val = b[row];
  if (min(mean_size)<0){
    for (int i=mean_size.indexmin(); i<=mean_size.indexmax(); i++){
      mean_size[i] = fmax(0,mean_size[i]);}
  }
  VECTOR result(a_val * pow(mean_size,b_val));
  if (min(result)<0){
    for (int i=result.indexmin(); i<=result.indexmax(); i++){
      result[i] = fmax(0,result[i]);}
  }
  if (size_at_age->get_dist() != "none"){
    VECTOR cvs(size_at_age->get_all_cvs()[row]);
    int is_stdev = size_at_age->cvs_actually_stdevs;
    if (is_stdev){
      for (int i=cvs.indexmin(); i<=cvs.indexmax(); i++){
            cvs[i] /= mean_size[i];}} // convert stdev to cv
    for (int i=result.indexmin(); i<=result.indexmax(); i++){
      result[i] *= pow((1+pow(cvs[i+cvs.indexmin()-result.indexmin()],2)),b_val*(b_val-1)*0.5);}
  }
  return result;
}

template<CDVM>
void Agebased_mean_weight<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Agebased_mean_weight::print");
  std::vector<VECTOR> results;
  std::vector<std::string> names;
  results.push_back(a);
  results.push_back(b);
  names.push_back("a");
  names.push_back("b");
  if (size_at_age->get_dist() != "none"){
    out << "  weight = a * mean size ^ b * bias correction, where \n";
    out << "  bias correction = (1+cv of sizes-at-age^2) ^ (b*(b-1)/2), and\n";
  } else {
    out << "  weight = a * mean size ^ b, where\n";
  }
  s.print_several_vectors(out,results,names);
  out << '\n';
};

template<CDVM>
Agebased_mean_weight<DVM>::Agebased_mean_weight(Parameter_set<DVM>& p,Basic_state<DVM>& s,
                                                Size_at_age<DVM>* _size_at_age)
  : a(1,s.n_rows)
  , b(1,s.n_rows){
  // Construct the mean-weight object from p, s,
  // and the address of the Basic_annual_cycle::size_at_age.
  DEBUG1("Agebased_mean_weight::Agebased_mean_weight");
  int stock_char = s.character_numbers("stock");
  int sex_char = s.character_numbers("sex");
  if (p.get_bool("weightless_model",0)){
    // All fish are assigned a nominal weight of 1.
    static int weightless_print_message=1;
    if(weightless_print_message) {
      cout << "Note, this is a weightless model. 'Biomass' and 'weight in tons' should be read as numbers of fish throughout.\n";
      weightless_print_message=0;
    }
    a = 1;
    b = 0;
  } else {
    std::string command;
    for (int stock=1; stock<=s.n_stocks; stock++){
      if (s.n_stocks==1 || p.present("size_weight.type") || p.present("size_weight.a") || p.present("size_weight.a_male")){
        command = "size_weight.";
      } else {
        command = "size_weight[" + s.stock_names[stock] + "].";
      }
      if (p.present(command+"a")){
        double a_all(p.get_constant(command+"a"));
        double b_all(p.get_constant(command+"b"));
        check_units_for_size_weight(a_all, b_all, stock, p, s);
        for (int i=1; i<=s.n_rows; i++){
          if (s.n_stocks>1){
            if (s.character_value(i,stock_char)!=stock) continue;}
          a[i] = a_all;
          b[i] = b_all;
        }
      } else {
        double a_male(p.get_constant(command+"a_male"));
        double b_male(p.get_constant(command+"b_male"));
        double a_female(p.get_constant(command+"a_female"));
        double b_female(p.get_constant(command+"b_female"));
        check_units_for_size_weight(a_male, b_male, stock, p, s, "male");
        check_units_for_size_weight(a_female, b_female, stock, p, s, "female");
        for (int i=1; i<=s.n_rows; i++){
          if (s.n_stocks>1){
            if (s.character_value(i,stock_char)!=stock) continue;}
          a[i] = s.character_value(i,sex_char)==1 ? a_male : a_female;
          b[i] = s.character_value(i,sex_char)==1 ? b_male : b_female;
        }
      }
    }
  }
  size_at_age = _size_at_age;
}

//########################## NON-PARTITION MATURITY ##########################
template<CDVM>
VECTOR Basic_nonpartition_maturity<DVM>::get_row(int row){
  // Return the proportions of mature fish in each element of row, which
  // are stored in mature_by_element[row].
  // get_row(i)[j] is the proportion of mature fish in element [i,j]
  // of the partition.
  DEBUG2("Basic_nonpartition_maturity::get_row");
  VECTOR temp(mature_by_element[row]);
  return mature_by_element[row];
}

template<CDVM>
void Basic_nonpartition_maturity<DVM>::print(Basic_state<DVM>& s,ostream& out){
  DEBUG1("Basic_nonpartition_maturity::print");
  s.print_matrix(out,mature_by_element);
  out << '\n';
};

template<CDVM>
Basic_nonpartition_maturity<DVM>::Basic_nonpartition_maturity(Parameter_set<DVM>& p,Basic_state<DVM>& s)
  : mature_by_element(1,s.n_rows,s.col_min,s.col_max){
  // Construct the proportion-mature function from p and s.
  // Should be able to depend on size, but this has not been implemented yet.
  DEBUG1("Basic_nonpartition_maturity::Basic_nonpartition_maturity");
  if (p.present("maturity_props.male")){
    int sex_char = s.character_numbers("sex");
    MATRIX props(1,2,s.col_min,s.col_max);
    if (!s.size_based &&
        (p.get_ogive_base("maturity_props.male") || p.get_ogive_base("maturity_props.female"))){
      fatal("Size-based proportions mature ogives in an age-based model are not implemented yet.");
    }
    props[1] = p.get_ogive_values("maturity_props.male");
    props[2] = p.get_ogive_values("maturity_props.female");
    for (int i=1; i<=s.n_rows; i++){
      if (s.character_value(i,sex_char)==1){
        mature_by_element[i] = props[1];
      } else {
        mature_by_element[i] = props[2];
      }
    }
  } else {
    MATRIX props(1,1,s.col_min,s.col_max);
    if (!s.size_based && p.get_ogive_base("maturity_props.all")){
      fatal("Size-based proportions mature ogives in an age-based model are not implemented yet.");
    }
    props[1] = p.get_ogive_values("maturity_props.all");
    if (p.get_ogive_base("maturity_props.all")==1 && !s.size_based){
      // size-based maturity ogive in an age-based model
      fatal("Size-based proportions mature ogives in an age-based model are not implemented yet.");
    }
    for (int i=1; i<=s.n_rows; i++){
      mature_by_element[i] = props[1];
    }
  }
  // check that proportions mature are monotone nondecreasing in each row - issue a warning otherwise
  int nondecreasing=1;
  for (int i=1; i<=s.n_rows; i++){
    DOUBLE previous=0;
    for (int j=s.col_min; j<=s.col_max; j++){
          if (mature_by_element[i][j] < previous) nondecreasing=0;
          previous = mature_by_element[i][j];
        }
  }
  if (!nondecreasing) {
    static int PropMat_print_message=1;
    if(PropMat_print_message) {
      cerr << "You have specified proportions mature which actually go down from one age/size class to the next. Are you sure you entered proportions mature, not proportions maturing??\n";
      PropMat_print_message=0;
    }
  }
}

// ###################################### INITIALIZATION DATA ###########################

template<CDVM>
void Basic_initialization_data<DVM>::multiply_abundance(double mult){
        DEBUG1("Basic_initialization_data::multiply_abundance");
        // scale all virgin abundance info provided by a factor of 'mult'
  if (B0>0) B0 *= mult;
  if (R0>0) R0 *= mult;
  if (use_mean_YCS){
     if (Bmean>0) Bmean *= mult;
     if (Rmean>0) Rmean *= mult;
  }
}

template<CDVM>
void Basic_initialization_data<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Basic_initialization_data::print");
  if (s.n_stocks>1)
    out << "  For stock " << s.stock_names[stock] << '\n';
  if (B0>0) out << "  B0 : " << B0 << '\n';
  if (R0>0) out << "  R0 : " << R0 << '\n';
  if (Binitial>0) out << "  Binitial : " << Binitial << '\n';
  if (Rinitial>0) out << "  Rinitial : " << Rinitial << '\n';
  if (use_mean_YCS){
          if (Bmean>0) out << "  Bmean : " << Bmean << '\n';
          if (Rmean>0) out << "  Rmean : " << Rmean << '\n';
  }
  if (Cinitial!=0) out << "  Cinitial : " << *Cinitial << '\n';
  if (Cinitial_male!=0) out << "  Cinitial_male : " << *Cinitial_male << '\n';
  if (Cinitial_female!=0) out << "  Cinitial_female : " << *Cinitial_female << '\n';
  if (n_equilibrium>0) out << "  Length of equilibrium period : " << n_equilibrium << '\n';
  out << '\n';
};

template<CDVM>
Basic_initialization_data<DVM>::Basic_initialization_data(Parameter_set<DVM>& p, Basic_state<DVM>& s,
                                                          int _stock, int y_enter)
  : command("initialization"+((s.n_stocks>1)?("["+s.stock_names[_stock]+"]."):".")){
  // Extract the initialization data for '_stock'.
  DEBUG1("Basic_initialization_data::Basic_initialization_data");
  if (s.n_stocks != 2 && (p.present("B0_prop_stock1") || p.present("Bmean_prop_stock1") || p.present("R0_prop_stock1") || p.present("Rmean_prop_stock1"))){
          fatal("Don't use initialization commands *_prop_stock1 unless you are working with a 2-stock model");}
  if (s.n_stocks != 2 && (p.present("log_B0_total") || p.present("log_Bmean_total") || p.present("log_R0_total") || p.present("log_Rmean_total"))){
          fatal("Don't use initialization commands log_*_total unless you are working with a 2-stock model");}
  if (s.n_stocks != 2 && (p.present("B0_total") || p.present("Bmean_total") || p.present("R0_total") || p.present("log_Rmean_total"))){
          fatal("Don't use initialization commands *_total unless you are working with a 2-stock model");}
  stock = _stock;
  use_mean_YCS = p.get_bool("use_mean_YCS",0);
  if (!use_mean_YCS){
    if (s.n_stocks == 2 && p.present("B0_prop_stock1")){
      B0 = p.get_estimable("B0_total",exp(p.get_estimable("log_B0_total")));
      DOUBLE B0_prop_stock1 = p.get_estimable("B0_prop_stock1");
      if (stock==1){
        B0 *= B0_prop_stock1;
      } else {
        B0 *= (1-B0_prop_stock1);
      }
      R0 = 0;
    } else if (s.n_stocks == 2 && p.present("R0_prop_stock1")){
      R0 = p.get_estimable("R0_total",exp(p.get_estimable("log_R0_total")));
      DOUBLE R0_prop_stock1 = p.get_estimable("R0_prop_stock1");
      if (stock==1){
        R0 *= R0_prop_stock1;
      } else {
        R0 *= (1-R0_prop_stock1);
      }
      B0 = 0;
    } else {
      B0 = p.get_estimable(command+"B0",0);
      R0 = p.get_estimable(command+"R0",0);
    }
    Bmean = 0;
    Rmean = 0;
  } else if (use_mean_YCS){
    if (s.n_stocks == 2 && p.present("Bmean_prop_stock1")){
      Bmean = p.get_estimable("Bmean_total",exp(p.get_estimable("log_Bmean_total")));
      DOUBLE Bmean_prop_stock1 = p.get_estimable("Bmean_prop_stock1");
      if (stock==1){
        Bmean *= Bmean_prop_stock1;
      } else {
        Bmean *= (1-Bmean_prop_stock1);
      }
      Rmean = 0;
    } else if (s.n_stocks == 2 && p.present("Rmean_prop_stock1")){
      Rmean = p.get_estimable("Rmean_total",exp(p.get_estimable("log_Rmean_total")));
      DOUBLE Rmean_prop_stock1 = p.get_estimable("Rmean_prop_stock1");
      if (stock==1){
        Rmean *= Rmean_prop_stock1;
      } else {
        Rmean *= (1-Rmean_prop_stock1);
      }
      Bmean = 0;
    } else {
      Bmean = p.get_estimable(command+"Bmean",0);
      Rmean = p.get_estimable(command+"Rmean",0);
    }
    B0=0;
    R0=0;
  }
  Binitial = p.get_estimable(command+"Binitial",0);
  Rinitial = p.get_estimable(command+"Rinitial",0);
  Rinitial_is_deviate = p.get_bool("Rinitial_is_deviate",0);
  if (Rinitial > 10 && Rinitial_is_deviate){
          cerr << "You've supplied an enormous value of " << Rinitial << " for stock " << s.stock_names[stock] << " - did you remember that Rinitial is expressed relative to R0?\n";
  }
  if (Rinitial < 5 && !Rinitial_is_deviate && Rinitial > 0){
    cerr << "You've supplied a tiny value of " << Rinitial << " for stock " << s.stock_names[stock] << " - did you remember that Rinitial is not expressed relative to R0?\n";
  }
  if (p.present(command+"Cinitial")){
    if (!s.size_based && p.get_ogive_base(command+"Cinitial")==1){
      fatal("Cinitial can't be a size-based ogive");}
    Cinitial = new VECTOR(p.get_ogive_values(command+"Cinitial"));
    if (p.get_ogive_type(command+"Cinitial") != "allvalues"){
                cerr << "Did you mean to use an allvalues ogive for Cinitial? This would be recommended\n";}
  } else {
    Cinitial = 0;
  }
  if (p.present(command+"Cinitial_male")){
    if (!s.size_based && p.get_ogive_base(command+"Cinitial_male")==1){
      fatal("Cinitial_male can't be a size-based ogive");}
    Cinitial_male = new VECTOR(p.get_ogive_values(command+"Cinitial_male"));
    if (p.get_ogive_type(command+"Cinitial_male") != "allvalues"){
                cerr << "Did you mean to use an allvalues ogive for Cinitial_male? This would be recommended\n";}
  } else {
    Cinitial_male = 0;
  }
  if (p.present(command+"Cinitial_female")){
    if (!s.size_based && p.get_ogive_base(command+"Cinitial_female")==1){
      fatal("Cinitial_female can't be a size-based ogive");}
    Cinitial_female = new VECTOR(p.get_ogive_values(command+"Cinitial_female"));
    if (p.get_ogive_type(command+"Cinitial_female") != "allvalues"){
                cerr << "Did you mean to use an allvalues ogive for Cinitial_female? This would be recommended\n";}
  } else {
    Cinitial_female = 0;
  }
  n_equilibrium = p.get_int("n_equilibrium",0);
}

template<CDVM>
Basic_initialization_data<DVM>::~Basic_initialization_data(){
  DEBUG2("~Basic_initialization_data");
  if (Cinitial != 0) delete Cinitial;
  if (Cinitial_male != 0) delete Cinitial_male;
  if (Cinitial_female != 0) delete Cinitial_female;
}
//############################## END OF POPULATION PROCESSES.cpp ##############################

// Create particular instantiations of the template
template class Size_at_age<double, dvector, dmatrix>;
template class Selectivity<double, dvector, dmatrix>;
template class Basic_recruitment<double, dvector, dmatrix>;
template class Basic_annual_cycle<double, dvector, dmatrix>;
template class Basic_initialization_data<double, dvector, dmatrix>;
template class Basic_partition_maturity<double, dvector, dmatrix>;
template class Basic_nonpartition_maturity<double, dvector, dmatrix>;
template class Basic_ageing<double, dvector, dmatrix>;
template class DiseaseMortality<double, dvector, dmatrix>;
template class TaggingFish<double, dvector, dmatrix>;
template class Migration_by_constant<double, dvector, dmatrix>;
template class Migration_by_ogive<double, dvector, dmatrix>;
template class Density_dependence<double, dvector, dmatrix>;
template class Natural_only_by_element<double, dvector, dmatrix>;
template class Natural_only_by_row<double, dvector, dmatrix>;
template class Basic_fisheries<double, dvector, dmatrix>;
template class No_mortality<double, dvector, dmatrix>;
template class Baranov_fisheries<double, dvector, dmatrix>;
template class Agebased_mean_weight<double, dvector, dmatrix>;
template class Sizebased_mean_weight<double, dvector, dmatrix>;
template class Growth_years_same<double, dvector, dmatrix>;
template class Size_at_age_years_same<double, dvector, dmatrix>;
template class Size_at_age_from_data<double, dvector, dmatrix>;
template class Size_at_age_effective_age<double, dvector, dmatrix>;
template class TagLoss<double,dvector,dmatrix>;
template class Size_at_age<dvariable, dvv, dvm>;
template class Size_at_age_years_same<dvariable, dvv, dvm>;
template class Basic_annual_cycle<dvariable, dvv, dvm>;
template class Basic_partition_maturity<dvariable, dvv, dvm>;
template class Selectivity<dvariable, dvv, dvm>;
template class Basic_recruitment<dvariable, dvv, dvm>;
template class DiseaseMortality<dvariable, dvv, dvm>;
template class TaggingFish<dvariable, dvv, dvm>;
template class Basic_ageing<dvariable, dvv, dvm>;
template class Basic_nonpartition_maturity<dvariable, dvv, dvm>;
template class Basic_initialization_data<dvariable, dvv, dvm>;
template class Migration_by_ogive<dvariable, dvv, dvm>;
template class Migration_by_constant<dvariable, dvv, dvm>;
template class Density_dependence<dvariable, dvv, dvm>;
template class Natural_only_by_element<dvariable, dvv, dvm>;
template class Natural_only_by_row<dvariable, dvv, dvm>;
template class No_mortality<dvariable, dvv, dvm>;
template class Baranov_fisheries<dvariable, dvv, dvm>;
template class Sizebased_mean_weight<dvariable, dvv, dvm>;
template class Agebased_mean_weight<dvariable, dvv, dvm>;
template class Growth_years_same<dvariable, dvv, dvm>;
template class Basic_fisheries<dvariable, dvv, dvm>;
template class Size_at_age_effective_age<dvariable, dvv, dvm>;
template class Size_at_age_from_data<dvariable, dvv, dvm>;
template class TagLoss<dvariable,dvv,dvm>;
