// const char* time_stamp = "$Date: 2007-05-28 14:06:56 +1200 (Mon, 28 May 2007) $\n";
// const char* dictionary_id = "$Id: dictionary.h 1677 2007-05-28 02:06:56Z bianrr $\n";

#if !defined(DICTIONARY)
#define DICTIONARY

//############################## DICTIONARY OF CASAL COMMANDS #####################################
#include <string>
#include <map>

///////////////////////////////////////////////////////////////////////////////////////////////////
class Table_compare{
// the comparison operator for the map in class Dictionary
public:
  bool operator()(const std::string& x, const std::string& y) const;
};

class Dictionary{
  /*
  This class contains a large data table, with one entry per CASAL input command.
  Commands come in three types:
   with_argument: The command must have an argument and never has subcommands. Provide the type of argument it takes.
   with_nolabel: The command never has an argument or label; it would usually have subcommands.
   with_label: The command never has an argument, must have a label, and would usually have subcommands. Provide the legitimate subcommands and the type of each. Use a wildcard ! for subcommands whose names can contain 'any number' (for example, if a command can have subcommands cv_[year] such as cv_2002, enter this as a subcommand with name cv_!)
   with_autonumber: The command cannot have a label: the first time it is used, the label '1' is inserted, then '2' the next time and so forth. This type of command is uncommon (@growth, @maturation, @profile, @estimate are the only types I can think of offhand) and I would like to see it phased out. Provide same as 'with_label' above.
  Commands are also divided into population / estimation / output.
  Commands and subcommands can also be marked as obsolete.
  */
public:
  int bad_command;
  map<std::string,std::string,Table_compare> table;
  // Each table key is constructed as follows:
  // [file]:[command], or [file]:[command]->[subcommand] (subcommand names can include ! as a wildcard for any number),
  // in either case can be suffixed with @OBSOLETE.
  // Thus
  //   P:initial
  //   E:estimate->same
  //   O:print->dead_command@OBSOLETE
  //
  // Each corresponding entry is a string taking one of the following values:
  //  "switch", "int", "constant", "estimable", "constant_vector", "estimable_vector", "ogive", "string", "vector_of_strings" (ie. the command or subcommand takes this kind of argument)
  //  or "nolabel" "label" "autonumber" (see main comment above)
  std::string check(std::string &command, std::string file, int nofatal=0);
  std::string check(std::string &command, std::string &subcommand, std::string file, int nofatal=0);
  // Is this (sub)command valid in this file? If so, what is its entry in the table ie. "label" "nolabel" "autolabel" or a data type (see above)
  Dictionary();

  void DictionaryPart1();
  void DictionaryPart2();
  void DictionaryPart3();
};

//############################## END OF DICTIONARY.h #####################################
#endif
