// const char* time_stamp = "$Date: 2006-08-08 15:18:31 +1200 (Tue, 08 Aug 2006) $\n";
// const char* priors_id = "$Id: priors.h 1593 2006-08-08 03:18:31Z adunn $\n";

#if !defined(PRIORS)
#define PRIORS

//############################## PRIORS ##############################
#include <iostream>
#include <string>
#include "development.h"

////////////////////////////////////////////////////////////////////////
template<CDVM>
class Scalar_prior{
  // Used to store the bounds, and the prior in a Bayesian analysis, on a single scalar parameter.
  // Specific prior distributions in Bayesian analysis are classes derived from
  //   Scalar_prior, and should supply prior(), which takes the parameter
  //   value and returns the negative log-prior.
  // The 'type' field is "None" for this base class, or for derived classes, the name of the class
  //   (e.g. "Normal_prior").
  // get_mu() and get_cv() can be supplied in derived classes, and give the mean and c.v.
  //   of the *unbounded* prior  (e.g., if you have a prior which is normal with a mean of 2.5
  //   before truncation at 2.1 and 4.3, get_mu() still returns 2.5).
public:
  std::string type;
  double lower_bound;
  double upper_bound;
  virtual DOUBLE prior(DOUBLE& p);
  virtual double get_mu();
  virtual double get_cv();
  virtual void print(ostream& out = cout);
  Scalar_prior(double _lower_bound, double _upper_bound);
};

template<CDVM>
class Uniform_prior : public Scalar_prior<DVM>{
  // Uniform prior on a single scalar parameter.
public:
  DOUBLE prior(DOUBLE& p);
  void print(ostream& out = cout);
  Uniform_prior(double _lower_bound, double _upper_bound);
};

template<CDVM>
class Uniform_log_prior : public Scalar_prior<DVM>{
  // Uniform-log prior on a single scalar parameter.
public:
  DOUBLE prior(DOUBLE& p);
  void print(ostream& out = cout);
  Uniform_log_prior(double _lower_bound, double _upper_bound);
};

template<CDVM>
class Normal_prior : public Scalar_prior<DVM>{
  // Normal prior on a single scalar parameter.
public:
  DOUBLE prior(DOUBLE& p);
  void print(ostream& out = cout);
  double get_mu(){return mu;}
  double get_cv(){return cv;}
  Normal_prior(double _lower_bound, double _upper_bound, double _mu, double _cv);
private:
  double mu;
  double cv;
};

template<CDVM>
class Normal_by_stdev_prior : public Scalar_prior<DVM>{
  // Normal prior on a single scalar parameter.
public:
  DOUBLE prior(DOUBLE& p);
  void print(ostream& out = cout);
  double get_mu(){return mu;}
  double get_cv(){return mu*stdev;}
  Normal_by_stdev_prior(double _lower_bound, double _upper_bound, double _mu, double _stdev);
private:
  double mu;
  double stdev;
};

template<CDVM>
class Lognormal_prior : public Scalar_prior<DVM>{
  // Lognormal prior on a single scalar parameter.
public:
  DOUBLE prior(DOUBLE& p);
  void print(ostream& out = cout);
  double get_mu(){return mu;}
  double get_cv(){return cv;}
  Lognormal_prior(double _lower_bound, double _upper_bound, double _mu, double _cv);
private:
  double mu;
  double cv;
  double sigma;
};

template<CDVM>
class Normal_log_prior : public Scalar_prior<DVM>{
  // Normal-log prior on a single scalar parameter.
  // Parameterised in terms of the mean and standard deviation of the log-parameter
  //  (though get_mu and get_sigma return results on the untransformed scale)
public:
  DOUBLE prior(DOUBLE& p);
  void print(ostream& out = cout);
  double get_mu();
  double get_cv();
  Normal_log_prior(double _lower_bound, double _upper_bound, double _m, double _s);
private:
  double m;
  double s;
};

template<CDVM>
class Beta_prior : public Scalar_prior<DVM>{
  // Beta prior on a single scalar parameter.
public:
  DOUBLE prior(DOUBLE& p);
  void print(ostream& out = cout);
  double get_mu(){return mu;}
  double get_stdev(){return stdev;}
  double get_Abound(){return Bbound;}
  double get_Bbound(){return Abound;}
  Beta_prior(double _lower_bound, double _upper_bound, double _mu, double _stdev, double _Abound, double _Bbound);
private:
  double mu;
  double stdev;
  double Abound, Bbound;
  double m, n;
  double nu, t;
};

template<CDVM>
class Vector_prior{
  // Used to store the bounds, and the prior in a Bayesian analysis, on a vector of parameters.
  // Specific prior distributions in Bayesian analysis are classes derived from
  //   Vector_prior, and should supply prior(), which takes the vector of parameter
  //   values and returns the negative log-prior.
  // The 'type' field is "None" for this base class, or for derived classes, the name of the class
  //   (e.g. "Normal_vector_prior").
  // For each scalar prior, there is a vector prior where the elements of the vector
  //   are independently distributed according to that scalar prior.
  //   So Normal_prior corresponds to Normal_vector_prior, etc.
  // In addition, normal, lognormal, and normal-log priors with AR(1) correlation structures
  //   are implemented (classes Normal_AR_prior, Normal_log_AR_prior, Normal_log_mean1_AR_prior).
public:
  std::string type;
  dvector lower_bounds;
  dvector upper_bounds;
  virtual DOUBLE prior(const VECTOR& p);
  virtual void print(ostream& out = cout);
  Vector_prior(const dvector& _lower_bounds, const dvector& _upper_bounds);
};

template<CDVM>
class Uniform_vector_prior : public Vector_prior<DVM>{
  // Independent uniform priors on a vector of parameters.
public:
  DOUBLE prior(const VECTOR& p);
  void print(ostream& out = cout);
  Uniform_vector_prior(const dvector& _lower_bounds, const dvector& _upper_bounds);
};

template<CDVM>
class Uniform_log_vector_prior : public Vector_prior<DVM>{
  // Independent uniform-log priors on a vector of parameters.
public:
  DOUBLE prior(const VECTOR& p);
  void print(ostream& out = cout);
  Uniform_log_vector_prior(const dvector& _lower_bounds, const dvector& _upper_bounds);
};

template<CDVM>
class Normal_vector_prior : public Vector_prior<DVM>{
  // Independent normal priors on a vector of parameters.
public:
  DOUBLE prior(const VECTOR& p);
  void print(ostream& out = cout);
  Normal_vector_prior(const dvector& _lower_bounds, const dvector& _upper_bounds,
                      const dvector& _mu, const dvector& _cv);
private:
  dvector mu;
  dvector cv;
};

template<CDVM>
class Normal_by_stdev_vector_prior : public Vector_prior<DVM>{
  // Independent normal priors on a vector of parameters.
public:
  DOUBLE prior(const VECTOR& p);
  void print(ostream& out = cout);
  Normal_by_stdev_vector_prior(const dvector& _lower_bounds, const dvector& _upper_bounds,
                               const dvector& _mu, const dvector& _stdev);
private:
  dvector mu;
  dvector stdev;
};

template<CDVM>
class Lognormal_vector_prior : public Vector_prior<DVM>{
  // Independent lognormal priors on a vector of parameters.
public:
  DOUBLE prior(const VECTOR& p);
  void print(ostream& out = cout);
  Lognormal_vector_prior(const dvector& _lower_bounds, const dvector& _upper_bounds,
                         const dvector& _mu, const dvector& _cv);
private:
  dvector mu;
  dvector cv;
};

template<CDVM>
class Normal_log_vector_prior : public Vector_prior<DVM>{
  // Independent normal-log priors on a vector of parameters.
  // Parameterised in terms of the mean and standard deviation of the log-parameters.
public:
  DOUBLE prior(const VECTOR& p);
  void print(ostream& out = cout);
  Normal_log_vector_prior(const dvector& _lower_bounds, const dvector& _upper_bounds,
                          const dvector& _m, const dvector& _s);
private:
  dvector m;
  dvector s;
};

template<CDVM>
class Beta_vector_prior : public Vector_prior<DVM>{
  // Independent beta priors on a vector of parameters.
public:
  DOUBLE prior(const VECTOR& p);
  void print(ostream& out = cout);
  Beta_vector_prior(const dvector& _lower_bounds, const dvector& _upper_bounds,
                    const dvector& _mu, const dvector& _stdev,
                    const dvector& _Abound, const dvector& _Bbound);
private:
  dvector mu;
  dvector stdev;
  dvector Abound, Bbound;
  dvector m, n;
  dvector nu, t;
};

template<CDVM>
class Normal_AR_prior : public Vector_prior<DVM>{
  // Multivariate normal from a stationary AR(1) process. See specifications.doc.
public:
  DOUBLE prior(const VECTOR& p);
  void print(ostream& out = cout);
  Normal_AR_prior(const dvector& _lower_bounds, const dvector& _upper_bounds,
                  double mu, double sigma, double _rho);
private:
  double mu;
  double sigma;  // not cv!
  double rho;
};

template<CDVM>
class Normal_log_AR_prior : public Vector_prior<DVM>{
  // Multivariate normal-log, where log(p) forms a stationary AR(1) process. See specifications.doc.
public:
  DOUBLE prior(const VECTOR& p);
  void print(ostream& out = cout);
  Normal_log_AR_prior(const dvector& _lower_bounds, const dvector& _upper_bounds,
                      double m, double s, double _rho);
private:
  double m;
  double s;  // not cv!
  double r;
};

template<CDVM>
class Normal_log_mean1_AR_prior : public Vector_prior<DVM>{
  // Multivariate normal-log with mean 1, where E(p_i)=1 and log(p) forms a stationary AR(1) process.
  // See specifications.doc.
public:
  DOUBLE prior(const VECTOR& p);
  void print(ostream& out = cout);
  Normal_log_mean1_AR_prior(const dvector& _lower_bounds, const dvector& _upper_bounds,
                            double s, double _rho);
private:
  double m;
  double s;  // not cv!
  double r;
};

//############################## END OF PRIORS.h ##############################
#endif
