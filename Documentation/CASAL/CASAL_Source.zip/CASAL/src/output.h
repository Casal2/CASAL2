// const char* time_stamp = "$Date: 2012-05-18 09:49:20 +1200 (Fri, 18 May 2012) $\n";
// const char* output_id = "$Id: output.h 4743 2012-05-17 21:49:20Z Dunn $\n";

#if !defined(OUTPUT)
#define OUTPUT

//############################## REQUESTS FOR PRINTING ##############################
#include <string>
#include <vector>
#include <iostream>
#include "parameter_set.h"

//Forward declarations
template<CDVM> class Observations_dataset;
template<CDVM> class Estimation_section;

/////////////////////////////////////////////////////////////////////////////////////
class Print_requests{
  // Lists the things which the estimation section is to print out as it runs,
  //  including the things which the population section should print out when it is
  //   called by the estimation section.
public:
  // Estimation section stuff:
  int parameters; // the population, estimation, and output parameters as they are read in from files
  int unused_parameters; // names of the parameters which are read in and never accessed
  int estimation_section; // a description of the estimation section
  int fits;       // after a model run or a point estimate, print the fits
  int fits_every_eval; // every time the objective function is calculated, print the fits
  int resids;     // when printing the fits, print the residuals as well
  int pearson_resids; // when printing the fits, print the Pearson residuals as well
  int normalised_resids; // when printing the fits, print the normalised residuals as well
  int objective_every_eval; // every time the objective function is calculated, print the objective
                            // function and its components
  int parameters_every_eval; // every time the objective function is calculated, print the free
                             // parameter values, in a verbose format
  int parameter_vector_every_eval; // every time the objective function is calculated, print
                                   // the free parameter values, in the standard parameter file format
                                   // (good for restarting an estimation run when it crashes;
                                   // just copy it out into a text file and restart with -i)
  int covariance; // after an -e or -E run, print the approximate covariance (inverse of the
                  // Hessian approximation) and correlation matrices.
  int printHessian; // after an -e or -E run, print out the Hessian matrix
  int eigenvalues; // after an -e or -E run, print out the eigenvalues of the Hessian matrix
  int yield_diagnostic_output; // while doing MCY/CAY/etc in a -Y run, print out annual catches and biomasses
                               // for diagnostic purposes
  // Population section stuff:
  int population_section; // a description of the population section
  int every_mean_size; // mean size at age for every step in every year (only if population_section=TRUE)
  int requests;     // the requests for outputs passed to the population section
  int results;      // the corresponding outputs
  int initial_state; // the state after initialization
  int state_annually; // the state after every year
  int state_every_step; // the state after every time step
  int final_state; // the state at the end of the run
  dvector print_sizebased_ogives_at; // sizes for which sizebased ogives should be printed
                                     // in an age-based model

  Print_requests(Parameter_set<double,dvector,dmatrix>& o, int suppress_population_printing = 0);
};

//############################## OUTPUT QUANTITIES ##############################
class Quantity_requests{
  // Lists the output quantities which should be extracted once the Estimation_section
  //  has done its thing.
  // (This does not include the objective function and the fits and residuals,
  //   which are the responsibility of the Estimation_section to collect.
  //  Generally it doesn't include things which the Estimation_ and Population_sections should
  //   print out as they go - see class Print_requests above.)
  // The set_request_parameters() function is used to tell the Population_section
  //  about all the quantities it should produce.
public:
  int projection; // are these quantities to be projected into the future?
  std::vector<std::string> scalar_parameters; // the names of the parameters to be extracted
  std::vector<std::string> vector_parameters;
  std::vector<std::string> ogive_parameters;  // here extract the ogive values
  std::vector<std::string> ogive_arguments;   // and here the ogive arguments
  dvector print_sizebased_ogives_at; // in an age-based model, evaluate size-based ogives at these sizes
  int nuisance_qs; // should nuisance q's be extracted?
  int B0, R0, Binitial, Rinitial, Bmean, Rmean; // extract the values of B0, R0, Binitial, Rinitial, Bmean, Rmean?
  int stock_crash; // calculate the projected quantity 'stock_crash'?
                   // The projected expectation of this is stock risk
  std::vector<int> SSBs; // the years for which SSBs should be extracted
  std::vector<int> recruitments; // the years for which absolute recruitments should be extracted
  std::vector<int> YCS; // the years for which YCS should be extracted
  std::vector<int> true_YCS; // the years for which 'true YCS' (YCS * CR * SR) should be extracted
  std::vector<int> Ts; // the years for which climate data T should be extracted
  std::vector<int> migration_annual_variation; // the years for which  migration_annual_variation should be extracted

  std::vector<int> actual_catches; // the years for which actual catches should be extracted. Also used as the years for discards and removals
  int catches_by_stock; // should actual catches be extracted by stock?
  int catches_by_area;  // should actual catches be extracted by area?
  int removals; // should removals be extracted or not?
  int discards; // should discards be extracted or not?
  std::vector<int> fishing_pressures; // the years for which fishing pressures should be extracted
  int disease_biomass_loss; // should the biomass of fish killed by disease in each year be extracted?
  int fits, resids, pearson_resids, normalised_resids; // should fits, residuals, pearson residuals and normalised residuals be extracted for each applicable set of observations?
  int tagged_age_distribution; // for use with tagging with release_type="deterministic": gets the age distribution of tagged fish (sexed or unsexed) in each tagging episode
  Observations_dataset<double,dvector,dmatrix> *pseudo_observations;
  // a pointer to the observations_dataset that will be used to generate the pseudo-fits
  Observations_dataset<double,dvector,dmatrix> *original_observations;
  // a pointer to the original observations_dataset so we can switch back to it
  int initial, current, final, y_enter;
  // the 'initial', 'current', and 'final' years and the recruitment delay 'y_enter'
  //  as extracted from the Population_section
  void set_request_parameters(Parameter_set<double,dvector,dmatrix>& p);
  Quantity_requests(Parameter_set<double,dvector,dmatrix>& o, Estimation_section<double,dvector,dmatrix>& estimation_section, int _projection = 0);
  ~Quantity_requests();
};

class Quantity_results{
  // The key function of the Quantity_results object is get(), which takes
  //  -a Quantity_requests
  //  -an Estimation_section (must be non-differentiable)
  //  -a vector of parameter values
  // and uses the Estimation_section to generate the outputs requested in the Quantity_requests object.
  // These outputs are stored within the Quantity_results, which can be printed.
  // empty() clears the results object.
  // In MCMC, there will be many sets of quantities generated, which we output as a large matrix,
  //  with one row per point in the posterior sample. To do this, we use make_header(), which
  //  generates the header row of the matrix, and make_vector(), which packs all the elements
  //  of the Quantity_results into a vector. Make sure to call get() at least once before make_header()
  //  and make_header() before make_vector().
public:
  void get(Quantity_requests& requests,
           Estimation_section<double,dvector,dmatrix>& estimation);
  std::vector<double> scalar_parameters;
  std::vector<dvector> vector_parameters, ogive_arguments, ogive_parameters;
  std::vector<int> ogives_sizebased_in_agebased;
  std::vector<double> nuisance_qs;
  std::vector<std::string> nuisance_qs_names;
  std::vector<double> B0, R0, Binitial, Rinitial, Bmean, Rmean;
  std::vector<dvector> SSBs, recruitments, YCS, true_YCS, Ts, migration_annual_variation,actual_catches, fishing_pressures, removals, discards;
  std::vector<std::vector<dvector> > actual_catches_by_stock, removals_by_stock, discards_by_stock,actual_catches_by_area, removals_by_area, discards_by_area;
  std::vector<int> stock_crash;
  std::vector<pair<int,double> > disease_biomass_loss;
  std::vector<dmatrix> fits;
  std::vector<dmatrix> resids;
  std::vector<dmatrix> pearson_resids;
  std::vector<dmatrix> normalised_resids;
  std::vector<int> fits_exist;
  std::vector<int> normalised_resids_exist;
  std::vector<std::string> fits_resids_labels;
  std::vector<dvector> fits_resids_years;
  std::vector<dmatrix> tagged_age_distributions;
  std::vector<std::string> tagging_episode_labels;
  std::vector<int> tagging_sexed;
  std::vector<dmatrix> pseudofits;
  std::vector<std::string> pseudofits_labels;
  std::vector<dvector> pseudofits_years;
  std::vector<std::string> stock_names, fishery_names,area_names, migration_annual_variation_names;
  int n_stocks, n_fisheries,n_areas;
  void empty();
  std::string make_header(Quantity_requests& quantity_requests);
  int n_quantities;
  dvector make_vector(Quantity_requests& quantity_requests);
  void print(Quantity_requests& quantity_requests, ostream& out = cout);
  Quantity_results();
};

//############################## END OF OUTPUT.h ##############################
#endif
