// const char* time_stamp = "$Date: 2006-08-08 15:18:31 +1200 (Tue, 08 Aug 2006) $\n";
// const char* user_likelihood_example_cpp_id = "$Id: user.likelihood.example.cpp 1593 2006-08-08 03:18:31Z adunn $\n";

#ifndef USER_LIKELIHOOD_CPP
#define USER_LIKELIHOOD_CPP

//############################# USER LIKELIHOOD.cpp ##########################################
#include "development.h"

//////////////////////////////////////////////////////////////////////////////////////////////
template<CDVM>
DOUBLE user_likelihood(std::string& label, const MATRIX& fits, const MATRIX& observations){

/*

   *** TEMPLATE - BRIAN BULL, 23/5/02 ***

   Use this function to implement new likelihood functions.

   This function takes the observations and fits, and returns the negative-log-likelihoods.

   You need to set the 'dist' argument for each set of observations for which you are supplying
    a likelihood to 'user_supplied'.

   You cannot use nuisance q's for relative time series with user-defined likelihoods (use free q's instead).

   The inputs to this function are the text label of a time series and the observations and fits.
     The obs and fits are stored as matrices. There is one row per year. For abundance data, there is one column.
        For all other data, there is one column per age or size class, per sex if they are sexed observations,
         with males before females. This is exactly the same as the format used by CASAL to print the data.
   The output is the corresponding negative-log-likelihood.
   If you want to use user-defined likelihoods for more than one time series, then you may need to put in
     an if-statement based on the 'label' argument, which tells you which time series is currently being dealt with.

   You need to use the DOUBLE, VECTOR, and MATRIX classes which are templates either for double, dvector and dmatrix
     or for dvariable, dvv, and dvm (apart from double, these are Betadiff classes: see betadiff.h) Note that the indices
     of these VECTORs and MATRIXs should always start at 1 (in this particular function)

*/

/*

   *** Brian Bull, 24/5/02. Calculates a Student's T likelihood for a relative abundance index. ***

   Notes: We use a t-likelihood with 4 degrees of freedom and a scale parameter of 20% of the mean
            (which means the c.v. is over 20%).
          The q for this abundance index must be an ordinary free parameter, not a nuisance parameter.

*/

  DEBUG1("user_likelihood");

  if (label!="acoustics"){
          fatal("user.likelihood.C doesn't know how to calculate a likelihood for " + label);}

  DOUBLE result = 0;
  for (int i=1; i<=observations.rowmax(); i++){
        result += log(fits[i][1]) + 2.5 * log(1 + 0.25*pow((observations[i][1]-fits[i][1])/(0.2*fits[i][1]),2));
  }

  return result;

}
//############################# END OF USER LIKELIHOOD.cpp ##########################################
#endif

