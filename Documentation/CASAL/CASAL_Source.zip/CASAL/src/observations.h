// const char* time_stamp = "$Date: 2006-08-08 15:18:31 +1200 (Tue, 08 Aug 2006) $\n";
// const char* observations_id = "$Id: observations.h 1593 2006-08-08 03:18:31Z adunn $\n";

#if !defined(OBSERVATIONS)
#define OBSERVATIONS

//############################## OBSERVATIONS ##############################
#include "development.h"
#include <iostream>
#include <string>

// Forward declarations
template<CDVM> class Objective;
template<CDVM> class Observations;
template<CDVM> class Parameter_set;
template<CDVM> class Basic_population_section;
template<CDVM> class Ageing_error;
template<CDVM> class Qs;

////////////////////////////////////////////////////////////////////////////
template<CDVM>
class Observations_dataset{
  // This object contains all the observations used in an assessment.
  // The key member is 'obs', a vector of pointers to Observations objects.
  //
  // set_request_parameters() is used to put entries into the Parameter_set which is sent to the
  //   population section, to request the results necessary for calculate_fits() to calculate the fits,
  //   from which get_objective_function() calculates the objective function for each individual
  //   observation and puts the results in objective_components and returns their sum.
  //
  // Use parametric_bootstrap() to randomize all the observations about their fitted values,
  //   according to the specified error distributions (the original observations are not kept).
public:
  std::vector<Observations<DVM>*> obs;
  std::vector<DOUBLE> objective_components;
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  DOUBLE get_objective_function();
  void parametric_bootstrap(long int seed);
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout,int print_fits = 0,int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  void print_objective_components(ostream& out = cout);
  Observations_dataset(Basic_population_section<DVM>& popn,
                       Ageing_error<DVM>* _ageing_error,Parameter_set<DVM>& e,
                       int pseudo=0);
  ~Observations_dataset();
};

template<CDVM>
class Observations{
  // The abstract base class for all types of observations.
  // Provides 'label', 'years', pointers to the 'obs' and 'fits' matrices,
  // and 'objective', the latter a pointer to the Objective object, and
  //   -get_objective_function: calculate and return the value of the objective function.
  //   -parametric_bootstrap: causes all the observation values to be randomized about their fitted
  //                          values, according to the specified error distributions (the original
  //                          observations are not kept)
  //   -get_resids, get_pearson_resids, get_normalised_resids:
  //                           return the residuals, Pearson residuals and normalised residuals
  //                           (calculate_fits() should already have been called)
  //                           Normalised residuals are not defined for all error distributions,
  //                           objective->normalised_residuals_defined == 1 if they are or 0 if not,
  //                           in the latter case, the result of get_normalised_resids is undefined.
  //   -fits_resids_defined (this virtual function usually returns 1 (True) but is overridden for e.g. Age_size where it returns 0, meaning that no fits or residuals are valid
  // Classes derived from Observations need to implement the virtual functions
  //   -set_request_parameters: puts entries into the Parameter_set to request the results
  //                            necessary to calculate the fits.
  //   -calculate_fits: obtain the derived quantities E which are used to calculate the fits,
  //              calculate the fits,
  //              as E for proportions or absolute indices,
  //              or qE for relative observations,
  //              or q(E/max(E))^(1/b) for relative observations with curvature and q_type='scaled',
  //              or q(E)^(1/b) for relative observations with curvature and q_type='standard',
  //              as a matrix with one row per year (row & col indices start at 1).
  //              Store them for use in parametric_bootstrap, print_with_fits, get_objective_function.
  //              It is passed (by reference) the population section after the
  //              population section has been successfully run.
  //   -print: prints out a description, and observed values, and optionally fits, residuals, etc.
  //   -and a constructor, which must at least allocate or zero years, obs, fits, and objective.
  // Relative observations classes also need to implement the virtual functions
  //   -relative: is this a relative time series?
  //   -curvature: does this relative time series have curvature? (and if so, what is its type?)
  //   -get_q_name: what is the label of the q used by this relative time_series?
  //   -set_qs_ptr: set a pointer in the Qs object to point to this time series.
  //  (For relative observations, the calculation of nuisance q's occur at a higher level:
  //   so, relative observations classes derived from Time_series need to reach outside and
  //   grab the current value of q each time they are asked to calculate_fits(). Relative
  //   observations with curvature also need to reach outside to get the current value of b.)
public:
  std::string label;
  dvector *years;
  MATRIX *obs;
  MATRIX *fits;
  Objective<DVM>* objective;
  virtual MATRIX get_resids();
  virtual MATRIX get_pearson_resids();
  virtual MATRIX get_normalised_resids();
  virtual int fits_resids_defined(){return 1;}
  virtual DOUBLE get_objective_function();
  virtual void parametric_bootstrap(long int seed);
  int do_bootstrap; // should we?
  virtual void write_to_file(ostream& o, Parameter_set<DVM> &e) = 0;
  virtual void set_request_parameters(Parameter_set<DVM>& p) = 0;
  virtual void calculate_fits(Basic_population_section<DVM>& popn) = 0;
  virtual void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
                     int print_pearson_resids = 0, int print_normalised_resids = 0) = 0;
  virtual int relative(){return 0;}
  virtual int curvature(){return 0;}
  virtual std::string get_q_name(){return "";}
  virtual void set_qs_ptr(Qs<DVM>* q){fatal("Can't set_qs_ptr except in relative time series");}
  virtual ~Observations();
};

template<CDVM>
class Abundance : public Observations<DVM> {
  // Observations of absolute biomass or total numbers,
  //  optionally after applying a selectivity ogive.
  // The observations and fits matrices have only 1 column.
  // See also the derived class Relative_abundance.
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  Abundance(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label,
            int relative, int pseudo);
protected:
  int n_years, obs_per_year;
private:
  int step;                     // time step in which the observations occur
  int biomass;                  // 1 = biomass, 0 = numbers
  std::string selectivity_name; // the name of the selectivity ogive in the common block, or "none"
  std::string area;             // observations are in this area ("" for a single-area model,
                                // or for observations pooled over all areas)
  std::string stock;            // observations are of this stock only ("" for a single-stock
                                // model, or for observations pooled over all stocks)
  int mature_only;              // 1 = mature fish only, 0 = all fish
  double proportion_mortality;  // observation is after this proportion of the mortality
};

template<CDVM>
Objective<DVM>* make_objective(Parameter_set<DVM>& e, const std::string& command,
                               const dvector& years, int obs_per_year, std::string& label);

template<CDVM>
class Relative_abundance : public Abundance<DVM> {
  // Observations of relative biomass or total numbers,
  //  optionally after applying a selectivity ogive.
  // The observations and fits matrices have only 1 column.
  // Inherits set_request_parameters from class Abundance without modification.
  // Contains a pointer to the Qs object so it can extract the current
  //  values of q and b (using qs_ptr->q[q_name], ->b[q_name]). This is filled in
  //  by the Qs constructor.
public:
  void calculate_fits(Basic_population_section<DVM>& popn);
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  int relative(){return 1;}
  int curvature(){return has_curvature;}
  std::string get_q_name(){return q_name;}
  void set_qs_ptr(Qs<DVM>* _qs_ptr){qs_ptr = _qs_ptr;}
  Relative_abundance(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label, int pseudo);
private:
  int has_curvature;
  std::string q_name;
  std::string q_type;
  DOUBLE q, b;
  Qs<DVM>* qs_ptr;
};

template<CDVM>
class Numbers_at : public Observations<DVM> {
  // Observations of numbers-at-age or -at-size,
  //  optionally sexed, optionally after applying a selectivity ogive.
  // The columns of the observations and fits matrices are
  //  (if unsexed) there are n_classes[1] columns, one per size/age class
  //  (if sexed)   there are n_classes[1] columns for males then n_classes[2] for females
  // See also the derived class Relative_numbers_at.
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  Numbers_at(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label,
             Ageing_error<DVM>* _ageing_error_ptr, int relative, int pseudo);
private:
  std::string command;
protected:
  int n_years, obs_per_year;
private:
  int step;                     // time step in which the observations occur
  int at_size;                  // 1 = numbers-at-size, 0 = numbers-at-age
  int sexed;                    // 1 = sexed, 0 = unsexed
  dvector n_classes;            // number of size/age classes observed;
                                //  male then female if sexed, a 1-vector if unsexed
  dvector min_class, max_class; // minimum and maximum classes; ditto
  dvector class_mins;           // if the observations are size-based in an age-based model,
                                //  class_mins[i] is the minimum size of the ith class.
                                //  If no plus group, the last entry is the maximum
                                //  size of the last class.
  int plus_group;               // indicates whether the last class is a plus group
  dvector class_nums;           // class_nums[i] is the lower limit for the ith bin (for the sizes)
                                // in a size-based model. The upper limit is class_nums[i+1] - 1 .
                                // The class_nums values are not the actual sizes, but refer to the
                                // bin numbers in which the size classes are located. If there is a plus group then
                                // the last bin is class_nums[last entry] inclusive and upwards. If there is no
                                // plus group then the last bin goes from class_nums[last entry - 1] inclusive
                                // up to class_nums[last entry] - 1 .
  dvector class_nums_male;      // As for class_nums, but male only.
  dvector class_nums_female;    // As for class_nums, but female only.
  std::string selectivity_name; // the name of the selectivity ogive in the common block, or "none"
  std::string area;             // observation is in this area ("" for a single-area model)
  double proportion_mortality;  // observation is after this proportion of the mortality
  int ageing_error;              // is there ageing error?
  Ageing_error<DVM>* ageing_error_ptr;
  void print_header(ostream& out,const std::string& what_it_is); // called repeatedly by print()
};

template<CDVM>
class Relative_numbers_at : public Numbers_at<DVM> {
  // Observations of relative numbers-at-age or -at-size,
  //  optionally sexed, optionally after applying a selectivity ogive.
  // The columns of the observations and fits matrices are
  //  (if unsexed) there are n_classes[1] columns, one per size/age class
  //  (if sexed)   there are n_classes[1] columns for males then n_classes[2] for females
  // Inherits set_request_parameters from class Numbers_at without modification.
  // Contains a pointer to the Qs object so it can extract the current
  //  values of q and b (using qs_ptr->q[q_name], ->b[q_name]). This is filled in
  //  by the Qs constructor.
public:
  void calculate_fits(Basic_population_section<DVM>& popn);
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  int relative(){return 1;}
  int curvature(){return has_curvature;}
  std::string get_q_name(){return q_name;}
  void set_qs_ptr(Qs<DVM>* _qs_ptr){qs_ptr = _qs_ptr;}
  Relative_numbers_at(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label,
                      Ageing_error<DVM>* _ageing_error_ptr, int pseudo);
private:
  int has_curvature;
  std::string q_name;
  std::string q_type;
  DOUBLE q, b;
  Qs<DVM>* qs_ptr;
};

template<CDVM>
class Proportions_at : public Observations<DVM> {
  // Observations of proportions-at-age or -at-size,
  //  optionally sexed, optionally after applying a selectivity ogive.
  // The columns of the observations and fits matrices are
  //  (if unsexed) there are n_classes[1] columns, one per size/age class
  //  (if sexed)   there are n_classes[1] columns for males then n_classes[2] for females
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  Proportions_at(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label,
                 Ageing_error<DVM>* _ageing_error_ptr, int pseudo);
private:
  std::string command;
  int n_years, obs_per_year;
  int step;                     // time step in which the observations occur
  int at_size;                  // 1 = proportions-at-size, 0 = proportions-at-age
  int sexed;                    // 1 = sexed, 0 = unsexed
  dvector n_classes;            // number of size/age classes observed;
                                //  male then female if sexed, a 1-vector if unsexed
  dvector min_class, max_class; // minimum and maximum classes; ditto
  dvector class_nums;           // class_nums[i] is the lower limit for the ith bin (for the sizes)
                                // in a size-based model. The upper limit is class_nums[i+1] - 1 .
                                // The class_nums values are not the actual sizes, but refer to the
                                // bin numbers in which the size classes are located. If there is a plus group then
                                // the last bin is class_nums[last entry] inclusive and upwards. If there is no
                                // plus group then the last bin goes from class_nums[last entry - 1] inclusive
                                // up to class_nums[last entry] - 1 .
  dvector class_nums_male;      // As for class_nums, but male only.
  dvector class_nums_female;    // As for class_nums, but female only.
  dvector class_mins;           // if the observations are size-based in an age-based model,
                                //  class_mins[i] is the minimum size of the ith class
                                //  If no plus group, the last entry is the maximum
                                //  size of the last class.
  int plus_group;               // indicates whether the last class is a plus group
  int sum_to_one;               // 1 = observations and fits sum to 1 for each year,
                                // 0 = observations and fits are proportions of the total
                                //     number of fish and can sum to less than 1 if
                                //     not all age/size classes are observed.
  std::string selectivity_name; // the name of the selectivity ogive in the common block, or "none"
  std::string area;             // observation is in this area ("" for a single-area model)
  double proportion_mortality;  // observation is after this proportion of the mortality
  int ageing_error;              // 1 if ageing error is applied, 0 if not
  Ageing_error<DVM>* ageing_error_ptr;
  void print_header(ostream& out, const std::string& what_it_is); // called repeatedly by print()
};

template<CDVM>
class Catch_at : public Observations<DVM> {
  // Observations of fishery catch proportions-at-age or -at-size, optionally sexed.
  // The columns of the observations and fits matrices are
  //  (if unsexed) there are n_classes[1] columns, one per size/age class
  //  (if sexed)   there are n_classes[1] columns for males then n_classes[2] for females
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  Catch_at(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label,
           Ageing_error<DVM>* _ageing_error_ptr, int pseudo);
private:
  std::string command;
  int n_years, obs_per_year;
  std::vector<std::string> fishery;
                                // the labels of the fishery or fisheries from which the data were taken
  int at_size;                  // 1 = proportions-at-size, 0 = proportions-at-age
  int sexed;                    // 1 = sexed, 0 = unsexed
  dvector n_classes;            // number of size/age classes observed;
                                //  male then female if sexed, a 1-vector if unsexed
  dvector min_class, max_class; // minimum and maximum classes; ditto
  dvector class_nums;           // class_nums[i] is the lower limit for the ith bin (for the sizes)
                                // in a size-based model. The upper limit is class_nums[i+1] - 1 .
                                // The class_nums values are not the actual sizes, but refer to the
                                // column numbers in which the size classes are located. If there is a plus group then
                                // the last bin is class_nums[last entry] inclusive and upwards. If there is no
                                // plus group then the last bin goes from class_nums[last entry - 1] inclusive
                                // up to class_nums[last entry] - 1 .
  dvector class_nums_male;      // As for class_nums, but male only.
  dvector class_nums_female;    // As for class_nums, but female only.
  dvector class_mins;           // if the observations are size-based in an age-based model,
                                //  class_mins[i] is the minimum size of the ith class
                                //  If no plus group, the last entry is the maximum
                                //  size of the last class.
  int plus_group;               // indicates whether the last class is a plus group
  int sum_to_one;               // 1 = observations and fits sum to 1 for each year,
                                // 0 = observations and fits are proportions of the total
                                //     number of fish and can sum to less than 1 if
                                //     not all age/size classes are observed.
  int ageing_error;              // 1 if ageing error is applied, 0 if not
  Ageing_error<DVM>* ageing_error_ptr;
  void print_header(ostream& out, const std::string& what_it_is); // called repeatedly by print()
};

template<CDVM>
class Proportions_mature : public Observations<DVM> {
  // Observations of proportions mature,
  //  optionally (usually) sexed, and if so females only,
  //  optionally after applying a selectivity ogive.
  // The columns of the observations and fits matrices are
  //  (if females only) there are n_classes[1] columns for females, one per size/age class
  //  (otherwise)       there are n_classes[1] columns for males then n_classes[2] for females
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  Proportions_mature(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label,
                     Ageing_error<DVM>* _ageing_error_ptr, int pseudo);
private:
  std::string command;
  int n_years, obs_per_year;
  int step;                     // time step in which the observations were taken
  int at_size;                  // 1 = proportions-at-size, 0 = proportions-at-age
  int sexed;                    // 1 = observations are sexed, 0 = not
  int females_only;             // 1 = females, 0 = males then females, only used if sexed==1
  dvector n_classes;            // number of size/age classes observed;
                                //  a 1-vector if unsexed or females only, or male then female otherwise
  dvector min_class, max_class; // minimum and maximum classes; ditto
  dvector class_mins;           // if the observations are size-based in an age-based model,
                                //  class_mins[i] is the minimum size of the ith class
                                //  If no plus group, the last entry is the maximum
                                //  size of the last class.
  int plus_group;               // indicates whether the last class is a plus group
  std::string selectivity_name; // the name of the selectivity ogive in the common block, or "none"
  std::string area;             // observation is in this area ("" for a single-area model)
  double proportion_mortality;  // observation is after this proportion of the mortality
  int ageing_error;             // 1 if ageing error is applied, 0 if not
  Ageing_error<DVM>* ageing_error_ptr;
  void print_header(ostream& out, const std::string& what_it_is); // called repeatedly by print()
};

template<CDVM>
class Proportions_migrating : public Observations<DVM> {
  // Observations of proportions migrating, optionally sexed,
  //  optionally after applying a selectivity ogive.
  // The observations have n_classes[1] columns, one per size/age class.
  // They can be for males, or females, or both combined, but not each separately.
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  Proportions_migrating(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label,
                        Ageing_error<DVM>* _ageing_error_ptr, int pseudo);
private:
  std::string command;
  int n_years, obs_per_year;
  std::string migration;        // text label of the migration concerned
  int at_size;                  // 1 = proportions-at-size, 0 = proportions-at-age
  int sex;                      // 1 = males, 2 = females, 0 = both sexes combined
  dvector n_classes;            // number of size/age classes observed;
                                //  a 1-vector if females only, or male then female otherwise
  dvector min_class, max_class; // minimum and maximum classes; ditto
  dvector class_mins;           // if the observations are size-based in an age-based model,
                                //  class_mins[i] is the minimum size of the ith class
                                //  If no plus group, the last entry is the maximum
                                //  size of the last class.
  int plus_group;               // indicates whether the last class is a plus group
  std::string selectivity_name; // the name of the selectivity ogive in the common block, or "none"
  int ageing_error;             // 1 if ageing error is applied, 0 if not
  Ageing_error<DVM>* ageing_error_ptr;
  void print_header(ostream& out, const std::string& what_it_is); // called repeatedly by print()
};

template<CDVM>
class Age_size : public Observations<DVM> {
  // Observations of age and size, sexed if the model is sexed,
  //   used primarily to fit size-at-age parameters.
  // This kind of observation is implemented rather differently from
  //   the standard ones like Abundance or Numbers_at. In fact it's
  //   a bit of a struggle to get it to fit into the same framework.
  // The obs and fits members are not used - because the observations
  //   are bi- or tri-variate (ie. age, size, ?sex) and the fits are
  //   really not defined. Nor are residuals, so all the functions
  //   relating to residuals are overridden with dummy functions.
  //   The fits_resids_defined member is overridden with a 0-returning-function.
  //   The objective pointer is not used because it has to work with a
  //   rather specialised group of likelihoods, and so get_objective_function
  //   also has to be overridden - it is no longer just a call of the
  //   objective member. Actually, most of the likelihood calculations
  //   are now done by 'calculate_fits' since it is called at the right time -
  //   And get_objective_function just adds up the neg-log-likelihood contribution of each fish.
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  DOUBLE get_objective_function();
  int fits_resids_defined(){return 0;} // not defined for this observations type
  MATRIX get_resids(); // overide - do nothing
  MATRIX get_pearson_resids(); // do nothing
  MATRIX get_normalised_resids(); // do nothing
  void parametric_bootstrap(long int seed); // must be provided as the 'objective' pointer is null
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  Age_size(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label,
           Ageing_error<DVM>* _ageing_error_ptr, int pseudo);
private:
  std::string command;
  int year, step;
  double proportion_mortality;
  std::string stock, area, selectivity_name, sample;
  int n_fish;
  int sexed;
  dvector sizes, ages, sexes;
  VECTOR neg_log_likelihoods;
  int n_stocks;
  std::vector<std::string> stock_names;
  int ageing_error; // 1 if ageing error is applied, 0 if not
  Ageing_error<DVM>* ageing_error_ptr;
  int selectivity; // 1 if a selectivity is applied, 0 if not
  std::string size_at_age_dist;
  DOUBLE get_f(Basic_population_section<DVM>& popn,std::string stock,int a,int s,double l);
  dvector quantile_breaks; // 5 evenly spaced quantiles of std normal distn - used in get_f
};

template<CDVM>
class Age_at_maturation : public Observations<DVM> {
  // Observations of age at maturation, sexed if the model is sexed,
  //   used primarily to fit maturation parameters.
  // This kind of observation is implemented rather differently from
  //   the standard ones like Abundance or Numbers_at. In fact it's
  //   a bit of a struggle to get it to fit into the same framework.
  //   Much more like Age_size.
  // The obs and fits members are not used - because the observations
  //   are bi- or tri-variate (ie. age at maturity, age at capture, ?sex)
  //   and the fits are really not defined. Nor are residuals, so all the functions
  //   relating to residuals are overridden with dummy functions.
  //   The fits_resids_defined member is overridden with a 0-returning-function.
  //   The objective pointer is not used because it has to work with a
  //   rather specialised group of likelihoods, and so get_objective_function
  //   also has to be overridden - it is no longer just a call of the
  //   objective member. Actually, most of the likelihood calculations
  //   are now done by 'calculate_fits' since it is called at the right time -
  //   And get_objective_function just adds up the neg-log-likelihood contribution of each fish.
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  DOUBLE get_objective_function();
  int fits_resids_defined(){return 0;} // not defined for this observations type
  MATRIX get_resids(); // overide - do nothing
  MATRIX get_pearson_resids(); // do nothing
  MATRIX get_normalised_resids(); // do nothing
  void parametric_bootstrap(long int seed); // must be provided as the 'objective' pointer is null
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  Age_at_maturation(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label,
           Ageing_error<DVM>* _ageing_error_ptr, int pseudo);
private:
  std::string command;
  std::string stock;
  int n_fish;
  int sexed;
  int k; // years until maturity is detectible
  dvector sampled_ages, maturation_ages, sexes;
  VECTOR neg_log_likelihoods;
  int n_stocks;
  std::vector<std::string> stock_names;
  int ageing_error; // 1 if ageing error is applied, 0 if not
  Ageing_error<DVM>* ageing_error_ptr;
};

template<CDVM>
class Selectivity_at : public Observations<DVM> {
  // Selectivity ogive observations,
  //  used as pseudo-observations to extract the values of the selectivity for each column of the partition
  //  for a given year, time step, age, sex...,
  //  particularly useful for extracting size-based selectivities as values-at-age.
  // one ogive for each year provided (can also be split male / female)
  // there must be enough criteria re. stock, area etc to determine a single set
  // of ogive values otherwise there is an error-out in the population section.
  // The columns of the observations and fits matrices are
  //  (if unsexed) there are n_classes[1] columns, one per size/age class
  //  (if sexed)   there are n_classes[1] columns for males then n_classes[2] for females
  // 26 Feb 04: now usable as real observations as well.
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  void write_to_file(ostream& o, Parameter_set<DVM> &e); // fatal error
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  Selectivity_at(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label, int pseudo);
private:
  std::string command;
  std::string selectivity_name; // the name of the selectivity ogive in the common block, or "none"
  int n_years, obs_per_year;
  int step;                     // time step in which the observations occur
  int at_size;                  // 1 = ogive-at-size, 0 = ogive-at-age
  int sexed;                    // 1 = sexed, 0 = unsexed
  dvector n_classes;            // number of size/age classes observed;
                                //  male then female if sexed, a 1-vector if unsexed
  dvector min_class, max_class; // minimum and maximum classes; ditto
  std::string area;             // observation is in this area ("" for a single-area model)
  double proportion_mortality;  // observation is after this proportion of the mortality
  std::string stock;            // observations are of this stock only ("" for a single-stock
                                // model, or for observations pooled over all stocks)
  int mature_only;              // 1 = mature fish only, 0 = all fish
  void print_header(ostream& out, const std::string& what_it_is); // called repeatedly by print()
};

template<CDVM>
class Tag_release : public Observations<DVM> {
  // Tag-release observations,
  //   size frequency of tagged fish at a particular tagging event.
  // Used when you have an LF of tagged fish and you want to estimate
  //   the ageF (as props_male, _female, or _all in the @tag block).
  // The fits are calculated before applying handling mortality.
  // Not many parameters, as CASAL can find the time,area,etc in the @tag block.
  // The columns of the observations and fits matrices are
  //  (if unsexed) there is one column per size class
  //  (if sexed)   there is one column per size class for males, then the same for females.
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  Tag_release(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label, int pseudo);
private:
  std::string command;
  std::string tag_label;        // which tagging event is it? This is the label of a @tag block
  std::string tag;              // which tag is being applied? We find this in the @tag block
  int year, step;               // only one year - we find this in the @tag block
  std::string area, stock;      // again we find these in the @tag block - can be area="" for all areas, usually stock="" for all stocks
  int sexed;                    // are the observations?
  dvector class_mins;           // class_mins[i] is the minimum size of the ith class
                                //  If no plus group, the last entry is the maximum
                                //  size of the last class.
  int plus_group;               // indicates whether the last class is a plus group
  int n_classes, obs_per_year;
  void print_header(ostream& out, const std::string& what_it_is); // called repeatedly by print()
};

template<CDVM>
class Tag_recapture : public Observations<DVM> {
  // Observations of tagged fish after recapture, usually sexed,
  //  for a specific tag.
  // The way the data are interpreted depends on the key parameter "sample".
  // sample="age" means that there is an age frequency for inspected fish
  //   and another for tagged fish,
  // sample="size" means that there is an size frequency for inspected fish
  //   and another for tagged fish (can be in age or size based model),
  // sample="age-size" means there is a size frequency for inspected fish
  //   and an age frequency for tagged fish (age based model only).
  // more sample options will be added later.
  // A selectivity ogive can be used but currently only for sample="size" or "age-size"
  //  in an age-based model (otherwise it would make no difference to the likelihood).
  // Ageing error can be used for sample="age" or "age-size" only.
  // A specialised likelihood is used.
  // So the obs and fits members are not used.
  // (quoting from a similar class:) Nor are residuals, so all the functions
  //   relating to residuals are overridden with dummy functions.
  //   The fits_resids_defined member is overridden with a 0-returning-function.
  //   The objective pointer is not used because it has to work with a
  //   rather specialised group of likelihoods, and so get_objective_function
  //   also has to be overridden - it is no longer just a call of the
  //   objective member. Actually, most of the likelihood calculations
  //   are now done by 'calculate_fits' since it is called at the right time -
  //   And get_objective_function just adds up the neg-log-likelihood contribution of each fish.
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  void calculate_fits(Basic_population_section<DVM>& popn);
  DOUBLE get_objective_function(); // must be provided as the 'objective' pointer is null
  int fits_resids_defined(){return 0;} // not defined for this observations type
  MATRIX get_resids(); // overide - do nothing
  MATRIX get_pearson_resids(); // do nothing
  MATRIX get_normalised_resids(); // do nothing
  void parametric_bootstrap(long int seed); // must be provided as the 'objective' pointer is null
  void write_to_file(ostream& o, Parameter_set<DVM> &e);
  void print(ostream& out = cout, int print_fits = 0, int print_resids = 0,
             int print_pearson_resids = 0, int print_normalised_resids = 0);
  Tag_recapture(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e, const std::string& _label,
                     Ageing_error<DVM>* _ageing_error_ptr, int pseudo);
private:
  std::string command;
  int n_years, obs_per_year, scanned_obs_per_year; // scanned_obs_per_year only used with sample="age-size"
  int step;                     // time step in which the observations were taken
  std::string sample;           // "age" or "size" or "age-size" so far
  std::string tag_name;         // label from @tag_names
  DOUBLE detection_probability; // between 0 and 1, chance that a tag is spotted in the sample
  int sexed;                    // 1 = observations are sexed, 0 = not
  int n_recaptured_classes, min_recaptured_class, max_recaptured_class;  // number of size/age classes, 1 to n_classes if size-based or min_age to max_age if age-based
  int n_scanned_classes, min_scanned_class, max_scanned_class; // ditto
  dvector class_mins;           // if sample="size" or "age-size" in an age-based model,
                                //  class_mins[i] is the minimum size of the ith class
                                //  If no plus group, the last entry is the maximum
                                //  size of the last class.
  int plus_group;               // if sample="size" or "age-size" in an age-based model,
                                // indicates whether the last class is a plus group
  std::string selectivity_name; // the name of the selectivity ogive in the common block, or "none"
  std::string area;             // observation is in this area ("" for a single-area model)
  double proportion_mortality;  // observation is after this proportion of the mortality
  int ageing_error;             // 1 if ageing error is applied, 0 if not
  Ageing_error<DVM>* ageing_error_ptr;
  dmatrix scanned;                              // 1 row per year. Rows and columns start from 1.
                                // If unsexed, columns cover min_scanned_class...max_scanned_class; if sexed, min_scanned_class...max_scanned_class for males then min_scanned_class...max_scanned_class for females.
  dmatrix recaptured;                   // 1 row per year. Rows and columns start from 1.
                                // If unsexed, columns cover min_recaptured_class...max_recaptured_class; if sexed, min_recaptured_class...max_recaptured_class for males then min_recaptured_class...max_recaptured_class for females.
  MATRIX expected_props;        // same size as recaptured - proportion tagged * detection_probability
  MATRIX scanned_by_age;        // same size as recaptured - only used for sample=="age-size"
  MATRIX neg_log_likelihoods;   // same size as recaptured
  MATRIX scan_neg_log_likelihoods;   // same size as scanned - only used for sample=="age-size"
  MATRIX popn_size_props;       // same size as scanned - only used for sample=="age-size"
  double delta;                 // robustification parameter in the likelihood
  double dispersion;            // overdispersion parameter (phi) in the likelihood
};

//############################## END OF OBSERVATIONS.h ##############################
#endif
