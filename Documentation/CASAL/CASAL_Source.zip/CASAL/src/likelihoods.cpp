// const char* time_stamp = "$Date: 2012-01-18 17:54:51 +1300 (Wed, 18 Jan 2012) $\n";
// const char* likelihoods_cpp_id = "$Id: likelihoods.cpp 4494 2012-01-18 04:54:51Z Dunn $\n";

//############################## OBJECTIVE FUNCTIONS ##############################
#include "likelihoods.h"
#include "parameter_set.h"
#include "user.likelihood.cpp"

////////////////////////////////////////////////////////////////////////////////////
template<CDVM>
int Objective<DVM>::normalised_resids_defined(){
  // Normalised residuals are not defined in the general case, though some Objectives define them.
  return 0;
}

template<CDVM>
MATRIX Objective<DVM>::get_normalised_resids(const MATRIX& obs, const MATRIX& fits){
  // The default, for objective types for which normalised residuals are undefined.
  // Return a nonsense value.
  DEBUG2("Objective::get_normalised_resids");
  MATRIX zero(1,1,1,1);
  zero.initialize();
  return 0;
}

template<CDVM>
DOUBLE Multinomial_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // Calculate the likelihood.
  DEBUG1("Multinomial_likelihood::obj_value");
  DOUBLE result=0;
  dvector r_vec(1,fits.colmax());
  r_vec = r;
  for (int y=1; y<=fits.rowmax(); y++){
    if (min(obs[y]+r_vec) <= 0){
      fatal("You have specified a multinomial likelihood for nonpositive observations, try increasing r");}
    if (min(fits[y]+r_vec) <= 0){
      fatal("You have specified a multinomial likelihood for observations with nonpositive fits, try increasing r");}
    result += sum(elem_prod((*N)[y],obs[y]+r_vec,log(elem_div(obs[y]+r_vec,fits[y]+r_vec))));
  }
  if (result != result){
    cerr << "obs " << obs << "\nfits\n" << fits << "\nN\n" << *N << "\nr_vec\n" << r_vec << '\n';
    fatal("Multinomial likelihood calculation has produced a NaN, possibly due to a 0 observation. Try setting r to a very small value.");}
  return result;
}

template<CDVM>
void Multinomial_likelihood<DVM>::set_process_error(DOUBLE& V){
  // Sets the process error N.
  DEBUG2("Multinomial_likelihood::set_process_error");
  for (int i=N->rowmin(); i<=N->rowmax(); i++){
    for (int j=N->colmin(); j<=N->colmax(); j++){
      (*N)[i][j] = 1 / (1/(*N_base)[i][j] + 1/V);
    }
  }
  this->process_error_val = V;
}

template<CDVM>
MATRIX Multinomial_likelihood<DVM>::bootstrap_observations(const MATRIX& fits, long int seed){
  // Return a parametric bootstrap of observations around the fits.
  // A couple of assumptions here: We ignore the robustifying constant r and round N up to the next integer.
  // We require that N is a constant for each year, otherwise it's not really a legitimate likelihood.
  DEBUG1("Multinomial_likelihood::bootstrap_observations");
  MATRIX obs(1,fits.rowmax(),1,fits.colmax());
  for (int y=obs.rowmin(); y<=obs.rowmax(); y++){
          DOUBLE first_N = (*N)[y][N->colmin()];
          for (int j=N->colmin()+1; j<=N->colmax(); j++){
                  if ((*N)[y][j] != first_N){
                          fatal("You cannot bootstrap from multinomial observations unless the same value of N is used for all observations occurring in the same year.");
                  }
          }
          int N_to_use = (int) ceil(value(first_N));
          VECTOR year_fits(fits[y]);
          dvector year_probs(value(fits[y] / sum(fits[y])));
          VECTOR year_boot(fits.colmin(),fits.colmax());
          year_boot.fill_multinomial_counts(seed,year_probs,N_to_use);
          year_boot = year_boot / sum(year_boot) * sum(year_fits);
          obs[y] = year_boot;
  }
  return obs;
}

template<CDVM>
MATRIX Multinomial_likelihood<DVM>::get_std_devs(const MATRIX& obs, const MATRIX& fits){
  // Calculate the standard deviation of each observation.
  DEBUG2("Multinomial_likelihood::get_std_devs");
  dmatrix ones(1,fits.rowmax(),1,fits.colmax());
  ones = 1;
  MATRIX zFits(1,fits.rowmax(),1,fits.colmax());
  zFits = fits;
  for (int i=1; i<=fits.rowmax(); i++){
    for (int j=1; j<=fits.colmax(); j++){
      if (zFits[i][j] < r) {
        zFits[i][j] = r/(2.0-(fits[i][j]/r));
      }
    }
  }
  return sqrt(elem_div(elem_prod(zFits,ones-zFits),*N));
}

template<CDVM>
void Multinomial_likelihood<DVM>::print(ostream& out){
  DEBUG2("Multinomial_likelihood::print");
  out << "multinomial likelihood, with r = " << r << ", N =\n" << *N << '\n';
}

template<CDVM>
Multinomial_likelihood<DVM>::Multinomial_likelihood(Parameter_set<DVM>& e,
                                                    const std::string& command,
                                                    const dvector& years){
  // Construct the likelihood object.
  DEBUG2("Multinomial_likelihood::Multinomial_likelihood");
  this->type = "Multinomial_likelihood";
  r = e.get_constant(command+"r",0);
  int n_obs;
  if (!e.present(command+"tag_label")){
    n_obs = e.get_constant_vector(command+dtos(years[1])).size();
  } else {
        // this is tagging data, need another way to get n_obs
        dvector class_mins(e.get_constant_vector(command+"class_mins"));
        int plus_group = e.get_int(command+"plus_group",1);
        int n_classes = class_mins.size()-1+plus_group;
        int sexed = e.present(command+"props_male")!=0;
        n_obs = (1+sexed)*n_classes;
  }
  N = new MATRIX(1,years.size(),1,n_obs);
  N_base = new dmatrix(1,years.size(),1,n_obs);
  if (e.present(command+"N_"+dtos(years[1]))){
    // a single N is supplied for each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N_"+dtos(years[y]));}
  } else if (e.present(command+"N")){
    // a single N is supplied for all years
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N");}
  } else {
    // an N is supplied for each observation in each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant_vector(command+"Ns_"+dtos(years[y]));}
  }
  this->process_error_parname = command+"N_process_error";
  this->has_process_error = e.present(this->process_error_parname);
  if (this->has_process_error){
    DOUBLE process_error = e.get_estimable(this->process_error_parname);
    set_process_error(process_error);
  }
  if (e.present(command+"cv_process_error") || e.present(command+"stdev_process_error")){
          fatal("Cannot use cv_process_error or stdev_process_error with a multinomial likelihood - perhaps use N_process_error?");}
}

template<CDVM>
  Multinomial_likelihood<DVM>::~Multinomial_likelihood(){
  DEBUG2("~Multinomial_likelihood");
  delete N_base;
  delete N;
}

template<CDVM>
DOUBLE Multinomial_withconst_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // Calculate the likelihood.
  DEBUG1("Multinomial_withconst_likelihood::obj_value");
  DOUBLE result=0;
  for (int y=1; y<=fits.rowmax(); y++){
    result += -lngamma((*N)[y][1]+1); // CONTROVERSIAL - Assumes here a single value of N for all partition classes. May not be the case.
    for (int i=1; i<=fits.colmax(); i++){
                result += lngamma((*N)[y][i]*obs[y][i]+1);
                result += -(*N)[y][i]*obs[y][i]*log(zerofun(fits[y][i],delta));
        }
  }
  if (result != result){
    cerr << "obs " << obs << "\nfits\n" << fits << "\nN\n" << *N << '\n';
    fatal("Multinomial likelihood calculation has produced a NaN.");}
  return result;
}

template<CDVM>
void Multinomial_withconst_likelihood<DVM>::set_process_error(DOUBLE& V){
  // Sets the process error N.
  DEBUG2("Multinomial_withconst_likelihood::set_process_error");
  for (int i=N->rowmin(); i<=N->rowmax(); i++){
    for (int j=N->colmin(); j<=N->colmax(); j++){
      (*N)[i][j] = 1 / (1/(*N_base)[i][j] + 1/V);
    }
  }
  this->process_error_val = V;
}

template<CDVM>
MATRIX Multinomial_withconst_likelihood<DVM>::bootstrap_observations(const MATRIX& fits, long int seed){
  // Return a parametric bootstrap of observations around the fits.
  // A couple of assumptions here: We ignore the robustifying constant delta and round N up to the next integer.
  DEBUG1("Multinomial_withconst_likelihood::bootstrap_observations");
  MATRIX obs(1,fits.rowmax(),1,fits.colmax());
  for (int y=obs.rowmin(); y<=obs.rowmax(); y++){
          DOUBLE first_N = (*N)[y][N->colmin()]; // ok since all N values are the same within each year
          for (int j=N->colmin()+1; j<=N->colmax(); j++){
                  if ((*N)[y][j] != first_N){
                          fatal("You cannot bootstrap from multinomial observations unless the same value of N is used for all observations occurring in the same year.");
                  }
          }
          int N_to_use = (int) ceil(value(first_N));
          VECTOR year_fits(fits[y]);
          dvector year_probs(value(fits[y] / sum(fits[y])));
          VECTOR year_boot(fits.colmin(),fits.colmax());
          year_boot.fill_multinomial_counts(seed,year_probs,N_to_use);
          year_boot = year_boot / sum(year_boot) * sum(year_fits);
          obs[y] = year_boot;
  }
  return obs;
}

template<CDVM>
MATRIX Multinomial_withconst_likelihood<DVM>::get_std_devs(const MATRIX& obs, const MATRIX& fits){
  // Calculate the standard deviation of each observation.
  DEBUG2("Multinomial_withconst_likelihood::get_std_devs");
  dmatrix ones(1,fits.rowmax(),1,fits.colmax());
  ones = 1;
  MATRIX zFits(1,fits.rowmax(),1,fits.colmax());
  zFits = fits;
  for (int i=1; i<=fits.rowmax(); i++){
    for (int j=1; j<=fits.colmax(); j++){
      if (zFits[i][j] < delta) {
        zFits[i][j] = delta/(2.0-(fits[i][j]/delta));
      }
    }
  }
  return sqrt(elem_div(elem_prod(zFits,ones-zFits),*N));
}

template<CDVM>
void Multinomial_withconst_likelihood<DVM>::print(ostream& out){
  DEBUG2("Multinomial_withconst_likelihood::print");
  out << "multinomial likelihood, with delta = " << delta << ", N =\n" << *N << '\n';
}

template<CDVM>
Multinomial_withconst_likelihood<DVM>::Multinomial_withconst_likelihood(Parameter_set<DVM>& e,
                                                    const std::string& command,
                                                    const dvector& years){
  // Construct the likelihood object.
  DEBUG2("Multinomial_withconst_likelihood::Multinomial_withconst_likelihood");
  this->type = "Multinomial_withconst_likelihood";
  delta = e.get_constant(command+"r",1e-11);
  int n_obs;
  if (!e.present(command+"tag_label")){
    n_obs = e.get_constant_vector(command+dtos(years[1])).size();
  } else {
        // this is tagging data, need another way to get n_obs
        dvector class_mins(e.get_constant_vector(command+"class_mins"));
        int plus_group = e.get_int(command+"plus_group",1);
        int n_classes = class_mins.size()-1+plus_group;
        int sexed = e.present(command+"props_male")!=0;
        n_obs = (1+sexed)*n_classes;
  }
  N = new MATRIX(1,years.size(),1,n_obs);
  N_base = new dmatrix(1,years.size(),1,n_obs);
  if (e.present(command+"N_"+dtos(years[1]))){
    // a single N is supplied for each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N_"+dtos(years[y]));}
  } else if (e.present(command+"N")){
    // a single N is supplied for all years
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N");}
  } else {
          /* This option disallowed for the multinomial now...
    // an N is supplied for each observation in each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant_vector(command+"Ns_"+dtos(years[y]));}
     */ fatal("You have not supplied the N or N_[year] subcommands for a multinomial likelihood. One or other is required. You may have used the Ns_[year] subcommand, which is no longer allowed for the multinomial - a single N value must be submitted for each year.");
  }
  this->process_error_parname = command+"N_process_error";
  this->has_process_error = e.present(this->process_error_parname);
  if (this->has_process_error){
    DOUBLE process_error = e.get_estimable(this->process_error_parname);
    set_process_error(process_error);
  }
  if (e.present(command+"cv_process_error") || e.present(command+"stdev_process_error")){
          fatal("Cannot use cv_process_error or stdev_process_error with a multinomial likelihood - perhaps use N_process_error?");}
}

template<CDVM>
  Multinomial_withconst_likelihood<DVM>::~Multinomial_withconst_likelihood(){
  DEBUG2("~Multinomial_withconst_likelihood");
  delete N_base;
  delete N;
}

template<CDVM>
DOUBLE Fournier_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // Calculate the likelihood.
  DEBUG1("Fournier_likelihood::obj_value");
  int years = fits.rowmax();
  int n = fits.colmax();
  MATRIX E_dash(1,years,1,n);
  MATRIX N_dash(1,years,1,n);
  for (int i=1; i<=years; i++){
    for (int j=1; j<=n; j++){
      E_dash[i][j] = (1-fits[i][j]) * fits[i][j] + 0.1/n;
      N_dash[i][j] = fmin((*N)[i][j],1000.0);
    }
  }
  dvector small(1,n);
  small = 0.01;
  DOUBLE result=0;
  for (int y=1; y<=years; y++){
    result += 0.5*sum(log(E_dash[y]))
      - sum(log(exp(elem_div(-elem_prod(obs[y]-fits[y],obs[y]-fits[y]),2*elem_div(E_dash[y],N_dash[y])))+small));
  }
  return result;
}

template<CDVM>
void Fournier_likelihood<DVM>::set_process_error(DOUBLE& V){
  // Sets the process error N.
  DEBUG2("Fournier_likelihood::set_process_error");
  for (int i=N->rowmin(); i<=N->rowmax(); i++){
    for (int j=N->colmin(); j<=N->colmax(); j++){
      (*N)[i][j] = 1 / (1/(*N_base)[i][j] + 1/V);
    }
  }
  this->process_error_val = V;
}

template<CDVM>
MATRIX Fournier_likelihood<DVM>::get_std_devs(const MATRIX& obs, const MATRIX& fits){
  // Calculate the standard deviation of each observation.
  DEBUG2("Fournier_likelihood::get_std_devs");
  int years = fits.rowmax();
  int n = fits.colmax();
  MATRIX E_dash(1,years,1,n);
  MATRIX N_dash(1,years,1,n);
  for (int i=1; i<=years; i++){
    for (int j=1; j<=n; j++){
      E_dash[i][j] = (1-fits[i][j]) * fits[i][j] + 0.1/n;
      N_dash[i][j] = fmin((*N)[i][j],1000.0);
    }
  }
  MATRIX result(sqrt(elem_div(E_dash,N_dash)));
  return result;
}

template<CDVM>
MATRIX Fournier_likelihood<DVM>::bootstrap_observations(const MATRIX& fits, long int seed){
  // Return a parametric bootstrap of observations around the fits.
  // We bootstrap as if the multinomial likelihood had been used instead of the Fournier (which is a pseudo-likelihood).
  // A couple of further assumptions here: We ignore the robustifying constant r and round N up to the next integer.
  // We require that N is a constant for each year, otherwise it's not really a legitimate likelihood.
  DEBUG1("Fournier_likelihood::bootstrap_observations");
  MATRIX obs(1,fits.rowmax(),1,fits.colmax());
  for (int y=obs.rowmin(); y<=obs.rowmax(); y++){
          DOUBLE first_N = (*N)[y][N->colmin()];
          for (int j=N->colmin()+1; j<=N->colmax(); j++){
                  if ((*N)[y][j] != first_N){
                          fatal("You cannot bootstrap from multinomial observations unless the same value of N is used for all observations occurring in the same year.");
                  }
          }
          int N_to_use = (int) ceil(value(first_N));
          VECTOR year_fits(fits[y]);
          dvector year_probs(value(fits[y] / sum(fits[y])));
          VECTOR year_boot(fits.colmin(),fits.colmax());
          year_boot.fill_multinomial_counts(seed,year_probs,N_to_use);
          year_boot = year_boot / sum(year_boot) * sum(year_fits);
          obs[y] = year_boot;
  }
  return obs;
}

template<CDVM>
void Fournier_likelihood<DVM>::print(ostream& out){
  DEBUG2("Fournier_likelihood::print");
  out << "Fournier likelihood, with N =\n" << *N << '\n';
}

template<CDVM>
Fournier_likelihood<DVM>::Fournier_likelihood(Parameter_set<DVM>& e,
                                              const std::string& command,
                                              const dvector& years){
  // Construct the likelihood object.
  DEBUG2("Fournier_likelihood::Fournier_likelihood");
  this->type = "Fournier_likelihood";
  int n_obs;
  if (!e.present(command+"tag_label")){
    n_obs = e.get_constant_vector(command+dtos(years[1])).size();
  } else {
        // this is tagging data, need another way to get n_obs
        dvector class_mins(e.get_constant_vector(command+"class_mins"));
        int plus_group = e.get_int(command+"plus_group",1);
        int n_classes = class_mins.size()-1+plus_group;
        int sexed = e.present(command+"props_male")!=0;
        n_obs = (1+sexed)*n_classes;
  }
  N = new MATRIX(1,years.size(),1,n_obs);
  N_base = new dmatrix(1,years.size(),1,n_obs);
  if (e.present(command+"N_"+dtos(years[1]))){
    // a single N is supplied for each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N_"+dtos(years[y]));}
  } else if (e.present(command+"N")){
    // a single N is supplied for all years
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N");}
  } else {
    // an N is supplied for each observation in each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant_vector(command+"Ns_"+dtos(years[y]));}
  }
  for (int y=1; y<=years.size(); y++){
          if (min((*N)[y]) <= 0){
                  fatal("You have supplied a nonpositive N for a Fournier likelihood");}}
  this->process_error_parname = command+"N_process_error";
  this->has_process_error = e.present(this->process_error_parname);
  if (this->has_process_error){
    DOUBLE process_error = e.get_estimable(this->process_error_parname);
    set_process_error(process_error);
  }
  if (e.present(command+"cv_process_error") || e.present(command+"stdev_process_error")){
          fatal("Cannot use cv_process_error or stdev_process_error with a Fournier likelihood - perhaps use N_process_error?");}
}

template<CDVM>
  Fournier_likelihood<DVM>::~Fournier_likelihood(){
  DEBUG2("~Fournier_likelihood");
  delete N_base;
  delete N;
}

template<CDVM>
DOUBLE Coleraine_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // Calculate the likelihood.
  DEBUG1("Coleraine_likelihood::obj_value");
  int years = fits.rowmax();
  int n = fits.colmax();
  MATRIX O_dash(1,years,1,n);
  MATRIX N_dash(1,years,1,n);
  for (int i=1; i<=years; i++){
    for (int j=1; j<=n; j++){
      O_dash[i][j] = (1-obs[i][j]) * obs[i][j] + 0.1/n;
      N_dash[i][j] = fmin((*N)[i][j],1000.0);
    }
  }
  dvector small(1,n);
  small = 0.01;
  DOUBLE result=0;
  for (int y=1; y<=years; y++){
    result += 0.5*sum(log(O_dash[y]))
      - sum(log(exp(elem_div(-elem_prod(obs[y]-fits[y],obs[y]-fits[y]),2*elem_div(O_dash[y],N_dash[y])))+small));
  }
  return result;
}

template<CDVM>
void Coleraine_likelihood<DVM>::set_process_error(DOUBLE& V){
  // Sets the process error N.
  DEBUG2("Coleraine_likelihood::set_process_error");
  for (int i=N->rowmin(); i<=N->rowmax(); i++){
    for (int j=N->colmin(); j<=N->colmax(); j++){
      (*N)[i][j] = 1 / (1/(*N_base)[i][j] + 1/V);
    }
  }
  this->process_error_val = V;
}

template<CDVM>
MATRIX Coleraine_likelihood<DVM>::bootstrap_observations(const MATRIX& fits, long int seed){
  // Return a parametric bootstrap of observations around the fits.
  // We bootstrap as if the multinomial likelihood had been used instead of the Coleraine (which is a pseudo-likelihood).
  // A couple of further assumptions here: We ignore the robustifying constant r and round N up to the next integer.
  // We require that N is a constant for each year, otherwise it's not really a legitimate likelihood.
  DEBUG1("Coleraine_likelihood::bootstrap_observations");
  MATRIX obs(1,fits.rowmax(),1,fits.colmax());
  for (int y=obs.rowmin(); y<=obs.rowmax(); y++){
          DOUBLE first_N = (*N)[y][N->colmin()];
          for (int j=N->colmin()+1; j<=N->colmax(); j++){
                  if ((*N)[y][j] != first_N){
                          fatal("You cannot bootstrap from multinomial observations unless the same value of N is used for all observations occurring in the same year.");
                  }
          }
          int N_to_use = (int) ceil(value(first_N));
          VECTOR year_fits(fits[y]);
          dvector year_probs(value(fits[y] / sum(fits[y])));
          VECTOR year_boot(fits.colmin(),fits.colmax());
          year_boot.fill_multinomial_counts(seed,year_probs,N_to_use);
          year_boot = year_boot / sum(year_boot) * sum(year_fits);
          obs[y] = year_boot;
  }
  return obs;
}

template<CDVM>
MATRIX Coleraine_likelihood<DVM>::get_std_devs(const MATRIX& obs, const MATRIX& fits){
  // Calculate the standard deviation of each observation.
  DEBUG2("Coleraine_likelihood::get_std_devs");
  int years = fits.rowmax();
  int n = fits.colmax();
  MATRIX O_dash(1,years,1,n);
  MATRIX N_dash(1,years,1,n);
  for (int i=1; i<=years; i++){
    for (int j=1; j<=n; j++){
      O_dash[i][j] = (1-obs[i][j]) * obs[i][j] + 0.1/n;
      N_dash[i][j] = fmin((*N)[i][j],1000.0);
    }
  }
  MATRIX result(sqrt(elem_div(O_dash,N_dash)));
  return result;
}

template<CDVM>
void Coleraine_likelihood<DVM>::print(ostream& out){
  DEBUG2("Coleraine_likelihood::print");
  out << "Coleraine likelihood, with N =\n" << *N << '\n';
}

template<CDVM>
Coleraine_likelihood<DVM>::Coleraine_likelihood(Parameter_set<DVM>& e,
                                                const std::string& command,
                                                const dvector& years){
  // Construct the likelihood object.
  DEBUG2("Coleraine_likelihood::Coleraine_likelihood");
  this->type = "Coleraine_likelihood";
  int n_obs;
  if (!e.present(command+"tag_label")){
    n_obs = e.get_constant_vector(command+dtos(years[1])).size();
  } else {
        // this is tagging data, need another way to get n_obs
        dvector class_mins(e.get_constant_vector(command+"class_mins"));
        int plus_group = e.get_int(command+"plus_group",1);
        int n_classes = class_mins.size()-1+plus_group;
        int sexed = e.present(command+"props_male")!=0;
        n_obs = (1+sexed)*n_classes;
  }
  N = new MATRIX(1,years.size(),1,n_obs);
  N_base = new dmatrix(1,years.size(),1,n_obs);
  if (e.present(command+"N_"+dtos(years[1]))){
    // a single N is supplied for each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N_"+dtos(years[y]));}
  } else if (e.present(command+"N")){
    // a single N is supplied for all years
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N");}
  } else {
    // an N is supplied for each observation in each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant_vector(command+"Ns_"+dtos(years[y]));}
  }
  for (int y=1; y<=years.size(); y++){
          if (min((*N)[y]) <= 0){
                  fatal("You have supplied a nonpositive N for a Coleraine likelihood");}}
  this->process_error_parname = command+"N_process_error";
  this->has_process_error = e.present(this->process_error_parname);
  if (this->has_process_error){
    DOUBLE process_error = e.get_estimable(this->process_error_parname);
    set_process_error(process_error);
  }
  if (e.present(command+"cv_process_error") || e.present(command+"stdev_process_error")){
          fatal("Cannot use cv_process_error or stdev_process_error with a Coleraine likelihood - perhaps use N_process_error?");}
}

template<CDVM>
  Coleraine_likelihood<DVM>::~Coleraine_likelihood(){
  DEBUG2("~Coleraine_likelihood");
  delete N_base;
  delete N;
}

template<CDVM>
DOUBLE Binomial_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // Calculate the likelihood.
  DEBUG1("Binomial_likelihood::obj_value");
  DOUBLE result=0, std_err;
  for (int i=1; i<=fits.rowmax(); i++){
          for (int j=1; j<=fits.colmax(); j++){
                std_err = sqrt((fits[i][j]+r)*(1-fits[i][j]+r)/(*N)[i][j]);
                result += log(std_err) + 0.5*pow((obs[i][j]-fits[i][j])/std_err,2);
          }
  }
  if (result != result){
    cerr << "obs " << obs << "\nfits\n" << fits << "\nN\n" << *N << '\n';
    fatal("Binomial likelihood calculation has produced a NaN, possibly due to a 0 observation. Try setting r to a very small value.");}
  return result;
}

template<CDVM>
void Binomial_likelihood<DVM>::set_process_error(DOUBLE& V){
  // Sets the process error N.
  DEBUG2("Binomial_likelihood::set_process_error");
  for (int i=N->rowmin(); i<=N->rowmax(); i++){
    for (int j=N->colmin(); j<=N->colmax(); j++){
      (*N)[i][j] = 1 / (1/(*N_base)[i][j] + 1/V);
    }
  }
  this->process_error_val = V;
}

template<CDVM>
MATRIX Binomial_likelihood<DVM>::bootstrap_observations(const MATRIX& fits, long int seed){
  // Return a parametric bootstrap of observations around the fits.
  // We ignore the robustifying constant r and round N up to the next integer.
  DEBUG1("Binomial_likelihood::bootstrap_observations");
  MATRIX obs(1,fits.rowmax(),1,fits.colmax());
  for (int i=1; i<=fits.rowmax(); i++){
          for (int j=1; j<=fits.colmax(); j++){
                int N_to_use = (int)(ceil(value((*N)[i][j])));
                dvector probs(1,2);
                probs[1] = value(fits[i][j]);
                probs[2] = 1-probs[1];
                VECTOR outcomes(1,2);
                // bug-fix for binomial where N=0
                // outcomes.fill_multinomial_counts(seed,probs,N_to_use);
                // obs[i][j] = outcomes[1] / N_to_use;
                if(N_to_use>0) {
                  outcomes.fill_multinomial_counts(seed,probs,N_to_use);
                  obs[i][j] = outcomes[1] / N_to_use;
                } else obs[i][j] = 0.0;
          }
  }
  return obs;
}

template<CDVM>
MATRIX Binomial_likelihood<DVM>::get_std_devs(const MATRIX& obs, const MATRIX& fits){
  // Calculate the standard deviation of each observation.
  DEBUG2("Binomial_likelihood::get_std_devs");
  dmatrix ones(1,fits.rowmax(),1,fits.colmax());
  ones = 1;
  dmatrix rmat(1,fits.rowmax(),1,fits.colmax());
  rmat = r;
  return sqrt(elem_div(elem_prod(fits+rmat,ones-fits+rmat),*N));
}

template<CDVM>
void Binomial_likelihood<DVM>::print(ostream& out){
  DEBUG2("Binomial_likelihood::print");
  out << "binomial likelihood, with r = " << r << ", N =\n" << *N << '\n';
}

template<CDVM>
Binomial_likelihood<DVM>::Binomial_likelihood(Parameter_set<DVM>& e,
                                                    const std::string& command,
                                                    const dvector& years){
  // Construct the likelihood object.
  DEBUG2("Binomial_likelihood::Binomial_likelihood");
  this->type = "Binomial_likelihood";
  r = e.get_constant(command+"r",0);
  int n_obs = e.get_constant_vector(command+dtos(years[1])).size();
  N = new MATRIX(1,years.size(),1,n_obs);
  N_base = new dmatrix(1,years.size(),1,n_obs);
  if (e.present(command+"N_"+dtos(years[1]))){
    // a single N is supplied for each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N_"+dtos(years[y]));}
  } else if (e.present(command+"N")){
    // a single N is supplied for all years
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N");}
  } else {
    // an N is supplied for each observation in each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant_vector(command+"Ns_"+dtos(years[y]));}
  }
  this->process_error_parname = command+"N_process_error";
  this->has_process_error = e.present(this->process_error_parname);
  if (this->has_process_error){
    DOUBLE process_error = e.get_estimable(this->process_error_parname);
    set_process_error(process_error);
  }
  if (e.present(command+"cv_process_error") || e.present(command+"stdev_process_error")){
          fatal("Cannot use cv_process_error or stdev_process_error with a binomial likelihood - perhaps use N_process_error?");}
}

template<CDVM>
  Binomial_likelihood<DVM>::~Binomial_likelihood(){
  DEBUG2("~Binomial_likelihood");
  delete N_base;
  delete N;
}

template<CDVM>
DOUBLE Binomial_exact_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // Calculate the likelihood.
  DEBUG1("Binomial_exact_likelihood::obj_value");
  DOUBLE result=0, o, n;
  for (int i=1; i<=fits.rowmax(); i++){
      for (int j=1; j<=fits.colmax(); j++){
                    n = (*N)[i][j];
                    o = n * obs[i][j];
            result -= o*log(zerofun(fits[i][j],delta)) + (n-o)*log(zerofun(1-fits[i][j],delta));
            result += lngamma(o+1) + lngamma(n-o+1) - lngamma(n+1);
            // combinatoric constant - remember ln(x!) = lngamma(x+1) for x integer.
      }
  }
  if (result != result){
    cerr << "obs " << obs << "\nfits\n" << fits << "\nN\n" << *N << '\n';
    fatal("Binomial_exact likelihood calculation has produced a NaN, possibly due to a 0 observation. Try setting r to a very small value.");}
  return result;
}

template<CDVM>
void Binomial_exact_likelihood<DVM>::set_process_error(DOUBLE& V){
  // Sets the process error N.
  DEBUG2("Binomial_exact_likelihood::set_process_error");
  for (int i=N->rowmin(); i<=N->rowmax(); i++){
    for (int j=N->colmin(); j<=N->colmax(); j++){
      (*N)[i][j] = 1 / (1/(*N_base)[i][j] + 1/V);
    }
  }
  this->process_error_val = V;
}

template<CDVM>
MATRIX Binomial_exact_likelihood<DVM>::bootstrap_observations(const MATRIX& fits, long int seed){
  // Return a parametric bootstrap of observations around the fits.
  // We round N up to the next integer.
  DEBUG1("Binomial_exact_likelihood::bootstrap_observations");
  MATRIX obs(1,fits.rowmax(),1,fits.colmax());
  for (int i=1; i<=fits.rowmax(); i++){
          for (int j=1; j<=fits.colmax(); j++){
                int N_to_use = (int)(ceil(value((*N)[i][j])));
                dvector probs(1,2);
                probs[1] = value(fits[i][j]);
                probs[2] = 1-probs[1];
                VECTOR outcomes(1,2);
                // bug-fix for binomial where N=0
                // outcomes.fill_multinomial_counts(seed,probs,N_to_use);
                // obs[i][j] = outcomes[1] / N_to_use;
                if(N_to_use>0) {
                  outcomes.fill_multinomial_counts(seed,probs,N_to_use);
                  obs[i][j] = outcomes[1] / N_to_use;
                } else obs[i][j] = 0.0;
          }
  }
  return obs;
}

template<CDVM>
MATRIX Binomial_exact_likelihood<DVM>::get_std_devs(const MATRIX& obs, const MATRIX& fits){
  // Calculate the standard deviation of each observation.
  DEBUG2("Binomial_exact_likelihood::get_std_devs");
  dmatrix ones(1,fits.rowmax(),1,fits.colmax());
  ones = 1;
  MATRIX zFits(1,fits.rowmax(),1,fits.colmax());
  zFits = fits;
  for (int i=1; i<=fits.rowmax(); i++){
    for (int j=1; j<=fits.colmax(); j++){
      if (zFits[i][j] < delta) {
        zFits[i][j] = delta/(2.0-(fits[i][j]/delta));
      }
    }
  }
  return sqrt(elem_div(elem_prod(zFits,ones-zFits),*N));
}

template<CDVM>
void Binomial_exact_likelihood<DVM>::print(ostream& out){
  DEBUG2("Binomial_exact_likelihood::print");
  out << "binomial likelihood (exact formula), with delta = " << delta << ", N =\n" << *N << '\n';
}

template<CDVM>
Binomial_exact_likelihood<DVM>::Binomial_exact_likelihood(Parameter_set<DVM>& e,
                                                    const std::string& command,
                                                    const dvector& years){
  // Construct the likelihood object.
  DEBUG2("Binomial_exact_likelihood::Binomial_exact_likelihood");
  this->type = "Binomial_exact_likelihood";
  delta = e.get_constant(command+"r",1e-11);
  int n_obs = e.get_constant_vector(command+dtos(years[1])).size();
  N = new MATRIX(1,years.size(),1,n_obs);
  N_base = new dmatrix(1,years.size(),1,n_obs);
  if (e.present(command+"N_"+dtos(years[1]))){
    // a single N is supplied for each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N_"+dtos(years[y]));}
  } else if (e.present(command+"N")){
    // a single N is supplied for all years
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant(command+"N");}
  } else {
    // an N is supplied for each observation in each year
    for (int y=1; y<=years.size(); y++){
      (*N)[y] = (*N_base)[y] = e.get_constant_vector(command+"Ns_"+dtos(years[y]));}
  }
  this->process_error_parname = command+"N_process_error";
  this->has_process_error = e.present(this->process_error_parname);
  if (this->has_process_error){
    DOUBLE process_error = e.get_estimable(this->process_error_parname);
    set_process_error(process_error);
  }
  if (e.present(command+"cv_process_error") || e.present(command+"stdev_process_error")){
          fatal("Cannot use cv_process_error or stdev_process_error with a binomial likelihood - perhaps use N_process_error?");}
}

template<CDVM>
  Binomial_exact_likelihood<DVM>::~Binomial_exact_likelihood(){
  DEBUG2("~Binomial_exact_likelihood");
  delete N_base;
  delete N;
}

template<CDVM>
DOUBLE Normal_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // Calculate the likelihood.
  DEBUG1("Normal_likelihood::obj_value");
  int years = fits.rowmax();
  int obs_per_year = fits.colmax();
  DOUBLE result=0;
  for (int i=1; i<=years; i++){
        if (min(fits[i]) <= 0){
          fatal("You have used a normal likelihood with a cv for an observation with nonpositive fits");}
    for (int j=1; j<=obs_per_year; j++){
      result += log((*cv)[i][j]*fits[i][j]) + 0.5*pow((obs[i][j]-fits[i][j])/((*cv)[i][j]*fits[i][j]),2);
    }
  }
  return result;
}

template<CDVM>
MATRIX Normal_likelihood<DVM>::bootstrap_observations(const MATRIX& fits, long int seed){
  // Return a parametric bootstrap of observations around the fits.
  DEBUG1("Normal_likelihood::bootstrap_observations");
  MATRIX obs(1,fits.rowmax(),1,fits.colmax());
  for (int j=1; j<=obs.colmax(); j++){
    obs.colfill_randn(j,seed);
  }
  for (int i=1; i<=obs.rowmax(); i++){
    for (int j=1; j<=obs.colmax(); j++){
      obs[i][j] = fits[i][j] * (1 + (*cv)[i][j] * obs[i][j]);
    }
  }
  return obs;
}

template<CDVM>
MATRIX Normal_likelihood<DVM>::get_std_devs(const MATRIX& obs, const MATRIX& fits){
  // Calculate the standard deviation of each observation.
  DEBUG2("Normal_likelihood::get_std_devs");
  return elem_prod(fits,*cv);
}

template<CDVM>
MATRIX Normal_likelihood<DVM>::get_normalised_resids(const MATRIX& obs, const MATRIX& fits){
  // Calculate the normalised residuals (as (obs - fits) / (fits*cvs))
  DEBUG2("Normal_likelihood::get_std_devs");
  return elem_div(obs-fits,elem_prod(fits,*cv));
}

template<CDVM>
void Normal_likelihood<DVM>::set_process_error(DOUBLE& V){
  // Sets the process error cv.
  DEBUG2("Normal_likelihood::set_process_error");
  for (int i=cv->rowmin(); i<=cv->rowmax(); i++){
    for (int j=cv->colmin(); j<=cv->colmax(); j++){
      (*cv)[i][j] = sqrt((*cv_base)[i][j]*(*cv_base)[i][j] + V*V);
    }
  }
  this->process_error_val = V;
}

template<CDVM>
void Normal_likelihood<DVM>::print(ostream& out){
  DEBUG2("Normal_likelihood::print");
  out << "normal likelihood, with cv = \n" << *cv << '\n';
}

template<CDVM>
Normal_likelihood<DVM>::Normal_likelihood(Parameter_set<DVM>& e,
                                          const std::string& command,
                                          const dvector& years){
  // Construct the likelihood object.
  DEBUG2("Normal_likelihood::Normal_likelihood");
  this->type = "Normal_likelihood";
  int n_obs = e.get_constant_vector(command+dtos(years[1])).size();
  cv = new MATRIX(1,years.size(),1,n_obs);
  cv_base = new MATRIX(1,years.size(),1,n_obs);
  if (e.present(command+"cv_"+dtos(years[1]))){
    // a single c.v. is supplied for each year
    for (int y=1; y<=years.size(); y++){
      (*cv)[y] = (*cv_base)[y] = e.get_constant(command+"cv_"+dtos(years[y]));}
  } else if (e.present(command+"cv")){
    // a single c.v. is supplied for all years
    for (int y=1; y<=years.size(); y++){
      (*cv)[y] = (*cv_base)[y] = e.get_constant(command+"cv");}
  } else {
    // a c.v. is supplied for each observation in each year
    for (int y=1; y<=years.size(); y++){
      (*cv)[y] = (*cv_base)[y] = e.get_constant_vector(command+"cvs_"+dtos(years[y]));}
  }
  for (int y=1; y<=years.size(); y++){
    if (min((*cv)[y]) < 0){
          fatal("You have supplied a nonpositive cv in a likelihood");}}
  this->process_error_parname = command+"cv_process_error";
  this->has_process_error = e.present(this->process_error_parname);
  if (this->has_process_error){
    DOUBLE process_error = e.get_estimable(this->process_error_parname);
    set_process_error(process_error);
  }
  if (e.present(command+"N_process_error") || e.present(command+"stdev_process_error")){
          fatal("Cannot use N_process_error or stdev_process_error with a normal likelihood - perhaps use cv_process_error?");}
}

template<CDVM>
Normal_likelihood<DVM>::Normal_likelihood(int n_obs, const DOUBLE& cv_all){
  // This constructor is only used for age/size observations so far
  // The observations are a single row with n_obs columns: all the cvs are cv_all.
  DEBUG2("Normal_likelihood::Normal_likelihood (unsexed age/size obs)");
  cv = new MATRIX(1,1,1,n_obs);
  cv_base = new MATRIX(1,1,1,n_obs);
  (*cv) = cv_all;
  (*cv_base) = cv_all;
}

template<CDVM>
Normal_likelihood<DVM>::Normal_likelihood(const dvector& sexes,
                                          const DOUBLE& cv_male, const DOUBLE& cv_female){
  // This constructor is only used for age/size observations so far
  // The observations are a single row with n_obs columns. The sexes have potentially different cvs,
  // 'sexes' designates whether each column is male (1) or female (2).
  DEBUG2("Normal_likelihood::Normal_likelihood (sexed age/size obs)");
  int n_obs = sexes.size();
  cv = new MATRIX(1,1,1,n_obs);
  cv_base = new MATRIX(1,1,1,n_obs);
  for (int i=1; i<=n_obs; i++){
    if (sexes[i]==1){
      (*cv)[1][i] = cv_male;
      (*cv_base)[1][i] = cv_male;
    } else if (sexes[i]==2){
      (*cv)[1][i] = cv_female;
      (*cv_base)[1][i] = cv_female;
    }
  }
}

template<CDVM>
Normal_likelihood<DVM>::~Normal_likelihood(){
  DEBUG2("~Normal_likelihood");
  delete cv_base;
  delete cv;
}

template<CDVM>
DOUBLE Lognormal_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // Calculate the likelihood.
  DEBUG1("Lognormal_likelihood::obj_value");
  int years = fits.rowmax();
  int obs_per_year = fits.colmax();
  DOUBLE result=0;
  for (int i=1; i<=years; i++){
    if (min(obs[i]) <= 0){
      fatal("Non-positive observation with lognormal likelihood");}
    for (int j=1; j<=obs_per_year; j++){
      result += log((*sigma)[i][j]) + 0.5*pow(log(obs[i][j]/fits[i][j])/(*sigma)[i][j]+0.5*(*sigma)[i][j],2);
    }
  }
  return result;
}

template<CDVM>
MATRIX Lognormal_likelihood<DVM>::bootstrap_observations(const MATRIX& fits, long int seed){
  // Return a parametric bootstrap of observations around the fits.
  // Note that sigma is the standard deviation on the log-scale.
  DEBUG1("Lognormal_likelihood::bootstrap_observations");
  MATRIX obs(1,fits.rowmax(),1,fits.colmax());
  for (int j=1; j<=obs.colmax(); j++){
    obs.colfill_randn(j,seed);
  }
  DOUBLE mu;
  for (int i=1; i<=obs.rowmax(); i++){
    for (int j=1; j<=obs.colmax(); j++){
      mu = log(fits[i][j]) - (*sigma)[i][j]*(*sigma)[i][j];
      obs[i][j] = exp(mu + (*sigma)[i][j] * obs[i][j]);
    }
  }
  return obs;
}

template<CDVM>
MATRIX Lognormal_likelihood<DVM>::get_std_devs(const MATRIX& obs, const MATRIX& fits){
  // Calculate the standard deviation of each observation.
  DEBUG2("Lognormal_likelihood::get_std_devs");
  return elem_prod(fits,*cv);
}

template<CDVM>
MATRIX Lognormal_likelihood<DVM>::get_normalised_resids(const MATRIX& obs, const MATRIX& fits){
  // Calculate the normalised residuals (as (log(obs/fits)+0.5*sigma*sigma) / sigma)
  DEBUG2("Lognormal_likelihood::get_std_devs");
  return elem_div(log(elem_div(obs,fits))+0.5*elem_prod(*sigma,*sigma),*sigma);
}

template<CDVM>
void Lognormal_likelihood<DVM>::set_process_error(DOUBLE& V){
  // Sets the process error cv.
  DEBUG2("Lognormal_likelihood::set_process_error");
  for (int i=cv->rowmin(); i<=cv->rowmax(); i++){
    for (int j=cv->colmin(); j<=cv->colmax(); j++){
      (*cv)[i][j] = sqrt((*cv_base)[i][j]*(*cv_base)[i][j] + V*V);
    }
  }
  for (int y=1; y<=cv->rowsize(); y++){
    for (int obs=1; obs<=cv->colsize(); obs++){
      (*sigma)[y][obs] = sqrt(log(1 + (*cv)[y][obs] * (*cv)[y][obs]));
    }
  }
  this->process_error_val = V;
}

template<CDVM>
void Lognormal_likelihood<DVM>::print(ostream& out){
  DEBUG2("Lognormal_likelihood::print");
  out << "lognormal likelihood, with cv = \n" << *cv << '\n';
}

template<CDVM>
Lognormal_likelihood<DVM>::Lognormal_likelihood(Parameter_set<DVM>& e,
                                                const std::string& command,
                                                const dvector& years){
  // Construct the likelihood object.
  DEBUG2("Lognormal_likelihood::Lognormal_likelihood");
  this->type = "Lognormal_likelihood";
  int n_obs = e.get_constant_vector(command+dtos(years[1])).size();
  cv = new MATRIX(1,years.size(),1,n_obs);
  sigma = new MATRIX(1,years.size(),1,n_obs);
  cv_base = new MATRIX(1,years.size(),1,n_obs);
  if (e.present(command+"cv_"+dtos(years[1]))){
    // a single c.v. is supplied for each year
    for (int y=1; y<=years.size(); y++){
      (*cv)[y] = (*cv_base)[y] = e.get_constant(command+"cv_"+dtos(years[y]));}
  } else if (e.present(command+"cv")){
    // a single c.v. is supplied for all years
    for (int y=1; y<=years.size(); y++){
      (*cv)[y] = (*cv_base)[y] = e.get_constant(command+"cv");}
  } else {
    // a c.v. is supplied for each observation in each year
    for (int y=1; y<=years.size(); y++){
      (*cv)[y] = (*cv_base)[y] = e.get_constant_vector(command+"cvs_"+dtos(years[y]));}
  }
  for (int y=1; y<=cv->rowsize(); y++){
    for (int obs=1; obs<=cv->colsize(); obs++){
      (*sigma)[y][obs] = sqrt(log(1+(*cv)[y][obs]*(*cv)[y][obs]));
    }
  }
  this->process_error_parname = command+"cv_process_error";
  this->has_process_error = e.present(this->process_error_parname);
  if (this->has_process_error){
    DOUBLE process_error = e.get_estimable(this->process_error_parname);
    set_process_error(process_error);
  }
  if (e.present(command+"N_process_error") || e.present(command+"stdev_process_error")){
          fatal("Cannot use N_process_error or stdev_process_error with a lognormal likelihood - perhaps use cv_process_error?");}
}

template<CDVM>
Lognormal_likelihood<DVM>::Lognormal_likelihood(int n_obs, const DOUBLE& cv_all){
  // This constructor is only used for age/size observations so far
  // The observations are a single row with n_obs columns: all the cvs are cv_all.
  DEBUG2("Lognormal_likelihood::Lognormal_likelihood (unsexed age/size obs)");
  cv = new MATRIX(1,1,1,n_obs);
  sigma = new MATRIX(1,1,1,n_obs);
  cv_base = new MATRIX(1,1,1,n_obs);
  (*cv) = cv_all;
  (*cv_base) = cv_all;
  for (int y=1; y<=cv->rowsize(); y++){
    for (int obs=1; obs<=cv->colsize(); obs++){
      (*sigma)[y][obs] = sqrt(log(1+(*cv)[y][obs]*(*cv)[y][obs]));
    }
  }
}

template<CDVM>
Lognormal_likelihood<DVM>::Lognormal_likelihood(const dvector& sexes,
                                                const DOUBLE& cv_male, const DOUBLE& cv_female){
  // This constructor is only used for age/size observations so far
  // The observations are a single row with n_obs columns. The sexes have potentially different cvs,
  // 'sexes' designates whether each column is male (1) or female (2).
  DEBUG2("Lognormal_likelihood::Lognormal_likelihood (sexed age/size obs)");
  int n_obs = sexes.size();
  cv = new MATRIX(1,1,1,n_obs);
  sigma = new MATRIX(1,1,1,n_obs);
  cv_base = new MATRIX(1,1,1,n_obs);
  for (int i=1; i<=n_obs; i++){
    if (sexes[i]==1){
      (*cv)[1][i] = cv_male;
      (*cv_base)[1][i] = cv_male;
    } else if (sexes[i]==2){
      (*cv)[1][i] = cv_female;
      (*cv_base)[1][i] = cv_female;
    }
  }
  for (int y=1; y<=cv->rowsize(); y++){
    if (min((*cv)[y]) < 0){
          fatal("You have supplied a nonpositive cv in a likelihood");}
    for (int obs=1; obs<=cv->colsize(); obs++){
      (*sigma)[y][obs] = sqrt(log(1+(*cv)[y][obs]*(*cv)[y][obs]));
    }
  }
}

template<CDVM>
Lognormal_likelihood<DVM>::~Lognormal_likelihood(){
  DEBUG2("~Lognormal_likelihood");
  delete cv_base;
  delete cv;
  delete sigma;
}

template<CDVM>
DOUBLE Robustified_lognormal_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // Calculate the likelihood.
  DEBUG1("Robustified_lognormal_likelihood::obj_value");
  int years = fits.rowmax();
  int obs_per_year = fits.colmax();
  DOUBLE result=0;
  for (int i=1; i<=years; i++){
    if (min(obs[i]) <= 0){
      fatal("Non-positive observation with robustified lognormal likelihood");}
    for (int j=1; j<=obs_per_year; j++){
      result += log((*(this->sigma))[i][j]) - log(exp(-0.5*pow(log(obs[i][j]/fits[i][j])/(*(this->sigma))[i][j]+0.5*(*(this->sigma))[i][j],2))+r);
    }
  }
  return result;
}

template<CDVM>
void Robustified_lognormal_likelihood<DVM>::print(ostream& out){
  DEBUG2("Robustified_lognormal_likelihood::print");
  out << "robustified lognormal likelihood, with r = " << r << " and cv = \n" << *(this->cv) << '\n';
}

template<CDVM>
Robustified_lognormal_likelihood<DVM>::Robustified_lognormal_likelihood(Parameter_set<DVM>& e,
                                                const std::string& command,
                                                const dvector& years)
  : Lognormal_likelihood<DVM>(e, command, years){
  // Most of the work is done by Lognormal_likelihood::Lognormal_likelihood
  // Just need to get r
  r = e.get_constant(command+"r",0);
}

template<CDVM>
DOUBLE Normal_log_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // Calculate the likelihood.
  DEBUG1("Normal_log_likelihood::obj_value");
  int years = fits.rowmax();
  int obs_per_year = fits.colmax();
  DOUBLE result=0;
  for (int i=1; i<=years; i++){
    if (min(obs[i]) <= 0){
      fatal("Non-positive observation with normal-log likelihood");}
    for (int j=1; j<=obs_per_year; j++){
      result += log((*sigma)[i][j]) + 0.5*pow(log(obs[i][j]/fits[i][j])/(*sigma)[i][j],2);
    }
  }
  return result;
}

template<CDVM>
MATRIX Normal_log_likelihood<DVM>::bootstrap_observations(const MATRIX& fits, long int seed){
  // Return a parametric bootstrap of observations around the fits.
  // Note that sigma is the standard deviation on the log-scale.
  DEBUG1("Normal_log_likelihood::bootstrap_observations");
  MATRIX obs(1,fits.rowmax(),1,fits.colmax());
  for (int j=1; j<=obs.colmax(); j++){
    obs.colfill_randn(j,seed);
  }
  DOUBLE mu;
  for (int i=1; i<=obs.rowmax(); i++){
    for (int j=1; j<=obs.colmax(); j++){
      mu = log(fits[i][j]);
      obs[i][j] = exp(mu + (*sigma)[i][j] * obs[i][j]);
    }
  }
  return obs;
}

template<CDVM>
MATRIX Normal_log_likelihood<DVM>::get_std_devs(const MATRIX& obs, const MATRIX& fits){
  // Calculate the standard deviation of each observation.
  DEBUG2("Normal_log_likelihood::get_std_devs");
  return elem_prod(fits,*cv);
}

template<CDVM>
MATRIX Normal_log_likelihood<DVM>::get_normalised_resids(const MATRIX& obs, const MATRIX& fits){
  // Calculate the normalised residuals (as log(obs/fits) / sigma)
  DEBUG2("Normal_log_likelihood::get_std_devs");
  return elem_div(log(elem_div(obs,fits)),*sigma);
}

template<CDVM>
void Normal_log_likelihood<DVM>::set_process_error(DOUBLE& V){
  // Sets the process error cv.
  DEBUG2("Normal_log_likelihood::set_process_error");
  for (int i=cv->rowmin(); i<=cv->rowmax(); i++){
    for (int j=cv->colmin(); j<=cv->colmax(); j++){
      (*cv)[i][j] = sqrt((*cv_base)[i][j]*(*cv_base)[i][j] + V*V);
    }
  }
  for (int y=1; y<=cv->rowsize(); y++){
    for (int obs=1; obs<=cv->colsize(); obs++){
      (*sigma)[y][obs] = sqrt(log(1 + (*cv)[y][obs] * (*cv)[y][obs]));
    }
  }
  this->process_error_val = V;
}

template<CDVM>
void Normal_log_likelihood<DVM>::print(ostream& out){
  DEBUG2("Normal_log_likelihood::print");
  out << "normal-log likelihood, with sigma = \n" << (*sigma) << '\n';
}

template<CDVM>
Normal_log_likelihood<DVM>::Normal_log_likelihood(Parameter_set<DVM>& e,
                                                  const std::string& command,
                                                  const dvector& years){
  // Construct the likelihood object.
  DEBUG2("Normal_log_likelihood::Normal_log_likelihood");
  this->type = "Normal_log_likelihood";
  int n_obs = e.get_constant_vector(command+dtos(years[1])).size();
  cv = new MATRIX(1,years.size(),1,n_obs);
  sigma = new MATRIX(1,years.size(),1,n_obs);
  cv_base = new dmatrix(1,years.size(),1,n_obs);
  if (e.present(command+"cv_"+dtos(years[1]))){
    // a single c.v. is supplied for each year
    for (int y=1; y<=years.size(); y++){
      (*cv)[y] = (*cv_base)[y] = e.get_constant(command+"cv_"+dtos(years[y]));}
  } else if (e.present(command+"cv")){
    // a single c.v. is supplied for all years
    for (int y=1; y<=years.size(); y++){
      (*cv)[y] = (*cv_base)[y] = e.get_constant(command+"cv");}
  } else {
    // a c.v. is supplied for each observation in each year
    for (int y=1; y<=years.size(); y++){
      (*cv)[y] = (*cv_base)[y] = e.get_constant_vector(command+"cvs_"+dtos(years[y]));}
  }
  for (int y=1; y<=cv->rowsize(); y++){
        if (min((*cv)[y]) < 0){
          fatal("You have supplied a nonpositive cv in a likelihood");}
    for (int obs=1; obs<=cv->colsize(); obs++){
      (*sigma)[y][obs] = sqrt(log(1+(*cv)[y][obs]*(*cv)[y][obs]));
    }
  }
  this->process_error_parname = command+"cv_process_error";
  this->has_process_error = e.present(this->process_error_parname);
  if (this->has_process_error){
    DOUBLE process_error = e.get_estimable(this->process_error_parname);
    set_process_error(process_error);
  }
  if (e.present(command+"N_process_error") || e.present(command+"stdev_process_error")){
          fatal("Cannot use N_process_error or stdev_process_error with a normal-log likelihood - perhaps use cv_process_error?");}
}

template<CDVM>
Normal_log_likelihood<DVM>::~Normal_log_likelihood(){
  DEBUG2("~Normal_log_likelihood");
  delete cv_base;
  delete cv;
  delete sigma;
}

template<CDVM>
DOUBLE Normal_by_stdev_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // Calculate the likelihood.
  DEBUG1("Normal_by_stdev_likelihood::obj_value");
  int years = fits.rowmax();
  int obs_per_year = fits.colmax();
  DOUBLE result=0;
  for (int i=1; i<=years; i++){
    for (int j=1; j<=obs_per_year; j++){
      result += log((*stdev)[i][j]) + 0.5*pow((obs[i][j]-fits[i][j])/(*stdev)[i][j],2);
    }
  }
  return result;
}

template<CDVM>
MATRIX Normal_by_stdev_likelihood<DVM>::bootstrap_observations(const MATRIX& fits, long int seed){
  // Return a parametric bootstrap of observations around the fits.
  DEBUG1("Normal_by_stdev_likelihood::bootstrap_observations");
  MATRIX obs(1,fits.rowmax(),1,fits.colmax());
  for (int j=1; j<=obs.colmax(); j++){
    obs.colfill_randn(j,seed);
  }
  for (int i=1; i<=obs.rowmax(); i++){
    for (int j=1; j<=obs.colmax(); j++){
      obs[i][j] = fits[i][j] + obs[i][j] * (*stdev)[i][j];
    }
  }
  return obs;
}

template<CDVM>
MATRIX Normal_by_stdev_likelihood<DVM>::get_std_devs(const MATRIX& obs, const MATRIX& fits){
  // Calculate the standard deviation of each observation.
  DEBUG2("Normal_by_stdev_likelihood::get_std_devs");
  return *stdev; // that's easy!
}

template<CDVM>
void Normal_by_stdev_likelihood<DVM>::set_process_error(DOUBLE& V){
  // Sets the process error std.dev.
  DEBUG2("Normal_by_stdev_likelihood::set_process_error");
  for (int i=stdev->rowmin(); i<=stdev->rowmax(); i++){
    for (int j=stdev->colmin(); j<=stdev->colmax(); j++){
      (*stdev)[i][j] = sqrt((*stdev_base)[i][j]*(*stdev_base)[i][j] + V*V);
    }
  }
  this->process_error_val = V;
}

template<CDVM>
void Normal_by_stdev_likelihood<DVM>::print(ostream& out){
  DEBUG2("Normal_by_stdev_likelihood::print");
  out << "normal likelihood, with stdev =\n" << *stdev << '\n';
}

template<CDVM>
Normal_by_stdev_likelihood<DVM>::Normal_by_stdev_likelihood(Parameter_set<DVM>& e,
                                                            const std::string& command,
                                                            const dvector& years){
  // Construct the likelihood object.
  DEBUG2("Normal_by_stdev_likelihood::Normal_by_stdev_likelihood");
  this->type = "Normal_by_stdev_likelihood";
  int n_obs = e.get_constant_vector(command+dtos(years[1])).size();
  stdev = new MATRIX(1,years.size(),1,n_obs);
  stdev_base = new dmatrix(1,years.size(),1,n_obs);
  if (e.present(command+"stdev_"+dtos(years[1]))){
    // a single std.dev is supplied for each year
    for (int y=1; y<=years.size(); y++){
      (*stdev)[y] = (*stdev_base)[y] = e.get_constant(command+"stdev_"+dtos(years[y]));}
  } else if (e.present(command+"stdev")){
    // a single std.dev is supplied for all years
    for (int y=1; y<=years.size(); y++){
      (*stdev)[y] = (*stdev_base)[y] = e.get_constant(command+"stdev");}
  } else {
    // a std.dev is supplied for each observation in each year
    for (int y=1; y<=years.size(); y++){
      (*stdev)[y] = (*stdev_base)[y] = e.get_constant_vector(command+"stdevs_"+dtos(years[y]));}
  }
  for (int y=1; y<=years.size(); y++){
    if (min((*stdev)[y]) < 0){
          fatal("You have supplied a nonpositive standard deviation in a likelihood");}}
  this->process_error_parname = command+"stdev_process_error";
  this->has_process_error = e.present(this->process_error_parname);
  if (this->has_process_error){
    DOUBLE process_error_stdev = e.get_estimable(this->process_error_parname);
    set_process_error(process_error_stdev);
  }
  if (e.present(command+"N_process_error") || e.present(command+"cv_process_error")){
          fatal("Cannot use N_process_error or cv_process_error with a normal-by-stdev likelihood - perhaps use stdev_process_error?");}
}

template<CDVM>
Normal_by_stdev_likelihood<DVM>::~Normal_by_stdev_likelihood(){
  DEBUG2("~Normal_by_stdev_likelihood");
  delete stdev_base;
  delete stdev;
}

template<CDVM>
DOUBLE User_supplied_likelihood<DVM>::obj_value(const MATRIX& fits, const MATRIX& obs){
  // call the user-supplied likelihood function
  DEBUG1("User_suppled_likelihood::obj_value");
  return user_likelihood<DVM>(label,fits,obs);
}

template<CDVM>
MATRIX User_supplied_likelihood<DVM>::bootstrap_observations(const MATRIX& fits, long int seed){
  // error out
  DEBUG1("User_supplied_likelihood::bootstrap_observations");
  fatal("Don't know how to bootstrap from a user-supplied likelihood");
  // never returned, but here to keep the compiler happy
  return dummyM;
}

template<CDVM>
MATRIX User_supplied_likelihood<DVM>::get_std_devs(const MATRIX& obs, const MATRIX& fits){
  // Used for Pearson residuals, but not defined in this case.
  // We'll just return zeros, which will make the Pearson residuals NaN.
  DEBUG2("User_supplied_likelihood::get_std_devs");
  MATRIX result(1,obs.rowsize(),1,obs.colsize());
  result = 0.0;
  return result;
}

template<CDVM>
void User_supplied_likelihood<DVM>::set_process_error(DOUBLE& V){
  // error out
  DEBUG1("User_supplied_likelihood::set_process_error");
  fatal("Don't know how to set process error for a user-supplied likelihood");
}

template<CDVM>
User_supplied_likelihood<DVM>::User_supplied_likelihood(std::string& _label){
  DEBUG2("User_supplied_likelihood::User_supplied_likelihood");
  this->type = "user-supplied";
  this->has_process_error = 0;
  label = _label;
}

template<CDVM>
MATRIX& Objective<DVM>::get_weights(){
  fatal("get_weights() not defined for Objectives of type " + type);
  // never returned, but here to keep the compiler happy
  return dummyM;
}

template<CDVM>
double Objective<DVM>::get_ko(){
  fatal("get_ko() not defined for Objectives of type " + type);
  return 0;
}

template<CDVM>
double Objective<DVM>::get_kp(){
  fatal("get_kp() not defined for Objectives of type " + type);
  return 0;
}

template<CDVM>
MATRIX& Objective<DVM>::get_sigmas(){
  fatal("get_sigmas() not defined for Objectives of type " + type);
  // never returned, but here to keep the compiler happy
  return dummyM;
}

template<CDVM>
MATRIX& Objective<DVM>::get_cvs(){
  fatal("get_cvs() not defined for Objectives of type " + type);
  // never returned, but here to keep the compiler happy
  return dummyM;
}

template<CDVM>
MATRIX& Objective<DVM>::get_Ns(){
  fatal("get_Ns() not defined for Objectives of type " + type);
  // never returned, but here to keep the compiler happy
  return dummyM;
}

//############################## END OF LIKELIHOODS.cpp ##############################

// Create particular instantiations of the template
template class Multinomial_likelihood<double, dvector, dmatrix>;
template class Multinomial_withconst_likelihood<double, dvector, dmatrix>;
template class Fournier_likelihood<double, dvector, dmatrix>;
template class Coleraine_likelihood<double, dvector, dmatrix>;
template class Binomial_likelihood<double, dvector, dmatrix>;
template class Binomial_exact_likelihood<double, dvector, dmatrix>;
template class Normal_likelihood<double, dvector, dmatrix>;
template class Lognormal_likelihood<double, dvector, dmatrix>;
template class Normal_log_likelihood<double, dvector, dmatrix>;
template class Normal_by_stdev_likelihood<double, dvector, dmatrix>;
template class Robustified_lognormal_likelihood<double, dvector, dmatrix>;
template class User_supplied_likelihood<double, dvector, dmatrix>;

template class Multinomial_likelihood<dvariable, dvv, dvm>;
template class Multinomial_withconst_likelihood<dvariable, dvv, dvm>;
template class Fournier_likelihood<dvariable, dvv, dvm>;
template class Coleraine_likelihood<dvariable, dvv, dvm>;
template class Binomial_likelihood<dvariable, dvv, dvm>;
template class Binomial_exact_likelihood<dvariable, dvv, dvm>;
template class Normal_likelihood<dvariable, dvv, dvm>;
template class Lognormal_likelihood<dvariable, dvv, dvm>;
template class Normal_log_likelihood<dvariable, dvv, dvm>;
template class Normal_by_stdev_likelihood<dvariable, dvv, dvm>;
template class Robustified_lognormal_likelihood<dvariable, dvv, dvm>;
template class User_supplied_likelihood<dvariable, dvv, dvm>;
