// const char* time_stamp = "$Date: 2009-12-02 16:19:28 +1300 (Wed, 02 Dec 2009) $\n";
// const char* parameter_set_cpp_id = "$Id: parameter_set.cpp 3489 2009-12-02 03:19:28Z dunn $\n";

//############################## PARAMETER SETS ##############################
#include "parameter_set.h"
#include "population_processes.h"
#include "ogive.h"
#include <algorithm> // for std::transform

///////////////////////////////////////////////////////////////////////////////
void decompose(const std::string &parname, std::string &command, std::string &label, std::string &subcommand){
  // extracts the command, label and subcommand out of parname - if not present, return ""
  if (!in(parname,".")){
        command=parname;
        label="";
        subcommand="";
  } else if (!in(parname,"[")){
        command = parname.substr(0,parname.find("."));
        label="";
        subcommand = parname.substr(parname.find(".")+1);
  } else {
        command = parname.substr(0,parname.find("["));
        label = parname.substr(parname.find("[")+1,parname.find("]")-parname.find("[")-1);
    subcommand = parname.substr(parname.find(".")+1);
  }
}

std::string decompose_into_words(const std::string &parname){
        std::string command, label, subcommand, result;
        decompose(parname,command,label,subcommand);
        if (subcommand==""){
      result = "command " + command;
    } else if (label==""){
          result = "subcommand " + subcommand + " of command " + command;
        } else {
          result = "subcommand " + subcommand + " of command " + command + " with label " + label;
        }
        return result;
}

int isws(const std::string &s){
        // is there anything in there apart from ' ', '\t', '\n'
        return (s.find_first_not_of(" \t\n")==std::string::npos);
}

void trim_comment(std::string& line){
  std::string::size_type pos = line.find('#');
  if (pos==0){
    line = "\n";
  } else if (pos != std::string::npos){
    line = line.substr(0,pos);
  }
}

template<CDVM>
void Parameter_set<DVM>::read_file(const std::string& filename, std::string file){
  // Used for reading input files in command-block format.
  //
  // The read_file function extracts parameters from a command-block file and dumps them
  // and their arguments into the strings compartment of the Parameter_set.
  // The Parameter_set is emptied first.
  //
  // A command-block file consists of any number of command blocks in any order.
  // Each command block is of the form
  //
  // @command arguments
  //
  // or
  //
  // @command [label]
  // [subcommand arguments]
  // [subcommand arguments]
  // [...]
  //
  // Commands and subcommands must consist of letters and/or underscores.
  // Blank lines are ignored, as is extra whitespace between arguments,
  // # marks a comment: the rest of the line is removed
  // { also put comments in braces
  // } this marks the end of the comment block (the whole line is lost, not just up to the }, I think)
  // Don't put extra whitespace before a @ character
  // and make sure the file ends with a carriage return.
  //
  // One new arguments added by BB, Mar 03, for checking inputs: the file type- "P", "O", or "E" (population/output/estimation).
  // This is referenced, along with command and subcommand name, into the global dictionary object. And I quote:
  // The Dictionary is a global object created early in model.C. It is defined in dictionary.C which has been added to the CVS and #included in model.C just like the other code files. Its purpose is to catalogue the commands and subcommands by name and type. Any command or subcommand which is not in the Dictionary or not used as the Dictionary specifies will cause a (hopefully informative) fatal error. Commands and subcommands can also be marked as �obsolete� which means they will again cause a fatal error, informing the user that they are no longer valid.
  // "Have a look at the Dictionary constructor. There are many entries: first standalone commands, then commands which start command blocks, then subcommands. Note the different calls for obsolete commands and subcommands; note also the difference between the five types of command:
  // -those which have arguments and never have subcommands (like �min_age�)
  // -those which have subcommands and can only be used once in a file (like �annual_cycle�)
  // -those which have subcommands and must have a label (like �abundance�)
  // -those which have subcommands, can appear multiple times, and must have a label if they are used more than once (like �size_at_age�)
  // -those which have commands, can appear multiple times, and never have a label (like �estimate�: they are internally and automatically labelled 1, 2, 3...)"
  //
  // Every command with arguments and every subcommand is translated into a parameter.
  // For commands, the parameter name is simply the command name.
  // For subcommands, the parameter name is
  //
  // (i) command.subcommand             if the command has no label and is not auto-numbered
  // (ii) command[label].subcommand     if the command has a label
  // (iii) command[i].subcommand        if the command is auto-numbered and is occurring for the ith time.
  //
  // The argument of each parameter in the command file should be of one of the following types:
  // int, constant, double, constant_vector, vector, ogive, string, vector_of_strings.
  //
  // An 'int' argument can be input as a single number,
  // or as (true, T, or t) interpreted as 1, or as (false, F, or f) interpreted as 0.
  // A 'constant' or 'double' argument is input as a single number,
  // 'constant_vector' or 'vector' as a list of numbers separated by whitespace,
  // 'string' as a single word containing no whitespace and 'vector_of_strings'
  // as a list of words separated by whitespace.
  //
  // 'ogive' arguments are input in the following format:
  //
  // [size_based] type argument1 [argument2 [argument3...]]]
  //
  // The optional size_based indicates a size-based ogive in an age-based model.
  // The type can be 'constant', 'knife_edge', 'logistic', etc... and the arguments
  // depend on the type.
  //
  DEBUG0("Parameter_set::read_file");
  empty();
  std::string longfilename=(file=="P" ? "population" : (file=="E" ? "estimation" : "output"));
  // read through line by line, discarding comment lines,
  // making keys and inserting into 'strings' and 'parameters_accessed'
  ifstream in_file(filename.c_str());
  if (!in_file){
    fatal("Could not open file " + filename);}
  std::string linebuf,command;
  istringstream *linestr;
  std::string command_line, label, subcommand, arguments, par_name, command_type;
  int can_have_subcommands;
  // read to the start of the first command block
  while (1){
   getline(in_file,linebuf);
   trim_comment(linebuf);
   linebuf += '\n';
   if (in(linebuf,"}") && !in(linebuf,"{")) fatal("Found a loose } with no matching {");
   while (in(linebuf,"{")){
     while (!in(linebuf,"}")){
           getline(in_file,linebuf);
       trim_comment(linebuf);
       linebuf += '\n';
       if (in(linebuf,"{")) fatal("Found a second { within a {} comment block");
       if (in_file.fail()) {
         fatal("Failed to find the end of comment. Check that there is a '}' character to end the comment block");
       }
     }
         getline(in_file,linebuf);
     trim_comment(linebuf);
     linebuf += '\n';
   }
   if (linebuf[0]=='@') break;
   if (linebuf[0]!=' ' && linebuf[0]!='\t' && linebuf[0]!='\n' && linebuf[0]!='\r'){
          fatal("Found the following line: " + linebuf + " at the start of your " + longfilename + " datafile: was expecting a command block instead");}
   if (in_file.fail()){
          fatal("Failed to find any command blocks in your " + longfilename + " parameter file.");}
  }
  while(1){
    linebuf.erase(0,1);                     // get rid of the initial '@'
    linestr = new istringstream(linebuf.c_str());
    *linestr >> command;
    command_type = dict.check(command,file);
    if (in(command_counts,command)){
      // this command is already in command_counts
      command_counts[command]++;
      // But error out if its a nolabel command that appears twice
      if (command_type=="nolabel") {
        fatal("Have found command " + command + " appears twice in the same parameter file.");
      }
    } else {
      // it's the first time we have seen this command
      command_counts.insert(make_pair(command,1));
    }
    getline(*linestr,command_line);         // this may be either the label or the arguments
    delete linestr;
    linestr = new istringstream((command_line+" ").c_str());
    *linestr >> label;
    if (command_type=="label"){
      if (!(linestr->good())) fatal("Command " + command + " must always have a label.");
      can_have_subcommands=1;
      if(in(get_command_labels(command),label)) {
        fatal("Have found command " + command + " with label " + label + " appears twice in the same parameter file.");
      }
    } else if (command_type=="nolabel"){
      if (linestr->good()) fatal("Command " + command + " may never have a label.");
      label="";
      can_have_subcommands=1;
    } else if (command_type=="autonumber"){
      if (linestr->good()) fatal("Command " + command + " may never have a label.");
      label = itos(command_counts[command]);
      can_have_subcommands=1;
    } else if (command_type=="labelifrepeated"){
      if (command_counts[command]>1){
        if (!(linestr->good()) || in(get_command_labels(command),std::string(""))){
          fatal("Command " + command + " must have a label if you use it more than once.");
        }
      }
      if (!(linestr->good())) label="";
        can_have_subcommands=1;
    } else if (command_type=="error"){
      can_have_subcommands=1;
    } else {
      // this command has arguments and is not the start of a command block
      if (in(strings,command)){
        fatal("Have found command " + command + " appears twice in the same parameter file.");}
      if (isws(command_line)) fatal("No arguments for command " + command);
      strings.insert(make_pair(command,command_line));
      parameters_accessed[command] = 0;
      can_have_subcommands=0;
    }
    delete linestr;
    getline(in_file,linebuf);
    trim_comment(linebuf);
    linebuf += '\n';
    if (in(linebuf,"}") && !in(linebuf,"{")) fatal("Found a loose } with no matching {");
    while (in(linebuf,"{")){
      while (!in(linebuf,"}")){
            getline(in_file,linebuf);
        trim_comment(linebuf);
        linebuf += '\n';
        if (in(linebuf,"{")) fatal("Found a second { within a {} comment block");
        if (in_file.fail()) {
          fatal("Failed to find the end of comment. Check that there is a '}' character to end the comment block");
        }
      }
      getline(in_file,linebuf);
      trim_comment(linebuf);
      linebuf += '\n';
    }
    if (in_file.fail()){
      if (dict.bad_command){
        fatal("A bad command was found in one of the input parameter files\n");}
          return;
    }
    while(linebuf[0]!='@'){                 // until start of next command block
      if (can_have_subcommands){
        linestr = new istringstream(linebuf.c_str());
        *linestr >> subcommand;
        if (linestr->good()){
          dict.check(command,subcommand,file);
          getline(*linestr,arguments);
          if (isws(arguments)) fatal("No arguments for subcommand " + subcommand + " of command " + command);
          par_name = command;
          if (label != ""){
            par_name += "[" + label + "]";}
          par_name += "." + subcommand;
          if (in(strings,par_name)){
            fatal("Subcommand " + subcommand + " of command " + command + " appears twice in the same parameter file.");}
          strings.insert(make_pair(par_name,arguments));
          parameters_accessed[par_name] = 0;
        }
        delete linestr;
          } else if (!can_have_subcommands){
        if (linebuf[0]!=' ' && linebuf[0]!='\t' && linebuf[0]!='\n' && linebuf[0]!='\r'){
               fatal("Found the following line: " + linebuf + " following command " + command + " which may never have subcommands.");}
          }
      getline(in_file,linebuf);
      trim_comment(linebuf);
      linebuf += '\n';
      if (in(linebuf,"}") && !in(linebuf,"{")) fatal("Found a loose } with no matching {");
      while (in(linebuf,"{")){
        while (!in(linebuf,"}")){
              getline(in_file,linebuf);
          trim_comment(linebuf);
          linebuf += '\n';
          if (in(linebuf,"{")) fatal("Found a second { within a {} comment block");
          if (in_file.fail()) {
            fatal("Failed to find the end of comment. Check that there is a '}' character to end the comment block");
          }
        }
            getline(in_file,linebuf);
        trim_comment(linebuf);
        linebuf += '\n';
      }
      if (in_file.fail()){
        if (dict.bad_command){
         fatal("A bad command has been received was found in one of the input parameter files");}
                return;
      }
    }
  }
}

template<CDVM>
int Parameter_set<DVM>::get_int(const std::string& s, const int default_val){
  DEBUG2("Parameter_set::get_int");
  int component = present(s);
  if (component==4){
    istringstream arguments((strings[s]+" ").c_str());
    std::string result;
    arguments >> result;
    if (!(arguments.fail())){
      std::string dummy;
      arguments >> dummy;
      if (!(arguments.fail())){
        fatal("For " + decompose_into_words(s) + ", you have supplied more than one value.");}
    }
    std::transform(result.begin(),result.end(),result.begin(),(int(*)(int)) tolower);
    int value;
    if (result == "true" || result == "t"){
      value = 1;
    } else if (result == "false" || result == "f"){
      value = 0;
    } else {
          value = stoi(result,"For " + decompose_into_words(s) + ", you did not supply an integer or T/F value.","For " + decompose_into_words(s) + ", you supplied a number with a decimal point in it: use an integer instead.");
    }
    return value;
  }
  // can't find the parameter
  if (default_val != -999){
    return default_val;
  } else {
    // no default argument supplied
    fatal("CASAL needs " + decompose_into_words(s) + ", but does not find it in your parameter files");
  }
}


template<CDVM>
int Parameter_set<DVM>::get_bool(const std::string& comm, const int default_val){
// This function is a modified version of get_int
//
// For the command or subcommand  comm  in a *.csl file read in the input True/T/1/False/F/0
// (and other upper or lowercase variations) and output either 0 (false) or 1 (true).
//
// If the command or subcommand is not given in a *.csl file then assign to it
// the value given by default_val (either 0 or 1).
DEBUG2("Parameter_set::get_bool");

  int component = present(comm);

  // The command/subcommand comm is supplied in a *.csl file
  if (component==4){
    // Find the argument in the *.csl file associated with the string comm
    istringstream arguments((strings[comm]+" ").c_str());
    std::string result;
    arguments >> result;

    if (!(arguments.fail())){
      std::string dummy;
      arguments >> dummy;
      if (!(arguments.fail())){
        fatal("For " + decompose_into_words(comm) + " you have supplied more than one value.");}
    }

    std::transform(result.begin(),result.end(),result.begin(),(int(*)(int)) tolower);
    int value;
    if (result == "true" || result == "t" || result == "1")
      return value = 1;
    else if (result == "false" || result == "f" || result == "0")
      return value = 0;
    else
       fatal("For " + decompose_into_words(comm) + " you did not supply a true/false argument.");
  }

  // the command/subcommand is not in a *.csl file, so use the default value given in the program code
  else if (component==0){
        if (default_val == 0 || default_val == 1)
           return default_val;
        else
            fatal("For " + decompose_into_words(comm) + " a default value of 0 or 1 should be supplied.");
  }

  else
    fatal("There is a problem with the " + decompose_into_words(comm) + " which should take a true/false argument.");

}


template<CDVM>
double Parameter_set<DVM>::get_constant(const std::string& s, const double default_val){
  DEBUG2("Parameter_set::get_constant");
  int component = present(s);
  if (component==4){
    return stod(strings[s],"For " + decompose_into_words(s) + ", you did not supply a valid number.","For " + decompose_into_words(s) + ", you supplied two or more values.");
  }
  // can't find the parameter
  if (default_val != -999){
    return default_val;
  } else {
    // no default argument supplied
    fatal("CASAL needs " + decompose_into_words(s) + ", but does not find it in your parameter files");
  }
}

template<CDVM>
DOUBLE Parameter_set<DVM>::get_estimable(const std::string& s, const DOUBLE& default_val){
  DEBUG2("Parameter_set::get_estimable");
  int component = present(s);
  if (component==1){
    return doubles[s];
  } else if (component==4){
    // it's in the strings rather than the doubles
    return stod(strings[s],"For " + decompose_into_words(s) + ", you did not supply a valid number.","For " + decompose_into_words(s) + ", you supplied two or more values.");
  }
  // can't find the parameter
  if (default_val != -999){
    return default_val;
  } else {
    // no default argument supplied
    fatal("CASAL needs " + decompose_into_words(s) + ", but does not find it in your parameter files");
  }
}

template<CDVM>
dvector Parameter_set<DVM>::get_constant_vector(const std::string& s, const dvector& default_val){
  DEBUG2("Parameter_set::get_constant_vector");
  int component = present(s);
  if (component==4){
    std::string temp;
    int count = 0;
    istringstream arguments((strings[s]+" ").c_str());
    arguments >> temp;
    while (!(arguments.fail())){
      count++;
      arguments >> temp;
    }
    dvector result(1,count);
    istringstream arguments2((strings[s]+" ").c_str());
    for (int i=1; i<=count; i++){
          arguments2 >> temp;
          result[i] = stod(temp,"CASAL found an invalid argument for " + decompose_into_words(s),"CASAL found an invalid argument for " + decompose_into_words(s));
        }
    return result;
  }
  // can't find the parameter
  if (default_val.size()!=1 || default_val[default_val.indexmin()]!=-999){
    return default_val;
  } else {
    // no default argument supplied
    fatal("CASAL needs " + decompose_into_words(s) + ", but does not find it in your parameter files");
  }
}

template<CDVM>
VECTOR Parameter_set<DVM>::get_estimable_vector(const std::string& s, const VECTOR& default_val){
  DEBUG2("Parameter_set::get_estimable_vector");
  int component = present(s);
  if (component==2){
    return vectors[s];
  } else if (component==4){
    // it's in the strings rather than the vectors
    std::string temp;
    int count = 0;
    istringstream arguments((strings[s]+" ").c_str());
    arguments >> temp;
    while (!(arguments.fail())){
      count++;
      arguments >> temp;
    }
    VECTOR result(1,count);
    istringstream arguments2((strings[s]+" ").c_str());
    for (int i=1; i<=count; i++){
          arguments2 >> temp;
          result[i] = stod(temp,"CASAL found an invalid argument for " + decompose_into_words(s),"CASAL found an invalid argument for " + decompose_into_words(s));
        }
    return result;
  }
  // can't find the parameter
  if (default_val.size()!=1 || default_val[default_val.indexmin()]!=-999){
    return default_val;
  } else {
    // no default argument supplied
    fatal("CASAL needs " + decompose_into_words(s) + ", but does not find it in your parameter files");
  }
}

template<CDVM>
VECTOR Parameter_set<DVM>::get_ogive_values(const std::string& s,
                                            Size_at_age<DVM> *size_at_age,
                                            int year, int step, int row,
                                            const DOUBLE& shift,
                                            VECTOR* at_sizes){
  // The size_at_age, year, step, row arguments are used to convert size-based ogives
  //   to age-based ogives in an age-based model. If this doesn't need to be done
  //   then omit them or set them to zero. The 'year' and 'step' arguments are used
  //   because size-at-age changes over time: the 'row' argument refers to a row
  //   of the partition and is necessary because size-at-age can depend on partition characters.
  // The shift argument moves the ogive horizontally. The default (-999) means no shift.
  // The at_sizes argument is intended for printing size-based ogives in age-based models,
  //   and returns the values of the ogive at the sizes provided, rather than for the ages
  //   in the partition.
  DEBUG2("Parameter_set::get_ogive_values");
  if (!ogive_unpacker_members_done){
    set_ogive_unpacker_members();
    ogive_unpacker_members_done = 1;
  }
  int component = present(s);
  if (component==4){
    // it's in the strings rather than the ogives
    // OPTIM: replace with Ogive factory
    // ogives.insert(make_pair(s,make_ogive<DVM>(strings[s],size_based,low,high,decompose_into_words(s))));
    ogives.insert(make_pair(s,Ogive_factory<DVM>::make_ogive(strings[s],size_based,low,high,decompose_into_words(s))));
  } else if (component != 3){
    fatal("CASAL needs " + decompose_into_words(s) + ", but does not find it in your parameter files");
  }
  if (at_sizes != 0 && (size_based || !ogives[s]->size_based)){
    fatal("Only provide at_sizes to get_ogive_values for a size-based ogive in an age-based model");}
  VECTOR result(low,high);
  VECTOR result2((at_sizes!=0) ? at_sizes->size() : 1);
  int do_shift = (shift != -999);
  if (do_shift){ // move the ogive horizontally
    ogives[s]->shift(shift);}
  if (size_based){
    // this is a size-based model
    if (!ogives[s]->by_class()){
      // For this ogive type, get_value() takes a size not a size class.
      for (int i=low; i<=high; i++){
        DOUBLE temp_ogive_value = (double)((*class_sizes)[i]); // AD: we do this because betadiff (probably) convinces the compiler that class_size is sometimes an int, rather than DOUBLE
        result[i] = ogives[s]->get_value(temp_ogive_value);
      }
    } else {
      // For this ogive type, get_value() takes a size class: straightforward.
      for (int i=low; i<=high; i++){
        result[i] = ogives[s]->get_value(i);
      }
    }
  } else if (!size_based && ogives[s]->size_based){
    if (ogives[s]->by_class()){
      fatal("Don't know how to convert size-based ogives of type " + ogives[s]->type + " to age-based.");}
    if (at_sizes == 0){
      // this is a size-based ogive in an age-based model - need to convert to age-based.
      VECTOR mean_sizes(size_at_age->get_mean_sizes_at(year,step,row));
      std::string dist = size_at_age->get_dist();
      if (dist=="none" || n_quant<=1){
        // just use the mean size at age
        for (int i=low; i<=high; i++){
          result[i] = ogives[s]->get_value(mean_sizes[i]);
        }
      } else {
        // use the distribution of sizes at age
        VECTOR cvs(size_at_age->get_all_cvs()[row]);
        int is_by_length = size_at_age->cvs_by_length;
        if(is_by_length) {
          // variation in cvs actually specified by length - not age
          VECTOR temp=cvs;
          for (int i=1; i<=temp.size(); i++){
            temp[i]=(mean_sizes[i]-mean_sizes[1])*(cvs[cvs.size()]-cvs[1])/(mean_sizes[mean_sizes.size()]-mean_sizes[1]) + cvs[1];
            if(temp[i]<0) temp[i]=0;
          }
          cvs=temp;
        }
        int is_stdev = size_at_age->cvs_actually_stdevs;
        if (is_stdev){
          for (int i=low; i<=high; i++){
                          cvs[i] /= mean_sizes[i];}} // convert stdev to cv
        DOUBLE mu,sigma,size;
        for (int i=low; i<=high; i++){
          if (dist=="lognormal"){
            // calculate mean and st.dev. of log(length) to pass to qlognorm
            sigma = sqrt(log(1+cvs[i]*cvs[i]));
            mu = log(mean_sizes[i]) - sigma*sigma*0.5;
          } else if (dist=="normal"){
            mu = mean_sizes[i];
            sigma = mu * cvs[i];
          }
          // calculate ogive at 'n_quant' evenly spaced quantiles of size dist, take average value
          DOUBLE sum_ogive_values = 0;
          for (int j=1; j<=n_quant; j++){
            if (dist=="lognormal"){
              size = qlognorm<DOUBLE>((*quantiles)[j],mu,sigma);
            } else if (dist=="normal"){
              // speed up the works by storing the standard normal quantiles
              // rather than recalculating them each time
              size = mu + sigma*((*quantiles_at)[j]);
            }
            sum_ogive_values += ogives[s]->get_value(size);
          }
          result[i] = sum_ogive_values / n_quant;
        }
      }
    } else if (at_sizes != 0){
      // evaluate the ogive at the sizes in at_sizes (typically for printing)
      for (int i=1; i<=at_sizes->size(); i++){
        result2[i] = ogives[s]->get_value((*at_sizes)[i]);
      }
    }
  } else {
    // this is an age-based ogive in an age-based model - straightforward.
    for (int i=low; i<=high; i++){
      if (ogives[s]->by_class()){
        result[i] = ogives[s]->get_value(i);
      } else {
        result[i] = ogives[s]->get_value(DOUBLE(i));
      }
    }
  }
  if (do_shift){ // put the ogive back the way it was
    ogives[s]->shift(-shift);}
  if (at_sizes==0) return result;
  else return result2;
}

template<CDVM>
int Parameter_set<DVM>::get_ogive_base(const std::string& s){
  // return 1 if size-based
  DEBUG2("Parameter_set::get_ogive_base");
  if (!ogive_unpacker_members_done){
    set_ogive_unpacker_members();
    ogive_unpacker_members_done = 1;
  }
  int component = present(s);
  if (component==3){
    return ogives[s]->size_based;
  } else if (component==4){
    // it's in the strings rather than the ogives
    istringstream arguments((strings[s]+" ").c_str());
    std::string base;
    arguments >> base;
    if (base == "size_based"){
      return 1;
    } else {
      return size_based;
    }
  }
  // can't find the parameter
  fatal("CASAL needs " + decompose_into_words(s) + ", but does not find it in your parameter files");
}

template<CDVM>
std::string Parameter_set<DVM>::get_ogive_type(const std::string& s){
  DEBUG2("Parameter_set::get_ogive_type");
  if (!ogive_unpacker_members_done){
    set_ogive_unpacker_members();
    ogive_unpacker_members_done = 1;
  }
  int component = present(s);
  if (component==3){
    return ogives[s]->type;
  } else if (component==4){
    // it's in the strings rather than the ogives
    istringstream arguments((strings[s]+" ").c_str());
    std::string type;
    arguments >> type;
    if (type == "size_based"){
      arguments >> type;}
    return type;
  }
  // can't find the parameter
  fatal("CASAL needs " + decompose_into_words(s) + ", but does not find it in your parameter files");
}

template<CDVM>
VECTOR Parameter_set<DVM>::get_ogive_free_parameters(const std::string& s){
  DEBUG2("Parameter_set::get_ogive_free_parameters");
  if (!ogive_unpacker_members_done){
    set_ogive_unpacker_members();
    ogive_unpacker_members_done = 1;
  }
  int component = present(s);
  if (component==3){
    return ogives[s]->get_free_parameters();
  } else if (component==4){
    // it's in the strings rather than the ogives
    Ogive<DVM>* ogive;
    // OPTIM: replace with Ogive_factory
    // ogive = make_ogive<DVM>(strings[s],size_based,low,high,decompose_into_words(s));
    ogive = Ogive_factory<DVM>::make_ogive(strings[s],size_based,low,high,decompose_into_words(s));
    VECTOR free_params(ogive->get_free_parameters());
    delete ogive;
    return free_params;
  } else {
    fatal("CASAL needs " + decompose_into_words(s) + ", but does not find it in your parameter files");
  }
}

template<CDVM>
std::string Parameter_set<DVM>::get_string(const std::string& s, const std::string& default_val){
  DEBUG2("Parameter_set::get_string");
  int component = present(s);
  if (component==4){
    std::string word, dummy;
    istringstream arguments((strings[s]+" ").c_str());
    arguments >> word;
    if (!(arguments.fail())){
          arguments >> dummy;
          if (!(arguments.fail())){
                fatal("For " + decompose_into_words(s) + ", you supplied two or more values.");
          }
        }
    return word;
  }
  // can't find the parameter
  if (default_val != "don't use default"){
    return default_val;
  } else {
    // no default argument supplied
    fatal("CASAL needs " + decompose_into_words(s) + ", but does not find it in your parameter files");
  }
}

template<CDVM>
std::vector<std::string> Parameter_set<DVM>::get_vector_of_strings(const std::string& s,
                                                        const std::vector<std::string>& default_val){
  DEBUG2("Parameter_set::get_vector_of_strings");
  int component = present(s);
  if (component==4){
    std::vector<std::string> result;
    istringstream arguments((strings[s]+" ").c_str());
    std::string word;
    while (!(arguments.fail())){
      arguments >> word;
      if (!(arguments.fail())){
                result.push_back(word);
      }
    }
    return result;
  }
  if (default_val != std::vector<std::string>(1,"don't use default")){
    return default_val;
  } else {
    // no default argument supplied
    fatal("CASAL needs " + decompose_into_words(s) + ", but does not find it in your parameter files");
  }
}

template<CDVM>
int Parameter_set<DVM>::present(const std::string& s){
  // Returns 0 if parameter s is not in the Parameter_set, or a positive value
  // indicating the type of s if it is:
  // 1 = double
  // 2 = vector
  // 3 = ogive
  // 4 = string
  // Marks the parameter as accessed.
  DEBUG2("Parameter_set::present  "+s);
  parameters_accessed[s] = 1;
  if (in(doubles,s)) return 1;
  if (in(vectors,s)) return 2;
  if (in(ogives,s))  return 3;
  if (in(strings,s)) return 4;
  return 0;
}

template<CDVM>
int Parameter_set<DVM>::get_command_count(const std::string& s){
  // Returns the number of times command 's' occurs in the Parameter_set.
  // So if the Parameter_set contains "fishery[1].name", "fishery[1].area",
  //                                  "fishery[2].name", "fishery[2].area",
  // get_command_count("fishery")==2  (not 4 - "name" and "area" are subcommands)
  DEBUG2("Parameter_set::get_command_count");
  if (in(command_counts,s)){
    return command_counts[s];
  } else {
    return 0;
  }
}

template<CDVM>
std::vector<std::string> Parameter_set<DVM>::get_command_labels(const std::string& s){
  // Returns the list of labels with which command 's' occurs in the Parameter_set.
  // So if the Parameter_set contains "fishery[trawl].area", "fishery[longline].area", etc...,
  // the result of get_command_labels("fishery") is a vector containing "trawl", "longline".
  DEBUG2("Parameter_set::get_command_labels");
  std::vector<std::string> result;
  std::string this_parameter, this_command, this_label, this_subcommand;
  typedef typename std::map<std::string,std::string>::iterator MAP_IT;
  for (MAP_IT i=strings.begin(); i!=strings.end(); ++i){
    this_parameter = i->first;
    decompose(this_parameter, this_command, this_label, this_subcommand);
    if (this_command == s){
      if (!in(result,this_label)){
        result.push_back(this_label);
      }
    }
  }
  return result;
}

template<CDVM>
void Parameter_set<DVM>::put_int(std::string name, int i){
  // insert 'name' = i into the 'strings' compartment of the Parameter_set,
  // update command_counts if necessary
  DEBUG2("Parameter_set::put_int");
  update_command_counts(name);
  std::string val = itos(i);
  strings[name] = val;
}

template<CDVM>
void Parameter_set<DVM>::put_constant(std::string name, double d){
  // insert 'name' = d into the 'strings' compartment of the Parameter_set,
  // update command_counts if necessary
  DEBUG2("Parameter_set::put_constant");
  update_command_counts(name);
  std::string val = dtos(d);
  strings[name] = val;
}

template<CDVM>
void Parameter_set<DVM>::put_estimable(std::string name, DOUBLE d){
  // insert 'name' = d into the 'doubles' compartment of the Parameter_set,
  // update command_counts if necessary
  DEBUG2("Parameter_set::put_estimable");
  update_command_counts(name);
  doubles[name] = d;
}

template<CDVM>
void Parameter_set<DVM>::put_constant_vector(std::string name, const dvector& v){
  // check that the indices of v start from 1,
  // insert 'name' = v into the 'strings' compartment of the Parameter_set,
  // update command_counts if necessary
  DEBUG2("Parameter_set::put_constant_vector");
  if (v.indexmin() != 1){
    fatal("Only use Parameter_set::put_constant_vector on vectors whose indices start from 1");}
  update_command_counts(name);
  std::string val="";
  for (int i=1; i<=v.size(); i++){
    val += (dtos(v[i]) + " ");}
  strings[name] = val;
}

template<CDVM>
void Parameter_set<DVM>::put_estimable_vector(std::string name, const VECTOR& v){
  // check that the indices of v start from 1,
  // insert 'name' = v into the 'vectors' compartment of the Parameter_set,
  // update command_counts if necessary
  DEBUG2("Parameter_set::put_estimable_vector");
  if (v.indexmin() != 1){
    fatal("Only use Parameter_set::put_estimable_vector on vectors whose indices start from 1");}
  update_command_counts(name);
  if (in(vectors,name)){
    if (vectors[name].size() != v.size()){
      fatal("Cannot do put_estimable_vector " + name + " because the size of the vector has changed");
    } else {
      vectors[name] = v;
    }
  } else {
    vectors.insert(make_pair(name,v));
  }
}

template<CDVM>
void Parameter_set<DVM>::put_ogive(std::string name, const VECTOR& v){
  // Put the ogive 'name' into the 'ogives' compartment of the Parameter_set.
  // Set the free parameters of the ogive to 'v'.
  // Only works for ogives which are already in the 'strings' compartment,
  // i.e. have been read in using read_file().
  // Update command_counts if necessary
  DEBUG2("Parameter_set::put_ogive");
  update_command_counts(name);
  if (!ogive_unpacker_members_done){
    set_ogive_unpacker_members();
    ogive_unpacker_members_done = 1;
  }
  if (present(name)==0){
    fatal("Attempt to use put_ogive on an ogive which is not already in the Parameter_set");}
  if (present(name)==4){ // it is only in the strings compartment, move it into the ogives section
    //OPTIM: replaced with Ogive_factory
    // ogives.insert(make_pair(name,make_ogive<DVM>(strings[name],size_based,low,high,decompose_into_words(name))));
    ogives.insert(make_pair(name,Ogive_factory<DVM>::make_ogive(strings[name],size_based,low,high,decompose_into_words(name))));
  }
  ogives[name]->set_free_parameters(v);
}

template<CDVM>
void Parameter_set<DVM>::put_string(std::string name, const std::string& s){
  // insert 'name' = s into the 'strings' compartment of the Parameter_set,
  // update command_counts if necessary
  DEBUG2("Parameter_set::put_string");
  update_command_counts(name);
  strings[name] = s;
}

template<CDVM>
void Parameter_set<DVM>::put_vector_of_strings(std::string name, std::vector<std::string>& vs){
  // insert 'name' = vs into the 'strings' compartment of the Parameter_set,
  // update command_counts if necessary
  DEBUG2("Parameter_set::put_vector_of_strings");
  update_command_counts(name);
  std::string val="";
  for (int i=0; i<vs.size(); i++){
    val += (vs[i] + " ");}
  strings[name] = val;
}

template<CDVM>
void Parameter_set<DVM>::update_command_counts(std::string& name){
  // Called by all the put_ functions, when they are adding parameter 'name',
  // to update the command counts if necessary.
  // Also converts names of form command[1].subcommand into just command.subcommand.
  DEBUG2("Parameter_set::update_command_counts");
  std::string command, label, subcommand;
  decompose(name, command, label, subcommand);
  if (command_counts[command]==0){
    command_counts[command] = 1;
  } else {
    // what labels does this command have so far?
    // e.g. if we already have fishery[trawl] and fishery[longline],
    // then adding fishery[trawl].area  would require no change to command_counts,
    // but  adding fishery[setnet].area would require command_counts["fishery"] to be incremented,
    // Incidentally, we don't check for fishery[].area, or fishery[6].area when we only
    // have fishery[1].area and fishery[2].area, both of which should probably be errors.
    std::string this_parameter, this_command, this_label, this_subcommand;
    typedef typename std::map<std::string,std::string>::iterator MAP_IT;
    for (MAP_IT i=strings.begin(); i!=strings.end(); ++i){
      this_parameter = i->first;
      decompose(this_parameter, this_command, this_label, this_subcommand);
      if (this_command == command && this_label == label) return;
    }
    command_counts[command]++; // if we are still here, we have not had this command
                               // with this label before
  }
}

template<CDVM>
std::vector<std::string> Parameter_set<DVM>::get_unused(ostream& out){
  // Return a list of the names of the parameters which were read in from the
  //  file and never accessed.
  DEBUG0("Parameter_set::get_unused");
  std::vector<std::string> result;
  typedef typename std::map<std::string,int>::iterator MAP_IT;
  for (MAP_IT i=parameters_accessed.begin(); i!=parameters_accessed.end(); ++i){
    if (i->second == 0){
      result.push_back(i->first);}
  }
  return result;
}

template<CDVM>
void Parameter_set<DVM>::extract_subcommands_of_command(Parameter_set<DVM>& to, std::string command, std::string label){
  // Find all the string parameters in this Parameter_set which are subcommands of 'command[label]'.
  // Put them into a second Parameter_set 'to' (empty it first).
  // Used when writing out simulated observations.
  std::string this_parameter, this_command, this_label, this_subcommand;
  to.empty();
  typedef typename std::map<std::string,std::string>::iterator MAP_IT;
  for (MAP_IT i=strings.begin(); i!=strings.end(); ++i){
    this_parameter = i->first;
    decompose(this_parameter, this_command, this_label, this_subcommand);
    if (this_command == command && this_label == label){
                to.strings.insert(make_pair(i->first,i->second));
    }
  }
}

template<CDVM>
void Parameter_set<DVM>::dump_as_subcommands(ostream &o){
        // Should be called by the Parameter_set created by extract_subcommands_of_command.
        // Dump the subcommands (not the original command) to the ostream.
        // Used when writing out simulated observations.
        std::string this_parameter, this_command, this_label, this_subcommand;
    typedef typename std::map<std::string,std::string>::iterator MAP_IT;
        for (MAP_IT i=strings.begin(); i!=strings.end(); ++i){
            this_parameter = i->first;
            decompose(this_parameter, this_command, this_label, this_subcommand);
            o << this_subcommand << " " << i->second << '\n';
        }
}

template<CDVM>
void Parameter_set<DVM>::print(ostream& out){
  DEBUG1("Parameter_set::print");
  out << "Stored as strings: " << strings;
  out << "Stored as DOUBLEs: " << doubles;
  out << "Stored as VECTORs: " << vectors;
  out << "Stored as OGIVEs: " << ogives;
  out << '\n';
}

template<CDVM>
void Parameter_set<DVM>::set_ogive_unpacker_members(){
  // Extract the population parameters which are needed to calculate ogive values.
  // The assumption is that this is the Population parameter_set, and hence
  // will contain everything necessary.
  DEBUG2("Parameter_set::set_ogive_unpacker_members");
  size_based = get_bool("size_based",0);
  low = size_based ? 1 : get_int("min_age");
  high = size_based ? get_int("n_classes") : get_int("max_age");
  if (size_based){
    if (class_sizes != 0) delete class_sizes;
    class_sizes = new dvector(low,high);
    dvector class_mins(get_constant_vector("class_mins"));
    for (int i=low; i<high; i++){
      (*class_sizes)[i] = (class_mins[i] + class_mins[i+1]) * 0.5;
    }
    if (get_bool("plus_group",1)){
      if (class_mins.size() != (high-low+1)) fatal("class_mins is the wrong size");
      (*class_sizes)[high] = (double)get_int("plus_group_size");
    } else {
      if (class_mins.size() != (high-low+2)) fatal("class_mins is the wrong size");
      (*class_sizes)[high] = (class_mins[high] + class_mins[high+1]) * 0.5;
    }
  }
  n_quant = get_int("n_quant",5);
  if (quantiles != 0) delete quantiles;
  if (quantiles != 0) delete quantiles_at;
  quantiles = new dvector(1,n_quant);
  quantiles_at = new dvector(1,n_quant);
  for (int i=1; i<=n_quant; i++){
    (*quantiles)[i] = ((double)i-0.5) / n_quant;
    (*quantiles_at)[i] = qnorm<double>((*quantiles)[i],0,1); // evenly spaced standard normal quantiles
  }
}

template<CDVM>
void Parameter_set<DVM>::empty(){
  DEBUG2("Parameter_set::empty");
  strings = std::map<std::string,std::string>();
  doubles = std::map<std::string,DOUBLE>();
  vectors = std::map<std::string,VECTOR>();
  ogives  = std::map<std::string,Ogive<DVM>*>();
  command_counts = std::map<std::string,int>();
  ogive_unpacker_members_done = 0;
}

template<CDVM>
Parameter_set<DVM>::Parameter_set(){
  DEBUG2("Parameter_set::Parameter_set");
  class_sizes = 0;
  quantiles = 0;
  empty();
}

template<CDVM>
Parameter_set<DVM>::~Parameter_set(){
  DEBUG1("~Parameter_set");
  typedef typename std::map<std::string,Ogive<DVM>*>::iterator MAP_IT;
  for (MAP_IT i=ogives.begin(); i!=ogives.end(); ++i){
    delete i->second;}
  if (class_sizes != 0) delete class_sizes;
  if (quantiles != 0) delete quantiles;
}

template<CDVM>
std::string check_parname(std::string& parname, Parameter_set<DVM>& p, Parameter_set<DVM>& e, std::string source, std::vector<std::string>& permitted_types){
        // A bit of an odd one out. This function is used to check user-specified parameter names,
        // as in the @estimate, @profile, and @quantity blocks. Does the parameter really exist,
        // is it in the parameter set(s) provided, is it of the designated type.
        // Returns the type of the parameter ("estimable", "constant" etc) or errors out.
        DEBUG2("check_parname");
    std::string command, subcommand, label;
    decompose(parname,command,label,subcommand);
    std::string status, loc, partype;
    if (subcommand!=""){
                // OPTIM: replaced dict.check with p.dictionary().check throughout function
                status = p.dictionary().check(command,subcommand,"P",1);
                if (status=="error"){
                        status = p.dictionary().check(command,subcommand,"E",1);
                        if (status=="error"){
                                fatal("You ask for parameter " + parname + " in " + source + ". This is not a valid CASAL parameter.");
                        } else loc="E";
                } else loc="P";
                if (label=="" && p.dictionary().check(command,loc)=="autonumber"){
                        fatal("You ask for parameter " + parname + " in " + source + ". But you have not specified a label and this command must always have a numeric label. For instance, if it is a growth parameter in a size-based model, label it with '1' for the first growth episode, etc. E.g. growth[1].g");
                } else if (label=="" && p.dictionary().check(command,loc)=="label"){
                        fatal("You ask for parameter " + parname + " in " + source + ". But you have not specified a label and this command must always have a label.");
                } else if (label!="" && p.dictionary().check(command,loc)=="nolabel"){
                        fatal("You ask for parameter " + parname + " in " + source + ". But you have specified a label and this command can never have a label.");
                }
        } else if (subcommand==""){
                status = p.dictionary().check(command,"P",1);
                if (status=="error"){
                        status = p.dictionary().check(command,"E",1);
                        if (status=="error"){
                                fatal("You ask for parameter " + parname + " in " + source + ". This is not a valid CASAL parameter.");
                        } else loc="E";
                } else loc="P";
        }
        partype = status;
        if (!in(permitted_types,partype)){
                fatal("You ask for parameter " + parname + " in " + source + ". This parameter cannot be estimated because it is of type " + partype + ". Only parameters of types estimable, estimable_vector, or ogive can be estimated.");
        }
        if (!p.present(parname) && !e.present(parname)){
                fatal("You ask for parameter " + parname + " in " + source + ". This is a legitimate CASAL parameter but CASAL cannot find it in your population or estimation parameter file.\n");}
        return partype;
}
//############################## END OF PARAMETER SET.cpp ##############################

// Create particular instantiations of the template
template class Parameter_set<double, dvector, dmatrix>;
template class Parameter_set<dvariable, dvv, dvm>;
template std::string check_parname(std::string&,
                                   Parameter_set<double, dvector, dmatrix>&,
                                   Parameter_set<double, dvector, dmatrix>&,
                                   std::string,
                                   std::vector<std::string>&);
template std::string check_parname(std::string&,
                                   Parameter_set<dvariable, dvv, dvm>&,
                                   Parameter_set<dvariable, dvv, dvm>&,
                                   std::string,
                                   std::vector<std::string>&);
