// const char* time_stamp = "$Date: 2012-02-23 12:05:33 +1300 (Thu, 23 Feb 2012) $\n";
// const char* ogive_id = "$Id: ogive.h 4553 2012-02-22 23:05:33Z Dunn $\n";

#if !defined(OGIVE)
#define OGIVE

//############################## OGIVES ##############################
#include <string>
#include <iostream>

#include "development.h"

///////////////////////////////////////////////////////////////////////
template<CDVM> class Ogive{
  // The Ogive class specifies the interface for the ogive types which inherit from it,
  // including Ogive_constant, Ogive_knife_edge, Ogive_allvalues, etc.
  //
  // The key functions are get_value(DOUBLE) which extracts the ogive value at a particular point,
  //  or get_value(int), which extracts the ogive value for a particular size or age class,
  //  and by_class() which is 0 if get_value() takes a DOUBLE or 1 if an int.
  // Also set_free_parameters() which supplies a set of free parameters,
  //  and get_free_parameters() which returns the current ones.
  // Each ogive type should have a constructor, which is passed a vector of parameters,
  //  two integers indicating the range of indices in the ogive, a switch indicating whether
  //  the ogive is size-based, and a string which is the ogive type.
  // Both the constructor and see_free_parameters() should check the size of the
  //  parameter vector provided.
  // And don't forget a destructor, if any memory is allocated.
  //
  // Have added the shift(DOUBLE size) function, which shifts the ogive 'size' units to the right.
  // Not all ogives provide this function.
  //
  // See also the function make_ogive, which sorts out the construction of an ogive
  //  from a string such as 'sizebased logistic 8 2', and returns an Ogive*. Need to tell
  //  it whether the model is size-based and give it the range of columns in the partition.
  //  This is called by Parameter_set::get_ogive_values and ::put_ogive.
  //
  // See class Basic_ogive_size_to_age for conversion of size-based ogives to
//  age-based ogives.
public:
  virtual DOUBLE get_value(const DOUBLE& x);
  // Return the value of the ogive at x.
  virtual DOUBLE get_value(int classno);
  // For 'allvalues' or 'allvalues_bounded' ogives, which are to be indexed by size or age class number.
  virtual int by_class() = 0;
  // = 1 if get_value takes an int, 0 if it takes a DOUBLE
  virtual void set_free_parameters(const VECTOR& pars) = 0;
  // Supply the ogive with free parameters, as a VECTOR with indices 1, 2...
  virtual VECTOR get_free_parameters() = 0;
  // Returns the free parameters of the ogive, as a VECTOR with indices 1, 2...
  virtual void shift(const DOUBLE& size);
  // Shifts the ogive 'size' units to the right.
  int low, high;
  // The minimum and maximum indices of the ogive
  int size_based;
  // Equals 1 if the ogive is size-based, or 0 if age-based.
  std::string type;
  // 'constant', 'logistic', 'knife_edge', etc...
  std::string command;
  // a text string giving the command and subcommand name, used in error messages
  Ogive(int _low, int _high, int _size_based, const std::string& _type, std::string _command);
  virtual ~Ogive();
};

// OPTIM: make_ogive placed inside a class becasue for some reason g++ wouldn't let one instantiate the required templated versions of make_ogive when it was just a function.
// template<CDVM>
// Ogive<DVM>* make_ogive(const std::string& s, int sizebased_model, int min_class, int max_class, std::string _command);
template<CDVM>
class Ogive_factory{
 public:
  static Ogive<DVM>* make_ogive(const std::string& s, int sizebased_model, int min_class, int max_class, std::string _command);
};

template<CDVM>
class Ogive_constant : public Ogive<DVM>{
// Ogive_constant is an implementation of class Ogive in which all values are equal.
// The only parameter is the value C.
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_constant(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE C;
};

template<CDVM>
class Ogive_knife_edge : public Ogive<DVM>{
  // Ogive_knife_edge is an implementation of class Ogive in which all values below
  //  an 'edge' is 0 and all values equal to or higher than the edge are 1.
  // The only parameter is E, the position of the edge.
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  Ogive_knife_edge(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  double E;
};

template<CDVM>
class Ogive_allvalues : public Ogive<DVM>{
  // Ogive_allvalues is an implementation of class Ogive in which every value is specified
  // separately. There is one parameter V for each index.
public:
  DOUBLE get_value(int classno);
  int by_class(){return 1;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  Ogive_allvalues(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  VECTOR V;
};

template<CDVM>
class Ogive_allvalues_bounded : public Ogive<DVM>{
  // Ogive_allvalues_bounded is an implementation of class Ogive in which lower and
  // upper bounds are specified, every value between those bounds (inclusive) is specified,
  // everything below the lower bound is 0, and everything above the upper bound is the
  // same as at the upper bound.
  // There are parameters L and H and one V for every index between them (inclusive).
public:
  DOUBLE get_value(int classno);
  int by_class(){return 1;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  Ogive_allvalues_bounded(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  int L, H;
  VECTOR V;
};

template<CDVM>
class Ogive_logistic : public Ogive<DVM>{
  // Ogive_logistic is an implementation of class Ogive for a logistic curve.
  // There are two parameters, a50 and a_to95 (the curve reaches 0.5 at a50 and 0.95 at a50+a_to95).
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_logistic(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95;
};

template<CDVM>
class Ogive_logistic_capped : public Ogive<DVM>{
  // Ogive_logistic_capped is an implementation of class Ogive for a logistic curve.
  // There are three parameters, a50 and a_to95, and a_max (the curve reaches 0.5*a_max at a50 and 0.95*a_max at a50+a_to95).
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_logistic_capped(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95, a_max;
};

template<CDVM>
class Ogive_logistic_product : public Ogive<DVM>{
  // Ogive_logistic_product is an implementation of class Ogive for a logistic curve.
  // There are five parameters, a50 and a_to95, b50, b_to95, and a_max.
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_logistic_product(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95, b50, b_to95, a_max, function_max, temp_var;
};

template<CDVM>
class Ogive_double_logistic : public Ogive<DVM>{
  // Ogive_double_logistic is an implementation of class Ogive for a combination of two logistic curves.
  // (a) is increasing, (b) is decreasing.
  // The value of the ogive is the minimum of the two logistic functions at that x-value.
  // There are five parameters, a50 and a_to95, b50, b_to95, and a_max.
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_double_logistic(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95, b50, b_to95, a_max, p, function_max;
};

template<CDVM>
class Ogive_logistic_bounded : public Ogive<DVM>{
  // Ogive_logistic_bounded is an implementation of class Ogive for a logistic curve
  // which drops to 0 below the 5th percentile and rises to 1 above the 95th percentile.
  // There are two parameters, a50 and a_to95 (the curve reaches 0.5 at a50 and 0.95 at a50+a_to95)
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_logistic_bounded(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95;
};

template<CDVM>
class Ogive_double_normal : public Ogive<DVM>{
  // Ogive_double_normal is an implementation of class Ogive for a double_normal curve.
  // There are three parameters, a1, sL, and sR (the ogive equals 1 at a1,
  // 0.5 at x=a1-sL and x=a1+sR)
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_double_normal(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a1, sL, sR;
};

template<CDVM>
class Ogive_double_normal_capped : public Ogive<DVM>{
  // Ogive_double_normal_capped is an implementation of class Ogive for a double_normal curve.
  // There are four parameters, a1, sL, sR, a_max (the ogive equals a_max at a1,
  // 0.5*a_max at x=a1-sL and x=a1+sR)
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_double_normal_capped(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a1, sL, sR, a_max;
};

template<CDVM>
class Ogive_double_normal_coleraine : public Ogive<DVM>{
  // Ogive_double_normal_coleraine is an implementation of class Ogive for a double_normal curve
  // using the Coleraine parameterization.
  // There are three parameters, a1, varL, and varR.
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_double_normal_coleraine(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a1, varL, varR;
};

template<CDVM>
class Ogive_double_normal_plateau : public Ogive<DVM>{
  // Ogive_double_normal_plateau is an implementation of class Ogive for a double_normal curve.
  // There are five parameters, a1, a2, sL, sR, a_max (the ogive equals a_max between a1 and a1+a2,
  // 0.5*a_max at x=a1-sL and x=(a1+a2)+sR)
  // It is essentially the same as the double_normal_capped, except with a plateau between a1 and a1+a2
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_double_normal_plateau(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a1, a2, sL, sR, a_max;
};

template<CDVM>
class Ogive_logistic_producing : public Ogive<DVM>{
  // Ogive_logistic_producing is an implementation of class Ogive which produces
  // rates which (in the absence of other influences) accumulate to generate a
  // logistic ogive with specified 50th percentile (a50) and 95th percentile (a50 + a_to95).
  // The ogive is bounded: values below L are set to 0, and values equal to or
  // above H to 1. Values in between are chosen to generate the specified logistic ogive.
  // This form of ogive was introduced to emulate the maturation ogives in the UW hoki model.
public:
  DOUBLE get_value(int classno);
  int by_class(){return 1;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  Ogive_logistic_producing(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95;
  int L, H;
  VECTOR logistic_ogive;
};

template<CDVM>
class Ogive_increasing : public Ogive<DVM>{
  // Ogive_increasing is like Ogive_allvalues_bounded except that the parameterization
  // is changed so that the ogive is nondecreasing. Lower and upper bounds are specified,
  // everything below the lower bound is 0, and everything above the upper bound is the same as the
  // upper bound, and 'pi' parameters control the rate of increase in between.
  // For L <= x <= H, f(x) = f(x-1) + pi_i * (1-f(x-1)).
  // There are parameters L and H and one pi for every index between them.
public:
  DOUBLE get_value(int classno);
  int by_class(){return 1;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  Ogive_increasing(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  int L, H;
  VECTOR pi;
};

template<CDVM>
class Ogive_increasing_capped : public Ogive<DVM>{
  // Ogive_increasing_capped is like Ogive_increasing except that there is a cap C towards which
  // it climbs.
  // For x < L, f(x) = 0.
  // For L <= x < H, f(x) = f(x-1) + pi_i * (C-f(x-1)).
  // For x >= H, f(x) = C.
  // There are parameters L, H, C and one pi for every index from L to H-1.
public:
  DOUBLE get_value(int classno);
  int by_class(){return 1;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  Ogive_increasing_capped(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  int L, H;
  double C;
  VECTOR pi;
};

template<CDVM>
class Ogive_richards : public Ogive<DVM>{
  // Ogive_richards_capped is an implementation of class Ogive for a Richards 3-parameter logistic curve.
  // There are three parameters, a50, a_to95, and delta (the curve reaches 0.5 at a50 and 0.95 at a50+a_to95).
  // delta is the asymetric parameter
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_richards(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95, delta, alpha, beta;
};

template<CDVM>
class Ogive_richards_capped : public Ogive<DVM>{
  // Ogive_richards_capped is an implementation of class Ogive for a Richards 3-parameter logistic curve.
  // There are four parameters, a50, a_to95, delta, and a_max (the curve reaches 0.5*a_max at a50 and 0.95*a_max at a50+a_to95).
  // delta is the asymetric parameter
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_richards_capped(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95, delta, a_max, alpha, beta;
};

template<CDVM>
class Ogive_hillary : public Ogive<DVM>{
  // Ogive_hillary is an implementation of class Ogive for a implemetation of a declining right-hand limb curve
  // There are four parameters, alpha, psi, gamma, a_max (the ogive equals a_max at alpha+psi)
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_hillary(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE alpha, gamma, psi;
};

template<CDVM>
class Ogive_hillary_capped : public Ogive<DVM>{
  // Ogive_hillary is an implementation of class Ogive for a implemetation of a declining right-hand limb curve
  // There are four parameters, alpha, psi, gamma, a_max (the ogive equals a_max at alpha+psi)
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_hillary_capped(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE alpha, gamma, psi, a_max;
};

template<CDVM>
class Ogive_cosh : public Ogive<DVM>{
  // Ogive_cosh is an implementation of class Ogive for a implemetation of "u" shaped ogive
  // There are four parameters, min_value, min_x, alpha, and beta
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_cosh(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE min_value, min_x, alpha, beta;
};

template<CDVM>
class Ogive_double_exponential : public Ogive<DVM>{
  // Ogive_double_exponential is an implementation of class Ogive for a implemetation of "u" shaped ogive
  // There are four parameters, x0, y0, y1, and y2, and two non-estimable parameters, x1 and x2
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  Ogive_double_exponential(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  double x1, x2;
  VECTOR V;
};

template<CDVM>
class Ogive_CompoundAll : public Ogive<DVM>{
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_CompoundAll(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95, amin, leftmu, to_rightmu, sd, Logistic, Left, Right;
};

template<CDVM>
class Ogive_CompoundLeft : public Ogive<DVM>{
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_CompoundLeft(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95, amin, leftmu, to_rightmu, sd, Logistic, Left, Right;
};

template<CDVM>
class Ogive_CompoundMiddle : public Ogive<DVM>{
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_CompoundMiddle(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95, amin, leftmu, to_rightmu, sd, Logistic, Left, Right;
};

template<CDVM>
class Ogive_CompoundRight : public Ogive<DVM>{
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_CompoundRight(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95, amin, leftmu, to_rightmu, sd, Logistic, Left, Right;
};

template<CDVM>
class Ogive_Tuck_logistic_m : public Ogive<DVM>{
  // Ogive_Tuck_logistic_m is an implementation of class Ogive for a logistic curve.
  // There are 4 parameters, a50 and a_to95, a_maxm and a_maxf (the curve reaches 0.5*a_maxm at a50 and 0.95*a_maxm at a50+a_to95).
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_Tuck_logistic_m(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95, a_maxm,a_maxf;
};

template<CDVM>
class Ogive_Tuck_logistic_f : public Ogive<DVM>{
  // Ogive_Tuck_logistic_f is an implementation of class Ogive for a logistic curve.
  // There are 4 parameters, a50 and a_to95, a_maxm and a_maxf (the curve reaches 0.5*a_maxf at a50 and 0.95*a_maxf at a50+a_to95).
public:
  DOUBLE get_value(const DOUBLE& x);
  int by_class(){return 0;}
  void set_free_parameters(const VECTOR& pars);
  VECTOR get_free_parameters();
  void shift(const DOUBLE& size);
  Ogive_Tuck_logistic_f(const VECTOR& pars, int _low, int _high, int _size_based, const std::string& _type, std::string _command);
private:
  DOUBLE a50, a_to95, a_maxm, a_maxf;
};


template<CDVM>
ostream& operator<<(ostream& out, const std::map<std::string,Ogive<DVM>*>& m);

//############################## END OF OGIVE.h ##############################
#endif
