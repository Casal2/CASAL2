// const char* time_stamp = "$Date: 2012-02-23 12:05:33 +1300 (Thu, 23 Feb 2012) $\n";
// const char* ogive_cpp_id = "$Id: ogive.cpp 4553 2012-02-22 23:05:33Z Dunn $\n";

//############################## OGIVES ##############################
#include "ogive.h"

/////////////////////////////////////////////////////////////////////
template<CDVM>
DOUBLE Ogive<DVM>::get_value(const DOUBLE& x){
  // Ogive classes override this when appropriate
  DEBUG2("Ogive::get_value (DOUBLE)");
  fatal("Use Ogive::get_value (int) for ogives of type " + type);
  return 0;
}

template<CDVM>
DOUBLE Ogive<DVM>::get_value(int classno){
  // Ogive classes override this when appropriate
  DEBUG2("Ogive::get_value (int)");
  fatal("Use Ogive::get_value (DOUBLE) for ogives of type " + type);
  return 0;
}

template<CDVM>
void Ogive<DVM>::shift(const DOUBLE& size){
  // Individual ogive types may provide alternative versions which work.
  DEBUG2("Ogive::shift");
  fatal("No 'shift' function defined for ogives of type " + type);
}

template<CDVM>
Ogive<DVM>::Ogive(int _low, int _high, int _size_based, const std::string& _type, std::string _command){
  // Called from the constructors of the various ogive classes,
  // which also have to fill in the free parameters.
  DEBUG2("Ogive::Ogive");
  low = _low;
  high = _high;
  size_based = _size_based;
  type = _type;
  command = _command;
}

template<CDVM>
Ogive<DVM>::~Ogive(){
  DEBUG2("~Ogive");
  // nothing to do, but some of the derived classes might need something
}

template<CDVM>
Ogive<DVM>* Ogive_factory<DVM>::make_ogive(const std::string& s, int sizebased_model, int min_class, int max_class, std::string _command){
// OPTIM: changed make_ogive to Ogive_factory. See Ogive.h file as well
// Ogive<DVM>* make_ogive(const std::string& s, int sizebased_model, int min_class, int max_class, std::string _command){
  // Construct an ogive from a string such as "size_based allvalues 0.1 0.2 0.3 ...".
  // Return a pointer to the ogive (which is on the free store).
  // The function needs to be told whether the model is size-based, and what range of
  // size or age classes is covered in the partition, and (in case it is a size-based ogive
  // in an age-based model) what is the minimum and maximum size class index.
  // BB added the last argument, Mar 2003, for use in error messages: it's a text description of the name of the ogive (command and subcommand)
  DEBUG2("make_ogive");
  Ogive<DVM>* ogive;
  istringstream arguments((s+" ").c_str());
  std::string type;
  int low, high;
  // Need to suss out whether the ogive is size-based, what type it is,
  // and what range of indices it covers
  int size_based;
  arguments >> type;
  if (type == "size_based" && sizebased_model == 0){
    size_based = 1;
    arguments >> type;
  } else {
    size_based = sizebased_model;
  }
  low = min_class;
  high = max_class;
  VECTOR parameters(stream_to_vector<DVM>(arguments,"Ogive from " + _command + " has no valid arguments"));
  // now build the ogive;
  if (type == "constant")
    ogive = new Ogive_constant<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "knife_edge")
    ogive = new Ogive_knife_edge<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "allvalues")
    ogive = new Ogive_allvalues<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "allvalues_bounded")
    ogive = new Ogive_allvalues_bounded<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "logistic")
    ogive = new Ogive_logistic<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "logistic_capped")
    ogive = new Ogive_logistic_capped<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "logistic_product")
    ogive = new Ogive_logistic_product<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "double_logistic")
    ogive = new Ogive_double_logistic<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "logistic_bounded")
    ogive = new Ogive_logistic_bounded<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "double_normal")
    ogive = new Ogive_double_normal<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "double_normal_capped")
    ogive = new Ogive_double_normal_capped<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "double_normal_coleraine")
    ogive = new Ogive_double_normal_coleraine<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "double_normal_plateau")
    ogive = new Ogive_double_normal_plateau<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "logistic_producing") {
    if(sizebased_model) fatal("The logistic_producing ogive cannot be used in a size-based model.");
    ogive = new Ogive_logistic_producing<DVM>(parameters,low,high,size_based,type,_command);
  } else if (type == "increasing")
    ogive = new Ogive_increasing<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "increasing_capped")
    ogive = new Ogive_increasing_capped<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "Richards")
    ogive = new Ogive_richards<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "Richards_capped")
    ogive = new Ogive_richards_capped<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "Hillary")
    ogive = new Ogive_hillary<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "Hillary_capped")
    ogive = new Ogive_hillary_capped<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "cosh")
    ogive = new Ogive_cosh<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "double_exponential")
    ogive = new Ogive_double_exponential<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "CompoundAll")
    ogive = new Ogive_CompoundAll<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "CompoundLeft")
    ogive = new Ogive_CompoundLeft<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "CompoundMiddle")
    ogive = new Ogive_CompoundMiddle<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "CompoundRight")
    ogive = new Ogive_CompoundRight<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "Tuck_logistic_m")
    ogive = new Ogive_Tuck_logistic_m<DVM>(parameters,low,high,size_based,type,_command);
  else if (type == "Tuck_logistic_f")
    ogive = new Ogive_Tuck_logistic_f<DVM>(parameters,low,high,size_based,type,_command);
  else fatal("Unknown ogive type: " + type + " in ogive from " + _command);
  return ogive;
}

template<CDVM>
DOUBLE Ogive_constant<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_constant::get_value"); too much output
  return C;
}

template<CDVM>
void Ogive_constant<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_constant::set_free_parameters");
  int n_pars = 1;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  C = pars[1];
}

template<CDVM>
VECTOR Ogive_constant<DVM>::get_free_parameters(){
  DEBUG2("Ogive_constant::get_free_parameters");
  VECTOR result(1,1);
  result = C;
  return result;
}

template<CDVM>
void Ogive_constant<DVM>::shift(const DOUBLE& size){
  // do nothing
  DEBUG2("Ogive_constant::shift");
}

template<CDVM>
Ogive_constant<DVM>::Ogive_constant(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_constant::Ogive_constant");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_knife_edge<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_knife_edge::get_value"); too much output
  return (x>=E);
}

template<CDVM>
void Ogive_knife_edge<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_knife_edge::set_free_parameters");
  fatal("You cannot call set_free_parameters for a knife-edge ogive - it has none.");
}

template<CDVM>
VECTOR Ogive_knife_edge<DVM>::get_free_parameters(){
  DEBUG2("Ogive_knife_edge::get_free_parameters");
  fatal("You cannot call get_free_parameters for a knife-edge ogive - it has none.");
  VECTOR v;
  return v;
}

template<CDVM>
Ogive_knife_edge<DVM>::Ogive_knife_edge(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_knife_edge::Ogive_knife_edge");
  int n_pars = 1;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  E = value(pars[1]);
};

template<CDVM>
DOUBLE Ogive_allvalues<DVM>::get_value(int classno){
  // DEBUG2("Ogive_allvalues::get_value"); too much output
  if (classno < this->low || classno > this->high){
    fatal("Attempt to extract element " + itos(classno) + " in ogive from " + this->command + " which goes from " + itos(this->low) + " to " + itos(this->high));}
  return V[classno - this->low + 1];
}

template<CDVM>
void Ogive_allvalues<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_allvalues::set_free_parameters");
  int n_pars = V.size();
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  V = pars;
}

template<CDVM>
VECTOR Ogive_allvalues<DVM>::get_free_parameters(){
  DEBUG2("Ogive_allvalues::get_free_parameters");
  return V;
}

template<CDVM>
Ogive_allvalues<DVM>::Ogive_allvalues(const VECTOR& pars, int _low, int _high,
                                      int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command)
  , V(pars){
  DEBUG2("Ogive_allvalues::Ogive_allvalues");
  int n_pars = _high - _low + 1;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
};

template<CDVM>
DOUBLE Ogive_allvalues_bounded<DVM>::get_value(int classno){
  // DEBUG2("Ogive_allvalues_bounded::get_value"); too much output
  if (classno < this->low || classno > this->high){
    fatal("Attempt to extract element " + itos(classno) + " in ogive from " + this->command + " which goes from " + itos(this->low) + " to " + itos(this->high));}
  if (classno < L) return 0;
  else if (classno > H) return V[H - L + 1];
  else return V[classno - L + 1];
}

template<CDVM>
void Ogive_allvalues_bounded<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_allvalues_bounded::set_free_parameters");
  int n_pars = V.size();
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  V = pars;
}

template<CDVM>
VECTOR Ogive_allvalues_bounded<DVM>::get_free_parameters(){
  DEBUG2("Ogive_allvalues_bounded::get_free_parameters");
  return V;
}

template<CDVM>
Ogive_allvalues_bounded<DVM>::Ogive_allvalues_bounded(const VECTOR& pars, int _low, int _high,
                                                      int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command)
  , V(1,pars.size()-2){
  DEBUG2("Ogive_allvalues_bounded::Ogive_allvalues_bounded");
  L = (int)(value(pars[1]));
  H = (int)(value(pars[2]));
  if (L>H || value(pars[1])!=(double)(int)(value(pars[1])) || value(pars[2])!=(double)(int)(value(pars[2]))){
        fatal("Bad L (" + dtos(value(pars[1])) + ") or H (" + dtos(value(pars[2])) + ") in ogive from " + this->command);}
  int n_pars = 2 + (H-L+1);
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars) + ", based on L and H");}
  for (int i=3; i<=pars.size(); i++){
    V[i-2] = pars[i];}
};

template<CDVM>
DOUBLE Ogive_logistic<DVM>::get_value(const DOUBLE& x){
// DEBUG2("Ogive_logistic::get_value"); too much output
//  if ((a50-x)/a_to95 > 5) return 0;
//  if ((a50-x)/a_to95 < -5) return 1;
//  return 1.0/(1.0+pow(19.0,(a50-x)/a_to95));
  DOUBLE temp=(a50-x)/a_to95;
  if(temp > 5.0) return 0.0;
  else if (temp < -5.0) return 1.0;
  else return 1.0/(1.0+pow(19.0,temp));
}

template<CDVM>
void Ogive_logistic<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_logistic::set_free_parameters");
  int n_pars = 2;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
}

template<CDVM>
VECTOR Ogive_logistic<DVM>::get_free_parameters(){
  DEBUG2("Ogive_logistic::get_free_parameters");
  VECTOR result(1,2);
  result[1] = a50;
  result[2] = a_to95;
  return result;
}

template<CDVM>
void Ogive_logistic<DVM>::shift(const DOUBLE& size){
  // move a50
  DEBUG2("Ogive_logistic::shift");
  a50 += size;
}

template<CDVM>
Ogive_logistic<DVM>::Ogive_logistic(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_logistic::Ogive_logistic");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_logistic_capped<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_logistic_capped::get_value"); too much output
  // if ((a50-x)/a_to95 > 5) return 0;
  // if ((a50-x)/a_to95 < -5) return a_max;
  // return a_max*(1/(1+pow(19.0,(a50-x)/a_to95)));
  DOUBLE temp=(a50-x)/a_to95;
  if(temp > 5.0) return 0.0;
  else if (temp < -5.0) return a_max;
  else return a_max/(1.0+pow(19.0,temp));
}

template<CDVM>
void Ogive_logistic_capped<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_logistic_capped::set_free_parameters");
  int n_pars = 3;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  a_max = pars[3];
}

template<CDVM>
VECTOR Ogive_logistic_capped<DVM>::get_free_parameters(){
  DEBUG2("Ogive_logistic_capped::get_free_parameters");
  VECTOR result(1,3);
  result[1] = a50;
  result[2] = a_to95;
  result[3] = a_max;
  return result;
}

template<CDVM>
void Ogive_logistic_capped<DVM>::shift(const DOUBLE& size){
  // move a50
  DEBUG2("Ogive_logistic_capped::shift");
  a50 += size;
}

template<CDVM>
Ogive_logistic_capped<DVM>::Ogive_logistic_capped(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_logistic_capped::Ogive_logistic_capped");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_logistic_product<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_logistic_product::get_value"); too much output
  if (a_to95 < 0.02 && b_to95 < 0.02){
    if (a50 <= x && x <= (a50+b50)) return a_max; else return 0.0;
  } else if (a_to95 < 0.02){
    function_max = 1.0+pow(19.0,(-b50)/b_to95);
    return a_max * function_max * (1.0/(1.0+pow(19.0,(x-(a50+b50))/b_to95)));
  } else if (b_to95 < 0.02){
    function_max = 1.0+pow(19.0,(-b50)/a_to95);
    return a_max * function_max * (1.0/(1.0+pow(19.0,(a50-x)/a_to95)));
  } else {
    function_max = 0.0;
    for (int i=0; i<=100; i++) {
      temp_var = a50 - a_to95 + (double)i * (b50 + b_to95 + a_to95) *0.01;
      function_max = fmax(function_max, (1.0+pow(19.0,(a50-temp_var)/a_to95))*(1.0+pow(19.0,(temp_var-(a50+b50))/b_to95)));
    }
    return a_max * function_max * (1.0/((1.0+pow(19.0,(a50-x)/a_to95)) * (1.0+pow(19.0,(x-(a50+b50))/b_to95))));
  }
}

template<CDVM>
void Ogive_logistic_product<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_logistic_product::set_free_parameters");
  int n_pars = 5;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  b50 = pars[3];
  b_to95 = pars[4];
  a_max = pars[5];
  if (a_to95<=0.0 || b_to95<=0.0){
    fatal("In the logistic_product ogive, a_to95 and b_to95 must be positive");}
  if (b50 <= 0.0){
    fatal("In the logistic_product ogive, b50 must be greater than zero.");}
}

template<CDVM>
VECTOR Ogive_logistic_product<DVM>::get_free_parameters(){
  DEBUG2("Ogive_logistic_product::get_free_parameters");
  VECTOR result(1,5);
  result[1] = a50;
  result[2] = a_to95;
  result[3] = b50;
  result[4] = b_to95;
  result[5] = a_max;
  return result;
}

template<CDVM>
void Ogive_logistic_product<DVM>::shift(const DOUBLE& size){
  // move a50, b50
  DEBUG2("Ogive_logistic_product::shift");
  a50 += size;
}

template<CDVM>
Ogive_logistic_product<DVM>::Ogive_logistic_product(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_logistic_product::Ogive_logistic_product");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_double_logistic<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_double_logistic::get_value"); too much output
  if (a_to95 < 0.02 && b_to95 < 0.02){
    if (a50 <= x && x <= (a50+b50)) return a_max; else return 0.0;
  } else if (a_to95 < 0.02){
    p = a50;
    function_max = 1.0+pow(19.0,(p-(a50+b50))/b_to95);
    return a_max * function_max * (1.0+pow(19.0,(x-(a50+b50))/b_to95));
  } else if (b_to95 < 0.02){
    p = a50+b50;
    function_max = 1.0+pow(19.0,(a50-p)/a_to95);
    return a_max * function_max * (1.0+pow(19.0,(a50-x)/a_to95));
  } else {
    p = (a50 * b_to95 + a_to95 * (a50 + b50)) / (a_to95 + b_to95);
    function_max = 1.0+pow(19.0,(a50-p)/a_to95);
    return a_max * function_max * fmin(1.0/(1.0+pow(19.0,(a50-x)/a_to95)), 1.0/(1.0+pow(19.0,(x-(a50+b50))/b_to95)));
  }
}

template<CDVM>
void Ogive_double_logistic<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_double_logistic::set_free_parameters");
  int n_pars = 5;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  b50 = pars[3];
  b_to95 = pars[4];
  a_max = pars[5];
  if (a_to95<=0.0 || b_to95<=0.0){
          fatal("In the double_logistic ogive, a_to95 and b_to95 must be positive");}
  if (b50 <= 0.0){
          fatal("In the double_logistic ogive, b50 must be greater than zero.");}
}

template<CDVM>
VECTOR Ogive_double_logistic<DVM>::get_free_parameters(){
  DEBUG2("Ogive_double_logistic::get_free_parameters");
  VECTOR result(1,5);
  result[1] = a50;
  result[2] = a_to95;
  result[3] = b50;
  result[4] = b_to95;
  result[5] = a_max;
  return result;
}

template<CDVM>
void Ogive_double_logistic<DVM>::shift(const DOUBLE& size){
  // move a50, b50
  DEBUG2("Ogive_double_logistic::shift");
  a50 += size;
}

template<CDVM>
Ogive_double_logistic<DVM>::Ogive_double_logistic(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_double_logistic::Ogive_double_logistic");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_logistic_bounded<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_logistic_bounded::get_value"); too much output
  if (x < (a50-a_to95)) return 0.0;
  else if (x > (a50+a_to95)) return 1.0;
  else return 1.0/(1.0+pow(19.0,(a50-x)/a_to95));
}

template<CDVM>
void Ogive_logistic_bounded<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_logistic_bounded::set_free_parameters");
  int n_pars = 2;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
}

template<CDVM>
VECTOR Ogive_logistic_bounded<DVM>::get_free_parameters(){
  DEBUG2("Ogive_logistic_bounded::get_free_parameters");
  VECTOR result(1,2);
  result[1] = a50;
  result[2] = a_to95;
  return result;
}

template<CDVM>
void Ogive_logistic_bounded<DVM>::shift(const DOUBLE& size){
  // move a50
  DEBUG2("Ogive_logistic_bounded::shift");
  a50 += size;
}

template<CDVM>
Ogive_logistic_bounded<DVM>::Ogive_logistic_bounded(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_logistic_bounded::Ogive_logistic_bounded");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_double_normal<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_double_normal::get_value"); too much output
  if (x < a1) return pow(2.0,-((x-a1)/sL * (x-a1)/sL));
  else return pow(2.0,-((x-a1)/sR * (x-a1)/sR));
}

template<CDVM>
void Ogive_double_normal<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_double_normal::set_free_parameters");
  int n_pars = 3;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a1 = pars[1];
  sL = pars[2];
  sR = pars[3];
  if (sL <= 0.01){
          fatal("Fatal error in Ogive_double_normal<DVM>::set_free_parameters: sL is very small or nonpositive. Increase the lower bound.\n");}
  if (sR <= 0.01){
          fatal("Fatal error in Ogive_double_normal<DVM>::set_free_parameters: sR is very small or nonpositive. Increase the lower bound.\n");}
}

template<CDVM>
VECTOR Ogive_double_normal<DVM>::get_free_parameters(){
  DEBUG2("Ogive_double_normal::get_free_parameters");
  VECTOR result(1,3);
  result[1] = a1;
  result[2] = sL;
  result[3] = sR;
  return result;
}

template<CDVM>
void Ogive_double_normal<DVM>::shift(const DOUBLE& size){
  // move a1
  DEBUG2("Ogive_double_normal::shift");
  a1 += size;
}

template<CDVM>
Ogive_double_normal<DVM>::Ogive_double_normal(const VECTOR& pars, int _low, int _high,
                                              int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_double_normal::Ogive_double_normal");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_double_normal_capped<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_double_normal_capped::get_value"); too much output
  if (x < a1) return a_max*pow(2.0,-((x-a1)/sL * (x-a1)/sL));
  else return a_max*pow(2.0,-((x-a1)/sR * (x-a1)/sR));
}

template<CDVM>
void Ogive_double_normal_capped<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_double_normal_capped::set_free_parameters");
  int n_pars = 4;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a1 = pars[1];
  sL = pars[2];
  sR = pars[3];
  a_max = pars[4];
  if (sL <= 0.01){
          fatal("Fatal error in Ogive_double_normal_capped<DVM>::set_free_parameters: sL is very small or nonpositive. Increase the lower bound.\n");}
  if (sR <= 0.01){
          fatal("Fatal error in Ogive_double_normal_capped<DVM>::set_free_parameters: sR is very small or nonpositive. Increase the lower bound.\n");}
}

template<CDVM>
VECTOR Ogive_double_normal_capped<DVM>::get_free_parameters(){
  DEBUG2("Ogive_double_normal_capped::get_free_parameters");
  VECTOR result(1,4);
  result[1] = a1;
  result[2] = sL;
  result[3] = sR;
  result[4] = a_max;
  return result;
}

template<CDVM>
void Ogive_double_normal_capped<DVM>::shift(const DOUBLE& size){
  // move a1
  DEBUG2("Ogive_double_normal_capped::shift");
  a1 += size;
}

template<CDVM>
Ogive_double_normal_capped<DVM>::Ogive_double_normal_capped(const VECTOR& pars, int _low, int _high,
                                              int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_double_normal_capped::Ogive_double_normal_capped");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_double_normal_coleraine<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_double_normal_coleraine::get_value"); too much output
  if (x<a1) return exp(-((x-a1)*(x-a1)/varL));
  else return exp(-((x-a1)*(x-a1)/varR));
}

template<CDVM>
void Ogive_double_normal_coleraine<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_double_normal_coleraine::set_free_parameters");
  int n_pars = 3;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a1 = pars[1];
  varL = pars[2];
  varR = pars[3];
  if (varL <= 0.01){
          fatal("Fatal error in Ogive_double_normal_coleraine<DVM>::set_free_parameters: varL is very small or nonpositive. Increase the lower bound.\n");}
  if (varR <= 0.01){
          fatal("Fatal error in Ogive_double_normal_coleraine<DVM>::set_free_parameters: varR is very small or nonpositive. Increase the lower bound.\n");}
}

template<CDVM>
VECTOR Ogive_double_normal_coleraine<DVM>::get_free_parameters(){
  DEBUG2("Ogive_double_normal_coleraine::get_free_parameters");
  VECTOR result(1,3);
  result[1] = a1;
  result[2] = varL;
  result[3] = varR;
  return result;
}

template<CDVM>
void Ogive_double_normal_coleraine<DVM>::shift(const DOUBLE& size){
  // move a1
  DEBUG2("Ogive_double_normal_coleraine::shift");
  a1 += size;
}

template<CDVM>
Ogive_double_normal_coleraine<DVM>::Ogive_double_normal_coleraine(const VECTOR& pars, int _low,
                                                                  int _high, int _size_based,
                                                                  const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_double_normal_coleraine::Ogive_double_normal_coleraine");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_double_normal_plateau<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_double_normal_plateau::get_value"); too much output
  if (x < a1) return a_max*pow(2.0,-((x-a1)/sL * (x-a1)/sL));
  else if (x < (a1+a2)) return(a_max);
  else return a_max*pow(2.0,-((x-(a1+a2))/sR * (x-(a1+a2))/sR));
}

template<CDVM>
void Ogive_double_normal_plateau<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_double_normal_plateau::set_free_parameters");
  int n_pars = 5;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a1 = pars[1];
  a2 = pars[2];
  sL = pars[3];
  sR = pars[4];
  a_max = pars[5];
  if (sL <= 0.01){
          fatal("Fatal error in Ogive_double_normal_plateau<DVM>::set_free_parameters: sL is very small or nonpositive. Increase the lower bound.\n");}
  if (sR <= 0.01){
          fatal("Fatal error in Ogive_double_normal_plateau<DVM>::set_free_parameters: sR is very small or nonpositive. Increase the lower bound.\n");}
}

template<CDVM>
VECTOR Ogive_double_normal_plateau<DVM>::get_free_parameters(){
  DEBUG2("Ogive_double_normal_plateau::get_free_parameters");
  VECTOR result(1,5);
  result[1] = a1;
  result[2] = a2;
  result[3] = sL;
  result[4] = sR;
  result[5] = a_max;
  return result;
}

template<CDVM>
void Ogive_double_normal_plateau<DVM>::shift(const DOUBLE& size){
  // move a1
  DEBUG2("Ogive_double_normal_plateau::shift");
  a1 += size;
}

template<CDVM>
Ogive_double_normal_plateau<DVM>::Ogive_double_normal_plateau(const VECTOR& pars, int _low, int _high,
                                              int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_double_normal_plateau::Ogive_double_normal_plateau");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_logistic_producing<DVM>::get_value(int classno){
  // DEBUG2("Ogive_logistic_producing::get_value"); too much output
  if (classno < this->low || classno > this->high){
    fatal("Attempt to extract element " + itos(classno) + " in ogive from " + this->command + " which goes from " + itos(this->low) + " to " + itos(this->high));}
  if (classno < L) return 0;
  else if (classno == L) return logistic_ogive[L];
  else if (classno < H){
    if (logistic_ogive[classno-1] > 0.9999) return 1;
    else return (logistic_ogive[classno] - logistic_ogive[classno-1]) / (1.0 - logistic_ogive[classno-1]);}
  else if (classno >= H) return 1;
}

template<CDVM>
void Ogive_logistic_producing<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_logistic_producing::set_free_parameters");
  int n_pars = 2;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  // recalculate the logistic ogive
  for (int i=L; i<H; i++){
    if ((a50-i)/a_to95 < -5.0) logistic_ogive[i] = 1.0;
        else if ((a50-i)/a_to95 > 5.0) logistic_ogive[i] = 0.0;
        else logistic_ogive[i] = 1.0/(1.0+pow(19.0,(a50-i)/a_to95));
  }
}

template<CDVM>
VECTOR Ogive_logistic_producing<DVM>::get_free_parameters(){
  DEBUG2("Ogive_logistic_producing::get_free_parameters");
  VECTOR result(1,2);
  result[1] = a50;
  result[2] = a_to95;
  return result;
}

template<CDVM>
Ogive_logistic_producing<DVM>::Ogive_logistic_producing(const VECTOR& pars, int _low, int _high,
                                                        int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command)
  , logistic_ogive((int)(value(pars[1])),(int)(value(pars[2]-1))){
  DEBUG2("Ogive_logistic_producing::Ogive_logistic_producing");
  if(_size_based) fatal("The logistic_producing ogive cannot be used as a size-based ogive in an age-based model.");
  int n_pars = 4;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  L = (int)(value(pars[1]));
  H = (int)(value(pars[2]));
  a50 = pars[3];
  a_to95 = pars[4];
  if (L>a50 || H<a50 || L>=H){
        fatal("Bad L (" + dtos(value(pars[1])) + ") or H (" + dtos(value(pars[2])) + ") or a50 (" + dtos(value(a50)) + ") in ogive from " + this->command);}
  // calculate the logistic ogive
  for (int i=L; i<H; i++){
        if ((a50-i)/a_to95 < -5) logistic_ogive[i] = 1;
        else if ((a50-i)/a_to95 > 5) logistic_ogive[i] = 0;
        else logistic_ogive[i] = 1/(1+pow(19.0,(a50-i)/a_to95));
  }
};

template<CDVM>
DOUBLE Ogive_increasing<DVM>::get_value(int classno){
  // DEBUG2("Ogive_increasing::get_value"); too much output
  if (classno < this->low || classno > this->high){
    fatal("Attempt to extract element " + itos(classno) + " in ogive from " + this->command + " which goes from " + itos(this->low) + " to " + itos(this->high));}
  if (classno < L) return 0;
  else{
    DOUBLE value = pi[1];
    for (int i=L+1; i<=classno; i++){
      if (i>H || value==1) break;
      value += (1-value) * pi[i-L+1];
    }
    return value;
  }
}

template<CDVM>
void Ogive_increasing<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_increasing::set_free_parameters");
  int n_pars = pi.size();
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  pi = pars;
}

template<CDVM>
VECTOR Ogive_increasing<DVM>::get_free_parameters(){
  DEBUG2("Ogive_increasing::get_free_parameters");
  return pi;
}

template<CDVM>
Ogive_increasing<DVM>::Ogive_increasing(const VECTOR& pars, int _low, int _high,
                                        int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command)
  , pi(1,pars.size()-2){
  DEBUG2("Ogive_increasing::Ogive_increasing");
  if(_size_based) fatal("The increasing ogive cannot be used as a size-based ogive in an age-based model.");
  L = (int)(value(pars[1]));
  H = (int)(value(pars[2]));
  if (L>H || value(pars[1])!=(double)(int)(value(pars[1])) || value(pars[2])!=(double)(int)(value(pars[2]))){
        fatal("Bad L (" + dtos(value(pars[1])) + ") or H (" + dtos(value(pars[2])) + ") in ogive from " + this->command);}
  int n_pars = 2 + (H-L+1);
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  for (int i=3; i<=pars.size(); i++){
    pi[i-2] = pars[i];}
};

template<CDVM>
DOUBLE Ogive_increasing_capped<DVM>::get_value(int classno){
  // DEBUG2("Ogive_increasing_capped::get_value"); too much output
  if (classno < this->low || classno > this->high){
    fatal("Attempt to extract element " + itos(classno) + " in ogive from " + this->command + " which goes from " + itos(this->low) + " to " + itos(this->high));}
  if (classno < L) return 0;
  else{
    DOUBLE value = fmin(C,pi[1]);
    for (int i=L+1; i<=classno; i++){
      if (i>H || value>=C) break;
      value += (C-value) * pi[i-L+1];
    }
    return value;
  }
}

template<CDVM>
void Ogive_increasing_capped<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_increasing_capped::set_free_parameters");
  int n_pars = pi.size();
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  pi = pars;
}

template<CDVM>
VECTOR Ogive_increasing_capped<DVM>::get_free_parameters(){
  DEBUG2("Ogive_increasing_capped::get_free_parameters");
  return pi;
}

template<CDVM>
Ogive_increasing_capped<DVM>::Ogive_increasing_capped(const VECTOR& pars, int _low, int _high,
                                        int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command)
  , pi(1,pars.size()-3){
  DEBUG2("Ogive_increasing_capped::Ogive_increasing_capped");
  if(_size_based) fatal("The increasing_capped ogive cannot be used as a size-based ogive in an age-based model.");
  L = (int)(value(pars[1]));
  H = (int)(value(pars[2]));
  if (L>H || value(pars[1])!=(double)(int)(value(pars[1])) || value(pars[2])!=(double)(int)(value(pars[2]))){
        fatal("Bad L (" + dtos(value(pars[1])) + ") or H (" + dtos(value(pars[2])) + ") in ogive from " + this->command);}
  C = value(pars[3]);
  int n_pars = 3 + (H-L);
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  for (int i=4; i<=pars.size(); i++){
    pi[i-3] = pars[i];}
};

template<CDVM>
DOUBLE Ogive_richards<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_richards::get_value"); too much output
  DOUBLE log19=log(19.0);
  beta = (a_to95*log19)/(log(pow(2.0,delta)-1.0)-log(pow(20.0/19.0,delta)-1.0));
  alpha = a50+((beta*log(pow(2.0,delta)-1.0))/(log19));
  if ((a50-x)/a_to95 > 5.0) return 0.0;
  if ((a50-x)/a_to95 < -5.0) return 1.0;
  return pow(1/(1+pow(19.0,(alpha-x)/beta)),1/delta);
}

template<CDVM>
void Ogive_richards<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_richards::set_free_parameters");
  int n_pars = 3;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  delta = pars[3];
}

template<CDVM>
VECTOR Ogive_richards<DVM>::get_free_parameters(){
  DEBUG2("Ogive_richards::get_free_parameters");
  VECTOR result(1,3);
  result[1] = a50;
  result[2] = a_to95;
  result[3] = delta;
  return result;
}

template<CDVM>
void Ogive_richards<DVM>::shift(const DOUBLE& size){
  // move a50
  DEBUG2("Ogive_richards::shift");
  a50 += size;
}

template<CDVM>
Ogive_richards<DVM>::Ogive_richards(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_richards::Ogive_richards");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_richards_capped<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_richards_capped::get_value"); too much output
  DOUBLE log19 = log(19.0);
  beta = (a_to95*log19)/(log(pow(2.0,delta)-1.0)-log(pow(20.0/19.0,delta)-1.0));
  alpha = a50+((beta*log(pow(2.0,delta)-1.0))/(log19));
  if ((a50-x)/a_to95 > 5.0) return 0;
  if ((a50-x)/a_to95 < -5.0) return a_max;
  return a_max*pow(1.0/(1.0+pow(19.0,(alpha-x)/beta)),1.0/delta);
}

template<CDVM>
void Ogive_richards_capped<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_richards_capped::set_free_parameters");
  int n_pars = 4;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  delta = pars[3];
  a_max = pars[4];
}

template<CDVM>
VECTOR Ogive_richards_capped<DVM>::get_free_parameters(){
  DEBUG2("Ogive_richards_capped::get_free_parameters");
  VECTOR result(1,4);
  result[1] = a50;
  result[2] = a_to95;
  result[3] = delta;
  result[4] = a_max;
  return result;
}

template<CDVM>
void Ogive_richards_capped<DVM>::shift(const DOUBLE& size){
  // move a50
  DEBUG2("Ogive_richards_capped::shift");
  a50 += size;
}

template<CDVM>
Ogive_richards_capped<DVM>::Ogive_richards_capped(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_richards_capped::Ogive_richards_capped");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_hillary<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_hillary::get_value"); too much output
  if (x <= alpha) return 0.0;
//  else return (pow(x-alpha,gamma)/(pow(2.0,-gamma)*pow(psi,gamma)))*pow(1.0+(pow(x-alpha,2.0)/pow(psi,2.0)),-gamma);
  else return exp(gamma*(log(x-alpha)+log(2.0)-log(psi)-log(1.0+((x-alpha)*(x-alpha))/(psi*psi))));
}

template<CDVM>
void Ogive_hillary<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_hillary::set_free_parameters");
  int n_pars = 3;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  alpha = pars[1];
  psi = pars[2];
  gamma = pars[3];
}

template<CDVM>
VECTOR Ogive_hillary<DVM>::get_free_parameters(){
  DEBUG2("Ogive_hillary::get_free_parameters");
  VECTOR result(1,3);
  result[1] = alpha;
  result[2] = psi;
  result[3] = gamma;
  return result;
}

template<CDVM>
void Ogive_hillary<DVM>::shift(const DOUBLE& size){
  // move a1
  DEBUG2("Ogive_hillary::shift");
  alpha += size;
  psi += size;
}

template<CDVM>
Ogive_hillary<DVM>::Ogive_hillary(const VECTOR& pars, int _low, int _high,
                                  int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_hillary::Ogive_hillary");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_hillary_capped<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_hillary_capped::get_value"); too much output
  if (x <= alpha) return 0.0;
//  else return (pow(x-alpha,gamma)/(pow(2.0,-gamma)*pow(psi,gamma)))*pow(1.0+(pow(x-alpha,2.0)/pow(psi,2.0)),-gamma)*a_max;
  else return exp(gamma*(log(x-alpha)+log(2.0)-log(psi)-log(1.0+((x-alpha)*(x-alpha))/(psi*psi))));

}

template<CDVM>
void Ogive_hillary_capped<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_hillary_capped::set_free_parameters");
  int n_pars = 4;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  alpha = pars[1];
  psi = pars[2];
  gamma = pars[3];
  a_max = pars[4];
}

template<CDVM>
VECTOR Ogive_hillary_capped<DVM>::get_free_parameters(){
  DEBUG2("Ogive_hillary_capped::get_free_parameters");
  VECTOR result(1,4);
  result[1] = alpha;
  result[2] = psi;
  result[3] = gamma;
  result[4] = a_max;
  return result;
}

template<CDVM>
void Ogive_hillary_capped<DVM>::shift(const DOUBLE& size){
  // move a1
  DEBUG2("Ogive_hillary_capped::shift");
  alpha += size;
  psi += size;
}

template<CDVM>
Ogive_hillary_capped<DVM>::Ogive_hillary_capped(const VECTOR& pars, int _low, int _high,
                                  int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_hillary_capped::Ogive_hillary_capped");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_cosh<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_cosh::get_value"); too much output
  if(alpha>1) fatal("The value of 'alpha' is greater than 1.");
  if(beta>1) fatal("The value of 'beta' is greater than 1.");
  return (zerofun(min_value,1e-11)*0.5)*(exp(-zerofun(alpha,1e-11)*(x-min_x))+exp(zerofun(beta,1e-11)*(x-min_x)));
}

template<CDVM>
void Ogive_cosh<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_cosh::set_free_parameters");
  int n_pars = 4;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  min_value = pars[1];
  min_x = pars[2];
  alpha = pars[3];
  beta = pars[4];
}

template<CDVM>
VECTOR Ogive_cosh<DVM>::get_free_parameters(){
  DEBUG2("Ogive_cosh::get_free_parameters");
  VECTOR result(1,4);
  result[1] = min_value;
  result[2] = min_x;
  result[3] = alpha;
  result[4] = beta;
  return result;
}

template<CDVM>
void Ogive_cosh<DVM>::shift(const DOUBLE& size){
  // move a1
  DEBUG2("Ogive_cosh::shift");
  min_x += size;
}

template<CDVM>
Ogive_cosh<DVM>::Ogive_cosh(const VECTOR& pars, int _low, int _high,
                                  int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_cosh::Ogive_cosh");
  set_free_parameters(pars);
};

//##############################################################################################
template<CDVM>
DOUBLE Ogive_double_exponential<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_double_exponential::get_value"); too much output
  // Note: when comparing to equation in manual,
  //       then x1=low, x2=high, x0=V[1], y0=V[2], y1=V[3], y2=V[4].
  if(V[1]<=(this->low)) fatal("The value of 'x0' must be greater than 'x1'.");
  if(V[1]>=(this->high)) fatal("The value of 'x0' must be less than than 'x2'.");
  if(x<=V[1]) return (V[2]*pow((V[3]/V[2]),(x-V[1])/((this->low)-V[1])));
  else return (V[2]*pow((V[4]/V[2]),(x-V[1])/((this->high)-V[1])));
}

template<CDVM>
void Ogive_double_exponential<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_double_exponential::set_free_parameters");
  int n_pars = V.size();
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  V = pars;
}

template<CDVM>
VECTOR Ogive_double_exponential<DVM>::get_free_parameters(){
  DEBUG2("Ogive_double_exponential::get_free_parameters");
  return V;
}

template<CDVM>
Ogive_double_exponential<DVM>::Ogive_double_exponential(const VECTOR& pars, int _low, int _high,
                                  int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command)
  , V(1,pars.size()-2){
  DEBUG2("Ogive_double_exponential::Ogive_cosh");
  x1 = (int)(value(pars[1]));
  x2 = (int)(value(pars[2]));
  if (x1>=x2){
    fatal("'x1' (" + dtos(value(pars[1])) + ") must be less than 'x2' (" + dtos(value(pars[2])) + ") in ogive from " + this->command);}
  int n_pars = 6;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars) + ", based on x1 and x2");}
  for (int i=3; i<=pars.size(); i++){
    V[i-2] = pars[i];}
};


//##############################################################################################
template<CDVM>
DOUBLE Ogive_CompoundAll<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_CompoundAll::get_value"); too much output
  Logistic = (1.0-amin)/(1.0+pow(19.0,(a50-x)/a_to95)) + amin;
  return Logistic;
}

template<CDVM>
void Ogive_CompoundAll<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_CompoundAll::set_free_parameters");
  int n_pars = 6;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  amin = pars[3];
  leftmu = pars[4];
  to_rightmu = pars[5];
  sd = pars[6];
}

template<CDVM>
VECTOR Ogive_CompoundAll<DVM>::get_free_parameters(){
  DEBUG2("Ogive_CompoundAll::get_free_parameters");
  VECTOR result(1,6);
  result[1] = a50;
  result[2] = a_to95;
  result[3] = amin;
  result[4] = leftmu;
  result[5] = to_rightmu;
  result[6] = sd;
  return result;
}

template<CDVM>
void Ogive_CompoundAll<DVM>::shift(const DOUBLE& size){
  // move a50
  DEBUG2("Ogive_CompoundAll::shift");
//  a50 += size;
  leftmu += size;
}

template<CDVM>
Ogive_CompoundAll<DVM>::Ogive_CompoundAll(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_CompoundAll::Ogive_CompoundAll");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_CompoundLeft<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_CompoundLeft::get_value"); too much output
  Logistic = (1.0-amin)/(1.0+pow(19.0,(a50-x)/a_to95)) + amin;
  Right = 1.0 - 1.0/(1.0+pow(19.0,(leftmu-x)/sd));
  return Logistic * Right;
}

template<CDVM>
void Ogive_CompoundLeft<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_CompoundLeft::set_free_parameters");
  int n_pars = 6;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  amin = pars[3];
  leftmu = pars[4];
  to_rightmu = pars[5];
  sd = pars[6];
}

template<CDVM>
VECTOR Ogive_CompoundLeft<DVM>::get_free_parameters(){
  DEBUG2("Ogive_CompoundLeft::get_free_parameters");
  VECTOR result(1,6);
  result[1] = a50;
  result[2] = a_to95;
  result[3] = amin;
  result[4] = leftmu;
  result[5] = to_rightmu;
  result[6] = sd;
  return result;
}

template<CDVM>
void Ogive_CompoundLeft<DVM>::shift(const DOUBLE& size){
  // move a50
  DEBUG2("Ogive_CompoundLeft::shift");
//  a50 += size;
  leftmu += size;
}

template<CDVM>
Ogive_CompoundLeft<DVM>::Ogive_CompoundLeft(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_CompoundLeft::Ogive_CompoundLeft");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_CompoundMiddle<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_CompoundMiddle::get_value"); too much output
  Logistic = (1.0-amin)/(1.0+pow(19.0,(a50-x)/a_to95)) + amin;
  Left = 1.0/(1.0+pow(19.0,(leftmu-x)/sd));
  Right = 1.0 - 1.0/(1.0+pow(19.0,(leftmu+to_rightmu-x)/sd));
  return Logistic * Left * Right;
}

template<CDVM>
void Ogive_CompoundMiddle<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_CompoundMiddle::set_free_parameters");
  int n_pars = 6;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  amin = pars[3];
  leftmu = pars[4];
  to_rightmu = pars[5];
  sd = pars[6];
}

template<CDVM>
VECTOR Ogive_CompoundMiddle<DVM>::get_free_parameters(){
  DEBUG2("Ogive_CompoundMiddle::get_free_parameters");
  VECTOR result(1,6);
  result[1] = a50;
  result[2] = a_to95;
  result[3] = amin;
  result[4] = leftmu;
  result[5] = to_rightmu;
  result[6] = sd;
  return result;
}

template<CDVM>
void Ogive_CompoundMiddle<DVM>::shift(const DOUBLE& size){
  // move a50
  DEBUG2("Ogive_CompoundMiddle::shift");
//  a50 += size;
  leftmu += size;
}

template<CDVM>
Ogive_CompoundMiddle<DVM>::Ogive_CompoundMiddle(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_CompoundMiddle::Ogive_CompoundMiddle");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_CompoundRight<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_CompoundRight::get_value"); too much output
  Logistic = (1.0-amin)/(1.0+pow(19.0,(a50-x)/a_to95)) + amin;
  Left = 1.0/(1.0+pow(19.0,(leftmu+to_rightmu-x)/sd));
  return Logistic * Left;
}

template<CDVM>
void Ogive_CompoundRight<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_CompoundRight::set_free_parameters");
  int n_pars = 6;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  amin = pars[3];
  leftmu = pars[4];
  to_rightmu = pars[5];
  sd = pars[6];
}

template<CDVM>
VECTOR Ogive_CompoundRight<DVM>::get_free_parameters(){
  DEBUG2("Ogive_CompoundRight::get_free_parameters");
  VECTOR result(1,6);
  result[1] = a50;
  result[2] = a_to95;
  result[3] = amin;
  result[4] = leftmu;
  result[5] = to_rightmu;
  result[6] = sd;
  return result;
}

template<CDVM>
void Ogive_CompoundRight<DVM>::shift(const DOUBLE& size){
  // move a50
  DEBUG2("Ogive_CompoundRight::shift");
//  a50 += size;
  leftmu += size;
}

template<CDVM>
Ogive_CompoundRight<DVM>::Ogive_CompoundRight(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_CompoundRight::Ogive_CompoundRight");
  set_free_parameters(pars);
};


template<CDVM>
DOUBLE Ogive_Tuck_logistic_m<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_Tuck_logistic_m::get_value"); too much output
  DOUBLE temp=(a50-x)/a_to95;
  if(temp > 5.0) return 0.0;
  else if (temp < -5.0) return a_maxm;
  else return a_maxm/(1.0+pow(19.0,temp));
}

template<CDVM>
void Ogive_Tuck_logistic_m<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_Tuck_logistic_m::set_free_parameters");
  int n_pars = 4;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  a_maxm = pars[3];
  a_maxf = pars[4];
}

template<CDVM>
VECTOR Ogive_Tuck_logistic_m<DVM>::get_free_parameters(){
  DEBUG2("Ogive_Tuck_logistic_m::get_free_parameters");
  VECTOR result(1,4);
  result[1] = a50;
  result[2] = a_to95;
  result[3] = a_maxm;
  result[4] = a_maxf;
  return result;
}

template<CDVM>
void Ogive_Tuck_logistic_m<DVM>::shift(const DOUBLE& size){
  // move a50
  DEBUG2("Ogive_Tuck_logistic_m::shift");
  a50 += size;
}

template<CDVM>
Ogive_Tuck_logistic_m<DVM>::Ogive_Tuck_logistic_m(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_Tuck_logistic_m::Ogive_logistic_capped");
  set_free_parameters(pars);
};

template<CDVM>
DOUBLE Ogive_Tuck_logistic_f<DVM>::get_value(const DOUBLE& x){
  // DEBUG2("Ogive_Tuck_logistic_f::get_value"); too much output
  DOUBLE temp=(a50-x)/a_to95;
  if(temp > 5.0) return 0.0;
  else if (temp < -5.0) return a_maxf;
  else return a_maxf/(1.0+pow(19.0,temp));
}

template<CDVM>
void Ogive_Tuck_logistic_f<DVM>::set_free_parameters(const VECTOR& pars){
  DEBUG2("Ogive_Tuck_logistic_f::set_free_parameters");
  int n_pars = 4;
  int n_pars_supplied = pars.size();
  if (n_pars_supplied != n_pars){
    fatal("Ogive from " + this->command + " has the wrong number of parameters (" + itos(n_pars_supplied) + ") - should be " + itos(n_pars));}
  a50 = pars[1];
  a_to95 = pars[2];
  a_maxm = pars[3];
  a_maxf = pars[4];
}

template<CDVM>
VECTOR Ogive_Tuck_logistic_f<DVM>::get_free_parameters(){
  DEBUG2("Ogive_Tuck_logistic_f::get_free_parameters");
  VECTOR result(1,4);
  result[1] = a50;
  result[2] = a_to95;
  result[3] = a_maxm;
  result[4] = a_maxf;
  return result;
}

template<CDVM>
void Ogive_Tuck_logistic_f<DVM>::shift(const DOUBLE& size){
  // move a50
  DEBUG2("Ogive_Tuck_logistic_f::shift");
  a50 += size;
}

template<CDVM>
Ogive_Tuck_logistic_f<DVM>::Ogive_Tuck_logistic_f(const VECTOR& pars, int _low, int _high,
                                    int _size_based, const std::string& _type, std::string _command)
  : Ogive<DVM>(_low,_high,_size_based,_type,_command){
  DEBUG2("Ogive_Tuck_logistic_f::Ogive_logistic_capped");
  set_free_parameters(pars);
};


template<CDVM>
ostream& operator<<(ostream& out, const std::map<std::string,Ogive<DVM>*>& m){
  // a printer for std::map<std::string,Ogive*>'s (see other printers of map<>s in development.h)
  out << '\n';
  typedef typename std::map<std::string,Ogive<DVM>*>::const_iterator MAP_IT;
  for (MAP_IT i=m.begin(); i!=m.end(); ++i){
    out << "  ";
    out.setf(ios::left,ios::adjustfield);
    out << setw(30);
    out << i->first.c_str();
    out << '\t' << ((i->second->size_based) ? "size-based " : "age-based ") << i->second->type << ' ' << i->second->get_free_parameters() << '\n';
  }
  return out;
}
//############################## END OF OGIVES.cpp ##############################

// Create particular instantiations of the template
template class Ogive<double, dvector, dmatrix>;
template class Ogive<dvariable, dvv, dvm>;
template class Ogive_factory<double, dvector, dmatrix>;
template class Ogive_factory<dvariable, dvv, dvm>;
template ostream& operator<<(ostream&, const std::map<std::string,
                             Ogive<double, dvector, dmatrix>*>&);
template ostream& operator<<(ostream&, const std::map<std::string,
                             Ogive<dvariable, dvv, dvm>*>&);
