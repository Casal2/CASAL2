// const char* time_stamp = "$Date: 2007-03-08 14:45:17 +1300 (Thu, 08 Mar 2007) $\n";
// const char* user_parameterisation_cpp_id = "$Id: user.parameterisation.cpp 1652 2007-03-08 01:45:17Z adunn $\n";

#ifndef USER_PARAMETERISATION_CPP
#define USER_PARAMETERISATION_CPP

//############################## USER PARAMETERISATION.cpp ##############################
#include "development.h"

/////////////////////////////////////////////////////////////////////////////////////////
template<CDVM>
void user_parameterisation(
        std::vector<std::string>& new_scalar_names,
        std::vector<DOUBLE>& new_scalar_vals,
        std::vector<std::string>& new_vector_names,
        std::vector<VECTOR>& new_vector_vals,
        std::vector<std::string>& old_scalar_names,
        std::vector<DOUBLE>& old_scalar_vals,
        std::vector<std::string>& old_vector_names,
        std::vector<VECTOR>& old_vector_vals){

/*
   *** TEMPLATE - BRIAN BULL, 23/5/02 ***

   Use this function to implement a new parameterisation in the CASAL population section.

   The function should convert the values of the 'new' parameters (i.e. those in your *.csl files)
    back to the 'old' parameters (i.e. those in the CASAL manual).

   The inputs to this function are the names and values of the new scalar and vector parameters,
    the outputs are the names and values of the old scalar and vector parameters.

   You cannot reparameterise ogives.

   You need to use the std::vector and std::string classes
     (these are in the STL, see any good C++ book, e.g. Stroustrup)
   and DOUBLE and VECTOR, which are templates either for double and dvector or for dvariable and dvv
     (apart from double, these are Betadiff classes: see betadiff.h)

   Note that the indices of these VECTORs should always start at 1 (in this particular function)
    but the indices of the std::vectors always start at 0.
    So, the name of the first new vector parameter is new_vector_names[0],
    and its values are new_vector_vals[0][1], new_vector_vals[0][2]...
   The output arguments are passed as vectors of length 0: you need to grow them and fill them in.
*/

/*
   Insert your documentation here!
*/

  DEBUG1("user_parameterisation");

  // remove the following line
  fatal("You are using the default 'user.parameterisation.cpp', but have requested a user-supplied parameterisation. You need to modify the CASAL source and recompile.");
/*
   Insert your code here!
*/

}
//############################## END OF USER PARAMETERISATION.cpp ##############################
#endif
