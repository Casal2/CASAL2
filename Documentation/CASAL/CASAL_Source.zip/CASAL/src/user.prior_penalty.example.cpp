// const char* time_stamp = "$Date: 2006-08-08 15:18:31 +1200 (Tue, 08 Aug 2006) $\n";
// const char* user_prior_penalty_example_cpp_id = "$Id: user.prior_penalty.example.cpp 1593 2006-08-08 03:18:31Z adunn $\n";

#ifndef USER_PRIOR_PENALITY_CPP
#define USER_PRIOR_PENALITY_CPP

//############################## USER PRIOR PENALTY.cpp ##############################
#include "development.h"

////////////////////////////////////////////////////////////////////////////////////////
template<CDVM>
void user_prior_penalty(
        std::vector<std::string>& free_scalar_names,
        std::vector<DOUBLE>& free_scalar_vals,
        std::vector<std::string>& free_vector_names,
        std::vector<VECTOR>& free_vector_vals,
        std::vector<std::string>& free_ogive_names,
        std::vector<VECTOR>& free_ogive_arguments,
        std::vector<std::string>& user_scalar_names,
        std::vector<DOUBLE>& user_scalar_vals,
        std::vector<std::string>& user_vector_names,
        std::vector<VECTOR>& user_vector_vals,
        std::vector<std::string>& objective_component_names,
        std::vector<DOUBLE>& objective_component_vals){

/*

   *** TEMPLATE - BRIAN BULL, 23/5/02 ***

   Use this function to implement new priors, and new penalties on the free parameters.

   This function takes the names and values of the free parameters, and returns
    user-defined objective components (i.e. priors and penalties).

   The inputs to this function are
    (a) the names and values of the free parameters (i.e. those in @estimate blocks in your estimation.csl
        If there are free ogive parameters, only their estimable arguments are supplied - like a1, sL and sR
        for a double-normal ogive - not the actual values of the ogives.
    (b) the names and values of the user-defined parameters calculated by user.parameterisation.C (if any)
   The outputs are the names and values of the user-defined objective components.

   You need to use the std::vector and std::string classes
     (these are in the STL, see any good C++ book, e.g. Stroustrup)
   and DOUBLE and VECTOR, which are templates either for double and dvector or for dvariable and dvv
     (apart from double, these are Betadiff classes: see betadiff.h)

   Note that the indices of these VECTORs should always start at 1 (in this particular function)
    but the indices of the std::vectors always start at 0.
    So, the name of the first free vector parameter is free_vector_names[0],
    and its values are free_vector_vals[0][1], free_vector_vals[0][2]...
   The output arguments are passed as vectors of length 0: you need to grow them and fill them in.

*/

/*

   *** Brian Bull, 24/5/02. ***

   (1) Applies a penalty to encourage q[AEX].q to be approximately 2 x q[TAN].q
   (2) Applies a t prior to natural_mortality.all
   (3) Applies a Cauchy prior to initialization.B0 (which has been reparameterized as initialization.log_B0).

   Notes:
     Both the above q's must be ordinary free parameters (not nuisance parameters)
     natural_mortality.all must be free
     user.parameterisation.C converts initialization.log_B0 to initialization.B0
     Need to insert the following in estimation.csl:
      @user_components AEX_TAN_penalty prior_on_M prior_on_B0

*/

  DEBUG1("user_prior_penalty");

  if (!in<std::string>(free_scalar_names,"q[AEX].q")){
          fatal("You need to estimate q[AEX].q");}
  if (!in<std::string>(free_scalar_names,"q[TAN].q")){
          fatal("You need to estimate q[TAN].q");}
  DOUBLE qAEX = free_scalar_vals[pos<std::string>(free_scalar_names,"q[AEX].q")];
  DOUBLE qTAN = free_scalar_vals[pos<std::string>(free_scalar_names,"q[TAN].q")];
  objective_component_vals.push_back(5 * pow(qAEX-2*qTAN , 2));
  objective_component_names.push_back("AEX_TAN_penalty");

  if (!in<std::string>(free_scalar_names,"natural_mortality.all")){
          fatal("You need to estimate natural_mortality.all");}
  DOUBLE M = free_scalar_vals[pos<std::string>(free_scalar_names,"natural_mortality.all")];
  objective_component_vals.push_back(2.5 * log(1 + 0.25*pow((M - 0.25)/0.05,2)));
  objective_component_names.push_back("prior_on_M");

  if (!in<std::string>(user_scalar_names,"initialization.B0")){
          fatal("You need to estimate initialization.B0 through reparameterization from initialization.log_B0");}
  DOUBLE B0 = user_scalar_vals[pos<std::string>(user_scalar_names,"initialization.B0")];
  objective_component_vals.push_back(log(1+B0*B0));
  objective_component_names.push_back("prior_on_B0");

}
//############################## END OF USER PRIOR PENALTY.cpp ##############################
#endif
