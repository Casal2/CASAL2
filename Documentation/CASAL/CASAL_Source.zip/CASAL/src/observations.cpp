// const char* time_stamp = "$Date: 2010-11-25 17:02:26 +1300 (Thu, 25 Nov 2010) $\n";
// const char* observations_cpp_id = "$Id: observations.cpp 3649 2010-11-25 04:02:26Z fud $\n";

//############################## OBSERVATIONS ##############################
#include "observations.h"
#include "likelihoods.h"
#include "parameter_set.h"
#include "population_section.h"
#include "population_processes.h"
#include <math.h> // for round()

// Forward declarations of global functions in this file
template<CDVM> DOUBLE age_at_mat_prob(int maturation_age, int sampled_age,
                                      VECTOR& O, VECTOR& U, int min_age,
                                      int max_age, int k);

////////////////////////////////////////////////////////////////////////
template<CDVM>
void Observations_dataset<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  // put entries into the Parameter_set to tell the population section what results to return
  DEBUG0("Observations_dataset::set_request_parameters");
  for (int i=0; i<obs.size(); i++){
    obs[i]->set_request_parameters(p);}
}

template<CDVM>
void Observations_dataset<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // call after set_request_parameters and running the Population_section
  // (and Qs::get_nuisance_qs, if applicable) to extract the results from popn.results
  // and calculate the fits.
  DEBUG0("Observations_dataset::calculate_fits");
  for (int i=0; i<obs.size(); i++){
    obs[i]->calculate_fits(popn);}
}

template<CDVM>
DOUBLE Observations_dataset<DVM>::get_objective_function(){
  // call after calculate_fits to get the components of the objective function and their sum.
  DEBUG0("Observations_dataset::get_objective_function");
  DOUBLE objective_fn = 0;
  for (int i=0; i<obs.size(); i++){
    objective_components[i] = obs[i]->get_objective_function();
    objective_fn += objective_components[i];
  }
  return objective_fn;
}

template<CDVM>
void Observations_dataset<DVM>::parametric_bootstrap(long int seed){
  // call after calculate_fits to do parametric bootstraps of all observations.
  // Overwrite the original observations values.
  DEBUG0("Observations_dataset::parametric_bootstraps");
  for (int i=0; i<obs.size(); i++){
        if (obs[i]->do_bootstrap){
          obs[i]->parametric_bootstrap(seed);
    }
  }
}

template<CDVM>
void Observations_dataset<DVM>::write_to_file(ostream& o, Parameter_set<DVM> &e){
  // Dump out a section of CASAL parameter file containing the parameters of each time series.
  // If you have called Observations_dataset::parametric_bootstrap, the new file will
  //  contain observations bootstrapped around the fits.
  // If you have not, then the new file will be equivalent to the
  //  observations part of the estimation parameter file you provided.
  DEBUG0("Observations_dataset::parametric_bootstraps");
  for (int i=0; i<obs.size(); i++){
        if (obs[i]->do_bootstrap){
      obs[i]->write_to_file(o,e);
      o << "\n\n";
    }
  }
}

template<CDVM>
void Observations_dataset<DVM>::print(ostream& out, int print_fits, int print_resids,
                                                 int print_pearson_resids, int print_normalised_resids){
  DEBUG2("Observations_dataset::print");
  out << "The observations are:";
  for (int i=0; i<obs.size(); i++){
    out << '\n' << obs[i]->label;
  }
  out << "\nFits follow:\n\n";
  for (int i=0; i<obs.size(); i++){
    out << obs[i]->label << " :\n";
    obs[i]->print(out,print_fits,print_resids,print_pearson_resids,print_normalised_resids);
  }
}

template<CDVM>
void Observations_dataset<DVM>::print_objective_components(ostream& out){
  DEBUG2("Observations_dataset::print_objective_components");
  for (int i=0; i<obs.size(); i++){
    out << obs[i]->label << " : " << objective_components[i] << '\n';}
  out << "\n";
}

template<CDVM>
Observations_dataset<DVM>::Observations_dataset(Basic_population_section<DVM>& popn,
                                             Ageing_error<DVM>* _ageing_error,
                                             Parameter_set<DVM>& e, int pseudo){
  // Construct all the observations, from
  //   -a Population_section 'popn', from which we can get details like the initial and current
  //    years, number of age/size classes, etc.
  //   -a pointer to the ageing-error object (though there may be no ageing error)
  //   -a Parameter_set 'e' containing parameters describing the observations.
  // Apply the overall_variability parameter, if it has been specified.
  // If the last argument is set to 1 (the default is 0), these are pseudo-observations taken from the output parameter file.
  DEBUG0("Observations_dataset::Observations_dataset");
  std::string label;
  for (int i=1; i<=e.get_command_count("abundance"); i++){
    label = e.get_command_labels("abundance")[i-1];
    obs.push_back(new Abundance<DVM>(popn,e,label,0,pseudo));}
  for (int i=1; i<=e.get_command_count("relative_abundance"); i++){
    label = e.get_command_labels("relative_abundance")[i-1];
    obs.push_back(new Relative_abundance<DVM>(popn,e,label,pseudo));}
  for (int i=1; i<=e.get_command_count("numbers_at"); i++){
    label = e.get_command_labels("numbers_at")[i-1];
    obs.push_back(new Numbers_at<DVM>(popn,e,label,_ageing_error,0,pseudo));}
  for (int i=1; i<=e.get_command_count("relative_numbers_at"); i++){
    label = e.get_command_labels("relative_numbers_at")[i-1];
    obs.push_back(new Relative_numbers_at<DVM>(popn,e,label,_ageing_error,pseudo));}
  for (int i=1; i<=e.get_command_count("proportions_at"); i++){
    label = e.get_command_labels("proportions_at")[i-1];
    obs.push_back(new Proportions_at<DVM>(popn,e,label,_ageing_error,pseudo));}
  for (int i=1; i<=e.get_command_count("catch_at"); i++){
    label = e.get_command_labels("catch_at")[i-1];
    obs.push_back(new Catch_at<DVM>(popn,e,label,_ageing_error,pseudo));}
  for (int i=1; i<=e.get_command_count("proportions_mature"); i++){
    label = e.get_command_labels("proportions_mature")[i-1];
    obs.push_back(new Proportions_mature<DVM>(popn,e,label,_ageing_error,pseudo));}
  for (int i=1; i<=e.get_command_count("proportions_migrating"); i++){
    label = e.get_command_labels("proportions_migrating")[i-1];
    obs.push_back(new Proportions_migrating<DVM>(popn,e,label,_ageing_error,pseudo));}
  for (int i=1; i<=e.get_command_count("age_size"); i++){
    label = e.get_command_labels("age_size")[i-1];
    obs.push_back(new Age_size<DVM>(popn,e,label,_ageing_error,pseudo));}
  for (int i=1; i<=e.get_command_count("selectivity_at"); i++){
    label = e.get_command_labels("selectivity_at")[i-1];
    obs.push_back(new Selectivity_at<DVM>(popn,e,label,pseudo));}
  for (int i=1; i<=e.get_command_count("age_at_maturation"); i++){
    label = e.get_command_labels("age_at_maturation")[i-1];
    obs.push_back(new Age_at_maturation<DVM>(popn,e,label,_ageing_error,pseudo));}
  for (int i=1; i<=e.get_command_count("tag_release"); i++){
    label = e.get_command_labels("tag_release")[i-1];
    obs.push_back(new Tag_release<DVM>(popn,e,label,pseudo));}
  for (int i=1; i<=e.get_command_count("tag_recapture"); i++){
    label = e.get_command_labels("tag_recapture")[i-1];
    obs.push_back(new Tag_recapture<DVM>(popn,e,label,_ageing_error,pseudo));}
  // check the labels for validity
  std::vector<std::string> all_labels;
  for (int i=0; i<obs.size(); i++){
    label = obs[i]->label;
    all_labels.push_back(label);
    if (label=="Bpre") fatal("Don't label a time series 'Bpre'");
    if (label=="Bpost") fatal("Don't label a time series 'Bpost'");
    if (in(all_labels[i],".")) fatal(label + " is an invalid name for a time series because it contains a full stop.");
    for (int j=0; j<i; j++){
          if (all_labels[i]==all_labels[j]){
                fatal("You have used the time series label " + all_labels[i] + " for two different time series. Use distinct labels.");
          }
        }
  }
  // set up objective_components
  objective_components.resize(obs.size());
}

template<CDVM>
Observations_dataset<DVM>::~Observations_dataset(){
  DEBUG1("~Observations_dataset");
  for (int i=0; i<obs.size(); i++){
    delete obs[i];}
}

template<CDVM>
DOUBLE Observations<DVM>::get_objective_function(){
  DEBUG1("Observations::get_objective_function");
  return this->objective->obj_value(*fits,*(this->obs));
}

template<CDVM>
MATRIX Observations<DVM>::get_resids(){
  // Calculate the residuals.
  // calculate_fits should have been called first.
  DEBUG1("Observations::get_resids");
  return *(this->obs) - *fits;
}

template<CDVM>
MATRIX Observations<DVM>::get_pearson_resids(){
  // Calculate the Pearson residuals.
  // calculate_fits() should have been called first.
  // works through a call to objective->get_std_devs.
  DEBUG2("Observations::get_standardised_resids()");
  return elem_div(*(this->obs) - *fits,objective->get_std_devs(*(this->obs),*fits));
  // get_std_devs needs to know obs in Coleraine likelihoods (only)
}

template<CDVM>
MATRIX Observations<DVM>::get_normalised_resids(){
  // Calculate the normalised residuals.
  // calculate_fits() should have been called first.
  // works through a call to objective->this->get_normalised_resids,
  // and note the results are undefined unless (objective->normalised_residuals_defined),
  DEBUG2("Observations::get_standardised_resids()");
  return this->objective->get_normalised_resids(*(this->obs),*fits);
}

template<CDVM>
void Observations<DVM>::parametric_bootstrap(long int seed){
  // Do a parametric bootstrap of these observations. Overwrite the original observation values.
  DEBUG2("Observations::get_parametric_bootstrap");
  *this->obs = this->objective->bootstrap_observations(*fits,seed);
}

template<CDVM>
Observations<DVM>::~Observations(){
  DEBUG2("~Observations");
  if (obs != 0) delete obs;
  if (fits != 0) delete fits;
  if (objective != 0) delete objective;
  if (years != 0) delete years;
}

template<CDVM>
void Abundance<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  // put entries into the Parameter_set to tell the population section what results to return
  DEBUG1("Abundance::set_request_parameters");
  std::string popn_command = "abundance[" + this->label + "].";
  p.put_constant_vector(popn_command+"years",*(this->years));
  p.put_int(popn_command+"step",step);
  p.put_constant(popn_command+"proportion_mortality",proportion_mortality);
  if (area != "") p.put_string(popn_command+"area",area);
  if (stock != "") p.put_string(popn_command+"stock",stock);
  p.put_int(popn_command+"mature_only",mature_only);
  p.put_constant(popn_command+"biomass",biomass);
  if (selectivity_name != "none") p.put_string(popn_command+"ogive",selectivity_name);
}

template<CDVM>
void Abundance<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // extract the abundances from popn.results
  DEBUG1("Abundance::calculate_fits");
  for (int i=1; i<=this->n_years; i++){
    (*(this->fits))[i][1] = popn.results.abundance[this->label][(int)((*(this->years))[i])];
  }
}

template<CDVM>
void Abundance<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Abundance::write_to_file");
  o << "@abundance " << this->label << '\n';
  o << "# simulated observations\n";
  std::string command = "abundance["+this->label+"].";
  Parameter_set<DVM> obs_pars;
  e.extract_subcommands_of_command(obs_pars,"abundance",this->label);
  // but we have to overwrite the original obs. with the simulated observations
  for (int y=this->obs->rowmin(); y<=this->obs->rowmax(); y++){
     obs_pars.put_constant_vector(command+itos((int)(*(this->years))[y]),value((*(this->obs))[y]));
  }
  obs_pars.dump_as_subcommands(o);
}

template<CDVM>
void Abundance<DVM>::print(ostream& out,int print_fits, int print_resids,
                                               int print_pearson_resids, int print_normalised_resids){
  DEBUG2("Abundance::print");
  out << "abundances in time step " << step << ((proportion_mortality!=0.5) ? (" after proportion " + dtos(proportion_mortality) + " of mortality") : "");
  if (area != ""){
    out << " in area " << area;
  }
  if (stock != ""){
    out << " for stock " << stock;
  }
  out << ((selectivity_name!="none") ? (" using selectivity " + selectivity_name) : "") << (mature_only ? " including mature fish only" : "") << ":\n";
  out << "year obs     ";
  if (print_fits)   out << "fits    ";
  if (print_resids) out << "resids  ";
  if (print_pearson_resids) out << "Pearson_resids ";
  if (print_normalised_resids && this->objective->normalised_resids_defined()) out << "Normalised_resids ";
  out << '\n';
  out << setprecision(6);
  for (int y=1; y<=this->n_years; y++){
    out << (*(this->years))[y] << " ";
    out << setw(7);
    out << (*(this->obs))[y][1];
    if (print_fits){
      out << ' ';
      out << setw(7);
      out << (*(this->fits))[y][1];
    }
    if (print_resids){
      out << ' ';
      out << setw(7);
      out << this->get_resids()[y][1];
    }
    if (print_pearson_resids){
      out << ' ';
      out << setw(7);
      out << this->get_pearson_resids()[y][1];
    }
    if (print_normalised_resids && this->objective->normalised_resids_defined()){
      out << ' ';
      out << setw(7);
      out << this->get_normalised_resids()[y][1];
    }
    out << '\n';
  }
  out << "objective function: ";
  this->objective->print(out);
  out << '\n';
}

template<CDVM>
Abundance<DVM>::Abundance(Basic_population_section<DVM>& popn,
                                              Parameter_set<DVM>& e,
                                              const std::string& _label,
                                              int relative, int pseudo){
  // Construct the Abundance observation from the Parameter_set,
  // extracting any other necessary information from the Population_section (e.g. n_areas etc)
  // If relative==1, Abundance::Abundance is being called by Relative_abundance.
  DEBUG1("Abundance::Abundance");
  this->label = _label;
  std::string command = std::string((relative) ? "relative_" : "") + "abundance[" + this->label + "].";
  step = e.get_int(command+"step");
  if (!popn.annual_cycle->valid_step(step)){
          fatal("Bad time step " + itos(step) + " for observation with label " + this->label);}
  this->years = new dvector(e.get_constant_vector(command+"years"));
  biomass = e.get_bool(command+"biomass");
  selectivity_name = e.get_string(command+"ogive","none");
  if (selectivity_name != "none" && !popn.annual_cycle->valid_selectivity(selectivity_name)){
          fatal("Bad selectivity " + selectivity_name + " for observation with label " + this->label);}
  if (popn.state.n_areas > 1){
    if (e.present(command+"all_areas")){
      area = "";
    } else {
      area = e.get_string(command+"area");
      if (!popn.state.valid_area(area)){
                  fatal("Bad area " + area + " for observations with label " + this->label);}
    }
  } else area = "";
  stock = e.get_string(command+"stock","");
  if (stock!=""){
          if (!popn.state.valid_stock(stock)){
                  fatal("Bad stock " + stock + " for observations with label " + this->label);}}
  proportion_mortality = e.get_constant(command+"proportion_mortality",0.5);
  mature_only = e.get_bool(command+"mature_only",0);
  this->do_bootstrap = e.get_bool(command+"do_bootstrap",1);
  n_years = this->years->size();
  obs_per_year = 1;
  this->fits = new MATRIX(1,n_years,1,obs_per_year);
  this->obs = new MATRIX(1,n_years,1,obs_per_year);
  if (pseudo){
    this->obs->initialize();
    this->objective = 0;
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->final){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for pseudo-observation " + command);
    }
  } else {
    for (int y=1; y<=this->n_years; y++){
      double year = (*(this->years))[y];
      if (e.get_constant_vector(command+dtos(year)).size() != obs_per_year){
        fatal("Wrong number of observations for year " + dtos(year) + " of " + this->label + ": should be " + itos(obs_per_year));}
      (*(this->obs))[y] = e.get_constant_vector(command+dtos(year));
    }
    if (!relative && e.present(command+"q")){
      fatal("have found " + command + "q - did you mean relative_abundance?");}
    this->objective = make_objective<DVM>(e,command,*(this->years),obs_per_year,this->label);
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->current){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for observation " + command);
    }
  }
}

template<CDVM>
Objective<DVM>* make_objective(Parameter_set<DVM>& e, const std::string& command,
                               const dvector& years, int obs_per_year, std::string& label){
  // Returns a pointer to the objective object.
  // I pulled this out into a separate function because all the time series types use it.
  // Currently there is no check that the objective type is appropriate for the data -
  //   expect errors if you use, for example, a multinomial likelihood for an abundance series.
  DEBUG1("make_objective");
  Objective<DVM>* objective;
  std::string estimator = e.get_string("estimator");
  std::string dist = e.get_string(command+"dist","none");
  if (estimator=="Bayes" || estimator=="likelihood"){
    if (dist=="multinomial-old"){
      objective = new Multinomial_likelihood<DVM>(e,command,years);
    } else if (dist=="multinomial"){
      objective = new Multinomial_withconst_likelihood<DVM>(e,command,years);
    } else if (dist=="Fournier"){
      objective = new Fournier_likelihood<DVM>(e,command,years);
    } else if (dist=="Coleraine"){
      objective = new Coleraine_likelihood<DVM>(e,command,years);
    } else if (dist=="binomial-approx"){
      objective = new Binomial_likelihood<DVM>(e,command,years);
    } else if (dist=="binomial"){
      objective = new Binomial_exact_likelihood<DVM>(e,command,years);
    } else if (dist=="normal"){
      objective = new Normal_likelihood<DVM>(e,command,years);
    } else if (dist=="lognormal"){
      objective = new Lognormal_likelihood<DVM>(e,command,years);
    } else if (dist=="normal-log"){
      objective = new Normal_log_likelihood<DVM>(e,command,years);
    } else if (dist=="normal-by-stdev"){
      objective = new Normal_by_stdev_likelihood<DVM>(e,command,years);
    } else if (dist=="robustified-lognormal"){
      objective = new Robustified_lognormal_likelihood<DVM>(e,command,years);
    } else if (dist=="user-supplied"){
      objective = new User_supplied_likelihood<DVM>(label);
    } else if (dist=="none"){
      fatal("You have not supplied " + command+"dist");
    } else fatal("Unknown dist " + dist);
  }
  return objective;
}

template<CDVM>
void Relative_abundance<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // extract the abundances from popn.results
  // get the fitted values as per class Abundance,
  // if the series has curvature then get and apply the b from the Qs object,
  // get and apply the q from the Qs object
  DEBUG1("Relative_abundance::calculate_fits");
  Abundance<DVM>::calculate_fits(popn);
  q = qs_ptr->q[q_name];
  VECTOR col_maxs(1,this->obs_per_year);
  if (has_curvature){
    b = qs_ptr->b[q_name];
    if (b>5){fatal("The curvature parameter b is very large (>5)");}
    if(q_type=="scaled") {
      col_maxs = 0;
      for (int y=1; y<=this->n_years; y++){
        for (int j=1; j<=this->obs_per_year; j++){
          col_maxs = fmax(col_maxs[j],(*(this->fits))[y][j]);
        }
      }
      for (int y=1; y<=this->n_years; y++){
        for (int j=1; j<=this->obs_per_year; j++){
          (*(this->fits))[y][j] = pow((*(this->fits))[y][j] / col_maxs[j], 1.0/b);
        }
      }
    } else {
      for (int y=1; y<=this->n_years; y++){
        for (int j=1; j<=this->obs_per_year; j++){
          (*(this->fits))[y][j] = pow((*(this->fits))[y][j], 1.0/b);
        }
      }
    }
  }
  (*(this->fits)) *= q;
}

template<CDVM>
void Relative_abundance<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Relative_abundance::write_to_file");
  o << "@relative_abundance " << this->label << '\n';
  o << "# simulated observations\n";
  std::string command = "relative_abundance["+this->label+"].";
  Parameter_set<DVM> obs_pars;
  e.extract_subcommands_of_command(obs_pars,"relative_abundance",this->label);
  // but we have to overwrite the original obs. with the simulated observations
  for (int y=this->obs->rowmin(); y<=this->obs->rowmax(); y++){
     obs_pars.put_constant_vector(command+itos((int)(*(this->years))[y]),value((*(this->obs))[y]));
  }
  obs_pars.dump_as_subcommands(o);
}

template<CDVM>
void Relative_abundance<DVM>::print(ostream& out, int print_fits, int print_resids,
                                                 int print_pearson_resids, int print_normalised_resids){
  DEBUG2("Relative_abundance::print");
  out << "relative ";
  if (print_fits){
    out << "(with q = " << q;
    if (has_curvature) out << ", curvature b = " << b << ", and q_type '" << q_type << "'" ;
    out << ") ";
  } else if (has_curvature) out << "(with curvature) ";
  Abundance<DVM>::print(out,print_fits,print_resids,
                        print_pearson_resids,print_normalised_resids);
}

template<CDVM>
Relative_abundance<DVM>::Relative_abundance(Basic_population_section<DVM>& popn,
                                                                Parameter_set<DVM>& e,
                                                                const std::string& _label, int pseudo)
  : Abundance<DVM>(popn, e, _label, 1, pseudo){
  // Construct the Relative_abundance observation from the Parameter_set.
  // Most of the work is done by Abundance::Abundance and Qs::Qs, we just need to grab q_name
  // and find out if there is curvature.
  DEBUG1("Relative_abundance::Relative_abundance");
  std::string command = "relative_abundance[" + _label + "].";
  has_curvature = e.get_bool(command+"curvature",0);
  q_name = e.get_string(command+"q");
  q_type = e.get_string("q_type","standard");
}

template<CDVM>
void Numbers_at<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  // put entries into the Parameter_set to tell the population section what results to return
  // Note that for an age-based model we ask for numbers in all age classes,
  //  which we may need for ageing error.
  DEBUG1("Numbers_at::set_request_parameters");
  std::string popn_command = "numbers_at[" + this->label + "].";
  p.put_constant_vector(popn_command+"years",*(this->years));
  p.put_int(popn_command+"step",step);
  p.put_int(popn_command+"sexed",sexed);
  p.put_int(popn_command+"at_size",at_size);
  p.put_constant(popn_command+"proportion_mortality",proportion_mortality);
  if (area != "") p.put_string(popn_command+"area",area);

  if (class_mins.size()!=1){
    p.put_constant_vector(popn_command+"class_mins",class_mins);
    p.put_int(popn_command+"plus_group",plus_group);
  }
  else if (class_nums.size()!=1){
    p.put_constant_vector(popn_command+"class_nums",class_nums);
    p.put_int(popn_command+"plus_group",plus_group);
  }
  else if (class_nums_male.size()!=1 && class_nums_female.size()!=1){
    p.put_constant_vector(popn_command+"class_nums_male",class_nums_male);
    p.put_constant_vector(popn_command+"class_nums_female",class_nums_female);
    p.put_int(popn_command+"plus_group",plus_group);
  }

  if (selectivity_name != "none") p.put_string(popn_command+"ogive",selectivity_name);
}

template<CDVM>
void Numbers_at<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // extract the numbers-at from popn.results
  DEBUG1("Numbers_at::calculate_fits");
  int max_class_in_result, col_in_fits;
  MATRIX* result;

  for (int y=1; y<=this->n_years; y++){
          if (!in(popn.results.numbers_at[this->label],(int)((*(this->years))[y]))) continue;
    result = new MATRIX(popn.results.numbers_at[this->label][(int)((*(this->years))[y])]);
    if (ageing_error){
      if (ageing_error_ptr->ageing_error) ageing_error_ptr->apply(*result);}
    max_class_in_result = result->colmax();

    // extract results
    // unsexed then sex_index = 1 = male and female
    // sexed   then sex_index = 1 = male, sex_index = 2 = female)
    // if sexed then the fits for the female are put as entries directly after the fits for the males
    if(class_nums.size() == 1 && class_nums_male.size() == 1){    // default entry is the element -1
        for(int sex_index = 1; sex_index<=1+sexed; sex_index++){
          for (int i=int(min_class[sex_index]); i<=int(max_class[sex_index]); i++){
            col_in_fits = int(i-min_class[sex_index]+1);
            if(sex_index == 2) col_in_fits += (int)n_classes[1];  // store female after male results
            (*(this->fits))[y][col_in_fits] = (*result)[sex_index][i];
          }
          if (plus_group){
            for (int i=int(max_class[sex_index]+1); i<=max_class_in_result; i++){
              (*(this->fits))[y][col_in_fits] += (*result)[sex_index][i];
            }
          }
        }


    }
    else {  // class_nums or  class_nums_male and class_nums_female  subcommands used
        if(!sexed){     // class_nums used
          for (int i = 1; i<=class_nums.size()-1 ; i++){
            (*(this->fits))[y][i] = 0;
            for (int j = (int)class_nums[i]; j<=(int)class_nums[i+1]-1; j++){
                (*(this->fits))[y][i]  += (*result)[1][j];
            }
          }
          if (plus_group){
            int end_index = class_nums.size();
            (*(this->fits))[y][end_index] = 0;
            for (int j = (int)class_nums[end_index]; j<=max_class_in_result; j++){
              (*(this->fits))[y][end_index] += (*result)[1][j];
            }
          }
        }
        else{   // class_nums_male and class_nums_female used
          // male fits
          for (int i = 1; i<=class_nums_male.size()-1 ; i++){
             (*(this->fits))[y][i] = 0;
             for (int j = (int)class_nums_male[i]; j<=(int)class_nums_male[i+1]-1; j++){
                 (*(this->fits))[y][i]  += (*result)[1][j];
             }
          }
          if(plus_group){
            int end_index = class_nums_male.size();
            (*(this->fits))[y][end_index] = 0;
            for (int j = (int)class_nums_male[end_index]; j<=max_class_in_result; j++){
              (*(this->fits))[y][end_index] += (*result)[1][j];
            }
          }
          // female fits
          for (int i = 1; i<=class_nums_female.size()-1 ; i++){
             int col_in_fits = i + (int)n_classes[1];
             (*(this->fits))[y][col_in_fits] = 0;
             for (int j = (int)class_nums_female[i]; j<=(int)class_nums_female[i+1]-1; j++){
                 (*(this->fits))[y][col_in_fits]  += (*result)[2][j];
             }
          }
          if(plus_group){
            int end_index = class_nums_female.size() + (int)n_classes[1];
            (*(this->fits))[y][end_index] = 0;
            for (int j = (int)class_nums_female[class_nums_female.size()]; j<=max_class_in_result; j++){
              (*(this->fits))[y][end_index] += (*result)[2][j];
            }
          }

        }

    }    // end of else for using class_nums or class_nums_male and class_nums_female
    delete result;
  }   // end of loop over years
}

template<CDVM>
void Numbers_at<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Numbers_at::write_to_file");
  o << "@numbers_at " << this->label << '\n';
  o << "# simulated observations\n";
  std::string command = "numbers_at["+this->label+"].";
  Parameter_set<DVM> obs_pars;
  e.extract_subcommands_of_command(obs_pars,"numbers_at",this->label);
  // but we have to overwrite the original obs. with the simulated observations
  for (int y=this->obs->rowmin(); y<=this->obs->rowmax(); y++){
     obs_pars.put_constant_vector(command+itos((int)(*(this->years))[y]),value((*(this->obs))[y]));
  }
  obs_pars.dump_as_subcommands(o);
}

template<CDVM>
void Numbers_at<DVM>::print(ostream& out, int print_fits, int print_resids,
                                                int print_pearson_resids, int print_normalised_resids){
  DEBUG2("Numbers_at::print");
  out << "numbers-at-" << (at_size ? "size" : "age") << (sexed ? " by sex" : "") << " in time step " <<
   step << ((proportion_mortality!=0.5) ? (" after proportion " + dtos(proportion_mortality) + " of mortality") : "") <<
   ((area!="") ? (" in area " + area) : "") << ((selectivity_name!="none") ? (" using selectivity " + selectivity_name) : "") <<
   (ageing_error ? " with ageing error" : "") << ":\n";
  print_header(out,"obs");
  for (int y=1; y<=this->n_years; y++){
    out << (*(this->years))[y] << " ";
    for (int i=1; i<=this->obs_per_year; i++){
      out << setw(7) << (*(this->obs))[y][i] << " ";
    }
    out << '\n';
  }
  if (print_fits){
    print_header(out,"fits");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << (*(this->fits))[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_resids){
    MATRIX resids(this->get_resids());
    print_header(out,"resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_pearson_resids){
    MATRIX pearson_resids(this->get_pearson_resids());
    print_header(out,"pearson_resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << pearson_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_normalised_resids && this->objective->normalised_resids_defined()){
    MATRIX normalised_resids(this->get_normalised_resids());
    print_header(out,"normalised_resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << normalised_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  out << "objective function: ";
  this->objective->print(out);
  out << '\n';
}

template<CDVM>
void Numbers_at<DVM>::print_header(ostream& out,const std::string& what_it_is){
  // called repeatedly by Numbers_at::print()
  DEBUG2("Numbers_at::print_header");
  out << setprecision(6);
  if (sexed){
    if( class_nums_male.size()!= 1 && class_nums_female.size()!=1 && !plus_group )
       out << what_it_is << " (male then female: last class is upper bound for last bin, "
       "but does not include this value)"  << ":\nclass ";
    else{
        out << what_it_is << " (male then female" << (plus_group ? " : last class is a plus group" : "") << "):\nclass ";
    }
    if (class_mins.size()!=1){
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << "M" << class_mins[i] << " ";}
      for (int i=int(min_class[2]); i<=int(max_class[2]); i++){
        out << "F" << class_mins[i] << " ";}
    }
    else if (class_nums_male.size()!=1 && class_nums_female.size()!= 1){
      for (int i=1; i<=class_nums_male.size(); i++){
        out << "M" << class_nums_male[i]  << " ";}
      for (int i=1; i<=class_nums_female.size(); i++){
        out << "F" << class_nums_female[i] << " ";}
    }
    else {  // all the classes
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << "M" << i << " ";}
      for (int i=int(min_class[2]); i<=int(max_class[2]); i++){
        out << "F" << i << " ";}
    }
  }

  else {   // unsexed
    if(class_nums.size()!=1)
      out << what_it_is << " (last class is upper bound for last bin, but does not include this value)"  << ":\nclass ";
    else{
      out << what_it_is << (plus_group ? " (last class is a plus group)" : "") << ":\nclass ";
    }
    if (class_mins.size()!=1){
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << setw(7) << class_mins[i] << " ";}
    }
    else if (class_nums.size()!=1){
      for (int i=1; i<=class_nums.size(); i++){
        out << setw(7) << class_nums[i] << " ";}
    }
    else {
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << setw(7) << i << " ";}
    }
  }
  out << '\n';
}

template<CDVM>
Numbers_at<DVM>::Numbers_at(Basic_population_section<DVM>& popn,
                                                Parameter_set<DVM>& e,
                                                const std::string& _label,
                                                Ageing_error<DVM>* _ageing_error_ptr,
                                                int relative, int pseudo)
  : command(((relative) ? "relative_numbers_at[" : "numbers_at[") + _label + "].")
  , n_classes(1+e.get_bool(command+"sexed",popn.state.sex_partition))
  , min_class(1+e.get_bool(command+"sexed",popn.state.sex_partition))
  , max_class(1+e.get_bool(command+"sexed",popn.state.sex_partition))
  , class_nums(e.get_constant_vector(command+"class_nums",dvector("{-1}")))
  , class_nums_male(e.get_constant_vector(command+"class_nums_male",dvector("{-1}")))
  , class_nums_female(e.get_constant_vector(command+"class_nums_female",dvector("{-1}")))
  , class_mins(e.get_constant_vector(command+"class_mins",dvector("{-1}"))){
  // Construct the Numbers_at observation from the Parameter_set,
  // extracting any other necessary information from the Population_section (e.g. n_areas etc)
  DEBUG1("Numbers_at::Numbers_at");
  this->label = _label;
  step = e.get_int(command+"step");
  if (!popn.annual_cycle->valid_step(step)){
          fatal("Bad time step " + itos(step) + " for observation with label " + this->label);}
  this->years = new dvector(e.get_constant_vector(command+"years"));
  n_years = this->years->size();
  at_size = e.get_bool(command+"at_size",popn.state.size_based);
  if (!at_size && e.present(command+"class_mins")){
          fatal("For numbers_at[" + _label + "], you can't specify class_mins for at-age observations");}
  if (!popn.state.size_based && at_size && !e.present(command+"class_mins")){
          fatal("For numbers_at[" + _label + "], you must specify class_mins for at-size observations in an age based model");}
  if (popn.state.size_based && e.present(command+"class_mins")){
          fatal("For numbers_at[" + _label + "], you can't specify class_mins in an observations block in a size-based model - must use same size classes as in population data file");}
  sexed = e.get_bool(command+"sexed",popn.state.sex_partition);
 if(sexed == 1 && popn.state.sex_partition == 0)
    fatal("It is not possible to have the sexed subcommand for the observation with label " + this->label + " set to True, "
    "while the command @sex_partition is set to False.");
  selectivity_name = e.get_string(command+"ogive","none");
  if (selectivity_name != "none" && !popn.annual_cycle->valid_selectivity(selectivity_name)){
          fatal("Bad selectivity " + selectivity_name + " for observation with label " + this->label);}
  if (popn.state.n_areas > 1){
          area = e.get_string(command+"area");
          if (!popn.state.valid_area(area)){
                  fatal("Bad area " + area + " for observations with label " + this->label);}
  } else area="";
  proportion_mortality = e.get_constant(command+"proportion_mortality",0.5);
  plus_group = e.get_bool(command+"plus_group",0);
  this->do_bootstrap = e.get_bool(command+"do_bootstrap",1);

  //
  // A great big pile of error checks on the subcommands class_nums, class_nums_male, class_nums_female
  //

  int p_cn =  e.present(command+"class_nums");
  int p_cnm = e.present(command+"class_nums_male");
  int p_cnf = e.present(command+"class_nums_female");

  if( (p_cnm && ! p_cnf) || (p_cnf && !p_cnm) )
    fatal("For numbers_at[" + _label + "], you should use both class_nums_male and class_nums_female in a sexed model");
  if(sexed && p_cn)
    fatal("For numbers_at[" + _label + "], you should use class_nums_male and class_nums_female in a sexed model (not class_nums)");
  if(!sexed && (p_cnm || p_cnf) )
    fatal("For numbers_at[" + _label + "], you should use class_nums in a non-sexed model (not class_nums_male/class_nums_female)");
  if ( !popn.state.size_based && (p_cn || p_cnm) )
    fatal("You can only use the subcommands class_nums, class_nums_male, class_nums_female in a size-based model.");
    if(e.present(command+"min_class") && (p_cn || p_cnm) ){
    fatal("For numbers_at[" + _label + "], you can't have both min_class/max_class and class_nums/class_nums_male/class_num_females "
    "as subcommands for @proportions");
  }

  if(p_cn){
    for(int i=1; i<=class_nums.size(); i++){
       if( fabs( floor(class_nums[i]) - class_nums[i] ) > 1e-8 )
         fatal("For numbers_at[" + _label + "], entries for class_nums should be integers");
    }
    for(int i=1; i<=class_nums.size()-1; i++){
       if ( class_nums[i+1] <= class_nums[i] )
         fatal("For numbers_at[" + _label + "], entries for class_nums should increase from left to right");
    }
  }
  if(p_cnm){
    for(int i=1; i<=class_nums_male.size(); i++){
       if( fabs( floor(class_nums_male[i]) - class_nums_male[i] ) > 1e-8 )
         fatal("For numbers_at[" + _label + "], entries for class_nums_male should be integers");
    }
    for(int i=1; i<=class_nums_male.size()-1; i++){
       if ( class_nums_male[i+1] <= class_nums_male[i] )
         fatal("For numbers_at[" + _label + "], entries for class_nums_male should increase from left to right");
    }
  }
  if(p_cnf){
    for(int i=1; i<=class_nums_female.size(); i++){
       if( fabs( floor(class_nums_female[i]) - class_nums_female[i] ) > 1e-8 )
         fatal("For numbers_at[" + _label + "], entries for class_nums_female should be integers");
    }
    for(int i=1; i<=class_nums_female.size()-1; i++){
       if ( class_nums_female[i+1] <= class_nums_female[i] )
         fatal("For numbers_at[" + _label + "], entries for class_nums_female should increase from left to right");
    }
  }

  if(popn.state.size_based){
    int max_classes = popn.state.col_max;
    if(p_cn){
      if (max(class_nums) > max_classes){
        fatal("For numbers_at[" + _label + "], one of your classes in class_nums exceeds the maximum class number: "  + itos(max_classes));
      }
    }
    if(p_cnm){
      if (max(class_nums_male) > max_classes){
        fatal("For numbers_at[" + _label + "], one of your classes in class_nums_male exceeds the maximum class number: "  + itos(max_classes));
      }
    }
    if(p_cnf){
      if (max(class_nums_female) > max_classes){
        fatal("For numbers_at[" + _label + "], one of your classes in class_nums_female exceeds the maximum class number: "  + itos(max_classes));
      }
    }
  }

  // Now that most error checks have finished, start setting up some variables

  if (e.present(command+"min_class")){
    //if(!popn.state.size_based && at_size)
    //  fatal("For numbers_at[" + _label + "], you cannot specify min_class/max_class for a size-based observation in an age-based model");
    if (e.get_constant_vector(command+"min_class").size()!=min_class.size()){
      fatal("Wrong size for argument " + command + "min_class - should be " + itos(min_class.size()));}
    min_class = e.get_constant_vector(command+"min_class");
    if(!(!popn.state.size_based && at_size) && min(min_class) < popn.state.col_min)
      fatal("For numbers_at[" + _label + "] an element of min_class is less than the number of the lowest partition age/size class.");
  }
  else if (class_mins.size()!=1)
    min_class = 1;
  else if (p_cn || p_cnm || p_cnf )
    min_class = -99;  // value not needed
  else
    min_class = popn.state.col_min;

  if (e.present(command+"max_class")){
    if (e.get_constant_vector(command+"max_class").size()!=max_class.size()){
      fatal("Wrong size for argument " + command + "max_class - should be " + itos(max_class.size()));}
    max_class = e.get_constant_vector(command+"max_class");
    if(e.present(command+"class_mins")){
          int number_of_classes = class_mins.size() - (plus_group ? 0 : 1);
          if (max(max_class) > number_of_classes){
            fatal("For numbers_at[" + _label + "] an element of max_class is greater than the number of "
            "classes defined by class_mins(" + itos(number_of_classes) + ").");
          }
        } else {
          if (max(max_class) > popn.state.col_max){
                  fatal("For numbers_at[" + _label + "] an element of max_class is greater than the number of the highest partition age/size class.");
          }
        }
  }
  else if (class_mins.size()!=1)
    max_class = class_mins.size() - (plus_group ? 0 : 1);
  else if (p_cn || p_cnm || p_cnf )
    max_class = -99;   // value not needed
  else
    max_class = popn.state.col_max;

  if( e.present(command+"class_nums") )
    n_classes = class_nums.size() - (plus_group ? 0 : 1);
  else if (p_cnm && p_cnf){
    n_classes[1] = class_nums_male.size() - (plus_group ? 0 : 1);
    n_classes[2] = class_nums_female.size() - (plus_group ? 0 : 1);
  }
  else
    n_classes = max_class - min_class + 1;

  obs_per_year = (int)sum(n_classes);
  this->fits = new MATRIX(1,n_years,1,obs_per_year);
  this->obs = new MATRIX(1,n_years,1,obs_per_year);
  if (e.get_string("ageing_error.type","none")=="none") ageing_error = 0;
  else ageing_error = e.get_bool(command+"ageing_error",!at_size);
  if (at_size && ageing_error) fatal("Numbers-at-size " + this->label + " requested ageing error");
  if (ageing_error) ageing_error_ptr = _ageing_error_ptr;
  if (pseudo){
    this->obs->initialize();
    this->objective = 0;
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->final){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for pseudo-observation " + command);
    }
  } else {
    for (int y=1; y<=this->n_years; y++){
      double year = (*(this->years))[y];
      if (e.get_constant_vector(command+dtos(year)).size() != obs_per_year){
        if(class_nums.size()==1 && class_nums_male.size()==1 && class_nums_female.size()==1){
          fatal("Wrong number of observations for year " + dtos(year) + " of " + this->label + ": should be " +
          itos(obs_per_year) + ". You may have omitted or misspecified the min_class, max_class and/or class_mins arguments.\n");
        }
        else{
          fatal("Wrong number of observations for year " + dtos(year) + " of " + this->label + ": should be " +
          itos(obs_per_year) +
          ". You may have omitted or misspecified the class_nums, class_nums_male, class_nums_female arguments.\n");
        }
      }
      (*(this->obs))[y] = e.get_constant_vector(command+dtos(year));
    }
    this->objective = make_objective<DVM>(e,command,*(this->years),obs_per_year,this->label);
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->current){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for observation " + command);
    }
  }
}

template<CDVM>
void Relative_numbers_at<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // extract the numbers_ats from popn.results
  // get the fitted values as per class Numbers_at,
  // if the series has curvature then get and apply the b from the Qs object,
  // get and apply the q from the Qs object
  DEBUG1("Relative_numbers_at::calculate_fits");
  Numbers_at<DVM>::calculate_fits(popn);
  q = qs_ptr->q[q_name];
  VECTOR col_maxs(1,this->obs_per_year);
  if (has_curvature){
    b = qs_ptr->b[q_name];
    if(q_type=="scaled") {
      col_maxs = 0;
      for (int y=1; y<=this->n_years; y++){
        for (int j=1; j<=this->obs_per_year; j++){
          col_maxs = fmax(col_maxs[j],(*(this->fits))[y][j]);
        }
      }
      for (int y=1; y<=this->n_years; y++){
        for (int j=1; j<=this->obs_per_year; j++){
          (*(this->fits))[y][j] = pow((*(this->fits))[y][j] / col_maxs[j], 1.0/b);
        }
      }
    } else {
      for (int y=1; y<=this->n_years; y++){
        for (int j=1; j<=this->obs_per_year; j++){
          (*(this->fits))[y][j] = pow((*(this->fits))[y][j], 1.0/b);
        }
      }
    }
  }
  (*(this->fits)) *= q;
}

template<CDVM>
void Relative_numbers_at<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Relative_numbers_at::write_to_file");
  o << "@relative_numbers_at " << this->label << '\n';
  o << "# simulated observations\n";
  std::string command = "relative_numbers_at["+this->label+"].";
  Parameter_set<DVM> obs_pars;
  e.extract_subcommands_of_command(obs_pars,"relative_numbers_at",this->label);
  // but we have to overwrite the original obs. with the simulated observations
  for (int y=this->obs->rowmin(); y<=this->obs->rowmax(); y++){
     obs_pars.put_constant_vector(command+itos((int)(*(this->years))[y]),value((*(this->obs))[y]));
  }
  obs_pars.dump_as_subcommands(o);
}

template<CDVM>
void Relative_numbers_at<DVM>::print(ostream& out,int print_fits,int print_resids,
                                                 int print_pearson_resids, int print_normalised_resids){
  DEBUG2("Relative_numbers_at::print");
  out << "relative ";
  if (print_fits){
    out << "(with q = " << q;
    if (has_curvature) out << ", curvature b = " << b << ", and q_type '" << q_type << "'" ;
    out << ") ";
  } else {
    if (has_curvature) out << "(with curvature) ";
  }
  Numbers_at<DVM>::print(out,print_fits,print_resids,
                                            print_pearson_resids, print_normalised_resids);
}

template<CDVM>
Relative_numbers_at<DVM>::Relative_numbers_at(Basic_population_section<DVM>& popn,
                                              Parameter_set<DVM>& e,
                                              const std::string& _label,
                                              Ageing_error<DVM>* _ageing_error_ptr, int pseudo)
  : Numbers_at<DVM>(popn, e, _label, _ageing_error_ptr, 1, pseudo){
  // Construct the Relative_numbers_at observation from the Parameter_set.
  // Most of the work is done by Numbers_at::Numbers_at and Qs::Qs, we just need to grab q_name
  // and find out if there is curvature.
  DEBUG1("Relative_numbers_at::Relative_numbers_at");
  std::string command = "relative_numbers_at[" + this->label + "].";
  has_curvature = e.get_bool(command+"curvature",0);
  q_name = e.get_string(command+"q");
  q_type= e.get_string("q_type","standard");
}

template<CDVM>
void Proportions_at<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  // put entries into the Parameter_set to tell the population section what results to return
  // we ask for numbers-at, then Proportions_at::calculate_fits converts them to proportions-at
  // Note that for an age-based model we ask for numbers in all age classes,
  //  which we may need for ageing error.
  DEBUG1("Proportions_at::set_request_parameters");
  std::string popn_command = "numbers_at[" + this->label + "].";
  p.put_constant_vector(popn_command+"years",*(this->years));
  p.put_int(popn_command+"step",step);
  p.put_int(popn_command+"sexed",sexed);
  p.put_int(popn_command+"at_size",at_size);
  p.put_constant(popn_command+"proportion_mortality",proportion_mortality);
  if (area != "") p.put_string(popn_command+"area",area);

  if (class_mins.size()!=1){
    if (!sum_to_one){
      // This is a size-based observation in an age-based model, and the proportions-at-size are
      // not constrained to sum to 1. We need to add in minus and plus groups, so that we can figure
      // the denominator of the proportions-at-size.
      dvector temp_class_mins(class_mins.size()+1);
      temp_class_mins[1]=0;
      for (int i=1; i<=class_mins.size(); i++){
        temp_class_mins[i+1] = class_mins[i];
      }
      p.put_constant_vector(popn_command+"class_mins",temp_class_mins);
      p.put_int(popn_command+"plus_group",1);
    }
    else {
      p.put_constant_vector(popn_command+"class_mins",class_mins);
      p.put_int(popn_command+"plus_group",plus_group);
    }
  }
  else if (class_nums.size()!=1){
    p.put_constant_vector(popn_command+"class_nums",class_nums);
    p.put_int(popn_command+"plus_group",plus_group);
  }
  else if (class_nums_male.size()!=1 && class_nums_female.size()!=1){
    p.put_constant_vector(popn_command+"class_nums_male",class_nums_male);
    p.put_constant_vector(popn_command+"class_nums_female",class_nums_female);
    p.put_int(popn_command+"plus_group",plus_group);
  }

  if (selectivity_name != "none") p.put_string(popn_command+"ogive",selectivity_name);
}

template<CDVM>
void Proportions_at<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // extract the numbers-at from popn.results
  DEBUG1("Proportions_at::calculate_fits");
  int max_class_in_result, col_in_fits;
  dvector _min_class(min_class);
  dvector _max_class(max_class);
  MATRIX *result;

  if (!sum_to_one && class_mins.size()!=1){
    // We have inserted a minus group, which is the new size class 1.
    // (See set_request_parameters)
    // We need to adjust min_class, max_class accordingly.
    _min_class = _min_class+1;
    _max_class = _max_class+1;
  }


  for (int y=1; y<=this->n_years; y++){
        if (!in(popn.results.numbers_at[this->label],(int)((*(this->years))[y]))) continue;
    result = new MATRIX(popn.results.numbers_at[this->label][(int)((*(this->years))[y])]);
    if (ageing_error){
      if (ageing_error_ptr->ageing_error) ageing_error_ptr->apply(*result);}
    max_class_in_result = result->colmax();

    // extract results
    // unsexed then sex_index = 1 = male and female
    // sexed   then sex_index = 1 = male, sex_index = 2 = female)
    // if sexed then the fits for the female are put as entries directly after the fits for the males
    if(class_nums.size() == 1 && class_nums_male.size() == 1){    // default entry is the element -1
        for(int sex_index = 1; sex_index<=1+sexed; sex_index++){
          for (int i=int(_min_class[sex_index]); i<=int(_max_class[sex_index]); i++){
            col_in_fits = int(i-_min_class[sex_index]+1);
            if(sex_index == 2) col_in_fits += (int)n_classes[1];  // store female after male results
            (*(this->fits))[y][col_in_fits] = (*result)[sex_index][i];
          }
          if (plus_group){
            for (int i=int(_max_class[sex_index]+1); i<=max_class_in_result; i++){
              (*(this->fits))[y][col_in_fits] += (*result)[sex_index][i];
            }
          }
        }


    }
    else {  // class_nums or  class_nums_male and class_nums_female  subcommands used
        if(!sexed){     // class_nums used
          for (int i = 1; i<=class_nums.size()-1 ; i++){
            (*(this->fits))[y][i] = 0;
            for (int j = (int)class_nums[i]; j<=(int)class_nums[i+1]-1; j++){
                (*(this->fits))[y][i]  += (*result)[1][j];
            }
          }
          if (plus_group){
            int end_index = class_nums.size();
            (*(this->fits))[y][end_index] = 0;
            for (int j = (int)class_nums[end_index]; j<=max_class_in_result; j++){
              (*(this->fits))[y][end_index] += (*result)[1][j];
            }
          }
        }
        else{   // class_nums_male and class_nums_female used
          // male fits
          for (int i = 1; i<=class_nums_male.size()-1 ; i++){
             (*(this->fits))[y][i] = 0;
             for (int j = (int)class_nums_male[i]; j<=(int)class_nums_male[i+1]-1; j++){
                 (*(this->fits))[y][i]  += (*result)[1][j];
             }
          }
          if(plus_group){
            int end_index = class_nums_male.size();
            (*(this->fits))[y][end_index] = 0;
            for (int j = (int)class_nums_male[end_index]; j<=max_class_in_result; j++){
              (*(this->fits))[y][end_index] += (*result)[1][j];
            }
          }
          // female fits
          for (int i = 1; i<=class_nums_female.size()-1 ; i++){
             int col_in_fits = i + (int)n_classes[1];
             (*(this->fits))[y][col_in_fits] = 0;
             for (int j = (int)class_nums_female[i]; j<=(int)class_nums_female[i+1]-1; j++){
                 (*(this->fits))[y][col_in_fits]  += (*result)[2][j];
             }
          }
          if(plus_group){
            int end_index = class_nums_female.size() + (int)n_classes[1];
            (*(this->fits))[y][end_index] = 0;
            for (int j = (int)class_nums_female[class_nums_female.size()]; j<=max_class_in_result; j++){
              (*(this->fits))[y][end_index] += (*result)[2][j];
            }
          }

        }

    }    // end of else for using class_nums or class_nums_male and class_nums_female

    delete result;

  }   // end of loop over years

  // convert from numbers to proportions
  DOUBLE denominator;
  for (int y=1; y<=this->n_years; y++){
    if (sum_to_one){
      denominator = sum((*(this->fits))[y]);
    } else {
      if (sexed){
        denominator = sum(popn.results.numbers_at[this->label][(int)((*(this->years))[y])][1]) +
                      sum(popn.results.numbers_at[this->label][(int)((*(this->years))[y])][2]);
      } else {
        denominator = sum(popn.results.numbers_at[this->label][(int)((*(this->years))[y])][1]);
      }
    }
    if(denominator>0) (*(this->fits))[y] /= denominator; // if sum(fits)==0, then don't divide by zero, just return the fits (which should all equal zero)
    // (*(this->fits))[y] /= denominator;
  }
}

template<CDVM>
void Proportions_at<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Proportions_at::write_to_file");
  o << "@proportions_at " << this->label << '\n';
  o << "# simulated observations\n";
  std::string command = "proportions_at["+this->label+"].";
  Parameter_set<DVM> obs_pars;
  e.extract_subcommands_of_command(obs_pars,"proportions_at",this->label);
  // but we have to overwrite the original obs. with the simulated observations
  for (int y=this->obs->rowmin(); y<=this->obs->rowmax(); y++){
     obs_pars.put_constant_vector(command+itos((int)(*(this->years))[y]),value((*(this->obs))[y]));
  }
  obs_pars.dump_as_subcommands(o);
}

template<CDVM>
void Proportions_at<DVM>::print(ostream& out, int print_fits, int print_resids,
                                               int print_pearson_resids, int print_normalised_resids){
  DEBUG2("Proportions_at::print");
  out << "proportions-at-" << (at_size ? "size" : "age") << (sexed ? " by sex" : "") << " in time step " << step << ((proportion_mortality!=0.5) ? (" after proportion " + dtos(proportion_mortality) + " of mortality") : "") << ((area!="") ? (" in area " + area) : "") << ((selectivity_name!="none") ? (" using selectivity " + selectivity_name) : "") << (ageing_error ? " with ageing error" : "") << " (" << (sum_to_one ? "" : "not ") << "constrained to sum to 1):\n";
  print_header(out,"obs");
  for (int y=1; y<=this->n_years; y++){
    out << (*(this->years))[y] << " ";
    for (int i=1; i<=this->obs_per_year; i++){
      out << setw(7) << (*(this->obs))[y][i] << " ";
    }
    out << '\n';
  }
  if (print_fits){
    print_header(out,"fits");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << (*(this->fits))[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_resids){
    MATRIX resids(this->get_resids());
    print_header(out,"resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_pearson_resids){
    MATRIX pearson_resids(this->get_pearson_resids());
    print_header(out,"pearson_resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << pearson_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_normalised_resids && this->objective->normalised_resids_defined()){
    MATRIX normalised_resids(this->get_normalised_resids());
    print_header(out,"normalised_resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << normalised_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  out << "objective function: ";
  this->objective->print(out);
  out << '\n';
}

template<CDVM>
void Proportions_at<DVM>::print_header(ostream& out, const std::string& what_it_is){
  // called repeatedly by print()
  DEBUG2("proportions_at::print_header");
  out << setprecision(6);
  if (sexed){
    if( class_nums_male.size()!= 1 && class_nums_female.size()!=1 && !plus_group )
       out << what_it_is << " (male then female: last class is upper bound for last bin, "
       "but does not include this value)"  << ":\nclass ";
    else{
        out << what_it_is << " (male then female" << (plus_group ? " : last class is a plus group" : "") << "):\nclass ";
    }
    if (class_mins.size()!=1){
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << "M" << class_mins[i] << " ";}
      for (int i=int(min_class[2]); i<=int(max_class[2]); i++){
        out << "F" << class_mins[i] << " ";}
    }
    else if (class_nums_male.size()!=1 && class_nums_female.size()!= 1){
      for (int i=1; i<=class_nums_male.size(); i++){
        out << "M" << class_nums_male[i]  << " ";}
      for (int i=1; i<=class_nums_female.size(); i++){
        out << "F" << class_nums_female[i] << " ";}
    }
    else {    // all the classes
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << "M" << i << " ";}
      for (int i=int(min_class[2]); i<=int(max_class[2]); i++){
        out << "F" << i << " ";}
    }
  }

  else {   // non-sexed
    if(class_nums.size()!=1)
      out << what_it_is << " (last class is upper bound for last bin, but does not include this value)"  << ":\nclass ";
    else{
      out << what_it_is << (plus_group ? " (last class is a plus group)" : "") << ":\nclass ";
    }
    if (class_mins.size()!=1){
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << setw(7) << class_mins[i] << " ";}
    }
    else if (class_nums.size()!=1){
      for (int i=1; i<=class_nums.size(); i++){
        out << setw(7) << class_nums[i] << " ";}
    }
    else {
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << setw(7) << i << " ";}
    }
  }
  out << '\n';
}

template<CDVM>
Proportions_at<DVM>::Proportions_at(Basic_population_section<DVM>& popn,
                                                        Parameter_set<DVM>& e,
                                                        const std::string& _label,
                                                Ageing_error<DVM>* _ageing_error_ptr, int pseudo)
  : command("proportions_at[" + _label + "].")
  , n_classes(1+e.get_bool(command+"sexed",popn.state.sex_partition))
  , min_class(1+e.get_bool(command+"sexed",popn.state.sex_partition))
  , max_class(1+e.get_bool(command+"sexed",popn.state.sex_partition))
  , class_nums(e.get_constant_vector(command+"class_nums",dvector("{-1}")))
  , class_nums_male(e.get_constant_vector(command+"class_nums_male",dvector("{-1}")))
  , class_nums_female(e.get_constant_vector(command+"class_nums_female",dvector("{-1}")))
  , class_mins(e.get_constant_vector(command+"class_mins",dvector("{-1}"))){
  // Construct the Proportions_at observation from the Parameter_set,
  // extracting any other necessary information from the Population_section (e.g. n_areas etc)
  DEBUG1("Proportions_at::Proportions_at");
  this->label = _label;
  step = e.get_int(command+"step");
  if (!popn.annual_cycle->valid_step(step)){
          fatal("Bad time step " + itos(step) + " for observation with label " + this->label);}
  this->years = new dvector(e.get_constant_vector(command+"years"));
  n_years = this->years->size();
  at_size = e.get_bool(command+"at_size",popn.state.size_based);
  if (!at_size && e.present(command+"class_mins")){
          fatal("For proportions_at[" + _label + "], you can't specify class_mins for at-age observations");}
  if (!popn.state.size_based && at_size && !e.present(command+"class_mins")){
          fatal("For proportions_at[" + _label + "], you must specify class_mins for at-size observations in an age based model");}
  if (popn.state.size_based && e.present(command+"class_mins")){
          fatal("For proportions_at[" + _label + "], you can't specify class_mins in an observations block in a size-based model - must use same size classes as in population data file");}
  sexed = e.get_bool(command+"sexed",popn.state.sex_partition);
  if(sexed == 1 && popn.state.sex_partition == 0)
    fatal("It is not possible to have the sexed subcommand for the observation with label " + this->label + " set to True, "
    "while the command @sex_partition is set to False.");
  selectivity_name = e.get_string(command+"ogive","none");
  if (selectivity_name != "none" && !popn.annual_cycle->valid_selectivity(selectivity_name)){
          fatal("Bad selectivity " + selectivity_name + " for observation with label " + this->label);}
  if (popn.state.n_areas > 1){
          area = e.get_string(command+"area");
          if (!popn.state.valid_area(area)){
                  fatal("Bad area " + area + " for observations with label " + this->label);}
  } else area="";
  proportion_mortality = e.get_constant(command+"proportion_mortality",0.5);
  plus_group = e.get_bool(command+"plus_group",0);
  this->do_bootstrap = e.get_bool(command+"do_bootstrap",1);

  //
  // A great big pile of error checks on the subcommands class_nums, class_nums_male, class_nums_female
  //

  int p_cn =  e.present(command+"class_nums");
  int p_cnm = e.present(command+"class_nums_male");
  int p_cnf = e.present(command+"class_nums_female");

  if( (p_cnm && ! p_cnf) || (p_cnf && !p_cnm) )
    fatal("For proportions_at[" + _label + "], you should use both class_nums_male and class_nums_female in a sexed model");
  if(sexed && p_cn)
    fatal("For proportions_at[" + _label + "], you should use class_nums_male and class_nums_female in a sexed model (not class_nums)");
  if(!sexed && (p_cnm || p_cnf) )
    fatal("For proportions_at[" + _label + "], you should use class_nums in a non-sexed model (not class_nums_male/class_nums_female)");
  if ( !popn.state.size_based && (p_cn || p_cnm) )
    fatal("For proportions_at[" + _label + "], you can only use the subcommands class_nums, class_nums_male, class_nums_female in a size-based model.");

  if(p_cn){
    for(int i=1; i<=class_nums.size(); i++){
       if( fabs( floor(class_nums[i]) - class_nums[i] ) > 1e-8 )
         fatal("For proportions_at[" + _label + "], entries for class_nums should be integers");
    }
    for(int i=1; i<=class_nums.size()-1; i++){
       if ( class_nums[i+1] <= class_nums[i] )
         fatal("For proportions_at[" + _label + "], entries for class_nums should increase from left to right");
    }
  }
  if(p_cnm){
    for(int i=1; i<=class_nums_male.size(); i++){
       if( fabs( floor(class_nums_male[i]) - class_nums_male[i] ) > 1e-8 )
         fatal("For proportions_at[" + _label + "], entries for class_nums_male should be integers");
    }
    for(int i=1; i<=class_nums_male.size()-1; i++){
       if ( class_nums_male[i+1] <= class_nums_male[i] )
         fatal("For proportions_at[" + _label + "], entries for class_nums_male should increase from left to right");
    }
  }
  if(p_cnf){
    for(int i=1; i<=class_nums_female.size(); i++){
       if( fabs( floor(class_nums_female[i]) - class_nums_female[i] ) > 1e-8 )
         fatal("For proportions_at[" + _label + "], entries for class_nums_female should be integers");
    }
    for(int i=1; i<=class_nums_female.size()-1; i++){
       if ( class_nums_female[i+1] <= class_nums_female[i] )
         fatal("For proportions_at[" + _label + "], entries for class_nums_female should increase from left to right");
    }
  }

  if(popn.state.size_based){
    int max_classes = popn.state.col_max;
    if(p_cn){
      if (max(class_nums) > max_classes){
        fatal("For proportions_at[" + _label + "], one of your classes in class_nums exceeds the maximum class number: "  + itos(max_classes));
      }
    }
    if(p_cnm){
      if (max(class_nums_male) > max_classes){
        fatal("For proportions_at[" + _label + "], one of your classes in class_nums_male exceeds the maximum class number: "  + itos(max_classes));
      }
    }
    if(p_cnf){
      if (max(class_nums_female) > max_classes){
        fatal("For proportions_at[" + _label + "], one of your classes in class_nums_female exceeds the maximum class number: "  + itos(max_classes));
      }
    }
  }

 if(e.present(command+"min_class") && (p_cn || p_cnm) ){
    fatal("For proportions_at[" + _label + "], you can't have both min_class/max_class and class_nums/class_nums_male/class_num_females "
    "as subcommands");
  }

  // Now that most error checks have finished, start setting up some variables

  if (e.present(command+"min_class")){
    //if(!popn.state.size_based && at_size)
    //  fatal("For proportions_at[" + _label + "], you cannot specify min_class/max_class for a size-based observation in an age-based model");
    if (e.get_constant_vector(command+"min_class").size()!=min_class.size()){
      fatal("Wrong size for argument " + command + "min_class - should be " + itos(min_class.size()) ); }
    min_class = e.get_constant_vector(command+"min_class");
    if(!(!popn.state.size_based && at_size) && min(min_class) < popn.state.col_min)
      fatal("For proportions_at[" + _label + "], an element of min_class is less than the number of the lowest partition age/size class.");
  }
  else if (class_mins.size()!=1)
    min_class = 1;
  else if (p_cn || p_cnm || p_cnf )
    min_class = -99;  // value not needed
  else
    min_class = popn.state.col_min;

  if (e.present(command+"max_class")){
    if (e.get_constant_vector(command+"max_class").size()!=max_class.size()){
      fatal("Wrong size for argument " + command + "max_class - should be " + itos(max_class.size())); }
    max_class = e.get_constant_vector(command+"max_class");
    if(e.present(command+"class_mins")){
          int number_of_classes = class_mins.size() - (plus_group ? 0 : 1);
          if (max(max_class) > number_of_classes){
            fatal("For proportions_at[" + _label + "] an element of max_class is greater than the number of "
            "classes defined by class_mins(" + itos(number_of_classes) + ").");
          }
        } else {
          if (max(max_class) > popn.state.col_max){
                  fatal("For proportions_at[" + _label + "] an element of max_class is greater than the number of the highest partition age/size class.");
          }
        }
  }
  else if (class_mins.size()!=1)
    max_class = class_mins.size() - (plus_group ? 0 : 1);
  else if (p_cn || p_cnm || p_cnf )
    max_class = -99;   // value not needed
  else
    max_class = popn.state.col_max;

  if( e.present(command+"class_nums") )
    n_classes = class_nums.size() - (plus_group ? 0 : 1);
  else if (p_cnm && p_cnf){
    n_classes[1] = class_nums_male.size() - (plus_group ? 0 : 1);
    n_classes[2] = class_nums_female.size() - (plus_group ? 0 : 1);
  }
  else
    n_classes = max_class - min_class + 1;

  obs_per_year = (int) sum(n_classes);
  this->fits = new MATRIX(1,n_years,1,obs_per_year);
  this->obs = new MATRIX(1,n_years,1,obs_per_year);
  sum_to_one = e.get_bool(command+"sum_to_one",1);
  if (e.get_string("ageing_error.type","none")=="none") ageing_error = 0;
  else ageing_error = e.get_bool(command+"ageing_error",!at_size);
  if (at_size && ageing_error) fatal("Proportions-at-size " + this->label + " requested ageing error");
  if (ageing_error) ageing_error_ptr = _ageing_error_ptr;
  if (e.present(command+"q")){
    fatal("have found " + command + "q - surely proportions-at should not have a q?");}
  if (pseudo){
    this->obs->initialize();
    this->objective = 0;
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->final){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for pseudo-observation " + command);
    }
  }
  else {
    for (int y=1; y<=this->n_years; y++){
      double year = (*(this->years))[y];
      if (e.get_constant_vector(command+dtos(year)).size() != obs_per_year){
        if(class_nums.size()==1 && class_nums_male.size()==1 && class_nums_female.size()==1){
          fatal("Wrong number of observations for year " + dtos(year) + " of " + this->label + ": should be " +
          itos(obs_per_year) + ". You may have omitted or misspecified the min_class, max_class and/or class_mins arguments.\n");
        }
        else{
          fatal("Wrong number of observations for year " + dtos(year) + " of " + this->label + ": should be " +
          itos(obs_per_year) +
          ". You may have omitted or misspecified the class_nums, class_nums_male, class_nums_female arguments.\n");
        }
      }
      (*(this->obs))[y] = e.get_constant_vector(command+dtos(year));
      if (sum_to_one && (sum((*(this->obs))[y])<0.99 || sum((*(this->obs))[y])>1.01)){
        cout << "Observations don't sum to 1 for year " << year << " of proportions-at observation " << this->label << '\n';
        (*(this->obs))[y] /= sum((*(this->obs))[y]);
      }
    }
    this->objective = make_objective<DVM>(e,command,*(this->years),obs_per_year,this->label);
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->current){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for observation " + command);
    }
  }
}

template<CDVM>
void Catch_at<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  // put entries into the Parameter_set to tell the population section what results to return
  // we ask for catch numbers, then Catch_at::calculate_fits converts them to proportions
  // Note that for an age-based model we ask for numbers in all age classes,
  //  which we may need for ageing error.
  DEBUG1("Catch_at::set_request_parameters");
  std::string popn_command = "catch_at[" + this->label + "].";
  p.put_vector_of_strings(popn_command+"fishery",fishery);
  p.put_constant_vector(popn_command+"years",*(this->years));
  p.put_int(popn_command+"sexed",sexed);
  p.put_int(popn_command+"at_size",at_size);
  if (class_mins.size()!=1){
    if (!sum_to_one){
      // This is a size-based observation in an age-based model, and the proportions-at-size are
      // not constrained to sum to 1. We need to add in minus and plus groups, so that we can figure
      // the denominator of the proportions-at-size.
      dvector temp_class_mins(class_mins.size()+1);
      temp_class_mins[1]=0;
      for (int i=1; i<=class_mins.size(); i++){
        temp_class_mins[i+1] = class_mins[i];
      }
      p.put_constant_vector(popn_command+"class_mins",temp_class_mins);
      p.put_int(popn_command+"plus_group",1);
    }
    else {
      p.put_constant_vector(popn_command+"class_mins",class_mins);
      p.put_int(popn_command+"plus_group",plus_group);
    }
  }
  else if (class_nums.size()!=1){
    p.put_constant_vector(popn_command+"class_nums",class_nums);
    p.put_int(popn_command+"plus_group",plus_group);
  }
  else if (class_nums_male.size()!=1 && class_nums_female.size()!=1){
    p.put_constant_vector(popn_command+"class_nums_male",class_nums_male);
    p.put_constant_vector(popn_command+"class_nums_female",class_nums_female);
    p.put_int(popn_command+"plus_group",plus_group);
  }
}

template<CDVM>
void Catch_at<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // extract the catch numbers-at from popn.results
  DEBUG1("Catch_at::calculate_fits");
  int max_class_in_result, col_in_fits;
  dvector _min_class(min_class);
  dvector _max_class(max_class);
  MATRIX* result;

  if (!sum_to_one && class_mins.size()!=1){
    // We have inserted a minus group, which is the new size class 1.
    // (See set_request_parameters)
    // We need to adjust min_class, max_class accordingly.
    _min_class = _min_class+1;
    _max_class = _max_class+1;
  }

  for (int y=1; y<=this->n_years; y++){
        if (!in(popn.results.catch_at[this->label],(int)((*(this->years))[y]))) continue;
    result = new MATRIX(popn.results.catch_at[this->label][(int)((*(this->years))[y])]);
    if (ageing_error){
      if (ageing_error_ptr->ageing_error) ageing_error_ptr->apply(*result);}
    max_class_in_result = result->colmax();

    // extract results
    // unsexed then sex_index = 1 = male and female
    // sexed   then sex_index = 1 = male, sex_index = 2 = female)
    // if sexed then the fits for the female are put as entries directly after the fits for the males
    if(class_nums.size() == 1 && class_nums_male.size() == 1){    // default entry is the element -1
        for(int sex_index = 1; sex_index<=1+sexed; sex_index++){
          for (int i=int(_min_class[sex_index]); i<=int(_max_class[sex_index]); i++){
            col_in_fits = int(i-_min_class[sex_index]+1);
            if(sex_index == 2) col_in_fits += (int)n_classes[1];  // store female after male results
            (*(this->fits))[y][col_in_fits] = (*result)[sex_index][i];
          }
          if (plus_group){
            for (int i=int(_max_class[sex_index]+1); i<=max_class_in_result; i++){
              (*(this->fits))[y][col_in_fits] += (*result)[sex_index][i];
            }
          }
        }


    }
    else {  // class_nums or  class_nums_male and class_nums_female  subcommands used
        if(!sexed){     // class_nums used
          for (int i = 1; i<=class_nums.size()-1 ; i++){
            (*(this->fits))[y][i] = 0;
            for (int j = (int)class_nums[i]; j<=(int)class_nums[i+1]-1; j++){
                (*(this->fits))[y][i]  += (*result)[1][j];
            }
          }
          if (plus_group){
            int end_index = class_nums.size();
            (*(this->fits))[y][end_index] = 0;
            for (int j = (int)class_nums[end_index]; j<=max_class_in_result; j++){
              (*(this->fits))[y][end_index] += (*result)[1][j];
            }
          }
        }
        else{   // class_nums_male and class_nums_female used
          // male fits
          for (int i = 1; i<=class_nums_male.size()-1 ; i++){
             (*(this->fits))[y][i] = 0;
             for (int j = (int)class_nums_male[i]; j<=(int)class_nums_male[i+1]-1; j++){
                 (*(this->fits))[y][i]  += (*result)[1][j];
             }
          }
          if(plus_group){
            int end_index = class_nums_male.size();
            (*(this->fits))[y][end_index] = 0;
            for (int j = (int)class_nums_male[end_index]; j<=max_class_in_result; j++){
              (*(this->fits))[y][end_index] += (*result)[1][j];
            }
          }
          // female fits
          for (int i = 1; i<=class_nums_female.size()-1 ; i++){
             int col_in_fits = i + (int)n_classes[1];
             (*(this->fits))[y][col_in_fits] = 0;
             for (int j = (int)class_nums_female[i]; j<=(int)class_nums_female[i+1]-1; j++){
                 (*(this->fits))[y][col_in_fits]  += (*result)[2][j];
             }
          }
          if(plus_group){
            int end_index = class_nums_female.size() + (int)n_classes[1];
            (*(this->fits))[y][end_index] = 0;
            for (int j = (int)class_nums_female[class_nums_female.size()]; j<=max_class_in_result; j++){
              (*(this->fits))[y][end_index] += (*result)[2][j];
            }
          }

        }

    }    // end of else for using class_nums or class_nums_male and class_nums_female

    delete result;

  }   // end of loop over years


  // convert from numbers to proportions
  DOUBLE denominator;
  for (int y=1; y<=this->n_years; y++){
    if (sum_to_one){
      denominator = sum((*(this->fits))[y]);
    } else {
      if (sexed){
        denominator = sum(popn.results.catch_at[this->label][(int)((*(this->years))[y])][1]) +
                      sum(popn.results.catch_at[this->label][(int)((*(this->years))[y])][2]);
      } else {
        denominator = sum(popn.results.catch_at[this->label][(int)((*(this->years))[y])][1]);
      }
    }
    if(denominator>0) (*(this->fits))[y] /= denominator; // if sum(fits)==0, then don't divide by zero, just return the fits (which should all equal zero)
    //(*(this->fits))[y] /= denominator;
  }
}

template<CDVM>
void Catch_at<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Catch_at::write_to_file");
  o << "@catch_at " << this->label << '\n';
  o << "# simulated observations\n";
  std::string command = "catch_at["+this->label+"].";
  Parameter_set<DVM> obs_pars;
  e.extract_subcommands_of_command(obs_pars,"catch_at",this->label);
  // but we have to overwrite the original obs. with the simulated observations
  for (int y=this->obs->rowmin(); y<=this->obs->rowmax(); y++){
     obs_pars.put_constant_vector(command+itos((int)(*(this->years))[y]),value((*(this->obs))[y]));
  }
  obs_pars.dump_as_subcommands(o);
}

template<CDVM>
void Catch_at<DVM>::print(ostream& out, int print_fits, int print_resids,
                                              int print_pearson_resids, int print_normalised_resids){
  DEBUG2("Catch_at::print");
  out << "catch proportions-at-" << (at_size ? "size" : "age") << (sexed ? " by sex" : "") <<
   " for " << ((fishery.size()==1) ? "fishery " : "fisheries ") << fishery <<
   (ageing_error ? " with ageing error" : "") << " (" << (sum_to_one ? "" : "not ") << "constrained to sum to 1):\n";
  print_header(out,"obs");
  for (int y=1; y<=this->n_years; y++){
    out << (*(this->years))[y] << " ";
    for (int i=1; i<=this->obs_per_year; i++){
      out << setw(7) << (*(this->obs))[y][i] << " ";
    }
    out << '\n';
  }
  if (print_fits){
    print_header(out,"fits");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << (*(this->fits))[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_resids){
    MATRIX resids(this->get_resids());
    print_header(out,"resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_pearson_resids){
    MATRIX pearson_resids(this->get_pearson_resids());
    print_header(out,"pearson_resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << pearson_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_normalised_resids && this->objective->normalised_resids_defined()){
    MATRIX normalised_resids(this->get_normalised_resids());
    print_header(out,"normalised_resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << normalised_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  out << "objective function: ";
  this->objective->print(out);
  out << '\n';
}

template<CDVM>
void Catch_at<DVM>::print_header(ostream& out, const std::string& what_it_is){
  // called repeatedly by print()
  DEBUG2("Catch_at::print_header");
  out << setprecision(6);
  if (sexed){
    if( class_nums_male.size()!= 1 && class_nums_female.size()!=1 && !plus_group )
       out << what_it_is << " (male then female: last class is upper bound for last bin, "
       "but does not include this value)"  << ":\nclass ";
    else{
       out << what_it_is << " (male then female" << (plus_group ? " : last class is a plus group" : "") << "):\nclass ";
    }
    if (class_mins.size()!=1){
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << "M" << class_mins[i] << " ";}
      for (int i=int(min_class[2]); i<=int(max_class[2]); i++){
        out << "F" << class_mins[i] << " ";}
    }
    else if (class_nums_male.size()!=1 && class_nums_female.size()!= 1){
      for (int i=1; i<=class_nums_male.size(); i++){
        out << "M" << class_nums_male[i]  << " ";}
      for (int i=1; i<=class_nums_female.size(); i++){
        out << "F" << class_nums_female[i] << " ";}
    }
    else {
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << "M" << i << " ";}
      for (int i=int(min_class[2]); i<=int(max_class[2]); i++){
        out << "F" << i << " ";}
    }
  }

  else {   // non-sexed
    if(class_nums.size()!=1)
      out << what_it_is << " (last class is upper bound for last bin, but does not include this value)"  << ":\nclass ";
    else{
      out << what_it_is << (plus_group ? " (last class is a plus group)" : "") << ":\nclass ";
    }
    if (class_mins.size()!=1){
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << setw(7) << class_mins[i] << " ";}
    }
    else if (class_nums.size()!=1){
      for (int i=1; i<=class_nums.size(); i++){
        out << setw(7) << class_nums[i] << " ";}
    }
    else {
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << setw(7) << i << " ";}
    }
  }
  out << '\n';
}

template<CDVM>
Catch_at<DVM>::Catch_at(Basic_population_section<DVM>& popn,
                                            Parameter_set<DVM>& e,
                                            const std::string& _label,
                                            Ageing_error<DVM>* _ageing_error_ptr, int pseudo)
  : command("catch_at[" + _label + "].")
  , n_classes(1+e.get_bool(command+"sexed",popn.state.sex_partition))
  , min_class(1+e.get_bool(command+"sexed",popn.state.sex_partition))
  , max_class(1+e.get_bool(command+"sexed",popn.state.sex_partition))
  , class_nums(e.get_constant_vector(command+"class_nums",dvector("{-1}")))
  , class_nums_male(e.get_constant_vector(command+"class_nums_male",dvector("{-1}")))
  , class_nums_female(e.get_constant_vector(command+"class_nums_female",dvector("{-1}")))
  , class_mins(e.get_constant_vector(command+"class_mins",dvector("{-1}"))){
  // Construct the Catch_at observation from the Parameter_set,
  // extracting any other necessary information from the Population_section
  DEBUG1("Catch_at::Catch_at");
  this->label = _label;
  fishery = e.get_vector_of_strings(command+"fishery");
  for (int i=0; i<fishery.size(); i++){
          if (!popn.annual_cycle->valid_fishery(fishery[i])){
                  fatal("You have used an invalid fishery label " + fishery[i] + " in the observations labelled " + this->label);}
  }
  this->years = new dvector(e.get_constant_vector(command+"years"));
  n_years = this->years->size();
  at_size = e.get_bool(command+"at_size",popn.state.size_based);
  if (!at_size && e.present(command+"class_mins")){
          fatal("You can't specify class_mins for at-age observations");}
  if (popn.state.size_based && e.present(command+"class_mins")){
          fatal("You can't specify class_mins in an observations block in a size-based model - must use same size classes as in population data file");}
  sexed = e.get_bool(command+"sexed",popn.state.sex_partition);
  if(sexed == 1 && popn.state.sex_partition == 0)
    fatal("It is not possible to have the sexed subcommand for the observation with label " + this->label + " set to True, "
    "while the command @sex_partition is set to False.");
  plus_group = e.get_bool(command+"plus_group",0);
  this->do_bootstrap = e.get_bool(command+"do_bootstrap",1);

  //
  // A great big pile of error checks on the subcommands class_nums, class_nums_male, class_nums_female
  //

  int p_cn =  e.present(command+"class_nums");
  int p_cnm = e.present(command+"class_nums_male");
  int p_cnf = e.present(command+"class_nums_female");

  if( (p_cnm && ! p_cnf) || (p_cnf && !p_cnm) )
    fatal("You should use both class_nums_male and class_nums_female in a sexed model");
  if(sexed && p_cn)
    fatal("You should use class_nums_male and class_nums_female in a sexed model (not class_nums)");
  if(!sexed && (p_cnm || p_cnf) )
    fatal("You should use class_nums in a non-sexed model (not class_nums_male/class_nums_female)");
  if ( !popn.state.size_based && (p_cn || p_cnm) )
    fatal("You can only use the subcommands class_nums, class_nums_male, class_nums_female in a size-based model.");

  if(p_cn){
    for(int i=1; i<=class_nums.size(); i++){
       if( fabs( floor(class_nums[i]) - class_nums[i] ) > 1e-8 )
         fatal("Entries for class_nums should be integers");
    }
    for(int i=1; i<=class_nums.size()-1; i++){
       if ( class_nums[i+1] <= class_nums[i] )
         fatal("Entries for class_nums should increase from left to right");
    }
  }
  if(p_cnm){
    for(int i=1; i<=class_nums_male.size(); i++){
       if( fabs( floor(class_nums_male[i]) - class_nums_male[i] ) > 1e-8 )
         fatal("Entries for class_nums_male should be integers");
    }
    for(int i=1; i<=class_nums_male.size()-1; i++){
       if ( class_nums_male[i+1] <= class_nums_male[i] )
         fatal("Entries for class_nums_male should increase from left to right");
    }
  }
  if(p_cnf){
    for(int i=1; i<=class_nums_female.size(); i++){
       if( fabs( floor(class_nums_female[i]) - class_nums_female[i] ) > 1e-8 )
         fatal("Entries for class_nums_female should be integers");
    }
    for(int i=1; i<=class_nums_female.size()-1; i++){
       if ( class_nums_female[i+1] <= class_nums_female[i] )
         fatal("Entries for class_nums_female should increase from left to right");
    }
  }

  if(popn.state.size_based){
    int max_classes = popn.state.col_max;
    if(p_cn){
      if (max(class_nums) > max_classes){
        fatal("One of your classes in class_nums exceeds the maximum class number: "  + itos(max_classes));
      }
    }
    if(p_cnm){
      if (max(class_nums_male) > max_classes){
        fatal("One of your classes in class_nums_male exceeds the maximum class number: "  + itos(max_classes));
      }
    }
    if(p_cnf){
      if (max(class_nums_female) > max_classes){
        fatal("One of your classes in class_nums_female exceeds the maximum class number: "  + itos(max_classes));
      }
    }
  }

  if(e.present(command+"min_class") && (p_cn || p_cnm) ){
    fatal("You can't have both min_class/max_class and class_nums/class_nums_male/class_num_females "
    "as subcommands for @proportions");
  }

  // Now that most error checks have finished, start setting up some variables

  if (e.present(command+"min_class")){
    if (e.get_constant_vector(command+"min_class").size()!=min_class.size()){
      fatal("Wrong size for argument " + command + "min_class - should be " + itos(min_class.size()));}
    min_class = e.get_constant_vector(command+"min_class");
    if(!(!popn.state.size_based && at_size) && min(min_class) < popn.state.col_min)
      fatal("For catch_at[" + _label + "] an element of min_class is less than the number of the lowest partition age/size class.");
  }
  else if (class_mins.size()!=1)
    min_class = 1;
  else if (p_cn || p_cnm || p_cnf )
    min_class = -99;  // value not needed
  else
    min_class = popn.state.col_min;

  if (e.present(command+"max_class")){
    if (e.get_constant_vector(command+"max_class").size()!=max_class.size()){
      fatal("Wrong size for argument " + command + "max_class - should be " + itos(max_class.size()));}
    max_class = e.get_constant_vector(command+"max_class");
    if(e.present(command+"class_mins"))
        {
          int number_of_classes = class_mins.size() - (plus_group ? 0 : 1);
          if (max(max_class) > number_of_classes)
          {
            fatal("For catch_at[" + _label + "] an element of max_class is greater than the number of "
            "classes defined by class_mins(" + itos(number_of_classes) + ").");
          }
        } else {
          if (max(max_class) > popn.state.col_max){
                  fatal("For catch_at[" + _label + "] an element of max_class is greater than the number of the highest partition age/size class.");
          }
        }
  }
  else if (class_mins.size()!=1){
    max_class = class_mins.size() - (plus_group ? 0 : 1);
  }
  else if (p_cn || p_cnm || p_cnf )
    max_class = -99;   // value not needed
  else
    max_class = popn.state.col_max;

  if( e.present(command+"class_nums") )
    n_classes = class_nums.size() - (plus_group ? 0 : 1);
  else if (p_cnm && p_cnf){
    n_classes[1] = class_nums_male.size() - (plus_group ? 0 : 1);
    n_classes[2] = class_nums_female.size() - (plus_group ? 0 : 1);
  }
  else
    n_classes = max_class - min_class + 1;

  obs_per_year = (int)sum(n_classes);
  this->fits = new MATRIX(1,n_years,1,obs_per_year);
  this->obs = new MATRIX(1,n_years,1,obs_per_year);
  sum_to_one = e.get_bool(command+"sum_to_one",1);
  if (e.get_string("ageing_error.type","none")=="none") ageing_error = 0;
  else ageing_error = e.get_bool(command+"ageing_error",!at_size);
  if (at_size && ageing_error) fatal("Catch-at-size " + this->label + " requested ageing error");
  if (ageing_error) ageing_error_ptr = _ageing_error_ptr;
  if (pseudo){
    this->obs->initialize();
    this->objective = 0;
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->final){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for pseudo-observation " + command);
    }
  } else {
    for (int y=1; y<=this->n_years; y++){
      double year = (*(this->years))[y];
      if (e.get_constant_vector(command+dtos(year)).size() != obs_per_year){
        if(class_nums.size()==1 && class_nums_male.size()==1 && class_nums_female.size()==1){
          fatal("Wrong number of observations for year " + dtos(year) + " of " + this->label + ": should be " +
          itos(obs_per_year) + ". You may have omitted or misspecified the min_class, max_class and/or class_mins arguments.\n");
        }
        else{
          fatal("Wrong number of observations for year " + dtos(year) + " of " + this->label + ": should be " +
          itos(obs_per_year) +
          ". You may have omitted or misspecified the class_nums, class_nums_male, class_nums_female arguments.\n");
        }
      }
      (*(this->obs))[y] = e.get_constant_vector(command+dtos(year));
      if (sum_to_one && (sum((*(this->obs))[y])<0.99 || sum((*(this->obs))[y])>1.01)){
        cout << "Observations don't sum to 1 for year " << year << " of catch_at observation " << this->label << '\n';
        (*(this->obs))[y] /= sum((*(this->obs))[y]);
      }
    }
    this->objective = make_objective<DVM>(e,command,*(this->years),obs_per_year,this->label);
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->current){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for observation " + command);
    }
  }
}

template<CDVM>
void Proportions_mature<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  // Put entries into the Parameter_set to tell the population section what results to return.
  // Ask for numbers-at and mature-numbers-at results,
  //  which will be used to calculate proportions mature.
  // Note that for an age-based model we ask for mature and total numbers in all age classes,
  //  which we may need for ageing error.
  DEBUG1("Proportions_mature::set_request_parameters");
  // first put in a request for numbers-at
  std::string popn_command = "numbers_at[" + this->label + "_total].";
  p.put_constant_vector(popn_command+"years",*(this->years));
  p.put_int(popn_command+"step",step);
  p.put_int(popn_command+"sexed",sexed);
  p.put_int(popn_command+"at_size",at_size);
  p.put_constant(popn_command+"proportion_mortality",proportion_mortality);
  if (area != "") p.put_string(popn_command+"area",area);
  if (class_mins.size()!=1){
    p.put_constant_vector(popn_command+"class_mins",class_mins);
    p.put_int(popn_command+"plus_group",plus_group);
  }
  if (selectivity_name != "none") p.put_string(popn_command+"ogive",selectivity_name);
  // second put in a request for mature numbers_at
  popn_command = "numbers_at[" + this->label + "_mature].";
  p.put_int(popn_command+"mature_only",1);
  p.put_constant_vector(popn_command+"years",*(this->years));
  p.put_int(popn_command+"step",step);
  p.put_int(popn_command+"sexed",sexed);
  p.put_int(popn_command+"at_size",at_size);
  p.put_constant(popn_command+"proportion_mortality",proportion_mortality);
  if (area != "") p.put_string(popn_command+"area",area);
  if (class_mins.size()!=1){
    p.put_constant_vector(popn_command+"class_mins",class_mins);
    p.put_int(popn_command+"plus_group",plus_group);
  }
  if (selectivity_name != "none") p.put_string(popn_command+"ogive",selectivity_name);
}

template<CDVM>
void Proportions_mature<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // -extract the numbers, mature and total, from popn.results
  // -use them to calculate proportions mature
  DEBUG1("Proportions_mature::calculate_fits");
  int max_class_in_result, col_in_fits;
  MATRIX *total_result, *mature_result;
  VECTOR *total_temp, *mature_temp;
  total_temp = new VECTOR(1,obs_per_year);
  mature_temp = new VECTOR(1,obs_per_year);
  for (int y=1; y<=this->n_years; y++){
        if (!in(popn.results.numbers_at[this->label+"_total"],(int)((*(this->years))[y]))) continue;
    total_result = new MATRIX(popn.results.numbers_at[this->label+"_total"][(int)((*(this->years))[y])]);
    mature_result = new MATRIX(popn.results.numbers_at[this->label+"_mature"][(int)((*(this->years))[y])]);
    total_temp->initialize();
    mature_temp->initialize();
    if (ageing_error){
      if (ageing_error_ptr->ageing_error){
        ageing_error_ptr->apply(*total_result);
        ageing_error_ptr->apply(*mature_result);
      }
    }
    max_class_in_result = total_result->colmax();
    if (!sexed){
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        col_in_fits = int(i-min_class[1]+1);
        (*total_temp)[col_in_fits] = (*total_result)[1][i];
        (*mature_temp)[col_in_fits] = (*mature_result)[1][i];
      }
      if (plus_group){
        for (int i=int(max_class[1]+1); i<=max_class_in_result; i++){
          (*total_temp)[col_in_fits] += (*total_result)[1][i];
          (*mature_temp)[col_in_fits] += (*mature_result)[1][i];
        }
      }
    } else if (!females_only){
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){  // extract male results
        col_in_fits = int(i-min_class[1]+1);
        (*total_temp)[col_in_fits] = (*total_result)[1][i];
        (*mature_temp)[col_in_fits] = (*mature_result)[1][i];
      }
      if (plus_group){
        for (int i=int(max_class[1]+1); i<=max_class_in_result; i++){
          (*total_temp)[col_in_fits] += (*total_result)[1][i];
          (*mature_temp)[col_in_fits] += (*mature_result)[1][i];
        }
      }
      for (int i=int(min_class[2]); i<=int(max_class[2]); i++){  // extract female results
        col_in_fits = int(i-min_class[2]+1+n_classes[1]);
        (*total_temp)[col_in_fits] = (*total_result)[2][i];
        (*mature_temp)[col_in_fits] = (*mature_result)[2][i];
      }
      if (plus_group){
        for (int i=int(max_class[2]+1); i<=max_class_in_result; i++){
          (*total_temp)[col_in_fits] += (*total_result)[2][i];
          (*mature_temp)[col_in_fits] += (*mature_result)[2][i];
        }
      }
    } else {  // female observations only
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        col_in_fits = int(i-min_class[1]+1);
        (*total_temp)[col_in_fits] = (*total_result)[2][i];
        (*mature_temp)[col_in_fits] = (*mature_result)[2][i];
      }
      if (plus_group){
        for (int i=int(max_class[1]+1); i<=max_class_in_result; i++){
          (*total_temp)[col_in_fits] += (*total_result)[2][i];
          (*mature_temp)[col_in_fits] += (*mature_result)[2][i];
        }
      }
    }
    for (int i=1; i<=this->obs_per_year; i++){
      if ((*total_temp)[i]>0){
        (*(this->fits))[y][i] = (*mature_temp)[i] / (*total_temp)[i];
      } else {
        (*(this->fits))[y][i] = 0;
      }
    }
    delete total_result;
    delete mature_result;
  }
  delete total_temp;
  delete mature_temp;
}

template<CDVM>
void Proportions_mature<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Proportions_mature::write_to_file");
  o << "@proportions_mature " << this->label << '\n';
  o << "# simulated observations\n";
  std::string command = "proportions_mature["+this->label+"].";
  Parameter_set<DVM> obs_pars;
  e.extract_subcommands_of_command(obs_pars,"proportions_mature",this->label);
  // but we have to overwrite the original obs. with the simulated observations
  for (int y=this->obs->rowmin(); y<=this->obs->rowmax(); y++){
     obs_pars.put_constant_vector(command+itos((int)(*(this->years))[y]),value((*(this->obs))[y]));
  }
  obs_pars.dump_as_subcommands(o);
}

template<CDVM>
void Proportions_mature<DVM>::print(ostream& out, int print_fits, int print_resids,
                                                  int print_pearson_resids, int print_normalised_resids){
  DEBUG2("Proportions_mature::print");
  out << "proportions-mature at-" << (at_size ? "size" : "age") << (sexed ? (females_only ? " (females only)" : "(sexed)") : "(unsexed)") << " in time step " << step << ((proportion_mortality!=0.5) ? (" after proportion " + dtos(proportion_mortality) + " of mortality") : "") << ((area!="") ? (" in area " + area) : "") << ((selectivity_name!="none") ? (" using selectivity " + selectivity_name) : "") << (ageing_error ? " with ageing error" : "") << '\n';
  print_header(out,"obs");
  for (int y=1; y<=this->n_years; y++){
    out << (*(this->years))[y] << " ";
    for (int i=1; i<=this->obs_per_year; i++){
      out << setw(7) << (*(this->obs))[y][i] << " ";
    }
    out << '\n';
  }
  if (print_fits){
    print_header(out,"fits");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << (*(this->fits))[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_resids){
    MATRIX resids(this->get_resids());
    print_header(out,"resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_pearson_resids){
    MATRIX pearson_resids(this->get_pearson_resids());
    print_header(out,"pearson_resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << pearson_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_normalised_resids && this->objective->normalised_resids_defined()){
    MATRIX normalised_resids(this->get_normalised_resids());
    print_header(out,"normalised_resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << normalised_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  out << "objective function: ";
  this->objective->print(out);
  out << '\n';
}

template<CDVM>
void Proportions_mature<DVM>::print_header(ostream& out, const std::string& what_it_is){
  // called repeatedly by print()
  DEBUG2("Proportions_mature::print_header");
  out << setprecision(6);
  if (!sexed){
    out << what_it_is << (plus_group ? " (last class is a plus group)" : "") << ":\nclass ";
    if (class_mins.size()!=1){
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << setw(7) << class_mins[i] << " ";}
    } else {
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << setw(7) << i << " ";}
    }
  } else if (!females_only){
    out << what_it_is << " (male then female" << (plus_group ? " : last class is a plus group" : "") <<"):\nclass ";
    if (class_mins.size()!=1){
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << "M" << class_mins[i] << " ";}
      for (int i=int(min_class[2]); i<=int(max_class[2]); i++){
        out << "F" << class_mins[i] << " ";}
    } else {
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << "M" << i << " ";}
      for (int i=int(min_class[2]); i<=int(max_class[2]); i++){
        out << "F" << i << " ";}
    }
  } else {
    out << what_it_is << (plus_group ? " (last class is a plus group)" : "") << ":\nclass ";
    if (class_mins.size()!=1){
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << setw(7) << class_mins[i] << " ";}
    } else {
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        out << setw(7) << i << " ";}
    }
  }
  out << '\n';
}

template<CDVM>
Proportions_mature<DVM>::Proportions_mature(Basic_population_section<DVM>& popn,
                                                Parameter_set<DVM>& e,
                                                const std::string& _label,
                                                Ageing_error<DVM>* _ageing_error_ptr, int pseudo)
  : command("proportions_mature[" + _label + "].")
  , n_classes(2-(!e.get_bool(command+"sexed",popn.state.sex_partition) || e.get_bool(command+"females_only",0)))
  , min_class(2-(!e.get_bool(command+"sexed",popn.state.sex_partition) || e.get_bool(command+"females_only",0)))
  , max_class(2-(!e.get_bool(command+"sexed",popn.state.sex_partition) || e.get_bool(command+"females_only",0)))
  , class_mins(e.get_constant_vector(command+"class_mins",dvector("{-1}"))){
  // Construct the Proportions_mature observation from the Parameter_set,
  // extracting any other necessary information from the Population_section (e.g. n_areas etc)
  DEBUG1("Proportions_mature::Proportions_mature");
  this->label = _label;
  this->years = new dvector(e.get_constant_vector(command+"years"));
  n_years = this->years->size();
  at_size = e.get_bool(command+"at_size",popn.state.size_based);
  if (!at_size && e.present(command+"class_mins")){
          fatal("You can't specify class_mins for at-age observations");}
  if (popn.state.size_based && e.present(command+"class_mins")){
          fatal("You can't specify class_mins in an observations block in a size-based model - must use same size classes as in population data file");}
  step = e.get_int(command+"step");
  if (!popn.annual_cycle->valid_step(step)){
          fatal("Bad time step " + itos(step) + " for observation with label " + this->label);}
  sexed = e.get_bool(command+"sexed",popn.state.sex_partition);
  if (sexed && !popn.state.sex_partition){
          fatal("You have requested sexed proportions-mature observations in an unsexed model");}
  females_only = sexed && e.get_bool(command+"females_only",0);
  selectivity_name = e.get_string(command+"ogive","none");
  if (selectivity_name != "none" && !popn.annual_cycle->valid_selectivity(selectivity_name)){
          fatal("Bad selectivity " + selectivity_name + " for observation with label " + this->label);}
  if (popn.state.n_areas > 1){
          area = e.get_string(command+"area");
          if (!popn.state.valid_area(area)){
                  fatal("Bad area " + area + " for observations with label " + this->label);}
  } else area="";
  proportion_mortality = e.get_constant(command+"proportion_mortality",0.5);
  plus_group = e.get_bool(command+"plus_group",0);
  this->do_bootstrap = e.get_bool(command+"do_bootstrap",1);

  if (e.present(command+"min_class")){
    if (e.get_constant_vector(command+"min_class").size()!=min_class.size()){
      fatal("Wrong size for argument " + command + "min_class - should be " + itos(min_class.size()));}
    min_class = e.get_constant_vector(command+"min_class");
    if(!(!popn.state.size_based && at_size) && min(min_class) < popn.state.col_min)
      fatal("For proportion_mature[" + _label + "] an element of min_class is less than the number of the lowest partition age/size class.");
  } else if (class_mins.size()!=1){
    min_class = 1;
  } else {
    min_class = popn.state.col_min;
  }

  if (e.present(command+"max_class")){
    if (e.get_constant_vector(command+"max_class").size()!=max_class.size()){
      fatal("Wrong size for argument " + command + "max_class - should be " + itos(max_class.size()));}
    max_class = e.get_constant_vector(command+"max_class");
    if(e.present(command+"class_mins")){
          int number_of_classes = class_mins.size() - (plus_group ? 0 : 1);
          if (max(max_class) > number_of_classes){
            fatal("For proportions_mature[" + _label + "] an element of max_class is greater than the number of "
            "classes defined by class_mins(" + itos(number_of_classes) + ").");
          }
        } else {
          if (max(max_class) > popn.state.col_max){
                  fatal("For proportions_mature[" + _label + "] an element of max_class is greater than the number of the highest partition age/size class.");
          }
        }
  } else if (class_mins.size()!=1){
    max_class = class_mins.size() - (plus_group ? 0 : 1);
  } else {
    max_class = popn.state.col_max;
  }

  n_classes = max_class - min_class + 1;
  obs_per_year = (int)sum(n_classes);
  this->fits = new MATRIX(1,n_years,1,obs_per_year);
  this->obs = new MATRIX(1,n_years,1,obs_per_year);
  if (e.get_string("ageing_error.type","none")=="none") ageing_error = 0;
  else ageing_error = e.get_bool(command+"ageing_error",!at_size);
  if (at_size && ageing_error) fatal("Proportions-mature-at-size " + this->label + " requested ageing error");
  if (ageing_error) ageing_error_ptr = _ageing_error_ptr;
  if (pseudo){
    this->obs->initialize();
    this->objective = 0;
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->final){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for pseudo-observation " + command);
    }
  } else {
    for (int y=1; y<=this->n_years; y++){
      double year = (*(this->years))[y];
      if (e.get_constant_vector(command+dtos(year)).size() != obs_per_year){
        fatal("Wrong number of observations for year " + dtos(year) + " of " + this->label + ": should be " + itos(obs_per_year) + ". You may have omitted or misspecified the min_class, max_class and/or class_mins arguments.\n");}
      (*(this->obs))[y] = e.get_constant_vector(command+dtos(year));
    }
    this->objective = make_objective<DVM>(e,command,*(this->years),obs_per_year,this->label);
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->current){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for observation " + command);
    }
  }
}

template<CDVM>
void Proportions_migrating<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  // Put entries into the Parameter_set to tell the population section what results to return.
  // Ask for numbers-at results both before and after the migration.
  // Note that for an age-based model we ask for mature and total numbers in all age classes,
  //  which we may need for ageing error.
  DEBUG1("Proportions_migrating::set_request_parameters");
  // first put in a request for numbers-at before the migration
  std::string popn_command = "numbers_at[" + this->label + "_before].";
  p.put_constant_vector(popn_command+"years",*(this->years));
  p.put_int(popn_command+"before",1);
  p.put_string(popn_command+"migration",migration);
  p.put_int(popn_command+"sexed",sex!=0);
  p.put_int(popn_command+"at_size",at_size);
  if (class_mins.size()!=1){
    p.put_constant_vector(popn_command+"class_mins",class_mins);
    p.put_int(popn_command+"plus_group",plus_group);
  }
  if (selectivity_name != "none") p.put_string(popn_command+"ogive",selectivity_name);
  // second put in a request for numbers-at after the migration
  popn_command = "numbers_at[" + this->label + "_after].";
  p.put_constant_vector(popn_command+"years",*(this->years));
  p.put_int(popn_command+"after",1);
  p.put_string(popn_command+"migration",migration);
  p.put_int(popn_command+"sexed",sex!=0);
  p.put_int(popn_command+"at_size",at_size);
  if (class_mins.size()!=1){
    p.put_constant_vector(popn_command+"class_mins",class_mins);
    p.put_int(popn_command+"plus_group",plus_group);
  }
  if (selectivity_name != "none") p.put_string(popn_command+"ogive",selectivity_name);
}

template<CDVM>
void Proportions_migrating<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // -extract the numbers, before and after, from popn.results
  // -use them to calculate proportions migrating
  DEBUG1("Proportions_migrating::calculate_fits");
  int max_class_in_result, col_in_fits;
  MATRIX *before_result, *after_result;
  VECTOR *before_temp, *after_temp;
  before_temp = new VECTOR(1,obs_per_year);
  after_temp = new VECTOR(1,obs_per_year);
  for (int y=1; y<=this->n_years; y++){
        if (!in(popn.results.numbers_at[this->label+"_before"],(int)((*(this->years))[y]))) continue;
    before_result = new MATRIX(popn.results.numbers_at[this->label+"_before"][(int)((*(this->years))[y])]);
    after_result = new MATRIX(popn.results.numbers_at[this->label+"_after"][(int)((*(this->years))[y])]);
    before_temp->initialize();
    after_temp->initialize();
    if (ageing_error){
      if (ageing_error_ptr->ageing_error){
        ageing_error_ptr->apply(*before_result);
        ageing_error_ptr->apply(*after_result);
      }
    }
    max_class_in_result = before_result->colmax();
    int row=1;
    if (sex==2) row=2;
    for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
      col_in_fits = int(i-min_class[1]+1);
      (*before_temp)[col_in_fits] = (*before_result)[row][i];
      (*after_temp)[col_in_fits] = (*after_result)[row][i];
    }
    if (plus_group){
      for (int i=int(max_class[1]+1); i<=max_class_in_result; i++){
        (*before_temp)[col_in_fits] += (*before_result)[row][i];
        (*after_temp)[col_in_fits] += (*after_result)[row][i];
      }
    }
    for (int i=1; i<=this->obs_per_year; i++){
      if ((*before_temp)[i]>0){
        (*(this->fits))[y][i] = ((*before_temp)[i] - (*after_temp)[i]) / (*before_temp)[i];
      } else {
        (*(this->fits))[y][i] = 0;
      }
    }
    delete before_result;
    delete after_result;
  }
  delete before_temp;
  delete after_temp;
}

template<CDVM>
void Proportions_migrating<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Proportions_migrating::write_to_file");
  o << "@proportions_migrating " << this->label << '\n';
  o << "# simulated observations\n";
  std::string command = "proportions_migrating["+this->label+"].";
  Parameter_set<DVM> obs_pars;
  e.extract_subcommands_of_command(obs_pars,"proportions_migrating",this->label);
  // but we have to overwrite the original obs. with the simulated observations
  for (int y=this->obs->rowmin(); y<=this->obs->rowmax(); y++){
     obs_pars.put_constant_vector(command+itos((int)(*(this->years))[y]),value((*(this->obs))[y]));
  }
  obs_pars.dump_as_subcommands(o);
}

template<CDVM>
void Proportions_migrating<DVM>::print(ostream& out, int print_fits,
                                                           int print_resids, int print_pearson_resids,
                                                           int print_normalised_resids){
  DEBUG2("Proportions_migrating::print");
  out << "proportions at " << (at_size ? "size" : "age") << " of " << ((sex==0) ? "both sexes combined" : ((sex==1) ? "males" : "females")) << " migrating in migration " << migration << ((selectivity_name!="none") ? (" using selectivity " + selectivity_name) : "") << (ageing_error ? " with ageing error" : "") << '\n';
  print_header(out,"obs");
  for (int y=1; y<=this->n_years; y++){
    out << (*(this->years))[y] << " ";
    for (int i=1; i<=this->obs_per_year; i++){
      out << setw(7) << (*(this->obs))[y][i] << " ";
    }
    out << '\n';
  }
  if (print_fits){
    print_header(out,"fits");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << (*(this->fits))[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_resids){
    MATRIX resids(this->get_resids());
    print_header(out,"resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_pearson_resids){
    MATRIX pearson_resids(this->get_pearson_resids());
    print_header(out,"pearson_resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << pearson_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_normalised_resids && this->objective->normalised_resids_defined()){
    MATRIX normalised_resids(this->get_normalised_resids());
    print_header(out,"normalised_resids");
    for (int y=1; y<=this->n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << normalised_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  out << "objective function: ";
  this->objective->print(out);
  out << '\n';
}

template<CDVM>
void Proportions_migrating<DVM>::print_header(ostream& out, const std::string& what_it_is){
  // called repeatedly by print()
  DEBUG2("Proportions_migrating::print_header");
  out << setprecision(6);
  out << what_it_is << (plus_group ? " (last class is a plus group)" : "") << ":\nclass ";
  if (class_mins.size()!=1){
    for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
      out << setw(7) << class_mins[i] << " ";}
  } else {
    for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
      out << setw(7) << i << " ";}
  }
  out << '\n';
}

template<CDVM>
Proportions_migrating<DVM>::Proportions_migrating(Basic_population_section<DVM>& popn,
                                                Parameter_set<DVM>& e,
                                                const std::string& _label,
                                                Ageing_error<DVM>* _ageing_error_ptr, int pseudo)
  : command("proportions_migrating[" + _label + "].")
  , n_classes(1)
  , min_class(1)
  , max_class(1)
  , class_mins(e.get_constant_vector(command+"class_mins",dvector("{-1}"))){
  // Construct the Proportions_migrating observation from the Parameter_set,
  // extracting any other necessary information from the Population_section (e.g. n_areas etc)
  DEBUG1("Proportions_migrating::Proportions_migrating");
  this->label = _label;
  migration = e.get_string(command+"migration");
  if (!popn.annual_cycle->valid_migration(migration)){
          fatal("Invalid migration label " + migration + " in observations labelled " + this->label);}
  sex = e.get_int(command+"sex",0);
  if((sex!=0) & (e.get_bool("sex_partition",0)==1)) {
    fatal("You have requested sexed migrations within the command " + command + " in an unsexed model.");}
  this->years = new dvector(e.get_constant_vector(command+"years"));
  n_years = this->years->size();
  at_size = e.get_bool(command+"at_size",popn.state.size_based);
  if (!at_size && e.present(command+"class_mins")){
          fatal("You can't specify class_mins for at-age observations");}
  if (popn.state.size_based && e.present(command+"class_mins")){
          fatal("You can't specify class_mins in an observations block in a size-based model - must use same size classes as in population data file");}
  selectivity_name = e.get_string(command+"ogive","none");
  if (selectivity_name != "none" && !popn.annual_cycle->valid_selectivity(selectivity_name)){
          fatal("Bad selectivity " + selectivity_name + " for observation with label " + this->label);}
  plus_group = e.get_bool(command+"plus_group",0);
  this->do_bootstrap = e.get_bool(command+"do_bootstrap",1);

  if (e.present(command+"min_class")){
    if (e.get_constant_vector(command+"min_class").size()!=min_class.size()){
      fatal("Wrong size for argument " + command + "min_class - should be " + itos(min_class.size()));}
    min_class = e.get_constant_vector(command+"min_class");
    if(!(!popn.state.size_based && at_size) && min(min_class) < popn.state.col_min)
      fatal("For proportions_migrating[" + _label + "] an element of min_class is less than the number of the lowest partition age/size class.");
  } else if (class_mins.size()!=1){
    min_class = 1;
  } else {
    min_class = popn.state.col_min;
  }

  if (e.present(command+"max_class")){
    if (e.get_constant_vector(command+"max_class").size()!=max_class.size()){
      fatal("Wrong size for argument " + command + "max_class - should be " + itos(max_class.size()));}
    max_class = e.get_constant_vector(command+"max_class");
    if(e.present(command+"class_mins")){
          int number_of_classes = class_mins.size() - (plus_group ? 0 : 1);
          if (max(max_class) > number_of_classes){
            fatal("For proportions_migrating[" + _label + "] an element of max_class is greater than the number of "
            "classes defined by class_mins(" + itos(number_of_classes) + ").");
          }
        } else {
          if (max(max_class) > popn.state.col_max){
                  fatal("For proportions_migrating[" + _label + "] an element of max_class is greater than the number of the highest partition age/size class.");
          }
        }
  } else if (class_mins.size()!=1){
    max_class = class_mins.size() - (plus_group ? 0 : 1);
  } else {
    max_class = popn.state.col_max;
  }
  n_classes = max_class - min_class + 1;
  obs_per_year = (int)sum(n_classes);
  this->fits = new MATRIX(1,n_years,1,obs_per_year);
  this->obs = new MATRIX(1,n_years,1,obs_per_year);
  if (e.get_string("ageing_error.type","none")=="none") ageing_error = 0;
  else ageing_error = e.get_bool(command+"ageing_error",!at_size);
  if (at_size && ageing_error) fatal("Proportions-migrating-at-size " + this->label + " requested ageing error");
  if (ageing_error) ageing_error_ptr = _ageing_error_ptr;
  if (pseudo){
    this->obs->initialize();
    this->objective = 0;
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->final){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for pseudo-observation " + command);
    }
  } else {
    for (int y=1; y<=this->n_years; y++){
      double year = (*(this->years))[y];
      if (e.get_constant_vector(command+dtos(year)).size() != obs_per_year){
        fatal("Wrong number of observations for year " + dtos(year) + " of " + this->label + ": should be " + itos(obs_per_year) + ". You may have omitted or misspecified the min_class, max_class and/or class_mins arguments.\n");}
      (*(this->obs))[y] = e.get_constant_vector(command+dtos(year));
    }
    this->objective = make_objective<DVM>(e,command,*(this->years),obs_per_year,this->label);
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->current){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for observation " + command);
    }
  }
}

template<CDVM>
DOUBLE Age_size<DVM>::get_objective_function(){
  // just return sum of neg-log-likelihood over fish
  // hard work is done by calculate_fits
  DEBUG1("Age_size::get_objective_function");
  return sum(neg_log_likelihoods);
}

template<CDVM>
MATRIX Age_size<DVM>::get_resids(){
  // do nothing - residuals not defined
  DEBUG2("Age_size::get_resids");
  return MATRIX(1,1);
}

template<CDVM>
MATRIX Age_size<DVM>::get_pearson_resids(){
  // do nothing - residuals not defined
  DEBUG2("Age_size::get_pearson_resids");
  return MATRIX(1,1);
}

template<CDVM>
MATRIX Age_size<DVM>::get_normalised_resids(){
  // do nothing - residuals not defined
  DEBUG2("Age_size::get_normalised_resids");
  return MATRIX(1,1);
}

template<CDVM>
void Age_size<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  DEBUG1("Age_size::set_request_parameters");
  // one request per stock, unless you specify that only one stock is to be included
  std::string popn_command;
  for (int i=1; i<=n_stocks; i++){
    if (n_stocks==1){
      popn_command = "numbers_at[" + this->label + "].";
    } else if (stock==""){
      // we are interested in all stocks
      popn_command = "numbers_at[" + this->label + "_" + stock_names[i] + "].";
      p.put_string(popn_command+"stock",stock_names[i]);
    } else if (stock_names[i]==stock){
      // we are interested in only this stock
      popn_command = "numbers_at[" + this->label + "].";
      p.put_string(popn_command+"stock",stock_names[i]);
    } else {
      // we are not interested in this stock
    continue;
    }
    dvector years(1,1);
    years[1]=year;
    p.put_constant_vector(popn_command+"years",years);
    p.put_int(popn_command+"step",step);
    p.put_constant(popn_command+"proportion_mortality",proportion_mortality);
    p.put_int(popn_command+"at_size",0);
    p.put_int(popn_command+"sexed",sexed);
    if (area != "") p.put_string(popn_command+"area",area);
    if (selectivity_name != "none") p.put_string(popn_command+"ogive",selectivity_name);
  }
}

template<CDVM>
void Age_size<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // Calculate negative-log-likelihood for each fish.
  DEBUG1("Age_size::calculate_fits");
  // Initialization starts here
  DOUBLE num, den;
  // next extract a matrix of numbers of fish for each stock
  // so for the ith stock, we can query (*N[i])[sex][age] (unless ignore_stock[i]=1)
  std::vector<MATRIX*> N;
  N.push_back(new MATRIX(1,1)); // dummy entry so real entries start at 1
  dvector ignore_stock(1,n_stocks);
  ignore_stock=0;
  for (int i=1; i<=n_stocks; i++){
    if (n_stocks==1){
      N.push_back(new MATRIX(popn.results.numbers_at[this->label][year]));
    } else if (stock==""){
      // we are interested in all stocks
      N.push_back(new MATRIX(popn.results.numbers_at[this->label + "_" + stock_names[i]][year]));
    } else if (stock_names[i]==stock){
      // we are interested in only this stock
      N.push_back(new MATRIX(popn.results.numbers_at[this->label][year]));
    } else {
      // we are not interested in this stock
      N.push_back(new MATRIX(1,1));
      ignore_stock[i]=1;
    }
    if (!ignore_stock[i]){
      // check for stocks with zero abundance in this area - don't have to include them in calculations
        if (sexed){
          if (max((*N[i])[1])==0 && max((*N[i])[2])==0 ){
          ignore_stock[i]=1;}
      } else {
        if (max((*N[i])[1])==0){
        ignore_stock[i]=1;}
      }
    }
  }
  if (min(ignore_stock)==1){
    fatal("There is a problem with your age-size observations - there are no fish in the specified area. Have you selected the wrong stock, wrong area, ...?");}
  // next initialize ageing error (if any)
  int min_age = popn.state.col_min;
  int max_age = popn.state.col_max;
  MATRIX M(min_age,max_age,min_age,max_age);
  // The [i,j]th element is the probability of classifying a fish of age i as age j.
  if (ageing_error){
    M = *(ageing_error_ptr->misclassification);
  } else M.initialize();
  std::string stock_name;
  if(sample=="random_at_size") {
    for (int k=1; k<=n_stocks; k++){
      if (!ignore_stock[k]){  // otherwise this is not the stock the user has asked for, or there are no fish of this stock in the area
        if (n_stocks==1) stock_name=""; else stock_name=stock_names[k];
        if(sexed) {
          // first calcuate the denominator for unique fish sizes, by sex
          vector<double> unique_sizes;
          for(int i=1; i<=sizes.size(); i++) {
            if(!in(unique_sizes,sizes[i])) {
              unique_sizes.push_back(sizes[i]);
            }
          }
          sort(unique_sizes.begin(),unique_sizes.end());
          VECTOR fal_male(0,unique_sizes.size());
          VECTOR fal_female(0,unique_sizes.size());
          for(int i=0; i<unique_sizes.size(); i++) {
            fal_male[i]=0;
            fal_female[i]=0;
            for(int j=min_age; j<=max_age; j++){
              fal_male[i] += (*N[k])[1][j] * get_f(popn,stock_name,j,1,unique_sizes[i]);
              fal_female[i] += (*N[k])[2][j] * get_f(popn,stock_name,j,2,unique_sizes[i]);
            }
          }
          for (int f=1; f<=n_fish; f++){
            // now loop over fish and calculate numerator, denominator and -log(L) for each
            num = 0;
            if (ageing_error){
              for (int i=min_age; i<=max_age; i++){
                if (M[i][(int)(ages[f])] > 1e-4){
                  num += (*N[k])[(int)(sexes[f])][i] * M[i][(int)(ages[f])] * get_f(popn,stock_name,i,(int)(sexes[f]),sizes[f]);
                }
              }
            } else if (!ageing_error){  // simpler case without ageing error
              num = (*N[k])[(int)(sexes[f])][(int)(ages[f])] * get_f(popn,stock_name,(int)(ages[f]),(int)(sexes[f]),sizes[f]);
            }
            den=0;
            for(int j=0; j<unique_sizes.size(); j++) {
              if(sizes[f]==unique_sizes[j]) {
                if(sexes[f]==1) den = fal_male[j];
                else den = fal_female[j];
                break;
              }
            }
            // calculate negative log-likelihood
            if (num==0 || den==0){
              // don't know why this would happen, but...
              neg_log_likelihoods[f] += 1000;
            } else neg_log_likelihoods[f] = -log(num/den);
          }
        } else if(!sexed) {
          // first calcuate the denominator for unique fish sizes
          vector<double> unique_sizes;
          for(int i=1; i<=sizes.size(); i++) {
            if(!in(unique_sizes,sizes[i])) {
              unique_sizes.push_back(sizes[i]);
            }
          }
          sort(unique_sizes.begin(),unique_sizes.end());
          VECTOR fal(0,unique_sizes.size());
          for(int i=0; i<unique_sizes.size(); i++) {
            fal[i]=0;
            for(int j=min_age; j<=max_age; j++){
              fal[i] += (*N[k])[1][j] * get_f(popn,stock_name,j,1,unique_sizes[i]);
            }
          }
          for (int f=1; f<=n_fish; f++){
            // now loop over fish and calculate numerator, denominator and -log(L) for each
            num = 0;
            if (ageing_error){
              for (int i=min_age; i<=max_age; i++){
                if (M[i][(int)(ages[f])] > 1e-4){
                  num += (*N[k])[1][i] * M[i][(int)(ages[f])] * get_f(popn,stock_name,i,1,sizes[f]);
                }
              }
            } else if (!ageing_error){  // simpler case without ageing error
              num = (*N[k])[1][(int)(ages[f])] * get_f(popn,stock_name,(int)(ages[f]),0,sizes[f]);
            }
            den=0;
            for(int j=0; j<unique_sizes.size(); j++) {
              if(sizes[f]==unique_sizes[j]) {
                den = fal[j];
                break;
              }
            }
            // calculate negative log-likelihood
            if (num==0 || den==0){
              // don't know why this would happen, but...
              neg_log_likelihoods[f] += 1000;
            } else neg_log_likelihoods[f] = -log(num/den);
          }
        }
      }
    }
  } else if(sample=="random_at_sex_and_size") {
    for (int k=1; k<=n_stocks; k++){
      if (!ignore_stock[k]){  // otherwise this is not the stock the user has asked for, or there are no fish of this stock in the area
        if (n_stocks==1) stock_name=""; else stock_name=stock_names[k];
        // first calcuate the denominator for unique fish sizes, by sex
        vector<double> unique_sizes;
        for(int i=1; i<=sizes.size(); i++) {
          if(!in(unique_sizes,sizes[i])) {
            unique_sizes.push_back(sizes[i]);
          }
        }
        sort(unique_sizes.begin(),unique_sizes.end());
        VECTOR fal_male(0,unique_sizes.size());
        VECTOR fal_female(0,unique_sizes.size());
        for(int i=0; i<unique_sizes.size(); i++) {
          fal_male[i]=0;
          fal_female[i]=0;
          for(int j=min_age; j<=max_age; j++){
            fal_male[i] += (*N[k])[1][j] * get_f(popn,stock_name,j,1,unique_sizes[i]);
            fal_female[i] += (*N[k])[2][j] * get_f(popn,stock_name,j,2,unique_sizes[i]);
          }
        }
        for (int f=1; f<=n_fish; f++){
          // now loop over fish and calculate numerator, denominator and -log(L) for each
          num = 0;
          if (ageing_error){
            for (int i=min_age; i<=max_age; i++){
              if (M[i][(int)(ages[f])] > 1e-4){
                num += (*N[k])[(int)(sexes[f])][i] * M[i][(int)(ages[f])] * get_f(popn,stock_name,i,(int)(sexes[f]),sizes[f]);
              }
            }
          } else if (!ageing_error){  // simpler case without ageing error
            num = (*N[k])[(int)(sexes[f])][(int)(ages[f])] * get_f(popn,stock_name,(int)(ages[f]),(int)(sexes[f]),sizes[f]);
          }
          den=0;
          for(int j=0; j<unique_sizes.size(); j++) {
            if(sizes[f]==unique_sizes[j]) {
              if(sexes[f]==1) den = fal_male[j];
              else den = fal_female[j];
              break;
            }
          }
        // calculate negative log-likelihood
          if (num==0 || den==0){
            // don't know why this would happen, but...
            neg_log_likelihoods[f] += 1000;
          } else neg_log_likelihoods[f] = -log(num/den);
        }
      }
    }
  } else {
    // now loop over fish and calculate numerator, denominator and -log(L) for each
    for (int f=1; f<=n_fish; f++){
      // calculate numerator
      num = 0;
      for (int k=1; k<=n_stocks; k++){
        if (!ignore_stock[k]){  // otherwise this is not the stock the user has asked for, or there are no fish of this stock in the area
          if (n_stocks==1) stock_name=""; else stock_name=stock_names[k];
          if (ageing_error){
            for (int i=min_age; i<=max_age; i++){
              if (M[i][(int)(ages[f])] > 1e-4){
                if (sexed){
                  num += (*N[k])[(int)(sexes[f])][i] * M[i][(int)(ages[f])] * get_f(popn,stock_name,i,(int)(sexes[f]),sizes[f]);
                } else if (!sexed){
                  num += (*N[k])[1][i] * M[i][(int)(ages[f])] * get_f(popn,stock_name,i,1,sizes[f]);
                }
              }
            }
          } else if (!ageing_error){  // simpler case without ageing error
            if (sexed){
              num = (*N[k])[(int)(sexes[f])][(int)(ages[f])] * get_f(popn,stock_name,(int)(ages[f]),(int)(sexes[f]),sizes[f]);
            } else if (!sexed){
              num = (*N[k])[1][(int)(ages[f])] * get_f(popn,stock_name,(int)(ages[f]),0,sizes[f]);
            }
          }
        }
      }
      // calculate denominator - depends on sampling method
      den = 0;
      if(sample=="random") {
        for (int k=1; k<=n_stocks; k++){
          if (!ignore_stock[k]){  // otherwise this is not the stock the user has asked for, or there are no fish of this stock in the area
            if (n_stocks==1) stock_name=""; else stock_name=stock_names[k];
            if (sexed){
              den = sum((*N[k])[1]) + sum((*N[k])[2]);
            } else {
              den = sum((*N[k])[1]);
            }
          }
        }
      } else if(sample=="random_at_sex") {
        for (int k=1; k<=n_stocks; k++){
          if (!ignore_stock[k]){  // otherwise this is not the stock the user has asked for, or there are no fish of this stock in the area
            if (n_stocks==1) stock_name=""; else stock_name=stock_names[k];
            den = sum((*N[k])[(int)(sexes[f])]);
          }
        }
      } else if(sample=="random_at_age") {
        for (int k=1; k<=n_stocks; k++){
          if (!ignore_stock[k]){  // otherwise this is not the stock the user has asked for, or there are no fish of this stock in the area
            if (n_stocks==1) stock_name=""; else stock_name=stock_names[k];
            if (ageing_error){
              for (int i=min_age; i<=max_age; i++){
                if (M[i][(int)(ages[f])] > 1e-4){
                  if (sexed){
                    den += ((*N[k])[1][i] + (*N[k])[2][i]) * M[i][(int)(ages[f])];
                  } else if (!sexed){
                    den += (*N[k])[1][i] * M[i][(int)(ages[f])];
                  }
                }
              }
            } else if (!ageing_error){
              if (sexed){
                den = (*N[k])[1][(int)(ages[f])] + (*N[k])[2][(int)(ages[f])];
              } else if (!sexed){
                den = (*N[k])[1][(int)(ages[f])];
              }
            }
          }
        }
      } else if(sample=="random_at_sex_and_age") {
        for (int k=1; k<=n_stocks; k++){
          if (!ignore_stock[k]){  // otherwise this is not the stock the user has asked for, or there are no fish of this stock in the area
            if (n_stocks==1) stock_name=""; else stock_name=stock_names[k];
            if (ageing_error){
              for (int i=min_age; i<=max_age; i++){
                if (M[i][(int)(ages[f])] > 1e-4){
                  den += (*N[k])[(int)(sexes[f])][i] * M[i][(int)(ages[f])];
                }
              }
            } else if (!ageing_error){
              den = (*N[k])[(int)(sexes[f])][(int)(ages[f])];
            }
          }
        }
      }
      // calculate negative log-likelihood
      if (num==0 || den==0){
        // don't know why this would happen, but...
        neg_log_likelihoods[f] += 1000;
      } else neg_log_likelihoods[f] = -log(num/den);
    }
  }
  // all done - now delete the free-store objects
  for (int i=0; i<=n_stocks; i++){
    delete N[i];
  }
}

template<CDVM>
DOUBLE Age_size<DVM>::get_f(Basic_population_section<DVM>& popn,std::string stock,int a,int s,double l){
  // used by Age_size::calculate_fits to return the pdf of the size-at-age
  // stock is the stock name (ignored if single-stock model)
  // a is the true age of the fish
  // s is the sex (1 or 2, or ignored if unsexed model)
  // l is the size
  // relatively simple unless a size-based selectivity is employed
  // BB note - there is an issue if we have tags that stunt fish growth
  //   - the issue is implicitly avoided by choosing the first row which matches
  //     the other criteria, which must be a 'no_tag' row (since tag states are
  //     sorted in ascending order)
  // first, which row of the partition are we dealing with?
  int row=0, row_ok;
  int stock_char=popn.state.character_numbers("stock");
  int sex_char=popn.state.character_numbers("sex");
  int area_char=popn.state.character_numbers("area");
  for (int i=1; i<=popn.state.n_rows; i++){
    row_ok = 1;
    if (stock!=""){
      if (popn.state.character_value(i,stock_char)!=popn.state.stock_numbers[stock]){
        row_ok=0;} // this row is fish of the wrong stock
    }
    if (sexed){
      if (popn.state.character_value(i,sex_char)!=s){
        row_ok=0;} // this row is fish of the wrong sex
    }
    if (area!=""){
      if (popn.state.character_value(i,area_char)!=popn.state.area_numbers[area]){
        row_ok=0;} // this row is fish in the wrong area
    }
    if (row_ok){ // this is the row we should be looking at
      row=i;
      break;
    }
  }
  if (selectivity){
    if (popn.annual_cycle->selectivities[selectivity_name]->sizebased_ogive_used){
      return popn.annual_cycle->size_at_age->get_pdf_with_sizebased_sel(year,step,row,a,l,popn.annual_cycle->selectivities[selectivity_name]);
    }
  }
  return popn.annual_cycle->size_at_age->get_pdf(year,step,row,a,l);
}

template<CDVM>
void Age_size<DVM>::parametric_bootstrap(long int seed){
  // Randomise the observations around the fits (discarding the original observations).
  // For most observations types the inherited version of this function is used,
  // but for Age_size it has to be overridden as the 'objective' pointer is null
  DEBUG2("Age_size::parametric_bootstrap");
  fatal("Parametric bootstrapping is not yet implemented for Age_size observations.");
}

template<CDVM>
void Age_size<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Age_size::write_to_file");
  fatal("Write_to_file is not yet implemented for Age_size observations.");
}

template<CDVM>
void Age_size<DVM>::print(ostream& out, int print_fits,int print_resids, int print_pearson_resids,
                          int print_normalised_resids){
  // Quite different to the print functions of the other observations classes.
  // We never print fits or any kind of residuals for Age_size observations.
  // But if print_fits is set, we print the negative-log-likelihood for each fish.
  DEBUG2("Age_size::print");
  out << "age-size data in year " << year << " step " << step << " after proportion " << proportion_mortality << " of mortality";
  if (stock!="") out << " from stock " << stock;
  if (area!="") out << " in area " << area;
  if (selectivity) out << " using selectivity " << selectivity_name;
  out << " with sampling method " << sample;
  if (ageing_error) out << " using ageing error";
  out << ".\n";
  if (print_fits){
    if (sexed){
      out << "age size sex neg_log_likelihood\n";
      for (int i=1; i<=n_fish; i++){
        out << ages[i] << ' ' << sizes[i] << ' ' << sexes[i] << ' ' << neg_log_likelihoods[i] << '\n';
      }
    } else if (!sexed){
      out << "age size neg_log_likelihood\n";
      for (int i=1; i<=n_fish; i++){
        out << ages[i] << ' ' << sizes[i] << ' ' << neg_log_likelihoods[i] << '\n';
      }
    }
    out << '\n';
    out << "total neg_log_likelihood: " << sum(neg_log_likelihoods) << "\n\n";
  } else if (!print_fits){
    if (sexed){
      out << "age size sex\n";
      for (int i=1; i<=n_fish; i++){
        out << ages[i] << ' ' << sizes[i] << ' ' << sexes[i] << '\n';
      }
    } else if (!sexed){
      out << "age size\n";
      for (int i=1; i<=n_fish; i++){
        out << ages[i] << ' ' << sizes[i] << '\n';
      }
    }
    out << "\n";
  }
}

template<CDVM>
Age_size<DVM>::Age_size(Basic_population_section<DVM>& popn, Parameter_set<DVM>& e,
                        const std::string& _label,Ageing_error<DVM>* _ageing_error_ptr, int pseudo)
  : command("age_size[" + _label + "].")
  , neg_log_likelihoods(1,e.get_constant_vector(command+"ages").size())
  , ages(e.get_constant_vector(command+"ages"))
  , sizes(e.get_constant_vector(command+"sizes"))
  , sexes(e.get_constant_vector(command+"sexes",dvector("{-1}")))
  , quantile_breaks(1,5){
  // Construct the Age_size observation from the Parameter_set,
  // extracting any other necessary information from the Population_section (e.g. n_areas etc)
  DEBUG1("Age_size::Age_size");
  this->label = _label;
  n_fish = ages.size();
  neg_log_likelihoods = 0;
  if (pseudo){
    fatal("You cannot use pseudo-observations of age/size data.");}
  if (popn.state.n_growthpaths>1){
    fatal("You cannot use age-size observations in a growthpath model.");}
  if (popn.state.size_based){
    fatal("You cannot use age-size observations in a size-based model.");}
  if (e.get_constant_vector(command+"sizes").size() != n_fish){
    fatal("The numbers of age observations and size observations in your age/size observations should be equal and aren't.");}
  if (popn.state.sex_partition){
    sexed = 1;
    if (!e.present(command+"sexes")){
      fatal("You need to supply sexes for your age/size observations.");}
    if (sexes.size() != n_fish){
      fatal("The numbers of sex observations and age observations in your age/size observations should be equal and aren't.");}
    for (int i=1; i<=n_fish; i++){
      if (sexes[i]!=1 && sexes[i]!=2){
        fatal("You have supplied an illegal sex of " + itos((int)sexes[i]) + " in your age/size observations - use either 1 (male) or 2 (female).");
      }
    }
  } else sexed=0;
  for (int i=1; i<=n_fish; i++){
    if (ages[i]<popn.state.col_min || ages[i]>popn.state.col_max || ages[i]!=(double)(int)ages[i]){
      fatal("Bad age of " + dtos(ages[i]) + " in age/size observations " + this->label + "\nCheck that the supplied ages lie within the range defined of the partition and that there are no non-interger ages\n");
    }
  }
  year = e.get_int(command+"year");
  step = e.get_int(command+"step");
  proportion_mortality = e.get_constant(command+"proportion_mortality",0.5);
  if (!popn.annual_cycle->valid_step(step)){
    fatal("Bad time step " + itos(step) + " for observation with label " + this->label);}
  if (popn.state.n_stocks==1){
    stock = "";
  } else {
    stock = e.get_string(command+"stock","");
  }
  if (stock!=""){
    if (!popn.state.valid_stock(stock)){
      fatal("You supplied an invalid stock name " + stock + " for the observation labelled " + this->label);
    }
  }
  n_stocks = popn.state.n_stocks;
  stock_names = popn.state.stock_names;
  if (popn.state.n_areas > 1){
    area = e.get_string(command+"area");
    if (!popn.state.valid_area(area)){
      fatal("Bad area " + area + " for observations with label " + this->label);}
  } else area="";
  // deal with the sampling method
  sample = e.get_string(command+"sample");
  if (sample!="random" && sample!="random_at_sex" && sample!="random_at_size" && sample!="random_at_age"
      && sample!="random_at_sex_and_size" && sample!="random_at_sex_and_age"){
    fatal("You specified an invalid sampling method " + sample + " for age-size observations with label " + this->label + " - use one of the following: random, random_at_sex, random_at_age, random_at_size, random_at_sex_and_size, random_at_sex_and_age");
  }
  if (!sexed && (sample=="random_at_sex" || sample=="random_at_sex_and_age" || sample=="random_at_sex_and_size")){
    fatal("You specified a sex-based sampling method " + sample + " for age-size observations with label " + this->label + " but this is not a sexed model.");
  }
  // deal with the selectivity
  selectivity_name = e.get_string(command+"ogive","none");
  if (selectivity_name != "none" && !popn.annual_cycle->valid_selectivity(selectivity_name)){
    fatal("Bad selectivity " + selectivity_name + " for observation with label " + this->label);}
  selectivity = (selectivity_name!="none");
  // check whether the selectivity actually has any effect on the likelihood, don't use it if not
  if (selectivity){
    if (popn.annual_cycle->selectivities[selectivity_name]->sizebased_ogive_used){
      if (sample=="random_at_sex_and_size" || (sample=="random_at_size" && !(popn.annual_cycle->selectivities[selectivity_name]->sel_depends_on_sex))){
        cerr << "Warning - you have used age-size observations with a size-based selectivity that has no effect on the likelihood. The selectivity will not be used.\n";
        selectivity_name="none";
        selectivity=0;
      } else {
        cerr << "Warning - you have used age-size observations with a size-based selectivity ogive - this will be quite computationally expensive\n";
      }
    } else { // selectivity ogive is age-based
      if (sample=="random_at_sex_and_age" || (sample=="random_at_age" && !(popn.annual_cycle->selectivities[selectivity_name]->sel_depends_on_sex))){
        cerr << "Warning - you have used age-size observations with an age-based selectivity that has no effect on the likelihood. The selectivity will not be used.\n";
        selectivity_name="none";
        selectivity=0;
      }
    }
  }
  // deal with the ageing error
  if (e.get_string("ageing_error.type","none")=="none") ageing_error = 0;
  else ageing_error = e.get_bool(command+"ageing_error",1);
  if (ageing_error) ageing_error_ptr = _ageing_error_ptr;
  // deal with the size-at-age
  size_at_age_dist = popn.annual_cycle->size_at_age->get_dist();
  if (size_at_age_dist=="none"){
    fatal("You have specified an Age_size observation, but you have not provided a size-at-age distribution. You must specify a distribution.");}
  if (popn.annual_cycle->size_at_age->any_nonpositive_cvs){
    fatal("You have specified an Age_size observation, but you have provided a size-at-age distribution with a coefficient of variation of 0 for at least one partition element. All cvs must be positive.");}
  // set up 5 evenly spaced quantiles of normal distn
  dvector quantiles(1,5);
  for (int i=1; i<=5; i++){
    quantiles[i] = ((double)i-0.5) / 5;
    quantile_breaks[i] = qnorm<double>(quantiles[i],0,1);
  }
  this->do_bootstrap = e.get_bool(command+"do_bootstrap",1); // error if T
  // a bunch of pointers are not used, we will just zero them,
  // the destructor knows not to delete zero pointers
  this->fits = 0;
  this->obs = 0;
  this->objective = 0;
  this->years = 0;
}

template<CDVM>
DOUBLE Age_at_maturation<DVM>::get_objective_function(){
  // just return sum of neg-log-likelihood over fish
  // hard work is done by calculate_fits
  DEBUG1("Age_at_maturation::get_objective_function");
  return sum(neg_log_likelihoods);
}

template<CDVM>
MATRIX Age_at_maturation<DVM>::get_resids(){
  // do nothing - residuals not defined
  DEBUG2("Age_at_maturation::get_resids");
  return MATRIX(1,1);
}

template<CDVM>
MATRIX Age_at_maturation<DVM>::get_pearson_resids(){
  // do nothing - residuals not defined
  DEBUG2("Age_at_maturation::get_pearson_resids");
  return MATRIX(1,1);
}

template<CDVM>
MATRIX Age_at_maturation<DVM>::get_normalised_resids(){
  // do nothing - residuals not defined
  DEBUG2("Age_at_maturation::get_normalised_resids");
  return MATRIX(1,1);
}

template<CDVM>
void Age_at_maturation<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  DEBUG1("Age_at_maturation::set_request_parameters");
  // no results needed (the likelihood is purely based on the maturation rates plus
  //  the parameters held in this object)
}

template<CDVM>
void Age_at_maturation<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // Calculate negative-log-likelihood for each fish.
  DEBUG1("Age_at_maturation::calculate_fits");
  MATRIX maturation(1,2,popn.state.col_min,popn.state.col_max);
  // column j is the probability of maturing at age j = O_a in manual
  // if sexed then row 1 is males and row 2 is females, otherwise row 1 is used and row 2 is ignored
  if (sexed){
    maturation[1] = popn.annual_cycle->maturation[1]->get(popn.state,1,stock);
    maturation[2] = popn.annual_cycle->maturation[1]->get(popn.state,2,stock);
  } else if (!sexed) {
    maturation[1] = popn.annual_cycle->maturation[1]->get(popn.state,-1,stock);
  }
  MATRIX U(1,2,popn.state.col_min-1,popn.state.col_max);
  // column j is the probability of not having matured by the end of age j = U_a in manual
  // if sexed then row 1 is males and row 2 is females, otherwise row 1 is used and row 2 is ignored
  if (sexed){
    U[1][popn.state.col_min-1] = 1;
    for (int j=popn.state.col_min; j<=popn.state.col_max; j++){
      U[1][j] = U[1][j-1] * (1-maturation[1][j]);}
    U[2][popn.state.col_min-1] = 1;
    for (int j=popn.state.col_min; j<=popn.state.col_max; j++){
      U[2][j] = U[2][j-1] * (1-maturation[2][j]);}
  } else if (!sexed) {
    U[1][popn.state.col_min-1] = 1;
    for (int j=popn.state.col_min; j<=popn.state.col_max; j++){
      U[1][j] = U[1][j-1] * (1-maturation[1][j]);}
  }
  MATRIX M(popn.state.col_min,popn.state.col_max,popn.state.col_min,popn.state.col_max);
    // The [i,j]th element is the probability of classifying a fish of age i as age j.
    if (ageing_error){
      M = *(ageing_error_ptr->misclassification);
  } else M.initialize();
  // OK, data is prepared, now go into the main loop
  for (int i=1; i<=n_fish; i++){
    int same=0;
      if (i>1){
            if (maturation_ages[i]==maturation_ages[i-1] && sampled_ages[i]==sampled_ages[i-1] && (sexed ? sexes[i]==sexes[i-1] : 1)){
            // same as last fish!
              neg_log_likelihoods[i] = neg_log_likelihoods[i-1];
              same=1;
          }
      }
      if (!same){
          int maturation_row = (int)(sexed ? sexes[i] : 1); // for accessing maturation and U
              DOUBLE likelihood;
              if (!ageing_error){
                    // simple
            likelihood = age_at_mat_prob<DVM>((int)(maturation_ages[i]),(int)(sampled_ages[i]),maturation[maturation_row],U[maturation_row],popn.state.col_min,popn.state.col_max,k);
              } else if (ageing_error){
            if (maturation_ages[i]==0){
                  // still simple
              likelihood = age_at_mat_prob<DVM>((int)(maturation_ages[i]),(int)(sampled_ages[i]),maturation[maturation_row],U[maturation_row],popn.state.col_min,popn.state.col_max,k);
                    } else {
                      // more complicated
              DOUBLE num=0, den=0, term, misclass;
              int summation_max = (int)(popn.state.col_max > sampled_ages[i]-k ? sampled_ages[i]-k : popn.state.col_max);
              for (int a=popn.state.col_min; a<=summation_max; a++){
                        term = 0;
                for (int b=popn.state.col_min; b<=summation_max; b++){
                  misclass = M[b][a];
                  if (misclass > 0.0001){
                                term += misclass * age_at_mat_prob<DVM>(b,(int)(sampled_ages[i]),maturation[maturation_row],U[maturation_row],popn.state.col_min,popn.state.col_max,k);
                          }
                        }
                        if (a == maturation_ages[i]) num = term;
                        den += term;
                      }
                  if (den==0) fatal("Zero denominator in Age_at_maturation::calculate_fits with maturation_age = " + itos((int)(maturation_ages[i])) + " and sampled_age = " + itos((int)(sampled_ages[i])));
                  if (num/den < 1e-6) likelihood=1e-6;
                  else likelihood=num/den;
                    }
              }
              neg_log_likelihoods[i] = -log(likelihood);
      }
  }
}

template<CDVM>
DOUBLE age_at_mat_prob(int maturation_age, int sampled_age, VECTOR& O, VECTOR& U, int min_age, int max_age, int k){
  // used by Age_at_maturation::calculate_fits
  // Calculates the probability of maturation_age given sampled_age
  //  in the absence of ageing error.
  // O=maturation ogive, U=cumulative non-maturation ogive
  if (maturation_age==0){
    DOUBLE num = U[sampled_age-1];
    DOUBLE den = U[sampled_age-1];
    DOUBLE term;
    for (int a=1; a<=sampled_age-1; a++){
          term = O[a]*U[a-1];
          den += term;
          if (a >= sampled_age - k) num += term;
        }
        if (den==0) fatal("Zero denominator in age_at_mat_prob with maturation_age = " + itos(maturation_age) + " and sampled_age = " + itos(sampled_age));
        if (num/den < 1e-6) return 1e-6;
        else return num/den;
  } else {
    DOUBLE num = 0;
    DOUBLE den = U[sampled_age-1];
    DOUBLE term;
    for (int a=1; a<=sampled_age-1; a++){
          term = O[a]*U[a-1];
          den += term;
          if (a == maturation_age) num = term;
        }
        if (den==0) fatal("Zero denominator in age_at_mat_prob with maturation_age = " + itos(maturation_age) + " and sampled_age = " + itos(sampled_age));
        if (num/den < 1e-6) return 1e-6;
        else return num/den;
  }
}

template<CDVM>
void Age_at_maturation<DVM>::parametric_bootstrap(long int seed){
        // Randomise the observations around the fits (discarding the original observations).
        // For most observations types the inherited version of this function is used,
        // but for Age_at_maturation it has to be overridden as the 'objective' pointer is null
        DEBUG2("Age_at_maturation::parametric_bootstrap");
        fatal("Parametric bootstrapping is not yet implemented for Age_at_maturation observations.");
}

template<CDVM>
void Age_at_maturation<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Age_at_maturation::write_to_file");
  fatal("Write_to_file is not yet implemented for Age_at_maturation observations.");
}

template<CDVM>
void Age_at_maturation<DVM>::print(ostream& out, int print_fits,
                                              int print_resids, int print_pearson_resids,
                                              int print_normalised_resids){
  // Quite different to the print functions of the other observations classes (except Age_size).
  // We never print fits or any kind of residuals for Age_at_maturation observations.
  // But if print_fits is set, we print the negative-log-likelihood for each fish.
  DEBUG2("Age_at_maturation::print");
  out << "age-at-maturation data";
  if (sexed) out << ", sexed, ";
  if (stock!="") out << ", from stock " << stock;
  if (ageing_error) out << ", using ageing error";
  if (k>0) out << ", with maturity detectible after " << k << " years";
  out << ".\n";
  if (print_fits){
        if (sexed){
          out << "age-at-maturity age-at-capture sex neg_log_likelihood\n";
          for (int i=1; i<=n_fish; i++){
            out << maturation_ages[i] << ' ' << sampled_ages[i] << ' ' << sexes[i] << ' ' << neg_log_likelihoods[i] << '\n';
          }
        } else if (!sexed){
          out << "age-at-maturity age-at-capture neg_log_likelihood\n";
          for (int i=1; i<=n_fish; i++){
            out << maturation_ages[i] << ' ' << sampled_ages[i] << ' ' << neg_log_likelihoods[i] << '\n';
          }
        }
    out << '\n';
    out << "total neg_log_likelihood: " << sum(neg_log_likelihoods) << "\n\n";
  } else if (!print_fits){
        if (sexed){
          out << "age-at-maturity age-at-capture sex\n";
          for (int i=1; i<=n_fish; i++){
            out << maturation_ages[i] << ' ' << sampled_ages[i] << ' ' << sexes[i] << '\n';
          }
        } else if (!sexed){
          out << "age-at-maturity age-at-capture\n";
          for (int i=1; i<=n_fish; i++){
            out << maturation_ages[i] << ' ' << sampled_ages[i] << '\n';
          }
        }
    out << "\n";
  }
}

template<CDVM>
Age_at_maturation<DVM>::Age_at_maturation(Basic_population_section<DVM>& popn,
                                            Parameter_set<DVM>& e,
                                            const std::string& _label,
                                            Ageing_error<DVM>* _ageing_error_ptr, int pseudo)
  : command("age_at_maturation[" + _label + "].")
  , neg_log_likelihoods(1,e.get_constant_vector(command+"maturation_ages").size())
  , maturation_ages(e.get_constant_vector(command+"maturation_ages"))
  , sampled_ages(e.get_constant_vector(command+"sampled_ages"))
  , sexes(e.get_constant_vector(command+"sexes",dvector("{-1}"))){
  // Construct the Age_at_maturation observation from the Parameter_set,
  // extracting any other necessary information from the Population_section (e.g. n_areas etc)
  DEBUG1("Age_at_maturation::Age_at_maturation");
  this->label = _label;
  n_fish = maturation_ages.size();
  neg_log_likelihoods = 0;
  if (pseudo){
    fatal("You cannot use pseudo-observations of age-at-maturation data.");}
  if (popn.state.size_based){
          fatal("You cannot use age-at-maturation observations in a size-based model.");}
  if (!(popn.state.mature_partition)){
          fatal("You cannot use age-at-maturation observations in a model where maturity is not a partition character.");}
  if (popn.annual_cycle->n_maturations!=1){
        fatal("You can only use age-at-maturation observations in models with one maturation episode per year.");}
  if (sampled_ages.size() != n_fish){
    fatal("The numbers of age-at-maturation observations and age-at-capture observations in your age-at-maturation observations should be equal and aren't.");}
  sexed = e.get_bool(command+"sexed", popn.state.sex_partition);
  if (sexed){
    if (!e.present(command+"sexes")){
      fatal("You need to supply sexes for your age-at-maturation observations.");}
    if (sexes.size() != n_fish){
      fatal("The numbers of sex observations and age-at-maturity observations in your age-at-maturation observations should be equal and aren't.");}
    for (int i=1; i<=n_fish; i++){
          if (sexes[i]!=1 && sexes[i]!=2){
                  fatal("You have supplied an illegal sex of " + itos((int)sexes[i]) + " in your age-at-maturation observations - use either 1 (male) or 2 (female).");
          }
    }
  }
  k = e.get_int(command+"k",0);
  for (int i=1; i<=n_fish; i++){
    if (sampled_ages[i]<popn.state.col_min || sampled_ages[i]!=(double)(int)sampled_ages[i]){
      if (sampled_ages[i]!=0) fatal("Bad age-at-capture of " + dtos(sampled_ages[i]) + " in age-at-maturation observations " +
                              this->label + "\nCheck that the supplied ages lie within the range defined in the partition and that there are no non-integer ages\n");}
    if (maturation_ages[i]<popn.state.col_min || maturation_ages[i]!=(double)(int)maturation_ages[i]){
      if (maturation_ages[i]!=0) fatal("Bad age-at-maturation of " + dtos(maturation_ages[i]) + " in age-at-maturation observations " + this->label + "\nCheck that the supplied ages lie within the range defined in the partition and that there are no non-integer ages\n");}
    if (maturation_ages[i]!=0 && sampled_ages[i]!=0 && maturation_ages[i]>sampled_ages[i]-k){
                fatal("In age-at-maturation observations " + this->label + ", we have a sampled age of " +
                dtos(sampled_ages[i]) + " which is within k=" + itos(k) + " years of its maturation age " +
                dtos(maturation_ages[i]) + ". This is illegal.");}
  }
  for (int i=1; i<=n_fish; i++){
          if (sampled_ages[i]>popn.state.col_max) sampled_ages[i]=popn.state.col_max;
          if (maturation_ages[i]>popn.state.col_max) maturation_ages[i]=popn.state.col_max;
  }
  if (popn.state.n_stocks==1){
    stock = "";
  } else {
    stock = e.get_string(command+"stock");
    if (!popn.state.valid_stock(stock)){
       fatal("You supplied an invalid stock name " + stock + " for the observation labelled " + this->label);}
  }
  n_stocks = popn.state.n_stocks;
  stock_names = popn.state.stock_names;
  // deal with the ageing error
  if (e.get_string("ageing_error.type","none")=="none") ageing_error = 0;
  else ageing_error = e.get_bool(command+"ageing_error",1);
  if (ageing_error) ageing_error_ptr = _ageing_error_ptr;
  this->do_bootstrap = e.get_bool(command+"do_bootstrap",1); // error if T
  // a bunch of pointers are not used, we will just zero them,
  // the destructor knows not to delete zero pointers
  this->fits = 0;
  this->obs = 0;
  this->objective = 0;
  this->years = 0;
}

template<CDVM>
void Selectivity_at<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  // put entries into the Parameter_set to tell the population section what results to return
  // note the new subcommand 'just_the_ogive'.
  DEBUG1("Selectivity_at::set_request_parameters");
  std::string popn_command = "numbers_at[" + this->label + "].";
  p.put_constant_vector(popn_command+"years",*(this->years));
  p.put_int(popn_command+"step",step);
  p.put_int(popn_command+"sexed",sexed);
  p.put_int(popn_command+"at_size",at_size);
  p.put_constant(popn_command+"proportion_mortality",proportion_mortality);
  if (area != "") p.put_string(popn_command+"area",area);
  if (stock != "") p.put_string(popn_command+"stock",stock);
  p.put_int(popn_command+"mature_only",mature_only);
  p.put_string(popn_command+"ogive",selectivity_name);
  p.put_int(popn_command+"just_the_ogive",1);
}

template<CDVM>
void Selectivity_at<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // extract the ogive-at from popn.results
  DEBUG1("Selectivity_at::calculate_fits");
  int max_class_in_result, col_in_fits;
  MATRIX *result;
  if (sexed){
    for (int y=1; y<=this->n_years; y++){
          if (!in(popn.results.numbers_at[this->label],(int)((*(this->years))[y]))) continue;
      result = new MATRIX(popn.results.numbers_at[this->label][(int)((*(this->years))[y])]);
      max_class_in_result = result->colmax();
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){  // extract male results
        col_in_fits = int(i-min_class[1]+1);
        (*(this->fits))[y][col_in_fits] = (*result)[1][i];
      }

      for (int i=int(min_class[2]); i<=int(max_class[2]); i++){  // extract female results
        col_in_fits = int(i-min_class[2]+1+n_classes[1]);
                (*(this->fits))[y][col_in_fits] = (*result)[2][i];
      }
      delete result;
    }
  } else {  // unsexed
    for (int y=1; y<=this->n_years; y++){
          if (!in(popn.results.numbers_at[this->label],(int)((*(this->years))[y]))) continue;
      result = new MATRIX(popn.results.numbers_at[this->label][(int)((*(this->years))[y])]);
      max_class_in_result = result->colmax();
      for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
        col_in_fits = int(i-min_class[1]+1);
        (*(this->fits))[y][col_in_fits] = (*result)[1][i];
      }
      delete result;
    }
  }
}

template<CDVM>
void Selectivity_at<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  // not implemented
  DEBUG1("Selectivity_at::write_to_file");
  fatal("Never use write_to_file on Selectivity_at observations.");
}

template<CDVM>
void Selectivity_at<DVM>::print(ostream& out, int print_fits, int print_resids,
                                              int print_pearson_resids, int print_normalised_resids){
  DEBUG2("Selectivity_at::print");
  out << "ogive-at-" << (at_size ? "size " : "age ") << selectivity_name << (sexed ? " by sex" : "") << " in time step " << step << ((proportion_mortality!=0.5) ? (" after proportion " + dtos(proportion_mortality) + " of mortality") : "") << ((area!="") ? (" in area " + area) : "") << ((stock!="") ? (" in stock " + stock) : "") << (mature_only ? " for mature fish only " : " ") << "\n";
  print_header(out,"obs");
  for (int y=1; y<=this->n_years; y++){
    out << (*(this->years))[y] << " ";
    for (int i=1; i<=this->obs_per_year; i++){
      out << setw(7) << (*(this->obs))[y][i] << " ";
    }
    out << '\n';
  }
  if (print_fits){
      print_header(out,"fits");
      for (int y=1; y<=this->n_years; y++){
        out << (*(this->years))[y] << " ";
        for (int i=1; i<=this->obs_per_year; i++){
          out << setw(7) << (*(this->fits))[y][i] << " ";
        }
        out << '\n';
      }
  }
  if (print_resids){
      MATRIX resids(this->get_resids());
      print_header(out,"resids");
      for (int y=1; y<=this->n_years; y++){
        out << (*(this->years))[y] << " ";
        for (int i=1; i<=this->obs_per_year; i++){
          out << setw(7) << resids[y][i] << " ";
        }
        out << '\n';
      }
  }
  if (print_pearson_resids){
      MATRIX pearson_resids(this->get_pearson_resids());
      print_header(out,"pearson_resids");
      for (int y=1; y<=this->n_years; y++){
        out << (*(this->years))[y] << " ";
        for (int i=1; i<=this->obs_per_year; i++){
          out << setw(7) << pearson_resids[y][i] << " ";
        }
        out << '\n';
      }
  }
  if (print_normalised_resids && this->objective->normalised_resids_defined()){
      MATRIX normalised_resids(this->get_normalised_resids());
      print_header(out,"normalised_resids");
      for (int y=1; y<=this->n_years; y++){
        out << (*(this->years))[y] << " ";
        for (int i=1; i<=this->obs_per_year; i++){
          out << setw(7) << normalised_resids[y][i] << " ";
        }
        out << '\n';
      }
  }
  out << "objective function: ";
  this->objective->print(out);
  out << '\n';
}

template<CDVM>
void Selectivity_at<DVM>::print_header(ostream& out, const std::string& what_it_is){
  // called repeatedly by print()
  DEBUG2("Selectivity_at::print_header");
  out << setprecision(6);
  if (sexed){
    out << what_it_is << " (male then female" << "):\nclass ";
    for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
          out << "M" << i << " ";}
    for (int i=int(min_class[2]); i<=int(max_class[2]); i++){
          out << "F" << i << " ";}
  } else {
    out << what_it_is << ":\nclass ";
    for (int i=int(min_class[1]); i<=int(max_class[1]); i++){
          out << setw(7) << i << " ";}
  }
  out << '\n';
}

template<CDVM>
Selectivity_at<DVM>::Selectivity_at(Basic_population_section<DVM>& popn,
                                                        Parameter_set<DVM>& e,
                                                        const std::string& _label, int pseudo)
  : command("selectivity_at[" + _label + "].")
  , n_classes(1+e.get_bool(command+"sexed",popn.state.sex_partition))
  , min_class(1+e.get_bool(command+"sexed",popn.state.sex_partition))
  , max_class(1+e.get_bool(command+"sexed",popn.state.sex_partition)){
  // Construct the Selectivity_at observation from the Parameter_set,
  // extracting any other necessary information from the Population_section (e.g. n_areas etc)
  DEBUG1("Selectivity_at::Selectivity_at");
  this->label = _label;
  step = e.get_int(command+"step");
  if (!popn.annual_cycle->valid_step(step)){
          fatal("Bad time step " + itos(step) + " for observation with label " + this->label);}
  this->years = new dvector(e.get_constant_vector(command+"years"));
  n_years = this->years->size();
  at_size = popn.state.size_based;
  sexed = e.get_bool(command+"sexed",popn.state.sex_partition);
  selectivity_name = e.get_string(command+"ogive");
  if (selectivity_name != "none" && !popn.annual_cycle->valid_selectivity(selectivity_name)){
          fatal("Bad selectivity " + selectivity_name + " for observation with label " + this->label);}
  if (popn.state.n_areas > 1){
          area = e.get_string(command+"area");
          if (!popn.state.valid_area(area)){
                  fatal("Bad area " + area + " for observations with label " + this->label);}
  } else area="";
  stock = e.get_string(command+"stock","");
  proportion_mortality = e.get_constant(command+"proportion_mortality",0.5);
  mature_only = e.get_bool(command+"mature_only",0);
  this->do_bootstrap = e.get_bool(command+"do_bootstrap",1); // error if T
  // class numbers - a bit more fiddly
  if (e.present(command+"min_class")){
    if (e.get_constant_vector(command+"min_class").size()!=min_class.size()){
      fatal("Wrong size for argument " + command + "min_class - should be " + itos(min_class.size()));}
    min_class = e.get_constant_vector(command+"min_class");
    if(!(!popn.state.size_based && at_size) && min(min_class) < popn.state.col_min)
      fatal("For selectivity_at[" + _label + "] an element of min_class is less than the number of the lowest partition age/size class.");
  } else {
    min_class = popn.state.col_min;
  }
  if (e.present(command+"max_class")){
    if (e.get_constant_vector(command+"max_class").size()!=max_class.size()){
      fatal("Wrong size for argument " + command + "max_class - should be " + itos(max_class.size()));}
    max_class = e.get_constant_vector(command+"max_class");
  } else {
        max_class = popn.state.col_max;
  }
  n_classes = max_class - min_class + 1;
  obs_per_year = (int)sum(n_classes);
  this->fits = new MATRIX(1,n_years,1,obs_per_year);
  this->obs = new MATRIX(1,n_years,1,obs_per_year);
  if (pseudo){
    this->obs->initialize();
    this->objective = 0;
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->final){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for pseudo-observation " + command);
    }
  } else {
    for (int y=1; y<=this->n_years; y++){
      double year = (*(this->years))[y];
      if (e.get_constant_vector(command+dtos(year)).size() != obs_per_year){
          fatal("Wrong number of observations for year " + dtos(year) + " of " + this->label + ": should be " +
          itos(obs_per_year) + ". You may have omitted or misspecified the min_class or max_class arguments.\n");
      }
      (*(this->obs))[y] = e.get_constant_vector(command+dtos(year));
    }
    this->objective = make_objective<DVM>(e,command,*(this->years),obs_per_year,this->label);
    if (min(*(this->years)) < popn.annual_cycle->initial || max(*(this->years)) > popn.annual_cycle->current){
      cerr << "years " << *(this->years) << '\n';
      fatal("Invalid years for observation " + command);
    }
  }
}

template<CDVM>
void Tag_release<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  // Put entries into the Parameter_set to tell the population section what results to return.
  // Ask for numbers-at results immediately after the tagging episode, but before applying handling mortality.
  DEBUG1("Tag_release::set_request_parameters");
  std::string popn_command = "numbers_at[" + this->label + "].";
  dvector years(1,1);
  years[1]=year;
  p.put_constant_vector(popn_command+"years",years);
  p.put_string(popn_command+"tagging_episode",tag_label);
  p.put_string(popn_command+"tag",tag);
  p.put_int(popn_command+"sexed",sexed);
  p.put_int(popn_command+"step",step);
  if (area != "") p.put_string(popn_command+"area",area);
  if (stock != "") p.put_string(popn_command+"stock",stock);
  p.put_int(popn_command+"at_size",1);
  p.put_constant_vector(popn_command+"class_mins",class_mins);
  p.put_int(popn_command+"plus_group",plus_group);
}

template<CDVM>
void Tag_release<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  // -extract the numbers by size class from popn.results
  // -very easy compared to most of the calculate_fits functions!!
  DEBUG1("Tag_release::calculate_fits");
  MATRIX result(popn.results.numbers_at[this->label][year]);
  if (sexed){
          for (int i=1; i<=n_classes; i++){
                  (*(this->fits))[1][i]=result[1][i];
                  (*(this->fits))[1][i+n_classes]=result[2][i];
          }
  } else if (!sexed){
          for (int i=1; i<=n_classes; i++){
                  (*(this->fits))[1][i]=result[1][i];
          }
  }
  (*(this->fits))[1] /= sum((*(this->fits))[1]);
}

template<CDVM>
void Tag_release<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Tag_release::write_to_file");
  o << "@tag_release " << this->label << '\n';
  o << "# simulated observations\n";
  std::string command = "tag_release["+this->label+"].";
  Parameter_set<DVM> obs_pars;
  e.extract_subcommands_of_command(obs_pars,"tag_release",this->label);
  // replace original counts with simulated counts
  if (sexed){
        dvector male_rates(1,n_classes);
        dvector female_rates(1,n_classes);
        for (int i=1; i<=n_classes; i++){
                male_rates[i] = value((*(this->obs))[1][i]);
                female_rates[i] = value((*(this->obs))[1][i+n_classes]);
        }
        obs_pars.put_constant_vector(command+"props_male",male_rates);
        obs_pars.put_constant_vector(command+"props_female",female_rates);
  } else if (!sexed){
        dvector rates(value((*(this->obs))[1]));
        obs_pars.put_constant_vector(command+"props_all",rates);
  }
  obs_pars.dump_as_subcommands(o);
}

template<CDVM>
void Tag_release<DVM>::print(ostream& out, int print_fits,
                              int print_resids, int print_pearson_resids,
                              int print_normalised_resids){
  DEBUG2("Tag_release::print");
  out << "size frequency of tagged fish " << (sexed?"(sexed) ":"") << "in tagging episode " << tag_label << ", before applying tagging mortality" << '\n';
  print_header(out,"obs");
  int n_years=1;
  for (int y=1; y<=n_years; y++){
    out << (*(this->years))[y] << " ";
    for (int i=1; i<=this->obs_per_year; i++){
      out << setw(7) << (*(this->obs))[y][i] << " ";
    }
    out << '\n';
  }
  if (print_fits){
    print_header(out,"fits");
    for (int y=1; y<=n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << (*(this->fits))[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_resids){
    MATRIX resids(this->get_resids());
    print_header(out,"resids");
    for (int y=1; y<=n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_pearson_resids){
    MATRIX pearson_resids(this->get_pearson_resids());
    print_header(out,"pearson_resids");
    for (int y=1; y<=n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << pearson_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  if (print_normalised_resids && this->objective->normalised_resids_defined()){
    MATRIX normalised_resids(this->get_normalised_resids());
    print_header(out,"normalised_resids");
    for (int y=1; y<=n_years; y++){
      out << (*(this->years))[y] << " ";
      for (int i=1; i<=this->obs_per_year; i++){
        out << setw(7) << normalised_resids[y][i] << " ";
      }
      out << '\n';
    }
  }
  out << "objective function: ";
  this->objective->print(out);
  out << '\n';
}

template<CDVM>
void Tag_release<DVM>::print_header(ostream& out, const std::string& what_it_is){
  // called repeatedly by print()
  DEBUG2("Tag_release::print_header");
  out << setprecision(6);
  out << what_it_is << (plus_group ? " (last class is a plus group)" : "") << ":\nclass ";
  for (int i=1; i<=n_classes; i++){
      out << setw(7) << i << " ";}
  out << '\n';
}

template<CDVM>
Tag_release<DVM>::Tag_release(Basic_population_section<DVM>& popn,
                              Parameter_set<DVM>& e,
                              const std::string& _label,
                              int pseudo)
  : command("tag_release[" + _label + "].")
  , class_mins(e.get_constant_vector(command+"class_mins")){
  // Construct the Tag_release observation from the Parameter_set,
  // extracting any other necessary information from the Population_section (e.g. n_areas etc)
  DEBUG1("Tag_release::Tag_release");
  this->label = _label;
  tag_label = e.get_string(command+"tag_label");
  plus_group = e.get_int(command+"plus_group",1);
  if (e.present(command+"props_male") && e.present(command+"props_female")){
          sexed=1;
  } else if (e.present(command+"props_male") || e.present(command+"props_female")){
          fatal("In Tag_release block " + this->label + ", you need to supply both props_male and props_female (or just props_all)");
  } else if (e.present(command+"props_all")==0){
          fatal("In Tag_release block " + this->label + ", you need to supply either props_all, or both props_male and props_female");
  } else {
          sexed=0;
  }
  // some info has to come out of the tagging part of the population section
  TaggingFish<DVM>* tag_block=0;
  for (int i=1; i<popn.annual_cycle->tagging.size(); i++){
          if (popn.annual_cycle->tagging[i]->episode_label == tag_label){
                  tag_block = popn.annual_cycle->tagging[i];
                  break;
          }
  }
  if (tag_block==0) fatal("Unknown tagging episode " + tag_label + " in tag_release block " + this->label + " - use the label of a @tag block from your population parameter file.");
  tag = tag_block->tag_name;
  year = tag_block->year;
  this->years = new dvector(1,1);
  (*(this->years))[1]=year;
  step = tag_block->step;
  area = tag_block->area;
  stock = tag_block->stock;
  n_classes = class_mins.size()-1+plus_group;
  obs_per_year = (1+sexed)*n_classes;
  this->fits = new MATRIX(1,1,1,obs_per_year);
  this->obs = new MATRIX(1,1,1,obs_per_year);
  this->do_bootstrap = e.get_bool(command+"do_bootstrap",1);
  if (pseudo){
    this->obs->initialize();
    this->objective = 0;
  } else {
          if (sexed){
                  dvector male_rates(e.get_constant_vector(command+"props_male"));
                  dvector female_rates(e.get_constant_vector(command+"props_female"));
          if (male_rates.size()!=n_classes || female_rates.size()!=n_classes){
                          fatal("The tagged size frequency in Tag_release block " + this->label + " is the wrong size, it was expected to contain " + itos(n_classes) + " elements");
                  }
                  for (int i=1; i<=n_classes; i++){
                          (*(this->obs))[1][i]=male_rates[i];
                          (*(this->obs))[1][i+n_classes]=female_rates[i];
                  }
          } else if (!sexed){
                  dvector all_rates(e.get_constant_vector(command+"props_all"));
                  if (all_rates.size()!=n_classes){
                          fatal("The tagged size frequency in Tag_release block " + this->label + " is the wrong size, it was expected to contain " + itos(n_classes) + " elements");
                  }
                  for (int i=1; i<=n_classes; i++){
                          (*(this->obs))[1][i]=all_rates[i];
                  }
          }
          if (fabs(value(sum((*(this->obs))[1]))-1)>=0.01){
            fatal("The size frequency in Tag_release block " + this->label + " should add up to 1 (for both sexes combined, if the observations are sexed). In fact it adds up to "+dtos(value(sum((*(this->obs))[1]))));}
          if (!e.present(command+"N")) fatal("In Tag_release block " + this->label + ", subcommand N (the sample size in the binomial likelihood) was expected and not found");
      this->objective = make_objective<DVM>(e,command,*(this->years),obs_per_year,this->label);
   }
}

template<CDVM>
DOUBLE Tag_recapture<DVM>::get_objective_function(){
    // just return sum of neg-log-likelihood over fish
    // hard work is done by calculate_fits
    DEBUG1("Tag_recapture::get_objective_function");
    DOUBLE total=0;
        for (int y=1; y<=n_years; y++){
       total += sum(neg_log_likelihoods[y]);}
    if (sample=="age-size"){
          for (int y=1; y<=n_years; y++){
        total += sum(scan_neg_log_likelihoods[y]);}}
    return(total/dispersion);
}

template<CDVM>
MATRIX Tag_recapture<DVM>::get_resids(){
        // do nothing - residuals not defined
        DEBUG2("Tag_recapture::get_resids");
        return MATRIX(1,1);
}

template<CDVM>
MATRIX Tag_recapture<DVM>::get_pearson_resids(){
        // do nothing - residuals not defined
        DEBUG2("Tag_recapture::get_pearson_resids");
        return MATRIX(1,1);
}

template<CDVM>
MATRIX Tag_recapture<DVM>::get_normalised_resids(){
        // do nothing - residuals not defined
        DEBUG2("Tag_recapture::get_normalised_resids");
        return MATRIX(1,1);
}

template<CDVM>
void Tag_recapture<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  // Put entries into the Parameter_set to tell the population section what results to return.
  DEBUG1("Tag_recapture::set_request_parameters");
  // Ask for numbers-at and tagged-numbers-at results,
  //  which will be used to calculate proportions tagged.
  if (sample=="size" || sample=="age" || sample=="age-size" || sample=="growth"){
          // first put in a request for total numbers-at
          std::string popn_command = "numbers_at[" + this->label + "_total].";
          p.put_constant_vector(popn_command+"years",*(this->years));
          p.put_int(popn_command+"step",step);
          p.put_int(popn_command+"sexed",sexed);
          p.put_int(popn_command+"at_size",sample=="size");
          p.put_constant(popn_command+"proportion_mortality",proportion_mortality);
          if (area != "") p.put_string(popn_command+"area",area);
          if (class_mins.size()!=1 && sample=="size"){
                p.put_constant_vector(popn_command+"class_mins",class_mins);
                p.put_int(popn_command+"plus_group",plus_group);
          }
          if (selectivity_name != "none") p.put_string(popn_command+"ogive",selectivity_name);
          // second put in a request for tagged numbers_at
          popn_command = "numbers_at[" + this->label + "_tagged].";
          p.put_string(popn_command+"tag",tag_name);
          p.put_constant_vector(popn_command+"years",*(this->years));
          p.put_int(popn_command+"step",step);
          p.put_int(popn_command+"sexed",sexed);
          p.put_int(popn_command+"at_size",sample=="size");
          p.put_constant(popn_command+"proportion_mortality",proportion_mortality);
          if (area != "") p.put_string(popn_command+"area",area);
          if (class_mins.size()!=1 && sample=="size"){
                p.put_constant_vector(popn_command+"class_mins",class_mins);
                p.put_int(popn_command+"plus_group",plus_group);
          }
          if (selectivity_name != "none") p.put_string(popn_command+"ogive",selectivity_name);
  }
  if (sample=="age-size"){
          // We also need some more results - the selected numbers-at-size in the appropriate part of the partition.
          // Can use this for the 'scanned' part of the likelihood.
          std::string popn_command = "numbers_at[" + this->label + "_size].";
          p.put_constant_vector(popn_command+"years",*(this->years));
          p.put_int(popn_command+"step",step);
          p.put_int(popn_command+"sexed",sexed);
          p.put_int(popn_command+"at_size",1);
          p.put_constant(popn_command+"proportion_mortality",proportion_mortality);
          if (area != "") p.put_string(popn_command+"area",area);
          p.put_constant_vector(popn_command+"class_mins",class_mins);
          p.put_int(popn_command+"plus_group",plus_group);
          if (selectivity_name != "none") p.put_string(popn_command+"ogive",selectivity_name);
  }
}

template<CDVM>
void Tag_recapture<DVM>::calculate_fits(Basic_population_section<DVM>& popn){
  DEBUG1("Tag_recapture::calculate_fits");
  if (sample=="age-size"){
          // Calculate likelihoods for scanned data
          MATRIX *result;
          int col_in_fits;
          for (int y=1; y<=this->n_years; y++){
                  // fill in the selected proportions in each size class, from the results object
          result = new MATRIX(popn.results.numbers_at[this->label+"_size"][(int)((*(this->years))[y])]);
                  if (!sexed){
                          for (int i=min_scanned_class; i<=max_scanned_class; i++){
                                col_in_fits = int(i-min_scanned_class+1);
                                popn_size_props[y][col_in_fits] = (*result)[1][i];
                          }
                  } else if (sexed){
                          for (int i=min_scanned_class; i<=max_scanned_class; i++){
                                col_in_fits = int(i-min_scanned_class+1);
                                popn_size_props[y][col_in_fits] = (*result)[1][i];
                                popn_size_props[y][col_in_fits+n_scanned_classes] = (*result)[2][i];
                          }
                  }
                  popn_size_props[y] /= sum(popn_size_props[y]); // numbers to proportions
                  // use this to calculate the likelihood
                  for (int i=1; i<=scanned_obs_per_year; i++){
              double N = sum(scanned[y]);
              DOUBLE P = popn_size_props[y][i];
              double O = scanned[y][i];
              double term1, term2;
              DOUBLE term3;
              term1 = -lngamma(N+1) / obs_per_year;
              term2 = lngamma(O+1);
              term3 = -O*log(zerofun(P,delta));
                      neg_log_likelihoods[y][i] = term1 + term2 + term3;
                  }
          delete result;
          }
  }
  if (sample=="size" || sample=="age" || sample=="age-size"){
          // Get the information out of the results object to fill in the 'expected_props' object
          int max_class_in_result, col_in_fits;
          MATRIX *total_result, *tagged_result;
          VECTOR *total_temp, *tagged_temp;
          total_temp = new VECTOR(1,obs_per_year);
          tagged_temp = new VECTOR(1,obs_per_year);
          for (int y=1; y<=this->n_years; y++){
                total_result = new MATRIX(popn.results.numbers_at[this->label+"_total"][(int)((*(this->years))[y])]);
                tagged_result = new MATRIX(popn.results.numbers_at[this->label+"_tagged"][(int)((*(this->years))[y])]);
            if (sample=="age-size"){
                  // Fill in estimated scanned numbers by age class, which will be used as the N in the recaptures likelihood below
                  // Note this is before applying ageing error - these are true not observed numbers
          double n_scanned = sum(scanned[y]);
          DOUBLE multiply_by = n_scanned / (sexed ? sum((*total_result)[1])+sum((*total_result)[2]) : sum((*total_result)[1]));
                        if (!sexed){
                          for (int i=min_recaptured_class; i<=max_recaptured_class; i++){
                                col_in_fits = int(i-min_recaptured_class+1);
                                scanned_by_age[y][col_in_fits] = multiply_by*(*total_result)[1][i];
                          }
                        } else if (sexed){
                          for (int i=min_recaptured_class; i<=max_recaptured_class; i++){  // extract male results
                                col_in_fits = int(i-min_recaptured_class+1);
                                scanned_by_age[y][col_in_fits] = multiply_by*(*total_result)[1][i];
                          }
                          for (int i=min_recaptured_class; i<=max_recaptured_class; i++){  // extract female results
                                col_in_fits = int(i-min_recaptured_class+1+n_recaptured_classes);
                                scanned_by_age[y][col_in_fits] = multiply_by*(*total_result)[2][i];
                          }
                        }
            }
                total_temp->initialize();
                tagged_temp->initialize();
                if (ageing_error){
                  if (ageing_error_ptr->ageing_error){
                        ageing_error_ptr->apply(*total_result);
                        ageing_error_ptr->apply(*tagged_result);
                  }
                }
                max_class_in_result = total_result->colmax();
                if (!sexed){
                  for (int i=min_recaptured_class; i<=max_recaptured_class; i++){
                        col_in_fits = int(i-min_recaptured_class+1);
                        (*total_temp)[col_in_fits] = (*total_result)[1][i];
                        (*tagged_temp)[col_in_fits] = (*tagged_result)[1][i];
                  }
                } else if (sexed){
                  for (int i=min_recaptured_class; i<=max_recaptured_class; i++){  // extract male results
                        col_in_fits = int(i-min_recaptured_class+1);
                        (*total_temp)[col_in_fits] = (*total_result)[1][i];
                        (*tagged_temp)[col_in_fits] = (*tagged_result)[1][i];
                  }
                  for (int i=min_recaptured_class; i<=max_recaptured_class; i++){  // extract female results
                        col_in_fits = int(i-min_recaptured_class+1+n_recaptured_classes);
                        (*total_temp)[col_in_fits] = (*total_result)[2][i];
                        (*tagged_temp)[col_in_fits] = (*tagged_result)[2][i];
                  }
                }
                for (int i=1; i<=this->obs_per_year; i++){
                  if ((*total_temp)[i]>0){
                        expected_props[y][i] = detection_probability * (*tagged_temp)[i] / (*total_temp)[i];
                  } else {
                        expected_props[y][i] = 0;
                  }
                }
                delete total_result;
                delete tagged_result;
          }
          delete total_temp;
          delete tagged_temp;
          // Check, is detection_probability legitimate?
          if (detection_probability<=0 || detection_probability>1){
                  fatal("In "+this->label+", detection probability has taken the illegal value of " + dtos(value(detection_probability))); }
          // now use expected_props to calculate the neg-log-likelihood components
          for (int y=1; y<=this->n_years; y++){
                for (int i=1; i<=this->obs_per_year; i++){
                  DOUBLE N,O,P;
                  N = (sample!="age-size"?scanned:scanned_by_age)[y][i];
                  O = recaptured[y][i];
                  P = expected_props[y][i];
                  if (O>N) neg_log_likelihoods[y][i]=0; else {
                   DOUBLE term1, term2;
                   term1 = O*log(zerofun(P,delta)) + (N-O)*log(zerofun(1-P,delta));
                   term2 = lngamma(O+1) + lngamma(N-O+1) - lngamma(N+1);
                   neg_log_likelihoods[y][i] = term2-term1;
                  }
                }
          }
  } else if (sample=="growth"){
          // more straightforward. No scanned fish, just compare observed & expected size distns
          // Get the information out of the results object to fill in the 'expected_props' object
          int max_class_in_result, col_in_fits;
          MATRIX *tagged_result;
          VECTOR *tagged_temp;
          tagged_temp = new VECTOR(1,obs_per_year);
          for (int y=1; y<=this->n_years; y++){
                tagged_result = new MATRIX(popn.results.numbers_at[this->label+"_tagged"][(int)((*(this->years))[y])]);
                tagged_temp->initialize();
                max_class_in_result = tagged_result->colmax();
                if (!sexed){
                  for (int i=min_recaptured_class; i<=max_recaptured_class; i++){
                        col_in_fits = int(i-min_recaptured_class+1);
                        (*tagged_temp)[col_in_fits] = (*tagged_result)[1][i];
                  }
                } else if (sexed){
                  for (int i=min_recaptured_class; i<=max_recaptured_class; i++){  // extract male results
                        col_in_fits = int(i-min_recaptured_class+1);
                        (*tagged_temp)[col_in_fits] = (*tagged_result)[1][i];
                  }
                  for (int i=min_recaptured_class; i<=max_recaptured_class; i++){  // extract female results
                        col_in_fits = int(i-min_recaptured_class+1+n_recaptured_classes);
                        (*tagged_temp)[col_in_fits] = (*tagged_result)[2][i];
                  }
                }
                for (int i=1; i<=this->obs_per_year; i++){
                        expected_props[y][i] = (*tagged_temp)[i] / sum(*tagged_temp);
                }
                delete tagged_result;
          }
          delete tagged_temp;
          // now use expected_props to calculate the neg-log-likelihood components
          for (int y=1; y<=this->n_years; y++){
                for (int i=1; i<=this->obs_per_year; i++){
           double N = sum(recaptured[y]);
           DOUBLE P = expected_props[y][i];
           double O = recaptured[y][i];
           double term1, term2;
           DOUBLE term3;
           term1 = -lngamma(N+1) / obs_per_year;
           term2 = lngamma(O+1);
           term3 = -O*log(zerofun(P,delta));
                   neg_log_likelihoods[y][i] = term1 + term2 + term3;
                }
          }
        }
}

template<CDVM>
void Tag_recapture<DVM>::parametric_bootstrap(long int seed){
  // Randomise the observations around the fits (discarding the original observations).
  // For most observations types the inherited version of this function is used,
  // but for Tag_recapture it has to be overridden as the 'objective' pointer is null
  DEBUG2("Tag_recapture::parametric_bootstrap");
  if (sample=="size" || sample=="age" || sample=="age-size"){
      // Overwrite the original recaptured numbers with the simulated observations
          for (int y=1; y<=this->n_years; y++){
                 if (sexed){
                        dvector recaptured_male(1,n_recaptured_classes);
                        dvector recaptured_female(1,n_recaptured_classes);
                        for (int i=1; i<=n_recaptured_classes; i++){
                                double prop_male = value(expected_props[y][i]);
                                double prop_female = value(expected_props[y][i+n_recaptured_classes]);
                                double scanned_male = floor((sample!="age-size"?scanned[y][i]:value(scanned_by_age[y][i])));
                                double scanned_female = floor((sample!="age-size"?scanned[y][i+n_recaptured_classes]:value(scanned_by_age[y][i+n_recaptured_classes])));
                                recaptured_male[i] = rbinomial(seed,(int)scanned_male,prop_male);
                                recaptured_female[i] = rbinomial(seed,(int)scanned_female,prop_female);
                        }
                        for (int i=1; i<=n_recaptured_classes; i++){
                                recaptured[y][i] = recaptured_male[i];
                                recaptured[y][i+n_recaptured_classes] = recaptured_female[i];
                        }
                 } else if (!sexed){
                        dvector recaptured_all(1,n_recaptured_classes);
                        for (int i=1; i<=n_recaptured_classes; i++){
                                double prop_all = value(expected_props[y][i]);
                                double scanned_all = floor((sample!="age-size"?scanned[y][i]:value(scanned_by_age[y][i])));
                                recaptured_all[i] = rbinomial(seed,(int)scanned_all,prop_all);
                        }
                        for (int i=1; i<=n_recaptured_classes; i++){
                                recaptured[y][i] = recaptured_all[i];
                        }
                }
          }
  }
  if (sample=="age-size"){
          // we also have to randomize the scanned numbers by length
          //  (we're holding the scanned numbers at age constant)
          // Use popn_size_props - element [y][i] is relevant population proportion in size class i in year y - sum over i is 1 for each y
          dvector random_row(1,scanned_obs_per_year);
          for (int y=1; y<=this->n_years; y++){
                random_row.fill_multinomial_counts(seed,value(popn_size_props[y]),(int)(floor(sum(scanned[y]))));
                scanned[y] = random_row;
          }
  }
  if (sample=="growth"){
      // Overwrite the original recaptured numbers with the simulated observations
          // We now do not have scanned numbers; the scanned object contains the original values of the recaptured object,
          //  which we will use to get total numbers of fish recaptured by year.
          for (int y=1; y<=this->n_years; y++){
                 int year_total = (int)(floor(sum(scanned[y])));
                 if (sexed){
                        dvector recaptured_male(1,n_recaptured_classes);
                        dvector recaptured_female(1,n_recaptured_classes);
                        for (int i=1; i<=n_recaptured_classes; i++){
                                double prop_male = value(expected_props[y][i]);
                                double prop_female = value(expected_props[y][i+n_recaptured_classes]);
                                recaptured_male[i] = rbinomial(seed,year_total,prop_male);
                                recaptured_female[i] = rbinomial(seed,year_total,prop_female);
                        }
                        for (int i=1; i<=n_recaptured_classes; i++){
                                recaptured[y][i] = recaptured_male[i];
                                recaptured[y][i+n_recaptured_classes] = recaptured_female[i];
                        }
                 } else if (!sexed){
                        for (int i=1; i<=n_recaptured_classes; i++){
                                double prop_all = value(expected_props[y][i]);
                                recaptured[y][i] = rbinomial(seed,year_total,prop_all);
                        }
                }
          }
  }
}

template<CDVM>
void Tag_recapture<DVM>::write_to_file(ostream &o, Parameter_set<DVM> &e){
  // kick the observations out to a parameter file
  DEBUG1("Tag_recapture::write_to_file");
  o << "@tag_recapture " << this->label << '\n';
  o << "# simulated observations\n";
  std::string command = "tag_recapture["+this->label+"].";
  Parameter_set<DVM> obs_pars;
  e.extract_subcommands_of_command(obs_pars,"tag_recapture",this->label);
  if (sample=="size" || sample=="age" || sample=="age-size" || sample=="growth"){
          // we have to overwrite the original recaptured numbers with the simulated observations
          for (int y=1; y<=this->n_years; y++){
                 if (sexed){
                        dvector recaptured_male(1,n_recaptured_classes);
                        dvector recaptured_female(1,n_recaptured_classes);
                        for (int i=1; i<=n_recaptured_classes; i++){
                                recaptured_male[i] = recaptured[y][i];
                                recaptured_female[i] = recaptured[y][i+n_recaptured_classes];
                        }
                        obs_pars.put_constant_vector(command+"recaptured_male_"+itos((int)((*(this->years))[y])),recaptured_male);
                        obs_pars.put_constant_vector(command+"recaptured_female_"+itos((int)((*(this->years))[y])),recaptured_female);
                 } else if (!sexed){
                        dvector recaptured_all(1,n_recaptured_classes);
                        for (int i=1; i<=n_recaptured_classes; i++){
                                recaptured_all[i] = recaptured[y][i];
                        }
                        obs_pars.put_constant_vector(command+"recaptured_"+itos((int)((*(this->years))[y])),recaptured_all);
                 }
          }
  }
  if (sample=="age-size"){
          // we may also have to overwrite the scanned numbers
          for (int y=1; y<=this->n_years; y++){
                 if (sexed){
                        dvector scanned_male(1,n_scanned_classes);
                        dvector scanned_female(1,n_scanned_classes);
                        for (int i=1; i<=n_scanned_classes; i++){
                                scanned_male[i] = scanned[y][i];
                                scanned_female[i] = scanned[y][i+n_scanned_classes];
                        }
                        obs_pars.put_constant_vector(command+"scanned_male_"+itos((int)((*(this->years))[y])),scanned_male);
                        obs_pars.put_constant_vector(command+"scanned_female_"+itos((int)((*(this->years))[y])),scanned_female);
                 } else if (!sexed){
                        dvector scanned_all(1,n_scanned_classes);
                        for (int i=1; i<=n_scanned_classes; i++){
                                scanned_all[i] = scanned[y][i];
                        }
                        obs_pars.put_constant_vector(command+"scanned_"+itos((int)((*(this->years))[y])),scanned_all);
                 }
          }
  }
  obs_pars.dump_as_subcommands(o);
}

template<CDVM>
void Tag_recapture<DVM>::print(ostream& out, int print_fits,
                              int print_resids, int print_pearson_resids,
                              int print_normalised_resids){
  // Quite different to the print functions of the other observations classes.
  // We never print fits or any kind of residuals for Age_size observations.
  // But if print_fits is set, we print the negative-log-likelihood for each fish.
  DEBUG2("Tag_recapture::print");
  out << "tag-recapture data for tag " << tag_name << " in years " << *(this->years) << ", step " << step << ", after proportion " << proportion_mortality << " of mortality";
  if (area!="") out << ", in area " << area;
  if (selectivity_name!="none") out << ", using selectivity " << selectivity_name;
  out << ", with sampling method " << sample;
  out << ", detection probability " << detection_probability;
  if(dispersion!=1.0) out << ", dispersion parameter " << dispersion;
  if (ageing_error) out << ", using ageing error";
  out << ".\n";
  if (sample=="size" || sample=="age" || sample=="growth"){
          for (int y=1; y<=this->years->size(); y++){
                  int this_year = (int)((*(this->years))[y]);
                  out << "Year " << this_year << '\n';
                  if (print_fits){
                                if (sexed){
                                  out << "sex class scanned recaptured expected_prop neg_log_likelihood\n";
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << "M " << (sample=="age"?(min_recaptured_class+i-1):class_mins[i]) << " " << scanned[y][i] << " " << recaptured[y][i] << " " << expected_props[y][i] << " " << neg_log_likelihoods[y][i] << '\n';
                                  }
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << "F " << (sample=="age"?(min_recaptured_class+i-1):class_mins[i]) << " " << scanned[y][i+n_recaptured_classes] << " " << recaptured[y][i+n_recaptured_classes] << " " << expected_props[y][i+n_recaptured_classes] << " " << neg_log_likelihoods[y][i+n_recaptured_classes] << '\n';
                                  }
                                } else if (!sexed){
                                  out << "class scanned recaptured expected_prop neg_log_likelihood\n";
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << (sample=="age"?(min_recaptured_class+i-1):class_mins[i]) << " " << scanned[y][i] << " " << recaptured[y][i] << " " << expected_props[y][i] << " " << neg_log_likelihoods[y][i] << '\n';
                                  }
                                }
                        out << '\n';
                        out << "total neg_log_likelihood: " << sum(neg_log_likelihoods[y]) << "\n\n";
                  } else if (!print_fits){
                                if (sexed){
                                  out << "sex class scanned recaptured\n";
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << "M " << (sample=="age"?(min_recaptured_class+i-1):class_mins[i]) << " " << scanned[y][i] << " " << recaptured[y][i] << '\n';
                                  }
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << "F " << (sample=="age"?(min_recaptured_class+i-1):class_mins[i]) << " " << scanned[y][i+n_recaptured_classes] << " " << recaptured[y][i+n_recaptured_classes] << '\n';
                                  }
                                } else if (!sexed){
                                  out << "class scanned recaptured\n";
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << (sample=="age"?(min_recaptured_class+i-1):class_mins[i]) << " " << scanned[y][i] << " " << recaptured[y][i] << '\n';
                                  }
                                }
                        out << "\n";
                  }
                  out << '\n';
          }
  } else if (sample=="age-size"){
          // similar, but we need to show scanned by size and recaptured by age separately
          for (int y=1; y<=this->years->size(); y++){
                  int this_year = (int)((*(this->years))[y]);
                  out << "Year " << this_year << '\n';
                  if (print_fits){
                                if (sexed){
                                  out << "sex class scanned scan_neg_log_likelihood\n";
                                  for (int i=1; i<=n_scanned_classes; i++){
                                        out << "M " << class_mins[i] << " " << scanned[y][i] << " " << scan_neg_log_likelihoods[y][i] << '\n';
                                  }
                                  for (int i=1; i<=n_scanned_classes; i++){
                                        out << "F " << class_mins[i] << " " << scanned[y][i+n_scanned_classes] << " " << scan_neg_log_likelihoods[y][i+n_scanned_classes] << '\n';
                                  }
                                  out << "sex class recaptured scanned_by_age expected_props neg_log_likelihood\n";
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << "M " << min_recaptured_class+i-1 << " " << recaptured[y][i] << " " << scanned_by_age[y][i] << " " << expected_props[y][i] << " " << neg_log_likelihoods[y][i] << '\n';
                                  }
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << "F " << min_recaptured_class+i-1 << " " << recaptured[y][i+n_recaptured_classes] << " " << scanned_by_age[y][i+n_recaptured_classes] << " " << expected_props[y][i+n_recaptured_classes] << " " << neg_log_likelihoods[y][i+n_recaptured_classes] << '\n';
                                  }
                                } else if (!sexed){
                                  out << "class scanned scan_neg_log_likelihood\n";
                                  for (int i=1; i<=n_scanned_classes; i++){
                                        out << class_mins[i] << " " << scanned[y][i] << " " << scan_neg_log_likelihoods[y][i] << '\n';
                                  }
                                  out << "class recaptured scanned_by_age expected_props neg_log_likelihood\n";
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << min_recaptured_class+i-1 << " " << recaptured[y][i] << " " << scanned_by_age[y][i] << " " << expected_props[y][i] << " " << neg_log_likelihoods[y][i] << '\n';
                                  }
                                }
                            out << '\n';
                            out << "total scan_neg_log_likelihood: " << sum(scan_neg_log_likelihoods[y]) << "\n\n";
                            out << "total neg_log_likelihood: " << sum(neg_log_likelihoods[y]) << "\n\n";
                  } else if (!print_fits){
                                if (sexed){
                                  out << "sex class scanned\n";
                                  for (int i=1; i<=n_scanned_classes; i++){
                                        out << "M " << class_mins[i] << " " << scanned[y][i] << '\n';
                                  }
                                  for (int i=1; i<=n_scanned_classes; i++){
                                        out << "F " << class_mins[i] << " " << scanned[y][i+n_scanned_classes] << '\n';
                                  }
                                  out << "sex class recaptured\n";
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << "M " << min_recaptured_class+i-1 << " " << recaptured[y][i] << '\n';
                                  }
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << "F " << min_recaptured_class+i-1 << " " << recaptured[y][i+n_recaptured_classes] << '\n';
                                  }
                                } else if (!sexed){
                                  out << "class scanned\n";
                                  for (int i=1; i<=n_scanned_classes; i++){
                                        out << class_mins[i] << " " << scanned[y][i] << '\n';
                                  }
                                  out << "class recaptured\n";
                                  for (int i=1; i<=n_recaptured_classes; i++){
                                        out << min_recaptured_class+i-1 << " " << recaptured[y][i] << '\n';
                                  }
                                }
                            out << '\n';
                  }
                  out << '\n';
          }
  }
}

template<CDVM>
Tag_recapture<DVM>::Tag_recapture(Basic_population_section<DVM>& popn,
                                                Parameter_set<DVM>& e,
                                                const std::string& _label,
                                                Ageing_error<DVM>* _ageing_error_ptr, int pseudo)
  : command("tag_recapture[" + _label + "].")
  , n_years(e.get_constant_vector(command+"years").size())
  , sample(e.get_string(command+"sample"))
  , class_mins((popn.state.size_based?popn.state.class_mins:e.get_constant_vector(command+"class_mins",dvector("{-1}"))))
  , plus_group(e.get_bool(command+"plus_group",popn.state.plus_group))
  , sexed(e.present(command+"recaptured_male_"+itos((int)(e.get_constant_vector(command+"years")[1]))) && e.present(command+"recaptured_female_"+itos((int)(e.get_constant_vector(command+"years")[1]))))
  , recaptured              (1,n_years,1,(((sample!="size" && sample!="growth")?popn.state.col_max:((popn.state.size_based?popn.state.class_mins:e.get_constant_vector(command+"class_mins")).size()-1+plus_group))-((sample!="size" && sample!="growth")?popn.state.col_min:1)+1)*(sexed+1))
  , expected_props          (1,n_years,1,(((sample!="size" && sample!="growth")?popn.state.col_max:((popn.state.size_based?popn.state.class_mins:e.get_constant_vector(command+"class_mins")).size()-1+plus_group))-((sample!="size" && sample!="growth")?popn.state.col_min:1)+1)*(sexed+1))
  , scanned_by_age          (1,(sample=="age-size"?n_years:1),1,(sample=="age-size"?(popn.state.col_max-popn.state.col_min+1)*(sexed+1):1))
  , neg_log_likelihoods     (1,n_years,1,(((sample!="size" && sample!="growth")?popn.state.col_max:((popn.state.size_based?popn.state.class_mins:e.get_constant_vector(command+"class_mins")).size()-1+plus_group))-((sample!="size" && sample!="growth")?popn.state.col_min:1)+1)*(sexed+1))
  , scanned                 (1,n_years,1,((sample=="age"?popn.state.col_max:((popn.state.size_based?popn.state.class_mins:e.get_constant_vector(command+"class_mins")).size()-1+plus_group))-(sample=="age"?popn.state.col_min:1)+1)*(sexed+1))
  , scan_neg_log_likelihoods(1,(sample=="age-size"?n_years:1),1,(sample=="age-size"?(e.get_constant_vector(command+"class_mins").size()-1+plus_group)*(sexed+1):1))
  , popn_size_props         (1,(sample=="age-size"?n_years:1),1,(sample=="age-size"?(e.get_constant_vector(command+"class_mins").size()-1+plus_group)*(sexed+1):1))
  {
  // Construct the Tag_recapture observation from the Parameter_set,
  // extracting any other necessary information from the Population_section (e.g. n_areas etc)
  DEBUG1("Tag_recapture::Tag_recapture");
  min_recaptured_class = (sample!="size" && sample!="growth")?popn.state.col_min:1;
  max_recaptured_class = (sample!="size" && sample!="growth")?popn.state.col_max:(class_mins.size()-1+plus_group);
  n_recaptured_classes = max_recaptured_class-min_recaptured_class+1;
  obs_per_year = (max_recaptured_class-min_recaptured_class+1)*(sexed+1);
  min_scanned_class = sample=="age"?popn.state.col_min:1;
  max_scanned_class = sample=="age"?popn.state.col_max:(class_mins.size()-1+plus_group);
  n_scanned_classes = max_scanned_class-min_scanned_class+1;
  if (sample=="age-size") scanned_obs_per_year=(max_scanned_class-min_scanned_class+1)*(sexed+1);
  this->label = _label;
  this->years = new dvector(e.get_constant_vector(command+"years"));
  tag_name = e.get_string(command+"tag_name");
  if (!in(popn.state.tag_names,tag_name)) fatal("Unknown tag name " + tag_name + " in tag_recapture block " + this->label + " - use an entry of @tag_names in your population parameter file.");
  if (sample!="age" && sample!="size" && sample!="age-size" && sample!="growth") fatal("In tag_recapture, sample should be age, size, age-size, or growth");
  if (sample=="age" && (e.present(command+"class_mins") || e.present(command+"plus_group"))){
          fatal("In " + this->label + ", you can't specify class_mins or plus_group for at-age observations");}
  if (popn.state.size_based && (e.present(command+"class_mins") || e.present(command+"plus_group"))){
          fatal("In " + this->label + ", you can't specify class_mins or plus_group in an observations block in a size-based model - must use same size classes as in population data file");}
  step = e.get_int(command+"step");
  if (!popn.annual_cycle->valid_step(step)){
          fatal("Bad time step " + itos(step) + " for observation with label " + this->label);}
  std::string first_year = itos((int)((*(this->years))[1]));
  if (sample!="growth"){
          if (e.present(command+"scanned_male_"+first_year) && e.present(command+"scanned_female_"+first_year)){
                  // sexed=1;
          } else if (e.present(command+"scanned_"+first_year)){
                  // sexed=0;
          } else {
                  fatal("In " + this->label + ", you should provide either scanned_male_[year], scanned_female_[year], recaptured_male_[year], and recaptured_female_[year], or scanned_[year] and recaptured_[year], for each year.");
          }
  }
  if (sexed && !popn.state.sex_partition){
          fatal("You have requested sexed tag_recapture observations in an unsexed model");}
  for (int y=1; y<=this->n_years; y++){
          if (sexed){
            dvector *this_scanned_male, *this_recaptured_male, *this_scanned_female, *this_recaptured_female;
            this_recaptured_male = new dvector(e.get_constant_vector(command+"recaptured_male_"+itos((int)((*(this->years))[y]))));
            this_recaptured_female = new dvector(e.get_constant_vector(command+"recaptured_female_"+itos((int)((*(this->years))[y]))));
        if (this_recaptured_male->size() != n_recaptured_classes) fatal("In " + this->label + ", recaptured_male is the wrong length for year " + itos((int)((*(this->years))[y])) + " - should be " + itos(n_recaptured_classes));
        if (this_recaptured_female->size() != n_recaptured_classes) fatal("In " + this->label + ", recaptured_female is the wrong length for year " + itos((int)((*(this->years))[y])) + " - should be " + itos(n_recaptured_classes));
        for (int i=1; i<=n_recaptured_classes; i++){
                        recaptured[y][i]=(*this_recaptured_male)[i];
                        recaptured[y][i+n_recaptured_classes]=(*this_recaptured_female)[i];
                }
            delete this_recaptured_male;
            delete this_recaptured_female;
                if (sample!="growth"){
                        this_scanned_male = new dvector(e.get_constant_vector(command+"scanned_male_"+itos((int)((*(this->years))[y]))));
                        this_scanned_female = new dvector(e.get_constant_vector(command+"scanned_female_"+itos((int)((*(this->years))[y]))));
                        if (this_scanned_male->size() != n_scanned_classes) fatal("In " + this->label + ", scanned_male is the wrong length for year " + itos((int)((*(this->years))[y])) + " - should be " + itos(n_scanned_classes));
                        if (this_scanned_female->size() != n_scanned_classes) fatal("In " + this->label + ", scanned_female is the wrong length for year " + itos((int)((*(this->years))[y])) + " - should be " + itos(n_scanned_classes));
                        for (int i=1; i<=n_scanned_classes; i++){
                                scanned[y][i]=(*this_scanned_male)[i];
                                scanned[y][i+n_scanned_classes]=(*this_scanned_female)[i];
                        }
                        delete this_scanned_male;
                        delete this_scanned_female;
                        if (sample=="age" || sample=="size"){
                          for (int i=1; i<=n_recaptured_classes; i++){
                                if ((scanned[y][i] < recaptured[y][i]) || (scanned[y][i+n_recaptured_classes] < recaptured[y][i+n_recaptured_classes])){
                                fatal("Less scanned fish than recaptured fish for an age/size class in year " + itos((int)((*(this->years))[y])) + " in Tag_recapture observations " + this->label);
                                }
                          }
                        }
            } else scanned[y] = recaptured[y];
      } else if (!sexed){
            dvector *this_scanned, *this_recaptured;
            this_recaptured = new dvector(e.get_constant_vector(command+"recaptured_"+itos((int)((*(this->years))[y]))));
        if (this_recaptured->size() != n_recaptured_classes) fatal("In " + this->label + ", recaptured is the wrong length for year " + itos((int)((*(this->years))[y])) + " - should be " + itos(n_recaptured_classes));
                recaptured[y] = *this_recaptured;
            delete this_recaptured;
                if (sample!="growth"){
                        this_scanned = new dvector(e.get_constant_vector(command+"scanned_"+itos((int)((*(this->years))[y]))));
                        if (this_scanned->size() != n_scanned_classes) fatal("In " + this->label + ", scanned is the wrong length for year " + itos((int)((*(this->years))[y])) + " - should be " + itos(n_scanned_classes));
                        scanned[y] = *this_scanned;
                        delete this_scanned;
                        if (sample=="age" || sample=="size"){
                          for (int i=1; i<=n_recaptured_classes; i++){
                           if ((scanned[y][i] < recaptured[y][i])){
                                fatal("Less scanned fish than recaptured fish for an age/size class in year " + itos((int)((*(this->years))[y])) + " in Tag_recapture observations " + this->label);
                           }
                          }
                        }
				} else scanned[y] = recaptured[y];
      }
  }
  delta = e.get_constant(command+"r",1e-11);
  detection_probability = e.get_estimable(command+"detection_probability",1.0);
  selectivity_name = e.get_string(command+"ogive","none");
  dispersion = e.get_constant(command+"dispersion",1.0);
  if(dispersion <= 0.0) fatal("A dispersion value of " + dtos(dispersion) + " was found in the tag-recapture observation " + this->label + ". Dispersion values less than or equal to zero are not allowed.");
  if (selectivity_name != "none" && !popn.annual_cycle->valid_selectivity(selectivity_name)){
          fatal("Bad selectivity " + selectivity_name + " for observation with label " + this->label);}
  if (selectivity_name!="none" && !((sample=="size" || sample=="age-size") && !popn.state.size_based)){
                fatal("You have requested a selectivity ogive in " + this->label + ", but this is only allowable for tag-recapture observations with sample=size or age-size, in an age-based model.");}
  if (popn.state.n_areas > 1){
          area = e.get_string(command+"area");
          if (!popn.state.valid_area(area)){
                  fatal("Bad area " + area + " for observations with label " + this->label);}
  } else area="";
  proportion_mortality = e.get_constant(command+"proportion_mortality",0.5);
  this->do_bootstrap = e.get_bool(command+"do_bootstrap",1);
  if (e.get_string("ageing_error.type","none")=="none") ageing_error = 0;
  else ageing_error = e.get_bool(command+"ageing_error",sample!="size" && sample!="growth");
  if ((sample=="size" || sample=="growth") && ageing_error) fatal("Tag-recapture at size " + this->label + " requested ageing error");
  if (ageing_error) ageing_error_ptr = _ageing_error_ptr;
  neg_log_likelihoods = 0.0;
  expected_props = 0.0;
  if (pseudo){
    fatal("You cannot use pseudo-observations of tag-recapture data.");}
  this->objective = 0; // we will just zero the remaining pointers, the destructor will know not to try to delete them
  this->fits = 0;
  this->obs = 0;
}

//############################## END OF OBSERVATIONS.cpp ##############################

// Create particular instantiations of the template

template class Observations_dataset<double, dvector, dmatrix>;
template class Observations_dataset<dvariable, dvv, dvm>;
