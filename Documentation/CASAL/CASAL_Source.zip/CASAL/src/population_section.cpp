// const char* time_stamp = "$Date: 2010-11-25 17:02:26 +1300 (Thu, 25 Nov 2010) $\n";
// const char* population_section_cpp_id = "$Id: population_section.cpp 3649 2010-11-25 04:02:26Z fud $\n";

//############################## POPULATION SECTION ##############################
#include "population_section.h"
#include "population_processes.h"
#include "output.h"

//////////////////////////////////////////////////////////////////////////////////
template<CDVM>
void Basic_population_section<DVM>::run_model(int to){
  // Runs the population model, puts the outputs requested in 'requests' into 'results',
  //  prints out stuff as requested.
  // Procedure:
  //  call results.empty;
  //  call set_initial_state;
  //  run annual_cycle->do_year from the start of year annual_cycle->initial
  //  to the end of year to (which defaults to annual_cycle->current);.
  DEBUG0("run_model");
  if (to==0) to=annual_cycle->current;  // the default
  results.empty();
  set_initial_state();
  if (print_requests->population_section){
    annual_cycle->print(state,cout,print_requests->every_mean_size,print_requests->print_sizebased_ogives_at);
    cout << '\n';
  }
  if (print_requests->requests){
    requests.print(state,cout);
    cout << '\n';
  }
  if (print_requests->initial_state){
    cout << "Initial state:\n";
    state.print(cout);
    cout << '\n';
  }
  for (int year = annual_cycle->initial; year <= to; year++){
    annual_cycle->do_year(state,print_requests->state_every_step,"normal",
                          year,&requests,&results);
    if (print_requests->state_annually){
      cout << "State at the end of year " << year << ":\n";
      state.print(cout);
      cout << '\n';
    }
  }
  if (print_requests->final_state){
    cout << "Final state:\n";
    state.print(cout);
    cout << '\n';
  }
  if (print_requests->results){
    results.print(state,requests,cout);
    cout << '\n';
  }
}

template<CDVM>
void Basic_population_section<DVM>::set_annual_cycle(Parameter_set<DVM>& p){
  // Fill in the components of annual_cycle from the parameters in p.
  DEBUG0("set_annual_cycle");
  delete annual_cycle;
  annual_cycle = new Basic_annual_cycle<DVM>(p,state);
}

template<CDVM>
void Basic_population_section<DVM>::set_initial_state(){
  // Set state to the initial state.
  // It is also necessary to call annual_cycle->recruitment[stock]->set_R0, ->set_B0, ->set_Rinitial, ->set_Rmean
  //   for each stock, and to fill in B0, R0, Binitial, Rinitial, Bmean, Rmean in the results object if requested,
  //   and, if there are density-dependent migrations, to set the relevant virgin abundances.
  DEBUG0("set_initial_state");
  state.initialize_partition();
  state.SSBs.initialize();
  VECTOR R0(1,state.n_stocks), Rinitial(1,state.n_stocks), Rmean(1,state.n_stocks);
  VECTOR B0(1,state.n_stocks), Binitial(1,state.n_stocks), Bmean(1,state.n_stocks);
  std::vector<VECTOR> Cinitial, Cinitial_male, Cinitial_female;
  Cinitial.push_back(VECTOR("{-1}")); // dummy entry so indices start at 1
  Cinitial_male.push_back(VECTOR("{-1}"));
  Cinitial_female.push_back(VECTOR("{-1}"));
  int stock_char = state.character_numbers("stock"), this_stock;
  int sex_char = state.character_numbers("sex"), this_sex;
  int n_equilibrium = annual_cycle->initialization[1]->n_equilibrium;
  if (state.size_based && n_equilibrium == 0){
    fatal("Must specify n_equilibrium");}
  int R0_supplied, Rinitial_supplied, Rmean_supplied, B0_supplied, Binitial_supplied, Bmean_supplied;
  int Cinitial_supplied, Cinitial_sexed_supplied;
  R0_supplied = annual_cycle->initialization[1]->R0 > 0;
  for (int stock = 2; stock<=state.n_stocks; stock++){
    if ( R0_supplied && annual_cycle->initialization[stock]->R0 == 0 ||
        !R0_supplied && annual_cycle->initialization[stock]->R0 != 0){
      fatal("You supplied R0 for some stocks but not others");
    }
  }
  B0_supplied = annual_cycle->initialization[1]->B0 > 0;
  for (int stock = 2; stock<=state.n_stocks; stock++){
    if ( B0_supplied && annual_cycle->initialization[stock]->B0 == 0 ||
        !B0_supplied && annual_cycle->initialization[stock]->B0 != 0){
      fatal("You supplied B0 for some stocks but not others");
    }
  }
  Rmean_supplied = annual_cycle->initialization[1]->Rmean > 0;
    for (int stock = 2; stock<=state.n_stocks; stock++){
      if ( Rmean_supplied && annual_cycle->initialization[stock]->Rmean == 0 ||
        !Rmean_supplied && annual_cycle->initialization[stock]->Rmean != 0){
        fatal("You supplied Rmean for some stocks but not others");
      }
    }
  Bmean_supplied = annual_cycle->initialization[1]->Bmean > 0;
    for (int stock = 2; stock<=state.n_stocks; stock++){
      if ( Bmean_supplied && annual_cycle->initialization[stock]->Bmean == 0 ||
        !Bmean_supplied && annual_cycle->initialization[stock]->Bmean != 0){
        fatal("You supplied Bmean for some stocks but not others");
      }
  }
  int use_mean_YCS = annual_cycle->initialization[1]->use_mean_YCS;
  if (use_mean_YCS){
    if (!Rmean_supplied && !Bmean_supplied){
      fatal("Must specify either Rmean or Bmean for each stock");}
    if (B0_supplied || R0_supplied){
      fatal("Cannot supply B0 or R0 with use_mean_YCS");}
    if (Rmean_supplied && Bmean_supplied){
      fatal("Can't specify both Bmean and Rmean in the same model");}
  } else if (!use_mean_YCS){
    if (!R0_supplied && !B0_supplied){
      fatal("Must specify either R0 or B0 for each stock");}
    if (Bmean_supplied || Rmean_supplied){
      fatal("Cannot supply Bmean or Rmean unless you set use_mean_YCS");}
    if (R0_supplied && B0_supplied){
      fatal("Can't specify both B0 and R0 in the same model");}
  }
  Rinitial_supplied = annual_cycle->initialization[1]->Rinitial > 0;
  for (int stock = 2; stock<=state.n_stocks; stock++){
    if ( Rinitial_supplied && annual_cycle->initialization[stock]->Rinitial == 0 ||
        !Rinitial_supplied && annual_cycle->initialization[stock]->Rinitial != 0){
      fatal("You supplied Rinitial for some stocks but not others");
    }
  }
  Binitial_supplied = annual_cycle->initialization[1]->Binitial > 0;
  for (int stock = 2; stock<=state.n_stocks; stock++){
    if ( Binitial_supplied && annual_cycle->initialization[stock]->Binitial == 0 ||
         !Binitial_supplied && annual_cycle->initialization[stock]->Binitial != 0){
      fatal("You supplied Binitial for some stocks but not others");
    }
  }
  Cinitial_supplied = annual_cycle->initialization[1]->Cinitial != 0;
  for (int stock = 2; stock<=state.n_stocks; stock++){
    if ( Cinitial_supplied && annual_cycle->initialization[stock]->Cinitial == 0 ||
         !Cinitial_supplied && annual_cycle->initialization[stock]->Cinitial != 0){
      fatal("You supplied Cinitial for some stocks but not others");
    }
  }
  Cinitial_sexed_supplied = annual_cycle->initialization[1]->Cinitial_male != 0;
  for (int stock = 2; stock<=state.n_stocks; stock++){
    if ( Cinitial_sexed_supplied && annual_cycle->initialization[stock]->Cinitial_male == 0 ||
         !Cinitial_sexed_supplied && annual_cycle->initialization[stock]->Cinitial_male != 0){
      fatal("You supplied Cinitial_male and Cinitial_female for some stocks but not others");
    }
  }
  if (Rinitial_supplied && Binitial_supplied){
    fatal("Cannot specify both initialization.Rinitial and initialization.Binitial");}
  if (Rinitial_supplied && Cinitial_supplied){
    fatal("Cannot specify both initialization.Rinitial and initialization.Cinitial");}
  if (Binitial_supplied && Cinitial_supplied){
    fatal("Cannot specify both initialization.Binitial and initialization.Cinitial");}
  if (Rinitial_supplied && Cinitial_sexed_supplied){
    fatal("Cannot specify both initialization.Rinitial and sexed initialization.Cinitial");}
  if (Binitial_supplied && Cinitial_sexed_supplied){
    fatal("Cannot specify both initialization.Binitial and sexed initialization.Cinitial");}
  if (Cinitial_supplied && Cinitial_sexed_supplied){
    fatal("Cannot specify both initialization.Cinitial and sexed initialization.Cinitial");}


  // copy B0, R0, Binitial, Rinitial, and Cinitial from the initialization objects
  //  (some of these values will be zero, i.e. not specified and to be determined)
  for (int stock=1; stock<=state.n_stocks; stock++){
    if (!use_mean_YCS){
                B0[stock] = annual_cycle->initialization[stock]->B0;
        R0[stock] = annual_cycle->initialization[stock]->R0;
        Bmean[stock] = 0;
        Rmean[stock] = 0;
        } else if (use_mean_YCS){
            Bmean[stock] = annual_cycle->initialization[stock]->Bmean;
            Rmean[stock] = annual_cycle->initialization[stock]->Rmean;
            B0[stock] = Bmean[stock] * annual_cycle->recruitment[stock]->ybar();
            R0[stock] = Rmean[stock] * annual_cycle->recruitment[stock]->ybar();
        }
    Binitial[stock] = annual_cycle->initialization[stock]->Binitial;
    Rinitial[stock] = annual_cycle->initialization[stock]->Rinitial;
    if (annual_cycle->initialization[stock]->Cinitial==0){
      Cinitial.push_back(VECTOR("{-1}"));
    } else {
      Cinitial.push_back(*(annual_cycle->initialization[stock]->Cinitial));
    }
    if (annual_cycle->initialization[stock]->Cinitial_male==0){
      Cinitial_male.push_back(VECTOR("{-1}"));
      Cinitial_female.push_back(VECTOR("{-1}"));
    } else {
      Cinitial_male.push_back(*(annual_cycle->initialization[stock]->Cinitial_male));
      Cinitial_female.push_back(*(annual_cycle->initialization[stock]->Cinitial_female));
    }
  }

  if (!state.size_based){
    int first_year = state.col_min;
    int last_year = state.col_max - ((annual_cycle->recruitment_time < annual_cycle->ageing_time) ? 1 : 0);
    if (R0_supplied || Rmean_supplied){
      for (int i=1; i<=state.n_stocks; i++){
        annual_cycle->recruitment[i]->set_R0(R0[i]);
    if (use_mean_YCS){
                annual_cycle->recruitment[i]->set_Rmean(R0[i]/(annual_cycle->recruitment[i]->ybar()));}
          }
      for (int year=first_year; year<=last_year; year++){
        annual_cycle->do_year(state,0,"unfished_equilibrium");}
      if (state.plus_group){
        // a shortcut to avoid running the model over more years to get the plus group right
        // calculate the annual change c for each element of the plus group
        std::vector<VECTOR> prechange_partition = state.partition;
        annual_cycle->do_year(state,0,"unfished_equilibrium");
        DOUBLE c;
        for (int i=1; i<=state.n_rows; i++){
          if (prechange_partition[i][state.col_max] > 0){
            c = state.partition[i][state.col_max] / prechange_partition[i][state.col_max] - 1;
            c = fmax(0.0,fmin(0.9,c));
            state.partition[i] = prechange_partition[i];
            state.partition[i][state.col_max] *= 1/(1-c);
          } else {
            state.partition[i] = prechange_partition[i];
          }
        }
      }
      DOUBLE max_rel_diff = 1e18;
      VECTOR plus_group(1,state.n_rows), old_plus_group(1,state.n_rows);
      for (int i=1; i<=state.n_rows; i++){
        old_plus_group[i] = state.partition[i][state.col_max];}
      while (max_rel_diff > 0.005){
        annual_cycle->do_year(state,0,"unfished_equilibrium");
        max_rel_diff = 0;
        for (int i=1; i<=state.n_rows; i++){
          plus_group[i] = state.partition[i][state.col_max];
          if (old_plus_group[i] != 0){
            max_rel_diff = fmax(max_rel_diff,fabs((plus_group[i]-old_plus_group[i])/old_plus_group[i]));}
        }
        old_plus_group = plus_group;
      }
      for (int i=1; i<=state.n_stocks; i++){
        B0[i] = (*annual_cycle->SSBs)[i];}
     } else if (B0_supplied || Bmean_supplied){
       for (int i=1; i<=state.n_stocks; i++){
                if (!use_mean_YCS){
                        annual_cycle->recruitment[i]->set_R0(1);
                } else if (use_mean_YCS){
                        annual_cycle->recruitment[i]->set_Rmean(1);
                        annual_cycle->recruitment[i]->set_R0(annual_cycle->recruitment[i]->ybar());
                  }
           }
      VECTOR SSB(1,state.n_stocks);
      for (int year=first_year; year<=last_year; year++){
        annual_cycle->do_year(state,0,"unfished_equilibrium");
      }
      if (state.plus_group){
        // a shortcut to avoid running the model over more years to get the plus group right
        // calculate the annual change c for each element of the plus group
        std::vector<VECTOR> prechange_partition = state.partition;
        annual_cycle->do_year(state,0,"unfished_equilibrium");
        DOUBLE c;
        for (int i=1; i<=state.n_rows; i++){
          if (prechange_partition[i][state.col_max] > 0){
            c = state.partition[i][state.col_max] / prechange_partition[i][state.col_max] - 1;
            state.partition[i] = prechange_partition[i];
            state.partition[i][state.col_max] *= pow(1-c,-1);
          } else {
            state.partition[i] = prechange_partition[i];
          }
        }
      }
      annual_cycle->do_year(state,0,"unfished_equilibrium");
      for (int i=1; i<=state.n_stocks; i++){
        SSB[i] = (*annual_cycle->SSBs)[i];}
      R0 = elem_div(B0,SSB);
      for (int i=1; i<=state.n_rows; i++){
        if (state.n_stocks==1){
          state.partition[i] *= R0[1];
        } else {
          this_stock = state.character_value(i,stock_char);
          state.partition[i] *= R0[this_stock];
        }
      }
    }
  } else if (state.size_based){
     if (R0_supplied || Rmean_supplied){
       for (int i=1; i<=state.n_stocks; i++){
        annual_cycle->recruitment[i]->set_R0(R0[i]);
     if (use_mean_YCS){
                annual_cycle->recruitment[i]->set_Rmean(R0[i]/(annual_cycle->recruitment[i]->ybar()));}
        }
      for (int year=1; year<n_equilibrium; year++){
        annual_cycle->do_year(state,0,"unfished_equilibrium");}
      DOUBLE plus_group_total=0, plus_group_total_later=0;  // initialise these variables
      for (int i=1; i<=state.n_rows; i++){
        plus_group_total += state.partition[i][state.col_max];}
      annual_cycle->do_year(state,0,"unfished_equilibrium");
      for (int i=1; i<=state.n_rows; i++){
        plus_group_total_later += state.partition[i][state.col_max];}
      if (plus_group_total_later > 1.05 * plus_group_total){
        cout << "Warning: your plus group grew by over 5% in your last equilibrium year. You should probably increase n_equilibrium and try again.\n\n";
        cout << "         Biomass =" << plus_group_total << " in year " << n_equilibrium-1 << endl;
        cout << "         Biomass =" << plus_group_total_later << " in year " << n_equilibrium << endl;
    }
      for (int i=1; i<=state.n_stocks; i++){
        B0[i] = (*annual_cycle->SSBs)[i];}
     } else if (B0_supplied || Bmean_supplied){
       for (int i=1; i<=state.n_stocks; i++){
                if (!use_mean_YCS){
                        annual_cycle->recruitment[i]->set_R0(1);
                } else if (use_mean_YCS){
                        annual_cycle->recruitment[i]->set_Rmean(1);
                        annual_cycle->recruitment[i]->set_R0(annual_cycle->recruitment[i]->ybar());
                  }
           }
      VECTOR SSB(1,state.n_stocks);
      for (int year=1; year<n_equilibrium; year++){
        annual_cycle->do_year(state,0,"unfished_equilibrium");}
      DOUBLE plus_group_total=0, plus_group_total_later=0;  //initialise these variables here
      for (int i=1; i<=state.n_rows; i++){
        plus_group_total += state.partition[i][state.col_max];}
      annual_cycle->do_year(state,0,"unfished_equilibrium");
      for (int i=1; i<=state.n_rows; i++){
        plus_group_total_later += state.partition[i][state.col_max];}
      if (plus_group_total_later > 1.05 * plus_group_total){
        cout << "Warning: your plus group grew by over 5% in your last equilibrium year. You should probably increase n_equilibrium and try again.\n\n";
        cout << "         Biomass =" << plus_group_total << " in year " << n_equilibrium-1 << endl;
        cout << "         Biomass =" << plus_group_total_later << " in year " << n_equilibrium << endl;
      }
      for (int i=1; i<=state.n_stocks; i++){
        SSB[i] = (*annual_cycle->SSBs)[i];}
      R0 = elem_div(B0,SSB);
      for (int i=1; i<=state.n_rows; i++){
        if (state.n_stocks==1){
          state.partition[i] *= R0[1];
        } else {
          this_stock = state.character_value(i,stock_char);
          state.partition[i] *= R0[this_stock];
        }
      }
    }
  }

  if (use_mean_YCS){
    // get Bmean from B0 if Rmean was supplied, or Rmean from R0 if Bmean was supplied
        if (Rmean_supplied){
                Bmean = elem_div(elem_prod(Rmean,B0),R0);
        } else if (Bmean_supplied){
                Rmean = elem_div(elem_prod(Bmean,R0),B0);
        }
  }

  // if there are any density-dependent migrations, fill in the virgin abundances
  // just before the migration happens. Do this by setting the 'record_virgin_abundance'
  // switch in each Density_dependence object, running the model for a year, during which
  // the virgin abundances are calculated, and unsetting the switch again.
  int any_density_dependent = 0;
  for (int i=1; i<=annual_cycle->n_migrations; i++){
    if (annual_cycle->migration[i]->density_dependent){
      any_density_dependent = 1;
      annual_cycle->migration[i]->density_dependence->record_virgin_abundance = 1;
    }
  }
  if (any_density_dependent){
    // Run the partition ahead one year to get the virgin_abundances, then put it back the way it was.
    std::vector<VECTOR> prechange_partition = state.partition;
    annual_cycle->do_year(state,0,"unfished_equilibrium");
    state.partition = prechange_partition;
  }
  for (int i=1; i<=annual_cycle->n_migrations; i++){
    if (annual_cycle->migration[i]->density_dependent){
      annual_cycle->migration[i]->density_dependence->record_virgin_abundance = 0;
    }
  }

  // apply Binitial or Rinitial or Cinitial or sexed Cinitial if supplied:
  // fill in Binitial or Rinitial if not provided
  if (Binitial_supplied){
    for (int i=1; i<=state.n_rows; i++){
      if (state.n_stocks==1){
        state.partition[i] *= Binitial[1] / B0[1];
      } else {
        this_stock = state.character_value(i,stock_char);
        state.partition[i] *= Binitial[this_stock] / B0[this_stock];
      }
    }
    for (int i=1; i<=state.n_stocks; i++){
      Rinitial[i] = R0[i] * Binitial[i] / B0[i];}
  } else if (Rinitial_supplied){
    if (annual_cycle->initialization[1]->Rinitial_is_deviate){
      Rinitial = elem_prod(R0, Rinitial);}
    for (int i=1; i<=state.n_rows; i++){
      if (state.n_stocks==1){
        state.partition[i] *= Rinitial[1] / R0[1];
      } else {
        this_stock = state.character_value(i,stock_char);
        state.partition[i] *= Rinitial[this_stock] / R0[this_stock];
      }
    }
    for (int i=1; i<=state.n_stocks; i++){
      Binitial[i] = B0[i] * Rinitial[i] / R0[i];}
  } else if (Cinitial_supplied || Cinitial_sexed_supplied){
    if (Cinitial_supplied){
      // calculate number of fish in each column of the partition for each stock
      // and scale to the relevant element of Cinitial
      VECTOR col_sums(state.col_min,state.col_max);
      VECTOR factor(state.col_min,state.col_max);
      for (int stock=1; stock<=state.n_stocks; stock++){
        col_sums = 0;
        for (int i=1; i<=state.n_rows; i++){
          if (stock_char!=-1){
            if (state.character_value(i,stock_char)!=stock) continue;}
          col_sums += state.partition[i];
        }
        for (int j=state.col_min; j<=state.col_max; j++){
          if (value(col_sums[j])!=0)
            factor[j] = Cinitial[stock][j] / col_sums[j];
          else if (value(Cinitial[stock][j])==0)
            factor[j] = 1;
          else{
            string temp1 = "You have asked for nonzero abundance in column " + itos(j) + " of the partition";
            string temp2 = ". However, there are no fish there in the equilibrium state, "
            "so this is not possible. This may be because ageing occurs after "
            "recruitment in your annual cycle, which you could change. Alternatively, if "
            "you are using a prior that allows for Cinitial to be zero, you could constrain "
            "Cinitial to be zero for this column.";
            if (state.n_stocks > 1)
              fatal(temp1 + " for stock " + state.stock_names[stock] + temp2);
            else
              fatal(temp1 + temp2);
          }
        }
        for (int i=1; i<=state.n_rows; i++){
          if (stock_char!=-1){
            if (state.character_value(i,stock_char)!=stock) continue;}
          state.partition[i] = elem_prod(state.partition[i],factor);
        }
      }
    } else if (Cinitial_sexed_supplied){
      // calculate number of fish in each column of the partition for each stock and sex
      // and scale to the relevant element of Cinitial_male or Cinitial_female
      VECTOR col_sums_male(state.col_min,state.col_max), col_sums_female(state.col_min,state.col_max);
      VECTOR factor_male(state.col_min,state.col_max), factor_female(state.col_min,state.col_max);
      for (int stock=1; stock<=state.n_stocks; stock++){
        col_sums_male = 0;
        col_sums_female = 0;
        for (int i=1; i<=state.n_rows; i++){
          if (stock_char!=-1){
            if (state.character_value(i,stock_char)!=stock) continue;}
          if (state.character_value(i,sex_char)==1) col_sums_male += state.partition[i];
          else if (state.character_value(i,sex_char)==2) col_sums_female += state.partition[i];
        }
        for (int j=state.col_min; j<=state.col_max; j++){

          if (value(col_sums_male[j])!=0)
            factor_male[j] = Cinitial_male[stock][j] / col_sums_male[j];
          else if (value(Cinitial_male[stock][j])==0)
            factor_male[j] = 1;
          else{
            string temp1 = "You have asked for nonzero abundance in column " + itos(j) + " of the partition";
            string temp2 = ". However, there are no male fish there in the equilibrium state, "
            "so this is not possible. This may be because ageing occurs after "
            "recruitment in your annual cycle, which you could change. Alternatively, if "
            "you are using a prior that allows for Cinitial to be zero, you could constrain "
            "Cinitial to be zero for this column.";
             if (state.n_stocks > 1)
               fatal(temp1 + " for stock " + state.stock_names[stock] + temp2);
            else
               fatal(temp1 + temp2);
          }

          if (value(col_sums_female[j])!=0)
            factor_female[j] = Cinitial_female[stock][j] / col_sums_female[j];
          else if (value(Cinitial_female[stock][j])==0)
            factor_female[j] = 1;
          else{
            string temp1 = "You have asked for nonzero abundance in column " + itos(j) + " of the partition";
            string temp2 = ". However, there are no female fish there in the equilibrium state, "
            "so this is not possible. This may be because ageing occurs after "
            "recruitment in your annual cycle, which you could change. Alternatively, if "
            "you are using a prior that allows for Cinitial to be zero, you could constrain "
            "Cinitial to be zero for this column.";
             if (state.n_stocks > 1)
               fatal(temp1 + " for stock " + state.stock_names[stock] + temp2);
            else
               fatal(temp1 + temp2);
          }

        }
        for (int i=1; i<=state.n_rows; i++){
          if (stock_char!=-1){
            if (state.character_value(i,stock_char)!=stock) continue;}
          if (state.character_value(i,sex_char)==1){
            state.partition[i] = elem_prod(state.partition[i],factor_male);
          } else if (state.character_value(i,sex_char)==2){
            state.partition[i] = elem_prod(state.partition[i],factor_female);
          }
        }
      }
    }
    // Whether supplied by sex or not...
    // Run the partition ahead one year to get the SSBs, then put it back the way it was.
    std::vector<VECTOR> prechange_partition = state.partition;
    annual_cycle->do_year(state,0,"unfished_equilibrium");
    for (int i=1; i<=state.n_stocks; i++){
      Binitial[i] = (*annual_cycle->SSBs)[i];
      Rinitial[i] = R0[i] * Binitial[i] / B0[i];
    }
    state.partition = prechange_partition;
    state.SSBs = 0.0;
  } else {
    // neither Binitial, Rinitial nor Cinitial provided
    Binitial = B0;
    Rinitial = R0;
  }

  // fill in the SSBs for preinitial years in the state object with Binitial
  for (int stock = 1; stock <= state.n_stocks; stock++){
    for (int year = state.SSBs.colmin(); year<annual_cycle->initial; year++){
      state.SSBs[stock][year] = Binitial[stock];
    }
  }
  // tell the recruitment objects the values of B0, R0, and Rinitial
  for (int i=1; i<=state.n_stocks; i++){
    annual_cycle->recruitment[i]->set_B0(B0[i]);
    annual_cycle->recruitment[i]->set_R0(R0[i]);
    if (use_mean_YCS){
            annual_cycle->recruitment[i]->set_Rmean(Rmean[i]);}
    annual_cycle->recruitment[i]->set_Rinitial(Rinitial[i]); // has to come last - used R0/Rmean
  }
  // fill in results as requested
  if (requests.B0){
    (*results.B0) = B0;}
  if (requests.Binitial){
    (*results.Binitial) = Binitial;}
  if (requests.R0){
    (*results.R0) = R0;}
  if (requests.Rinitial){
    (*results.Rinitial) = Rinitial;}
  if (requests.Bmean && use_mean_YCS){
    (*results.Bmean) = Bmean;}
  if (requests.Rmean && use_mean_YCS){
    (*results.Rmean) = Rmean;}
}

// OPTIM: changed type of harvest_rate from DOUBLE to double.
template<CDVM>
int Basic_population_section<DVM>::deterministic_equilibrium(Harvest_strategy<DVM> *harvest_strategy,
                                                             const double& harvest_rate){
  // Find the equilibrium state under a given Harvest_strategy using constant recruitment.
  // If there is no equilibrium state (because the level of fishing pressure is too high),
  //   it returns 0, otherwise 1. The state should be left at equilibrium.
  // The Population_section should have been constructed with the 'simulation' parameter set to 1,
  //   so that it covers an abstract simulation period rather than the original model period.
  // The first Abundance_request in the Requests object should be the measure of abundance
  //   used in Harvest_strategies() (such as the CAY constant-F strategy). There should
  //   also be requests for B0 and SSBs.
  // At the end of deterministic_equilibrium, we also set all the preinitial entries in
  //   state.SSBs to the deterministic equilibrium SSBs (in case the state is to be used as the
  //   starting state for a stochastic simulation).
  // BB: Just added a refresh() call for the harvest strategy.
  DEBUG0("deterministic_equilibrium");
  results.empty();
  harvest_strategy->refresh();
  set_initial_state();
  if (print_requests->initial_state){
    cout << "Deterministic simulation: initial state:\n";
    state.print(cout);
    cout << '\n';
  }
  VECTOR B0(*(results.B0)), R0(*(results.R0));
  VECTOR SSBs(1,state.n_stocks), previous_SSBs(1,state.n_stocks);
  SSBs = B0;
  int have_reached_convergence = 0;
  int iter=0;
  while (1){
    annual_cycle->do_year(state, 0, "deterministic_simulation",
                          0, &requests, &results,
                          harvest_strategy, harvest_rate); // always year 0
    if (print_requests->state_annually){
      cout << "State at the end of a deterministic equilibrium year:\n";
      state.print(cout);
      cout << '\n';
    }
    previous_SSBs = SSBs;
    SSBs = *(annual_cycle->SSBs);
        iter++;
    // have we converged to an equilibrium?
        // Wait for at least 10 iterations before testing convergence, otherwise with spawning_part_mort at small
        // values (<0.01) the recorded biomass will be close to B0, but equilbrium under natural and fishing mortality
        // won't have being reached.
        if(iter>=10){
                have_reached_convergence = 1;
                for (int i=1; i<=state.n_stocks; i++){
                  if (fabs(previous_SSBs[i] - SSBs[i])/previous_SSBs[i] > 0.0001) {
                        have_reached_convergence = 0;}
                }
                if (have_reached_convergence|| (results.fishing_pressure_limit_exceeded && iter>=100)) break;
                if (iter==1e5) fatal("Very long loop in deterministic_equilibrium(), we have gone for 100000 years and still not found a steady state. Try a lower fishing pressure if possible : or, if this is a per-recruit analysis, try temporarily removing the stock-recruit relationship (but don't forget to put it back afterwards!).");
        }
  }
  // Set the preinitial SSBs in the state object
  for (int i=state.SSBs.colmin(); i<annual_cycle->initial; i++){
    state.SSBs.colfill(i,SSBs);}
  if (print_requests->final_state){
    cout << "Deterministic simulation: final state:\n";
    state.print(cout);
    cout << '\n';
  }
  if (print_requests->results){
    cout << "Deterministic simulation: ";
    results.print(state,requests,cout);
    cout << '\n';
  }
  return (!results.fishing_pressure_limit_exceeded);
}

// OPTIM: changed type of harvest_rate from DOUBLE to double.
template<CDVM>
void Basic_population_section<DVM>::stochastic_simulation(Harvest_strategy<DVM> *harvest_strategy,
                                                          const double& harvest_rate,
                                                          long RNG_seed){
  // Randomise recruitments and run the model over the simulation period using
  //   the specified Harvest_strategy.
  // This function does not start by initializing the state, which you should do first,
  //   perhaps using set_initial_state() or deterministic_equilibrium().
  // The Population_section should have been constructed with the 'simulation' parameter set to 1,
  //   so that it covers an abstract simulation period rather than the original model period.
  // The first Abundance_request in the Requests object should be the measure of abundance
  //   used in Harvest_strategies (such as the CAY constant-F strategy). There should
  //   also be a request for SSBs. B0 should already be in the Basic_results object (it will be
  //   if you called set_initial_state() or deterministic_equilibrium()).
  DEBUG0("stochastic_simulation");
  annual_cycle->randomise(RNG_seed);
  if (print_requests->initial_state){
    cout << "Stochastic simulation: initial state:\n";
    state.print(cout);
    cout << '\n';
  }
  for (int year = 1; year <= annual_cycle->current; year++){
    annual_cycle->do_year(state, 0, "stochastic_simulation",
                          year, &requests, &results,
                          harvest_strategy, harvest_rate, RNG_seed);
    if (print_requests->state_annually){
      cout << "State at the end of stochastic simulation year " << year << ":\n";
      state.print(cout);
      cout << '\n';
    }
  }
  if (print_requests->final_state){
    cout << "Stochastic simulation: final state:\n";
    state.print(cout);
    cout << '\n';
  }
  if (print_requests -> results){
    cout << "Stochastic simulation: results:\n";
    results.print(state,requests,cout);
    cout << '\n';
  }
}

template<CDVM>
void Basic_population_section<DVM>::print(ostream& out){
  DEBUG1("Basic_population_section::print");
  out << "Basic model; population section\n";
  state.print(out);
  annual_cycle->print(state,out,print_requests->every_mean_size);
  // OPTIM: Changed requests.print(out) to requests.print(state, out)
  requests.print(state, out);
  results.print(state,requests,out);
}

template<CDVM>
Basic_population_section<DVM>::Basic_population_section(Parameter_set<DVM>& p,
                                                        Print_requests *_print_requests)
  : state(p)
  , requests(p)
  , results(p){
  // The population section is constructed from a set of parameters p, which is passed
  // to the constructors of the state object, annual cycle, requests, and results,
  // and then used to initialize the requests and annual_cycle.
  DEBUG0("Basic_population_section::Basic_population_section");
  annual_cycle = new Basic_annual_cycle<DVM>(p,state);
  print_requests = _print_requests;
  set_annual_cycle(p);
  set_requests(p);
}

template<CDVM>
Basic_population_section<DVM>::~Basic_population_section(){
  DEBUG1("~Basic_population_section");
  delete annual_cycle;
}

//############################## STATE OBJECT ##############################
template<CDVM>
void Partition<DVM>::initialize_partition(){
  // Empty the partition.
  DEBUG2("Partition::initialize_partition");
  for (int i=1; i<=n_rows; i++){
    partition[i].initialize();
  }
}

template<CDVM>
void Partition<DVM>::move(VECTOR& proportions, int source, int sink){
  // Move fish from row 'source' to row 'sink', or remove them if 'sink' == 0.
  // proportions[i] is the proportion of fish moving in column i.
  DEBUG2("Partition::move (vector)");
  if (source <= 0 || source > n_rows){
    fatal("Bad source column " + itos(source) + " in Partition::move");}
  if (sink < 0 || sink > n_rows){
    fatal("Bad sink column " + itos(sink) + " in Partition::move");}
  if (proportions.indexmin() < col_min || proportions.indexmax() > col_max){
    fatal("Bad proportions indices: from " + itos(proportions.indexmin()) +
          " to " + itos(proportions.indexmax()) + " in Partition::move");}
  if (sink==0){
    for (int j = max(proportions.indexmin(),col_min);
            j <= min(proportions.indexmax(),col_max); j++){
      partition[source][j] *= (1-proportions[j]);
    }
  } else {
    DOUBLE temp;
    for (int j = max(proportions.indexmin(),col_min);
            j <= min(proportions.indexmax(),col_max); j++){
        temp = partition[source][j] * proportions[j];
        partition[source][j] -= temp;
        partition[sink][j] += temp;
    }
  }
}

template<CDVM>
void Partition<DVM>::move(const DOUBLE& proportion, int source, int sink){
  // Move fish from row 'source' to row 'sink', or remove them if 'sink' == 0.
  // 'proportion' is the proportion of fish moving in each column.
  DEBUG2("Partition::move (double)");
  if (source <= 0 || source > n_rows){
    fatal("Bad source column " + itos(source) + " in Partition::move");}
  if (sink < 0 || sink > n_rows){
    fatal("Bad sink column " + itos(sink) + " in Partition::move");}
  if (sink==0){
    partition[source] *= (1-proportion);
  } else {
    DOUBLE temp;
    for (int j = col_min; j <= col_max; j++){
      temp = partition[source][j] * proportion;
      partition[source][j] -= temp;
      partition[sink][j] += temp;
    }
  }
}

template<CDVM>
std::string Partition<DVM>::character_names(int number){
  // character_names(i) is the name of the character with number i (i=0,1...n_characters-1).
  // Return the empty string "" if there is no such character.
  // The inverse of character_numbers.
  // Note, the characters which are currently used in the basic model are spelt "sex", "area", "stock"
  // "maturity", "tag" and "growthpath".
  if (!in(char_names,number)) return "";
  else return char_names[number];
}

template<CDVM>
int Partition<DVM>::character_numbers(const std::string& name) {
  // character_numbers(name) is the number of character 'name'.
  // Return -1 if there is no such character.
  // The inverse of character_names.
  if (!in(char_nos,name)) return -1;
  else return char_nos[name];
}

template<CDVM>
int Partition<DVM>::character_value(int row, int character){
  // Returns the value of 'character' in 'row'.
  if (row < 1 || row > n_rows){
    fatal("bad row " + itos(row) + " in character_value");}
  if (character < 0 || character >= n_characters){
    fatal(" bad character " + itos(character) + " in character_value.\n\nCASAL has attempted to access a member of the partition that does not existin this model. You may be able to determine the cause of the problem by checking your input parameter files. Please notify the CASAL maintainer of this error.");}
  return int(char_value[character][row]);
}

template<CDVM>
dvector Partition<DVM>::rows_with(int character, int value){
  // Return the rows for which 'character' has 'value' (or a single 0 if there are none).
  DEBUG2("Partition::rows_with");
  if (character < 0 || character >= n_characters){
    fatal("bad character " + itos(character) + " in rows_with");}
  if (value < 1 || value > character_lengths[character]){
    fatal("bad value " + itos(value) + " for character " + itos(character) + " in rows_with");}
  return rows_by_char[character][value];
}

template<CDVM>
dvector Partition<DVM>::corresponding_rows(const dvector& rows, int character, int value){
  // Returns, for each entry of 'rows', the other row with exactly the same character
  // values, except that 'character' has 'value' (or 0 if there is no such row).
  DEBUG2("Partition::corresponding_rows");
  if (character < 0 || character >= n_characters){
    fatal("bad character " + itos(character) + " in corresponding_rows");}
  if (value < 1 || value > character_lengths[character]){
    fatal("bad value " + itos(value) + " for character " + itos(character) + " in corresponding_rows");}
  dvector c(rows.indexmin(),rows.indexmax());
  for (int i=c.indexmin();i<=c.indexmax();i++){
    if (rows[i] < 1 || rows[i] > n_rows){
      fatal("bad row " + dtos(rows[i]) + " in corresponding_rows");}
    c[i] = corresponding_rows_by_char[character][(int)(rows[i])][value];}
  return c;
}

template<CDVM>
int Partition<DVM>::corresponding_row(int row, int character, int value){
  // Returns the other row with exactly the same character values as 'row',
  // except that 'character' has 'value' (or 0 if there is none).
  DEBUG2("Partition::corresponding_row");
  if (character < 0 || character >= n_characters){
    fatal("bad character " + itos(character) + " in corresponding_row");}
  if (value < 1 || value > character_lengths[character]){
    fatal("bad value " + itos(value) + " for character " + itos(character) + " in corresponding_row");}
  if (row < 1 || row > n_rows){
    fatal("bad row " + itos(row) + " in corresponding_row");}
  //OPTIM: added explicit cast to (int) to resolve compiler warning
  return ((int)(corresponding_rows_by_char[character][row][value]));
}

template<CDVM>
void Partition<DVM>::average_partition(std::vector<VECTOR>& during, const std::vector<VECTOR>& before,
                                       double proportion, const std::string& method){
  // Used to calculate the partition partway through a mortality episode.
  // If method=="weighted_sum", 'during' becomes (proportion*partition + (1-proportion)*before),
  // or if method=="weighted_product", 'during' becomes partition^proportion * before^(1-proportion).
  DEBUG2("Partition::average_partition");
  if (proportion==1){
    during = partition;
  } else if (proportion==0){
    during = before;
  } else {
    if (method=="weighted_sum"){
      for (int i=1; i<=n_rows; i++){
        during[i]=partition[i]*proportion + before[i]*(1-proportion);
      }
    } else if (method=="weighted_product"){
      for (int i=1; i<=n_rows; i++){
        during[i]=elem_prod(pow(partition[i],proportion),pow(before[i],1-proportion));
      }
    } else fatal("Unknown method " + method + " in Partition::average_partition");
  }
}

template<CDVM>
void Partition<DVM>::print_matrix(ostream& out,const std::vector<VECTOR>& mat){
  DEBUG2("Partition::print_matrix");
  if (mat.size() != (n_rows+1)){
    fatal("in Partition::print_matrix, mat is wrong size");
  }
  DOUBLE temp;
  out << "  ";
  for (int k = 0; k < n_characters; k++){
    out.setf(ios::left,ios::adjustfield);
    out << setw(10);
    out << char_names[k].c_str() << " ";}
  for (int j = col_min; j <= col_max; j++){
    out << setw(9);
    if (col_names[0]!=-1){
      out << col_names[j] << ' ';
    } else {
      out << j << ' ';
    }
  }
  out << '\n';
  for (int i = 1; i <= n_rows; i++){
    if (mat[i].indexmin()!=col_min){
      fatal("in Partition::print_matrix, mat is wrong size");
    }
    out << "  ";
    for (int k = 0; k < n_characters; k++){
      out.setf(ios::left,ios::adjustfield);
      out << setw(10);
      out << character_labels[k][all_values[i][k]].c_str() << " ";
    }
    for (int j = col_min; j <= mat[i].indexmax(); j++){
      temp = mat[i][j];
      out << setw(9);
      out << setprecision(4);
      out << temp;
      out << ' ';
    }
    out << '\n';
  }
}

template<CDVM>
void Partition<DVM>::print_matrix(ostream& out,const MATRIX& mat){
  DEBUG2("Partition::print_matrix");
  if (mat.rowmin()!=1 || mat.rowmax()!=n_rows || mat.colmin()!=col_min || mat.colmax()!=col_max){
    fatal("in Partition::print_matrix, mat is wrong size");
  }
  DOUBLE temp;
  out << "  ";
  for (int k = 0; k < n_characters; k++){
    out.setf(ios::left,ios::adjustfield);
    out << setw(10);
    out << char_names[k].c_str() << " ";}
  for (int j = col_min; j <= col_max; j++){
    out << setw(9);
    if (col_names[0]!=-1){
      out << col_names[j] << ' ';
    } else {
      out << j << ' ';
    }
  }
  out << '\n';
  for (int i = 1; i <= n_rows; i++){
    out << "  ";
    for (int k = 0; k < n_characters; k++){
      out.setf(ios::left,ios::adjustfield);
      out << setw(10);
      out << character_labels[k][all_values[i][k]].c_str() << " ";
    }
    for (int j = col_min; j <= col_max; j++){
      temp = mat[i][j];
      out << setw(9);
      out << setprecision(4);
      out << temp;
      out << ' ';
    }
    out << '\n';
  }
}

template<CDVM>
void Partition<DVM>::print_vector(ostream& out,const VECTOR& vec, const std::string& column_label){
  DEBUG2("Partition::print_vector");
  if (vec.indexmin()!=1 || vec.indexmax()!=n_rows){
    fatal("in Partition::print_vector, vec is wrong size");
  }
  out << "  ";
  for (int k = 0; k < n_characters; k++){
    out.setf(ios::left,ios::adjustfield);
    out << setw(10);
    out << char_names[k].c_str() << " ";
  }
  out << column_label;
  out << '\n';
  for (int i = 1; i <= n_rows; i++){
    out << "  ";
    for (int k = 0; k < n_characters; k++){
      out.setf(ios::left,ios::adjustfield);
      out << setw(10);
      out << character_labels[k][all_values[i][k]].c_str() << " ";
    }
    out << setw(9);
    out << vec[i];
    out << '\n';
  }
}

template<CDVM>
void Partition<DVM>::print_vector(ostream& out, const std::vector<DOUBLE>& vec,
                                  const std::string& column_label){
  DEBUG2("Partition::print_vector");
  if (vec.size()!=(n_rows+1)){
    fatal("in Partition::print_vector, vec is wrong size");
  }
  out << "  ";
  for (int k = 0; k < n_characters; k++){
    out.setf(ios::left,ios::adjustfield);
    out << setw(10);
    out << char_names[k].c_str() << " ";
  }
  out << column_label << '\n';
  for (int i = 1; i <= n_rows; i++){
    out << "  ";
    for (int k = 0; k < n_characters; k++){
      out.setf(ios::left,ios::adjustfield);
      out << setw(10);
      out << character_labels[k][all_values[i][k]].c_str() << " ";
    }
    out << setw(9);
    out << vec[i];
    out << '\n';
  }
}

template<CDVM>
void Partition<DVM>::print_several_vectors(ostream& out, const std::vector<VECTOR>& vecs, const std::vector<std::string>& column_labels){
  DEBUG2("Partition::print_several_vectors");
  for (int j=0; j<vecs.size(); j++){
    if (vecs[j].indexmin()!=1 || vecs[j].indexmax()!=n_rows){
      fatal("in Partition::print_several_vectors, vecs[" + itos(j) + "] is wrong size");
    }
  }
  out << "  ";
  for (int k = 0; k < n_characters; k++){
    out.setf(ios::left,ios::adjustfield);
    out << setw(10);
    out << char_names[k].c_str() << " ";
  }
  for (int j=0; j<column_labels.size(); j++){
    out << setw(9);
    out << column_labels[j].c_str() << " ";
  }
  out << '\n';
  for (int i = 1; i <= n_rows; i++){
    out << "  ";
    for (int k = 0; k < n_characters; k++){
      out.setf(ios::left,ios::adjustfield);
      out << setw(10);
      out << character_labels[k][all_values[i][k]].c_str() << " ";
    }
    for (int j=0; j<vecs.size(); j++){
      out << setw(9);
      out << vecs[j][i] << ' ';
    }
    out << '\n';
  }
}

template<CDVM>
void Partition<DVM>::print(ostream& out){
  DEBUG1("Partition::print");
  out << "Partition: \n";
  print_matrix(out,partition);
  out << '\n';
}

template<CDVM>
Partition<DVM>::Partition(Parameter_set<DVM>& p, const std::string& model_type){
  // A means of constructing the partition.
  // The first bit depends on which model type is being used ('basic' is currently the
  //  only one). The second half is more generic.
  DEBUG1("Partition::Partition");
  if (model_type == "basic"){ // This is the basic model
    int size_based, sex_partition, mature_partition, n_growthpaths, n_stocks, n_areas, n_tag_states;
    std::vector<std::string> stock_names, area_names, tag_names;
    if (p.present("class_mins")){
      size_based = p.get_bool("size_based");
    } else {
      size_based = 0;
    }
    sex_partition = p.get_bool("sex_partition",0);
    mature_partition = p.get_bool("mature_partition",0);
    n_growthpaths = p.get_int("n_growthpaths",1);
    n_stocks = p.get_int("n_stocks",1);
    n_tag_states = 1+p.get_int("n_tags",0);
    if (n_stocks>1){
      stock_names = p.get_vector_of_strings("stock_names");
      if (stock_names.size()!=n_stocks) fatal("No stock names provided, or the wrong number of them");
      stock_names.insert(stock_names.begin(),"");
    } else {
      if(p.present("stock_names"))
        fatal("If you have only one stock, then you cannot supply a name for that stock (i.e., remove the command '@stock_names' from your population.csl file).");
    }
    n_areas = p.get_int("n_areas",1);
    if (n_areas>1){
      area_names = p.get_vector_of_strings("area_names");
      if (area_names.size()!=n_areas) fatal("No area names provided, or the wrong number of them");
      area_names.insert(area_names.begin(),"");
    }
    if (n_tag_states>1){
                tag_names = p.get_vector_of_strings("tag_names");
        if (tag_names.size()!=(n_tag_states-1)) fatal("No tag names provided, or the wrong number of them");
        tag_names.insert(tag_names.begin(),"no_tag");
        tag_names.insert(tag_names.begin(),"");
        }
    if (size_based){
      n_cols = p.get_int("n_classes");
      col_max = n_cols;
      col_min = 1;
      dvector names(p.get_constant_vector("class_mins"));
      // Check class_mins, plus_group, and n_classes are compatable
      if (p.get_bool("plus_group",1)) {
        if (names.size() != (n_cols)) fatal("class_mins is the wrong size");
      } else {
        if (names.size() != (n_cols+1)) fatal("class_mins is the wrong size");}
      col_names.resize(names.size()+1);
      col_names[0] = 0;
      for (int i=1; i<=names.size(); i++){
        col_names[i] = (int)names[i];}
    } else {
      col_max = p.get_int("max_age");
      col_min = p.get_int("min_age");
      n_cols = (col_max - col_min + 1);
      col_names.resize(1);
      col_names[0] = -1;
    }
    exclusions_names1 = p.get_vector_of_strings("exclusions_char1",std::vector<std::string>());
    exclusions_labels1 = p.get_vector_of_strings("exclusions_val1",std::vector<std::string>());
    exclusions_names2 = p.get_vector_of_strings("exclusions_char2",std::vector<std::string>());
    exclusions_labels2 = p.get_vector_of_strings("exclusions_val2",std::vector<std::string>());
    // Set up char_names, char_nos, n_characters, character_lengths, character_labels;
    n_characters=0;
    std::vector<std::string> labels;
    if (sex_partition){
      char_names.insert(make_pair(n_characters,std::string("sex")));
      char_nos.insert(make_pair(std::string("sex"),n_characters));
      character_lengths.push_back(2);
      labels.push_back("");
      labels.push_back("male");
      labels.push_back("female");
      character_labels.push_back(labels);
      n_characters++;
    }
    if (mature_partition){
      char_names.insert(make_pair(n_characters,std::string("maturity")));
      char_nos.insert(make_pair(std::string("maturity"),n_characters));
      character_lengths.push_back(2);
      labels = std::vector<std::string>();
      labels.push_back("");
      labels.push_back("immature");
      labels.push_back("mature");
      character_labels.push_back(labels);
      n_characters++;
    }
    if (n_growthpaths>1){
      char_names.insert(make_pair(n_characters,std::string("growthpath")));
      char_nos.insert(make_pair(std::string("growthpath"),n_characters));
      character_lengths.push_back(n_growthpaths);
      labels = std::vector<std::string>();
      labels.push_back("");
      for (int i=1; i<=n_growthpaths; i++){
        labels.push_back(itos(i));}
      character_labels.push_back(labels);
      n_characters++;
    }
    if (n_stocks>1){
      char_names.insert(make_pair(n_characters,std::string("stock")));
      char_nos.insert(make_pair(std::string("stock"),n_characters));
      character_lengths.push_back(n_stocks);
      labels = std::vector<std::string>();
      labels.push_back("");
      for (int i=0; i<n_stocks; i++){
        labels.push_back(stock_names[i+1]);}
      character_labels.push_back(labels);
      n_characters++;
    }
    if (n_areas>1){
      char_names.insert(make_pair(n_characters,std::string("area")));
      char_nos.insert(make_pair(std::string("area"),n_characters));
      character_lengths.push_back(n_areas);
      labels = std::vector<std::string>();
      labels.push_back("");
      for (int i=0; i<n_areas; i++){
        labels.push_back(area_names[i+1]);}
      character_labels.push_back(labels);
      n_characters++;
    }
    if (n_tag_states>1){
      char_names.insert(make_pair(n_characters,std::string("tag")));
      char_nos.insert(make_pair(std::string("tag"),n_characters));
      character_lengths.push_back(n_tag_states);
      labels = std::vector<std::string>();
      labels.push_back("");
      for (int i=0; i<n_tag_states; i++){
        labels.push_back(tag_names[i+1]);}
      character_labels.push_back(labels);
      n_characters++;
    }
  } else {
    fatal("unknown model type: " + model_type);
  }
  // from here on it's probably a bit more generic
  // Set up character_label_values;
  character_label_values.resize(n_characters);
  for (int k=0; k<n_characters; k++){
    for (int i=1; i<=character_lengths[k]; i++){
      character_label_values[k].insert(make_pair(character_labels[k][i],i));
    }
  }
  // Process the exclusions:
  // The way the exclusions work is that each combination of character values for which
  // (the character named exclusions_names1[i] takes the value exclusions_labels1[i] &&
  //  the character named exclusions_names2[i] takes the value exclusions_labels2[i])
  // is not allowed.
  // So, if no female fish are allowed in area "home", then the values
  // are "sex","female","area","home" respectively.
  int n_exclusions = (exclusions_names1.size());
  if((exclusions_labels1.size() != n_exclusions) || (exclusions_names2.size() != n_exclusions) || (exclusions_labels2.size() != n_exclusions)){
    fatal("Either exclusion_val1, exclusions_val2, exclusions_char1, or exclusions_char2 is the wrong size");}
  for (int i=0; i<n_exclusions; i++){
    exclusions_nums1.push_back(character_numbers(exclusions_names1[i]));
    exclusions_nums2.push_back(character_numbers(exclusions_names2[i]));
    if (exclusions_nums1[i] < 0 )
      fatal("Unrecognised exclusion " + exclusions_names1[i]);
    if (exclusions_nums2[i] < 0)
      fatal("Unrecognised exclusion " + exclusions_names2[i]);
    if (!in(character_label_values[exclusions_nums1[i]],exclusions_labels1[i]))
      fatal("Unrecognised exclusion " + exclusions_labels1[i]);
    if (!in(character_label_values[exclusions_nums2[i]],exclusions_labels2[i]))
      fatal("Unrecognised exclusion " + exclusions_labels2[i]);
    exclusions_vals1.push_back(character_label_values[exclusions_nums1[i]][exclusions_labels1[i]]);
    exclusions_vals2.push_back(character_label_values[exclusions_nums2[i]][exclusions_labels2[i]]);
  }
  // Set up all_values, all_values_map, n_rows:
  n_rows = 0;
  all_values.push_back(std::vector<int>()); // dummy entry
  // loop through sets of character values; assign each 'good' set of values a row of
  // the partition
  std::vector<int> value_set(n_characters);
  if (n_characters > 0){
    for (int i=0; i<n_characters; i++){
      value_set[i]=1;}
    value_set[0]=0;
    int character_to_change = 0, excluded;
    while(1){
      if (value_set[character_to_change]==character_lengths[character_to_change]){
        if (character_to_change == n_characters-1){
          break;
        } else {
          value_set[character_to_change]=1;
          character_to_change++;
        }
      } else {
        value_set[character_to_change]++;
        character_to_change=0;
        // this is a valid value set: is it excluded?
        excluded = 0;
        if (n_exclusions > 0){
          for (int i=0; i<n_exclusions; i++){
            if (value_set[exclusions_nums1[i]]==exclusions_vals1[i]
                && value_set[exclusions_nums2[i]]==exclusions_vals2[i]){
              excluded = 1;
              break;
            }
          }
        }
        if (!excluded){
          n_rows++;
          all_values.push_back(value_set);
          all_values_map.insert(make_pair(value_set,n_rows));
        }
      }
    }
  } else n_rows = 1;
  // set up partition:
  partition.push_back(VECTOR()); // dummy entry - no 0th row
  for (int i=1; i<=n_rows; i++){
    partition.push_back(VECTOR(col_min,col_max));
  }
  initialize_partition();
  // Set up char_value:
  for (int k=0; k<n_characters; k++){
    char_value.push_back(dvector(1,n_rows));
    for (int i=1; i<=n_rows; i++){
      char_value[k][i] = all_values[i][k];
    }
  }
  // Set up rows_by_char:
  int rows_thisval;
  for (int k=0; k<n_characters; k++){
    rows_by_char.push_back(std::vector<dvector>());
    rows_by_char[k].push_back(dvector());
    for (int v=1; v<=character_lengths[k]; v++){
      rows_thisval = 0;
      for (int i=1; i<=n_rows; i++){
        if (char_value[k][i]==v) rows_thisval++;}
      rows_by_char[k].push_back(dvector(1,rows_thisval));
      for (int i=n_rows; i>=1; i--){
        if (char_value[k][i]==v){
          rows_by_char[k][v][rows_thisval]=i;
          rows_thisval--;
        }
      }
    }
  }
  // Set up corresponding_rows_by_char:
  std::vector<int> these_values(n_characters);
  for (int k=0; k<n_characters; k++){
    corresponding_rows_by_char.push_back(std::vector<dvector>());
    corresponding_rows_by_char[k].push_back(dvector());
    for (int i=1; i<=n_rows; i++){
      corresponding_rows_by_char[k].push_back(dvector(1,character_lengths[k]));
      for (int v=1; v<=character_lengths[k]; v++){
        these_values = all_values[i];
        these_values[k] = v;
        if (in(all_values_map,these_values)){
          corresponding_rows_by_char[k][i][v] = all_values_map[these_values];
        } else {
          corresponding_rows_by_char[k][i][v] = 0;
        }
      }
    }
  }
}

template<CDVM>
DOUBLE Basic_state<DVM>::abundance(const std::string& type, int year, int step,
                                   Mean_weight<DVM>* mean_weight,
                                   const std::vector<int>& character_nums,
                                   const std::vector<int>& character_vals,
                                   const std::vector<VECTOR>& _partition,
                                   Selectivity<DVM> *selectivity){
  // Returns the current biomass or total numbers (for type = "biomass" or "numbers")
  // using mean_weight->get_row(s,i) for weights (if applicable),
  // in the rows which have 'character_vals' for characters 'character_nums',
  // applying the selectivity to each row, optionally replacing the current partition
  // by '_partition'. There are defaults indicating 'no value' for the
  // last four arguments.
  DEBUG2("Basic_state::abundance");
  if (type != "biomass" && type != "numbers"){
    fatal("Unknown type " + type + " in Basic_state::abundance");}
  VECTOR entry_by_col(this->col_min,this->col_max);
  VECTOR total_by_col(this->col_min,this->col_max);
  total_by_col.initialize();
  int ok;
  for (int i=1; i<=this->n_rows; i++){
    ok = 1;
    for (int k=0; k<character_nums.size(); k++){
      if (this->character_value(i,character_nums[k])!=character_vals[k]){
        ok = 0;
        break;
      }
    }
    if (ok){
      if (_partition.size() != 0){
        entry_by_col = _partition[i];
      } else {
        entry_by_col = this->partition[i];
      }
      if (type=="biomass"){
        entry_by_col = elem_prod(entry_by_col, mean_weight->get_row((*this),i));
      }
      if (selectivity != 0){
        entry_by_col = elem_prod(entry_by_col, selectivity->get_selectivity(year,step)[i]);
      }
      total_by_col += entry_by_col;
    }
  }
  return sum(total_by_col);
}

template<CDVM>
DOUBLE Basic_state<DVM>::mature_abundance(const std::string& type, int year, int step,
                                          Mean_weight<DVM>* mean_weight,
                                          Basic_nonpartition_maturity<DVM>* maturity_props,
                                          const std::vector<int>& character_nums,
                                          const std::vector<int>& character_vals,
                                          const std::vector<VECTOR>& _partition,
                                          Selectivity<DVM>* selectivity){
  // Returns the current mature {biomass or total numbers} (for type = "biomass" or "numbers"),
  // using either partition or non-partition maturity,
  // using mean_weight->get_row(s,i) for weights (if applicable),
  // in the rows which have 'character_vals' for characters 'character_nums',
  // applying the selectivity to each row, optionally replacing the current partition
  // by '_partition'. There are defaults indicating 'no value' for the
  // last four arguments.
  DEBUG2("Basic_state::mature_abundance");
  if (type != "biomass" && type != "numbers"){
    fatal("Unknown type " + type + " in Basic_state::mature_abundance");}
  if (mature_partition){
    // Maturity is a character in the partition: use an ::abundance() call
    std::vector<int> new_character_nums = character_nums;
    new_character_nums.push_back(this->character_numbers("maturity"));
    std::vector<int> new_character_vals = character_vals;
    new_character_vals.push_back(2);
    return abundance(type,year,step,mean_weight,
                     new_character_nums,new_character_vals,_partition,selectivity);
  }
  // Maturity is not a character in the partition: use the maturity_props object
  VECTOR entry_by_col(this->col_min,this->col_max);
  VECTOR total_by_col(this->col_min,this->col_max);
  total_by_col.initialize();
  int ok;
  for (int i=1; i<=this->n_rows; i++){
    ok = 1;
    for (int k=0; k<character_nums.size(); k++){
      if (this->character_value(i,character_nums[k])!=character_vals[k]){
        ok = 0;
        break;
      }
    }
    if (ok){
      if (_partition.size() != 0){
        entry_by_col = _partition[i];
      } else {
        entry_by_col = this->partition[i];
      }
      entry_by_col = elem_prod(entry_by_col, maturity_props->get_row(i));
      if (type=="biomass"){
        entry_by_col = elem_prod(entry_by_col, mean_weight->get_row((*this),i));
      }
      if (selectivity != 0){
        entry_by_col = elem_prod(entry_by_col, selectivity->get_selectivity(year,step)[i]);
      }
      total_by_col += entry_by_col;
    }
  }
  return sum(total_by_col);
}

template<CDVM>
MATRIX Basic_state<DVM>::numbers_at(int sexed, int year, int step,
                                    const std::vector<int>& character_nums,
                                    const std::vector<int>& character_vals,
                                    const std::vector<VECTOR>& _partition,
                                    Selectivity<DVM>* selectivity, int just_the_ogive){
  // Returns the current numbers-at-age (in an age-based model) or at-size (in a size-based model),
  //  by sex if 'sexed',
  //  in the rows which have 'character_vals' for characters 'character_nums',
  //  applying the selectivity to each row,
  //  optionally replacing the current partition by '_partition'.
  // There are defaults indicating 'no value' for all arguments.
  // Use numbers_at_size_in_agebased for numbers-at-size in an age-based model.
  // If just_the_ogive=1, return only the ogive values, not the actual selected numbers-at.
  DEBUG2("Basic_state::numbers_at");
  int sex_char = this->character_numbers("sex");
  VECTOR entry_by_col(this->col_min,this->col_max);
  entry_by_col.initialize();
  MATRIX total_by_col(1,(sexed ? 2 : 1),this->col_min,this->col_max);
  total_by_col.initialize();
  int ok;
  for (int i=1; i<=this->n_rows; i++){
    ok = 1;
    for (int k=0; k<character_nums.size(); k++){
      if (this->character_value(i,character_nums[k])!=character_vals[k]){
        ok = 0;
        break;
      }
    }
    if (ok){
          if (just_the_ogive){
    if (sum(total_by_col[sexed ? this->character_value(i,sex_char) : 1])!=0){
      for (int j=this->col_min; j<=this->col_max; j++){
        if (selectivity->get_selectivity(year,step)[i][j] != total_by_col[sexed ? this->character_value(i,sex_char) : 1][j]){
                        fatal("You have entered an Ogive_at pseudo-observation covering two or more rows with different ogive values.\n");
                }
      }
           entry_by_col=0; // so no change to result
        } else {
          entry_by_col = 1;
    }
      } else if (_partition.size() != 0){
        entry_by_col = _partition[i];
      } else {
        entry_by_col = this->partition[i];
      }
      if (selectivity != 0){
        entry_by_col = elem_prod(entry_by_col, selectivity->get_selectivity(year,step)[i]);
      }
      //richard test
    for (int j=this->col_min; j<=this->col_max; j++){
      entry_by_col[j]=zerofun(entry_by_col[j],ZERO);
    }
    if(sexed){
        total_by_col[this->character_value(i,sex_char)] += entry_by_col;
      } else {
        total_by_col[1] += entry_by_col;
      }
  }
  }
  return total_by_col;
}

template<CDVM>
MATRIX Basic_state<DVM>::numbers_at_size_in_agebased(
                                     int sexed, int year, int step,
                                     dvector& _class_mins, int _plus_group,
                                     Size_at_age<DVM>* size_at_age,
                                     const std::vector<int>& character_nums,
                                     const std::vector<int>& character_vals,
                                     const std::vector<VECTOR>& _partition,
                                     Selectivity<DVM>* selectivity){
  DEBUG2("Basic_state::numbers_at_size_in_agebased");
  // Returns the current numbers-at-size, in an age-based model,
  // by sex if 'sexed',
  // in the rows which have 'character_vals' for characters 'character_nums',
  // applying the selectivity to each row,
  // optionally replacing the current partition by '_partition'.
  // Use the size class minimums given in 'class_mins', with 'plus_group' indicating
  // whether the last class is a plus group. If not, the last entry of class_mins
  // should be the maximum size of the last size class.
  // Get the size distribution from size_at_age->get_size_dist(row,_plus_group,_class_mins).
  // There are defaults indicating 'no value' for the last four arguments.
  DEBUG2("Basic_state::numbers_at_size_in_agebased");
  int sex_char = this->character_numbers("sex");
  VECTOR entry_by_col(this->col_min,this->col_max);
  MATRIX total_by_col(1,(sexed ? 2 : 1),1,_class_mins.size()-(_plus_group ? 0 : 1));
  total_by_col.initialize();
  int ok;
  for (int i=1; i<=this->n_rows; i++){
    ok = 1;
    for (int k=0; k<character_nums.size(); k++){
      if (this->character_value(i,character_nums[k])!=character_vals[k]){
        ok = 0;
        break;
      }
    }
    if (ok){
      if (_partition.size() != 0){
        entry_by_col = _partition[i];
      } else {
        entry_by_col = this->partition[i];
      }
      if (selectivity != 0){
        entry_by_col = elem_prod(entry_by_col, selectivity->get_selectivity(year,step)[i]);
      }
      if(sexed){
        total_by_col[this->character_value(i,sex_char)] +=
                           size_at_age->get_size_dist(i,_plus_group,_class_mins) * entry_by_col;
      } else {
        total_by_col[1] += size_at_age->get_size_dist(i,_plus_group,_class_mins) * entry_by_col;
      }
    }
  }
  return total_by_col;
}

template<CDVM>
MATRIX Basic_state<DVM>::mature_numbers_at(int sexed, int year, int step,
                                           Basic_nonpartition_maturity<DVM>* maturity_props,
                                           const std::vector<int>& character_nums,
                                           const std::vector<int>& character_vals,
                                           const std::vector<VECTOR>& _partition,
                                           Selectivity<DVM>* selectivity, int just_the_ogive){
  // Returns the current numbers-at-age (in an age-based model) or at-size (in a size-based model),
  //  including mature fish only,
  //  by sex if 'sexed',
  //  in the rows which have 'character_vals' for characters 'character_nums',
  //  applying the selectivity to each row,
  //  optionally replacing the current partition by '_partition'.
  // There are defaults indicating 'no value' for all arguments.
  // Use numbers_at_size_in_agebased for numbers-at-size in an age-based model.
  // If just_the_ogive=1, return only the ogive values, not the actual selected numbers-at.
  DEBUG2("Basic_state::mature_numbers_at");
  if (mature_partition){
    // maturity is a character in the partition: use a numbers_at() call
    std::vector<int> new_character_nums = character_nums;
    new_character_nums.push_back(this->character_numbers("maturity"));
    std::vector<int> new_character_vals = character_vals;
    new_character_vals.push_back(2);
    return numbers_at(sexed,year,step,new_character_nums,new_character_vals,_partition,selectivity);
  } else {
    // maturity is not a character in the partition: use the maturity_props object
    int sex_char = this->character_numbers("sex");
    VECTOR entry_by_col(this->col_min,this->col_max);
    MATRIX total_by_col(1,(sexed ? 2 : 1),this->col_min,this->col_max);
    total_by_col.initialize();
    int ok;
    for (int i=1; i<=this->n_rows; i++){
      ok = 1;
      for (int k=0; k<character_nums.size(); k++){
        if (this->character_value(i,character_nums[k])!=character_vals[k]){
          ok = 0;
          break;
        }
      }
      if (ok){
          if (just_the_ogive){
        if (sum(total_by_col[sexed ? this->character_value(i,sex_char) : 1])!=0){
      for (int j=this->col_min; j<=this->col_max; j++){
        if (selectivity->get_selectivity(year,step)[i][j] != total_by_col[sexed ? this->character_value(i,sex_char) : 1][j]){
          fatal("You have entered an Ogive_at pseudo-observation covering two or more rows with different ogive values.\n");
        }
      }
      entry_by_col=0; // so no change to result
    } else {
    entry_by_col = 1;
    }
      } else if (_partition.size() != 0){
          entry_by_col = _partition[i];
        } else {
          entry_by_col = this->partition[i];
        }
        entry_by_col = elem_prod(entry_by_col, maturity_props->get_row(i));
        if (selectivity != 0){
          entry_by_col = elem_prod(entry_by_col, selectivity->get_selectivity(year,step)[i]);
        }
        if(sexed){
          total_by_col[this->character_value(i,sex_char)] += entry_by_col;
        } else {
          total_by_col[1] += entry_by_col;
        }
      }
    }
    return total_by_col;
  }
}

template<CDVM>
MATRIX Basic_state<DVM>::mature_numbers_at_size_in_agebased(
                                     int sexed, int year, int step,
                                     dvector& _class_mins, int _plus_group,
                                     Basic_nonpartition_maturity<DVM>* maturity_props,
                                     Size_at_age<DVM>* size_at_age,
                                     const std::vector<int>& character_nums,
                                     const std::vector<int>& character_vals,
                                     const std::vector<VECTOR>& _partition,
                                     Selectivity<DVM>* selectivity){
  DEBUG2("Basic_state::mature_numbers_at_size_in_agebased");
  // Returns the current numbers-at-size, in an age-based model,
  // including mature fish only,
  // by sex if 'sexed',
  // in the rows which have 'character_vals' for characters 'character_nums',
  // applying the selectivity to each row,
  // optionally replacing the current partition by '_partition'.
  // Use the size class minimums given in 'class_mins', with 'plus_group' indicating
  // whether the last class is a plus group. If not, the last entry of class_mins
  // should be the maximum size of the last size class.
  // Get the size distribution from size_at_age->get_size_dist(row,_plus_group,_class_mins).
  // There are defaults indicating 'no value' for the last four arguments.
  if (mature_partition){
    // maturity is a character in the partition: use a numbers_at_size_in_agebased() call
    std::vector<int> new_character_nums = character_nums;
    new_character_nums.push_back(this->character_numbers("maturity"));
    std::vector<int> new_character_vals = character_vals;
    new_character_vals.push_back(2);
    return numbers_at_size_in_agebased(sexed,year,step,_class_mins,_plus_group,size_at_age,
                                       new_character_nums,new_character_vals,_partition,selectivity);
  } else {
    // maturity is not a character in the partition: use the maturity_props object
    int sex_char = this->character_numbers("sex");
    VECTOR entry_by_col(this->col_min,this->col_max);
    MATRIX total_by_col(1,(sexed ? 2 : 1),1,_class_mins.size()-(_plus_group ? 0 : 1));
    total_by_col.initialize();
    int ok;
    for (int i=1; i<=this->n_rows; i++){
      ok = 1;
      for (int k=0; k<character_nums.size(); k++){
        if (this->character_value(i,character_nums[k])!=character_vals[k]){
          ok = 0;
          break;
        }
      }
      if (ok){
        if (_partition.size() != 0){
          entry_by_col = _partition[i];
        } else {
          entry_by_col = this->partition[i];
        }
        entry_by_col = elem_prod(entry_by_col, maturity_props->get_row(i));
        if (selectivity != 0){
          entry_by_col = elem_prod(entry_by_col, selectivity->get_selectivity(year,step)[i]);
        }
        if(sexed){
          total_by_col[this->character_value(i,sex_char)] +=
            size_at_age->get_size_dist(i,_plus_group,_class_mins) * entry_by_col;
        } else {
          total_by_col[1] += size_at_age->get_size_dist(i,_plus_group,_class_mins) * entry_by_col;
        }
      }
    }
    return total_by_col;
  }
}

template<CDVM>
int Basic_state<DVM>::valid_area(std::string area){
  DEBUG2("Basic_state::valid_area");
  int ok=0;
  for (int i=1; i<=n_areas; i++){
    if (area_names[i]==area) ok=1;
  }
  return ok;
};

template<CDVM>
int Basic_state<DVM>::valid_stock(std::string stock){
  DEBUG2("Basic_state::valid_stock");
  int ok=0;
  for (int i=1; i<=n_stocks; i++){
    if (stock_names[i]==stock) ok=1;
  }
  return ok;
};

template<CDVM>
int Basic_state<DVM>::valid_tag(std::string tag){
  DEBUG2("Basic_state::valid_tag");
  int ok=0;
  for (int i=1; i<=n_tag_states; i++){
    if (tag_names[i]==tag) ok=1;
  }
  return ok;
};

template<CDVM>
void Basic_state<DVM>::print(ostream& out){
  DEBUG1("Basic_state::print");
  Partition<DVM>::print(out);
  out << "SSBs:\n" << SSBs << "\n  with indices from " << SSBs.colmin() << " to " << SSBs.colmax() << "\n\n";
};

template<CDVM>
Basic_state<DVM>::Basic_state(Parameter_set<DVM>& p)
  : Partition<DVM>(p,"basic")
  , SSBs(1,p.get_int("n_stocks",1),   // one row per stock
         p.get_int("initial") - p.get_int("y_enter"),    // first year for which to record SSB
         p.get_int("final"))                             // last year for which to record SSB
  , class_mins(p.get_constant_vector("class_mins",dvector("{-1}"))){
  // Construct the basic model state object.
  // First, construct the Partition base class, by passing p to Partition::Partition.
  // Second, construct SSBs and any other member objects.
  // Third, fill in the members from p.
  // Initialization of the partition matrix and SSBs is done later by set_initial_state().
  DEBUG1("Basic_state::Basic_state");
  if (p.present("class_mins")){
    size_based = p.get_bool("size_based");
  } else {
    size_based = 0;
  }
  if (!size_based){
    min_age = p.get_int("min_age");}
  if (size_based && !p.present("class_mins")){
    fatal("Class_mins not supplied\n");}
  plus_group = p.get_bool("plus_group",1);
  if (size_based && plus_group){
    plus_group_size = p.get_constant("plus_group_size");}
  sex_partition = p.get_bool("sex_partition",0);
  mature_partition = p.get_bool("mature_partition",0);
  n_growthpaths = p.get_int("n_growthpaths",1);
  n_stocks = p.get_int("n_stocks",1);
  if (n_stocks>1){
    stock_names = p.get_vector_of_strings("stock_names");
    if (stock_names.size()!=n_stocks) fatal("No stock names provided, or the wrong number of them");
    stock_names.insert(stock_names.begin(),"");
    for (int i=1; i<=n_stocks; i++){
      stock_numbers.insert(make_pair(stock_names[i],i));
    }
  }
  n_areas = p.get_int("n_areas",1);
  if (n_areas>1){
    area_names = p.get_vector_of_strings("area_names");
    if (area_names.size()!=n_areas) fatal("No area names provided, or the wrong number of them");
    area_names.insert(area_names.begin(),"");
    for (int i=1; i<=n_areas; i++){
      area_numbers.insert(make_pair(area_names[i],i));
    }
}
  n_tag_states = 1+p.get_int("n_tags",0);
  if (n_tag_states>1){
        tag_names = p.get_vector_of_strings("tag_names");
    if (tag_names.size()!=(n_tag_states-1)) fatal("No tag names provided, or the wrong number of them");
    tag_names.insert(tag_names.begin(),"no_tag");
    tag_names.insert(tag_names.begin(),"");
    for (int i=1; i<=n_tag_states; i++){
      tag_numbers.insert(make_pair(tag_names[i],i));
    }
  }
}

template<CDVM>
Basic_state<DVM>::~Basic_state(){
  DEBUG1("~Basic_state");
}

//############################## ANNUAL CYCLE ##############################
template<CDVM>
void Basic_annual_cycle<DVM>::do_year(Basic_state<DVM>& s, int print_state_every_step,
                                      const std::string& type, int year,
                                      Basic_requests<DVM>* requests, Basic_results<DVM>* results,
                                      Harvest_strategy<DVM>* harvest_strategy,
                                      double harvest_rate, long RNG_seed){
  // Run the annual cycle on state s.
  //
  // 'type' should be one of the following:
  //
  // 'normal'
  //                 (Provide 'year', 'requests', and 'results'.
  //                  Also used for projections, where randomise() should have been called first.)
  //
  // 'unfished_equilibrium'
  //                 (You are running the model to determine the equilibrium state with
  //                    constant recruitment and no fishing mortality.
  //                  Recruitment uses apply_constant() instead of apply().
  //                  Do not provide 'year', 'requests' or 'results':
  //                    no requests for results will be considered.)
  //
  // 'deterministic_simulation'
  //                 (You are running the model to determine the equilibrium state with
  //                    constant recruitment under a given harvest strategy (with any
  //                    randomness in the harvest strategy removed).
  //                  Recruitment uses apply_constant() instead of apply().
  //                  Catches are determined using harvest_strategy.get_catch().
  //                  Provide a dummy year of 0,
  //                    requests and results (needed to record B0, SSB, and any measure
  //                      of abundance used in the harvest strategy),
  //                    provide a pointer to the harvest_strategy object
  //                    and the harvest rate, but not a RNG seed.)
  //
  // 'stochastic_simulation'
  //                 (You are running the model to determine the equilibrium state
  //                    under a given harvest strategy, with stochastic recruitment.
  //                    randomise() should have been called first.
  //                  Catches are determined using harvest_strategy.get_catch().
  //                  Provide a nonzero year,
  //                    requests and results (needed to record B0, SSB, and any measure
  //                      of abundance used in the harvest strategy),
  //                    provide a pointer to the harvest_strategy object
  //                    and the harvest rate and a RNG seed.)
  //
  // Carry out processes in the specified order; for multiple processes within a time step,
  // use the order (as applicable):
  // ageing
  // recruitment
  // maturation
  // migration
  // growth
  // mortality
  // disease mortality
  // tagging
  //
  // In an age-based model, do_year is responsible for executing size_at_age.set_time(year,step)
  //   at the start of each time step.
  //
  // For type=='normal', do_year is also responsible for updating s.SSBs,
  //  i.e. for recording the SSB of each stock in each year. For other types, the SSB is not recorded
  //  in the state object, but is left lying around in *(annual_cycle.SSBs).
  //
  DEBUG1("Basic_annual_cycle::do_year");
  for (int step=1; step<=time_steps; step++){
    if (!s.size_based){
      size_at_age->set_time(year,step);
    }
    if (ageing_time==step && !s.size_based){
      ageing->apply(s,year);
    }
    if (recruitment_time==step){
      if (type == "normal" || type == "stochastic_simulation"){
        for (int i=1; i<recruitment.size(); i++){
          recruitment[i]->apply(s,year,requests,results);}
      } else if (type == "unfished_equilibrium"){
        for (int i=1; i<recruitment.size(); i++){
          recruitment[i]->apply_constant(s,0);}
      } else if (type == "deterministic_simulation"){
        for (int i=1; i<recruitment.size(); i++){
          DOUBLE SSB;
          if (s.SSBs[i][1] == 0){
            SSB = s.SSBs[i][0]; // first year of simulation - use SSB = B0 in SR()
          } else {
            SSB = s.SSBs[i][1]; // use the SSB from last simulated year in SR() 
          }
          recruitment[i]->apply_constant(s,SSB,requests,results);}
      }
    }
    if (s.mature_partition){
      for (int i=1; i<=n_maturations; i++){
        if ((int)((*maturation_times)[i])==step){
          maturation[i]->apply(s,year);
        }
      }
    }
    // Migrations: there may be numbers-at requests before and/or after each migration
    if (s.n_areas > 1){
      for (int i=1; i<=n_migrations; i++){
        if ((*migration_times)[i]==step){
          if (type == "normal"||type == "deterministic_simulation"||type == "stochastic_simulation"){
            // do requests for pre-migration results (can only be numbers-at so far)
            //  (no results for equilibrium years)
            for (int entry=0; entry<requests->numbers_at.size(); entry++){
              std::string label = requests->numbers_at_labels[entry];
              if (requests->numbers_at[label].migration == migration_names[i] &&
                  in(requests->numbers_at[label].years,year) &&
                  requests->numbers_at[label].before){
                results->numbers_at[label].insert(make_pair(year,
                                             requests->numbers_at[label].get_result(s,*this,year,0)));
              }
            }
          }
          // do the migration
          migration[i]->apply(s,year,requests,results);
          if (type == "normal"||type == "deterministic_simulation"||type == "stochastic_simulation"){
            // do requests for post-migration results (can only be numbers-at so far)
            //  (no results for equilibrium years)
            for (int entry=0; entry<requests->numbers_at.size(); entry++){
              std::string label = requests->numbers_at_labels[entry];
              if (requests->numbers_at[label].migration == migration_names[i] &&
                  in(requests->numbers_at[label].years,year) &&
                  requests->numbers_at[label].after){
                results->numbers_at[label].insert(make_pair(year,
                                              requests->numbers_at[label].get_result(s,*this,year,0)));
              }
            }
          }
        }
      }
    }
    if (s.size_based){
      for (int i=1; i<=n_growths; i++){
        if ((*growth_times)[i]==step){
          growth[i]->apply(s,year);
        }
      }
    }
    if (type == "normal" || type == "deterministic_simulation" || type == "stochastic_simulation"){
      // do requests for pre-mortality results
      //  (no results for equilibrium years)
      // abundance
      for (int entry=0; entry<requests->abundance.size(); entry++){
        std::string label = requests->abundance_labels[entry];
        if (in(requests->abundance[label].years,year) &&
            requests->abundance[label].step == step &&
            requests->abundance[label].proportion_mortality == 0){
          results->abundance[label][year] = requests->abundance[label].get_result(s,*this,year,1);
        }
      }
      // numbers_at
      for (int entry=0; entry<requests->numbers_at.size(); entry++){
        std::string label = requests->numbers_at_labels[entry];
        if (in(requests->numbers_at[label].years,year) &&
            requests->numbers_at[label].migration == "" &&
            requests->numbers_at[label].step == step &&
            requests->numbers_at[label].proportion_mortality == 0){
          results->numbers_at[label].insert(make_pair(year,
                                               requests->numbers_at[label].get_result(s,*this,year,1)));
        }
      }
    }
    // proceed to take the mortality
    premortality_partition = s.partition;
    if (type == "normal"){
      mortality[step]->apply(s,year,requests,results,0);
    } else if (type == "unfished_equilibrium"){
      mortality[step]->apply(s,year,0,0,0);
    } else if (type == "deterministic_simulation" || type == "stochastic_simulation"){
      if (harvest_strategy->constant_instantaneous_mortality()){
        // the harvest rate represents an instantaneous mortality as in the Baranov equation
        double F_to_use = harvest_rate;
        mortality[step]->apply(s,year,requests,results,F_to_use);
      } else {
        if (step==min(*fishery_times)){
          // need to apply the Harvest_strategy to determine the catch
          VECTOR B0(*(results->B0));
          VECTOR last_SSB(1,B0.size());
          if (type != "deterministic_simulation"){
            last_SSB = extract_column(*(results->SSBs),year-1);
          } else if (type == "deterministic_simulation"){
            if (max(extract_column(*(results->SSBs),year)) == 0){
              // this is the first year of deterministic sims, no SSB has been recorded yet
              last_SSB = B0;
            } else {
              // use the SSB from year 0 (deterministic sims always use year 0)
              last_SSB = extract_column(*(results->SSBs),year);
            }
          }
          DOUBLE harvest_abundance = results->abundance["Bpre"][year];
          DOUBLE last_year_total_catch = 0;
          if (year>0){
                          // this is a stochastic sim, get last year's TAC in case the harvest strategy needs to know it, i.e. assess_frequency>1
                          for (int i=1; i<fishery_names.size(); i++){
                                  last_year_total_catch += results->specified_catches[year-1][fishery_names[i]];
                          }
              }
          dvector catches(harvest_strategy->get_catch(harvest_rate, last_SSB, B0,
                                                      harvest_abundance, RNG_seed, (year==1),
                                                      last_year_total_catch, year));
          catches_this_year = std::map<std::string,double>();
          for (int i=1; i<=catches.size(); i++){
            catches_this_year.insert(make_pair(fishery_names[i],catches[i]));}
		}
        mortality[step]->apply(s,year,requests,results,0,&catches_this_year);
	  }
    }
  if (disease_time != 0 && initial <= year && year <= final){
          if (type=="normal"){
                disease->apply(s,year,mean_weight,requests,results);
          } else {
                disease->apply(s,year,0,0,0);
          }
  }  //apply disease mortality here
  if (s.n_tag_states > 1 && initial <= year && year <= final){
        // apply tagging here
        for (int i=1; i<tagging.size(); i++){ // dummy element 0
          if (type == "normal"){
             tagging[i]->apply(s,year,step,this,requests,results);
              } else { // no requests for results - but then there shouldn't be any tagging either
             tagging[i]->apply(s,year,step,this,0,0);
                  }
        }
        // and tag loss
        for (int i=2; i<tag_loss.size(); i++){ // dummy element 0, 1 is 'no tag'
          //      cerr << " applying tag loss " << i << '\n';
                        if (tag_loss[i]!=0){
                                tag_loss[i]->apply(s,year,step);
                        }
                }
        //      cerr << "done\n";

  }
  if (spawning_time==step){ // record SSB
      for (int i=1; i<=s.n_stocks; i++){
		biomass = 0;
        if (spawning_part_mort==1){
          if (s.mature_partition || !spawning_use_total_B){
			for (int j=0;j<spawning_chars[i].size();j++)
				biomass += s.mature_abundance("biomass",year,step,mean_weight, maturity_props,spawning_chars[i][j], spawning_vals[i][j]);
          } else {
			for (int j=0;j<spawning_chars[i].size();j++)
				biomass += s.abundance("biomass",year,step,mean_weight, spawning_chars[i][j], spawning_vals[i][j]);
		  }
        } else {
          // need SSB partway through mortality;
          // back-calculate it from the pre-mortality and current partitions
          // 'midmortality_method' tells how to calculate partition partway through mortality
          s.average_partition(partmortality_partition,premortality_partition,
                              spawning_part_mort,midmortality_method);
          if (s.mature_partition || !spawning_use_total_B){
			for (int j=0;j<spawning_chars[i].size();j++)
				biomass += s.mature_abundance("biomass",year,step, mean_weight, maturity_props,spawning_chars[i][j], spawning_vals[i][j], partmortality_partition);
          } else {
			for (int j=0;j<spawning_chars[i].size();j++)
				biomass += s.abundance("biomass",year,step,mean_weight, spawning_chars[i][j], spawning_vals[i][j],partmortality_partition);
          }
        }
        (*SSBs)[i] = (*spawning_ps)[i] * biomass;
        if (type != "unfished_equilibrium"){
          s.SSBs[i][year] = (*SSBs)[i];}
	  }
    }
    if (semelparous_time==step){ // if semelparous, then remove mature fish from the partition
      int maturity_char = s.character_numbers("maturity");
      int is_mature = s.character_label_values[maturity_char]["mature"];
      for (int j=1; j<=s.n_rows; j++){
        if (s.character_value(j,maturity_char)==is_mature){
          s.partition[j]= (1.0-semelparous_mortality) * s.partition[j];
        }
      }
    }
    if (type == "normal" || type == "deterministic_simulation" || type == "stochastic_simulation"){
      // do requests for results
      //  (no results for equilibrium years)
      // SSB
      if (requests->SSBs && spawning_time==step){
        for (int i=1; i<=s.n_stocks; i++){
          (*results->SSBs)[i][year] = (*SSBs)[i];}
      }
      // abundance
      for (int entry=0; entry<requests->abundance.size(); entry++){
        std::string label = requests->abundance_labels[entry];
        if (in(requests->abundance[label].years,year) &&
            requests->abundance[label].step == step &&
            requests->abundance[label].proportion_mortality != 0){
          results->abundance[label][year] = requests->abundance[label].get_result(s,*this,year,0);
        }
      }
      // numbers_at
      for (int entry=0; entry<requests->numbers_at.size(); entry++){
        std::string label = requests->numbers_at_labels[entry];
        if (in(requests->numbers_at[label].years,year) &&
            requests->numbers_at[label].migration == "" &&
            requests->numbers_at[label].step == step &&
            requests->numbers_at[label].proportion_mortality != 0){
          results->numbers_at[label].insert(make_pair(year,
                                                 requests->numbers_at[label].get_result(s,*this,year,0)));
        }
      }
    }
    if (print_state_every_step){
      cout << "State at the end of step " << step;
      if (year > 0){
        cout << " in year " << year;}
      cout << ":\n";
      s.print(cout);
      cout << '\n';
    }
  } // finished this time step
} // finished the year

template<CDVM>
void Basic_annual_cycle<DVM>::randomise(long seed){
  // Randomise the recruitments (and anything else necessary) for projection or stochastic simulation
  DEBUG0("Basic_annual_cycle::randomise");
  for (int i=1; i<recruitment.size(); i++){
    recruitment[i]->randomise(seed);
  }
  // Randomise mirgraion annual variation (only if they are defined)
  for (int i=1; i<migration.size(); i++){
     if(migration[i]->annual_varying){
		 migration[i]->density_dependence->randomise(seed);
	 }
  }
}

template<CDVM>
void Basic_annual_cycle<DVM>::multiply_initial_abundance(int stock, double multiplier){
    DEBUG2("Basic_annual_cycle::multiply_initial_abundance");
        initialization[stock]->multiply_abundance(multiplier);
}

template<CDVM>
int Basic_annual_cycle<DVM>::valid_step(int step){
    DEBUG2("Basic_annual_cycle::valid_fishery");
    return (step>=1 && step<=time_steps);
};

template<CDVM>
int Basic_annual_cycle<DVM>::valid_fishery(std::string fishery){
    DEBUG2("Basic_annual_cycle::valid_fishery");
    int ok=0;
    for (int i=1; i<=n_fisheries; i++){
      if (fishery_names[i]==fishery) ok=1;
    }
    return ok;
};

template<CDVM>
int Basic_annual_cycle<DVM>::valid_selectivity(std::string selectivity){
    DEBUG2("Basic_annual_cycle::valid_selectivity");
    int ok=0;
    for (int i=1; i<selectivity_names.size(); i++){
      if (selectivity_names[i]==selectivity) ok=1;
    }
    return ok;
};

template<CDVM>
int Basic_annual_cycle<DVM>::valid_migration(std::string migration){
    DEBUG2("Basic_annual_cycle::valid_migration");
    int ok=0;
    for (int i=1; i<=n_migrations; i++){
      if (migration_names[i]==migration) ok=1;
    }
    return ok;
};

// OPTIM: Changed dvector& print_size_based to dvector print_sized_based
template<CDVM>
void Basic_annual_cycle<DVM>::print(Basic_state<DVM>& s, ostream& out,
                                    int every_mean_size,
                                    dvector print_sizebased_ogives_at){
  // The last argument is only used in age-based models containing size-based selectivity ogives,
  // and indicates the sizes for which the ogive should be printed.
  DEBUG1("Basic_annual_cycle::print");
  out << "Initial year : " << initial << "\nCurrent year : " << current << "\nFinal year : " << final << '\n';
  out << "Annual cycle:\n";
  int number;
  for (int i = 1; i<=time_steps; i++){
    out << "Step " << i << ":\n";
    if (!s.size_based){
      if (ageing_time==i){
        out << "  Ageing\n";
      } else {
        out << "  Growth since last birthday: " << (*growth_props)[i] << "\n";
      }
    }
    if (recruitment_time==i){
      if (s.n_areas==1){
        out << "  Recruitment\n";
      } else {
        if (s.n_stocks > 1){
          for (int i=1; i<=s.n_stocks; i++){
            out << "  Recruitment in " << s.area_names[recruitment_areas[i]] << " for stock " << s.stock_names[i] << '\n';
          }
        } else {
          out << "  Recruitment in " << s.area_names[recruitment_areas[1]] << '\n';
        }
      }
    }
    if (s.mature_partition){
      if (in(*maturation_times,i)){
        if (n_maturations>1){
          for (int j=1; j<=n_maturations; j++){
            if ((*maturation_times)[j]==i){
              out << "  Maturation episode " << j << '\n';}}
        } else {
          out << "  Maturation\n";
        }
      }
    }
    if (s.n_areas > 1){
      if (n_migrations > 0){
        if (in(*migration_times,i)){
          for (int j=1; j<=n_migrations; j++){
            if ((*migration_times)[j]==i){
              out << "  Migration " << migration_names[j];
              if (s.n_areas > 1){
                out << " from " << s.area_names[(int)((*migrate_from)[j])];
                out << " to " << s.area_names[(int)((*migrate_to)[j])] << '\n';
              } else {
                out << '\n';
              }
            }
          }
        }
      }
    }
    if (s.size_based){
      if (in(*growth_times,i)){
        if (n_growths>1){
          for (int j=1; j<=n_growths; j++){
            if ((int)((*growth_times)[j])==i){
              out << "  Growth episode " << j << '\n';}}
        } else {
          out << "  Growth\n";
        }
      }
    }
    if ((*M_props)[i]>0){
      out << "  Natural mortality: " << (*M_props)[i] << " of a year's M\n";
    }
    if (in(*fishery_times,i)){
      for (int j=1; j<=n_fisheries; j++){
        if ((int)((*fishery_times)[j])==i){
          if (n_fisheries>1){
            out << "  Fishery " << fishery_names[j] << " ";
          } else {
            out << "  Fishery ";
          }
          if (s.n_areas > 1){
            //out << "in " << s.area_names[(int)((*fishery_areas)[j])] << '\n';
          } else {
            out << '\n';
          }
        }
      }
    }
    if (spawning_time==i){
      if (s.n_stocks == 1){
        out << "  SSB counted" << (spawning_part_mort==1 ? " at end" : (spawning_part_mort==0.5 ? " in middle" : (" after proportion " + dtos(spawning_part_mort)))) << " of mortality ";
		if (s.n_areas>1){
			if(spawning_all_areas)
				out<<" in all areas ";
			else {
				out<<" in area ";
				for(int j=0;j<spawning_areas[1].size();j++)
					out<<s.area_names[spawning_areas[1][j]]+" ";
			}
			out<< "including " + dtos(100*value((*spawning_ps)[1])) + "% of " << ((spawning_use_total_B && !s.mature_partition) ? "all" : "mature") << " fish\n";
		}
	  } else {
        for (int i=1; i<=s.n_stocks; i++){
			out << "  SSB counted for stock " << s.stock_names[i] << (spawning_part_mort==1 ? " at end" : (spawning_part_mort==0.5 ? " in middle" : (" after proportion " + dtos(spawning_part_mort)))) << " of mortality ";
			if (s.n_areas>1){
				out<<" in area ";
				for(int j=0;j<spawning_areas[i].size();j++)
					out<<s.area_names[spawning_areas[i][j]]+" ";
			}
			out << "including " + dtos(100*value((*spawning_ps)[i])) + "% of " << ((spawning_use_total_B && !s.mature_partition) ? "all" : "mature") << " fish\n";
		}
      }
    }
    if (disease_time==i){
      out << "  Disease mortality\n" ;
    }
  }
  out << "The Baranov equation " << (baranov ? "is" : "is not") << " used.\n";
  out << "The partition, after proportion p of a mortality episode, is considered to be\n";
  if (midmortality_method == "weighted_sum"){
    out << "  (1-p) x pre-mortality partition + p x post-mortality partition.\n";
  } else {
    out << "  pre-mortality partition^(1-p) + post-mortality partition^p.\n";
  }
  out << "\nProcesses and calculations:\n";
  if (!s.size_based){
    out << "Ageing:\n";
    ageing->print(s,out);
  }
  if (s.n_stocks==1){
    out << "Recruitment:";
    recruitment[1]->print(s,out);
  } else {
    for (int i=1; i<=s.n_stocks; i++){
      out << "Recruitment:";
      recruitment[i]->print(s,out);
    }
  }
  if (s.size_based){
    for (int i=1;i<growth.size();i++){
      if (n_growths>1){
        out << "Growth episode " << itos(i) << ":\n";
      } else {
        out << "Growth:\n";
      }
      growth[i]->print(s,out);
    }
  }
  if (s.mature_partition){
    for (int i=1;i<maturation.size();i++){
      if (n_maturations>1){
        out << "Maturation episode " << itos(i) << ":\n";
      } else {
        out << "Maturation:\n";
      }
      maturation[i]->print(s,out);
    }
    dvector row_nos(1,s.n_rows);
    for (int i=1; i<=s.n_rows; i++){
      row_nos[i]=i;
    }
    out << "  where the rows are:\n";
    s.print_vector(out,row_nos,"row");
    out << '\n';
  }
  if (s.n_areas>1){
  for (int i=1;i<migration.size();i++){
      out << "Migration " << migration_names[i] << ":\n";
      migration[i]->print(s,out);
    }
    dvector row_nos(1,s.n_rows);
    for (int i=1; i<=s.n_rows; i++){
      row_nos[i]=i;}
    out << "  where the rows are:\n";
    s.print_vector(out,row_nos,"row");
    out << '\n';
  }
  for (int i=1;i<=time_steps;i++){
    out << "Mortality in time step " << itos(i) << ":\n";
    mortality[i]->print(s,out);
  }
  if (disease!=0){
    out << "Disease mortality:\n";
    disease->print(s,out);
  }
  if (tagging.size()!=0){
        for (int i=1; i<tagging.size(); i++){
            out << "Putting tags on fish: tagging event "+tagging[i]->episode_label+"\n";
            tagging[i]->print(s,out);
        }
  }
  if (tag_loss.size()!=0){
        for (int i=2; i<tag_loss.size(); i++){ // start from 2 because 1 is the 'no tag' tag
            out << "Fish shed tags: tag " + tag_loss[i]->tag_name + '\n';
            tag_loss[i]->print(s,out);
        }
  }
  if (!s.mature_partition){
    out << "Proportions mature:\n";
    maturity_props->print(s,out);
  }
  if (selectivities.size() > 0){
    out << "Selectivities:\n";
    std::string name;
    for (int j=1; j<selectivity_names.size(); j++){
      name = selectivity_names[j];
      out << name << ":\n  ";
      selectivities[name]->print(s,out,print_sizebased_ogives_at);
    }
    out << '\n';
  }
  if (!s.size_based){
    out << "Size at age:\n";
    size_at_age->print(s,out);
    if (every_mean_size){
            out << "Full printout of mean size at age in each year and time step:\n";
                size_at_age->print_every_mean_size(s,out);
        }
  }
  out << "Weight:\n";
  mean_weight->print(s,out);
  for (int i=1; i<=s.n_stocks; i++){
    out << "Data used in calculating the initial state\n";
    initialization[i]->print(s,out);
  }
}

template<CDVM>
Basic_annual_cycle<DVM>::Basic_annual_cycle(Parameter_set<DVM>& p,Basic_state<DVM>& s){
  // Construct the annual cycle from p.
  // Firstly the time sequence and information parameters have to be set, then the
  // various processes have to be constructed, typically via process = new Process(p).
  // If any pointer member *isn't* allocated by 'new', make sure to zero it,
  //  so that the destructor knows not to 'delete' it.
  // Otherwise, if you add any new pointer member, make sure to 'delete' it in the destructor.
  DEBUG0("Basic_annual_cycle::Basic_annual_cycle");
  DEBUG1("annual_cycle: constructing the sequence");
  initial = p.get_int("initial");
  current = p.get_int("current");
  final   = p.get_int("final");
  if (current < initial || final < current){
    fatal("In your population file, 'initial' may not be after 'current', and 'final' may not be before 'current'");}
  time_steps = p.get_int("annual_cycle.time_steps");
  recruitment_time = p.get_int("annual_cycle.recruitment_time");
  if (recruitment_time < 1 || recruitment_time > time_steps){
    fatal("Bad recruitment time of " + itos(recruitment_time) + " with " + itos(time_steps) + " time steps");}
  if (s.size_based){
    if (p.present("annual_cycle.growth_props")){
      fatal("annual_cycle.growth_props cannot be defined in a size based model");}
    n_growths = p.get_int("annual_cycle.n_growths",1);
    growth_times = new dvector(p.get_constant_vector("annual_cycle.growth_times"));
    // check growth_times for specification errors
    if (p.get_command_count("growth")!=n_growths){
      fatal("annual_cycle.n_growths does not match the number of growth episodes supplied");}
    if (growth_times->size() != n_growths){
      fatal("annual_cycle.growth_times is the wrong length (should be one time per growth episode)");}
    for (int i = 1; i<=n_growths; i++){
      std::string stock_i = p.get_string("growth["+itos(i)+"].stock","");
      if (!valid_step((int)((*growth_times)[i]))){
        fatal("Bad growth time of " + dtos((*growth_times)[i]) + " with " + itos(time_steps) + " time steps");}
      for (int j = i+1; j<=n_growths; j++){
        std::string stock_j = p.get_string("growth["+itos(j)+"].stock","");
        if ((*growth_times)[i] == (*growth_times)[j] &&
            (stock_i=="" || stock_j=="" || stock_i==stock_j)){
          fatal("Should not be more than one growth episode for the same stock in the same time step");}
      }
    }
    growth_props = 0;
    if (n_growths != growth_times->size()){
      fatal("size of growth_times should equal n_growths");}
  } else {
    if(p.present("annual_cycle.aging_time")) {
      if(p.present("annual_cycle.ageing_time")) fatal("You have used both annual_cycle.aging_time and annual_cycle.ageing_time. Note that the subcommand aging_time will be deprecated in a future version. Use ageing_time instead.");
      ageing_time = p.get_int("annual_cycle.aging_time");
    } else ageing_time = p.get_int("annual_cycle.ageing_time");
    if (!valid_step(ageing_time)){
      fatal("Bad ageing time of " + itos(ageing_time) + " with " + itos(time_steps) + " time steps");}
    growth_props = new dvector(1,time_steps);
    if (p.present("annual_cycle.growth_props")){
      if (p.get_constant_vector("annual_cycle.growth_props").size() != time_steps){
        fatal("annual_cycle.growth_props is the wrong length (should be one entry per time step)");}
      (*growth_props) = p.get_constant_vector("annual_cycle.growth_props");
    } else {
      growth_props->initialize();
    }
    growth_times = 0;
    // check growth_props for various specification errors
    if (max(*(growth_props)) > 1 || min(*(growth_props)) < 0){
      fatal("growth_props should be between 0 and 1");
    }
    if ((*growth_props)[ageing_time] != 0){
      fatal("The entry of growth_props corresponding to the time step in which ageing occurs must be set to 0.");
    }
    if (time_steps > 1){
      for (int i=2; i<=time_steps; i++){
        if (((*growth_props)[i] < (*growth_props)[i-1]) &&
            i != ageing_time){
          fatal("growth_props should not decrease except at fish birthdays");
        }
      }
      if (((*growth_props)[1] < (*growth_props)[time_steps]) &&
          1 != ageing_time){
        fatal("growth_props should not decrease except at fish birthdays");
      }
    }
  }
  if (s.n_areas > 1){
    n_migrations = p.get_int("annual_cycle.n_migrations");
    if (n_migrations > 0){
      migration_times = new dvector(p.get_constant_vector("annual_cycle.migration_times"));
      if (migration_times->size() != n_migrations){
        fatal("annual_cycle.migration_times is the wrong length (should be length n_migrations)");}
      for (int i = 1; i<=n_migrations; i++){
        if (!valid_step((int)((*migration_times)[i]))){
          fatal("Bad migration time of " + dtos((*migration_times)[i]) + " with " + itos(time_steps) + " time steps");
        }
      }
    } else migration_times = 0;
  } else {
    n_migrations = 0;
    migration_times = 0;
  }
  if (s.mature_partition){
    n_maturations = p.get_int("annual_cycle.n_maturations",1);
        if(n_maturations < s.n_stocks){
          fatal("n_maturations must be greater than or equal to the number of stocks.");
        }
    maturation_times = new dvector(p.get_constant_vector("annual_cycle.maturation_times"));
    if (maturation_times->size() != n_maturations){
      fatal("annual_cycle.maturation_times is the wrong length (should be length n_maturations)");}
    for (int i = 1; i<=n_maturations; i++){
      if (!valid_step((int)((*maturation_times)[i]))){
        fatal("Bad maturation time of " + dtos((*maturation_times)[i]) + " with " + itos(time_steps) + " time steps");
      }
    }
  } else {
    n_maturations = 0;
    maturation_times = 0;
  }
  baranov = p.get_bool("annual_cycle.baranov",0);
  fishery_names = p.get_vector_of_strings("annual_cycle.fishery_names");
  n_fisheries = fishery_names.size();
  fishery_names.insert(fishery_names.begin(),"");
  fishery_times = new dvector(p.get_constant_vector("annual_cycle.fishery_times"));
  if (fishery_times->size() != n_fisheries){
    fatal("annual_cycle.fishery_times is the wrong length (should be length n_fisheries)");}
  for (int i = 1; i<=n_fisheries; i++){
    if (!valid_step((int)((*fishery_times)[i]))){
      fatal("Bad fishery time of " + dtos((*fishery_times)[i]) + " with " + itos(time_steps) + " time steps");
    }
  }
  M_props = new dvector(p.get_constant_vector("annual_cycle.M_props"));
  // check M_props for specification errors
  if (fabs(sum(*M_props)-1)>1e-10){
    fatal("M_props should sum to 1\n");}
  if (M_props->size() != time_steps){
    fatal("size of M_props should equal time_steps");}
  midmortality_method = p.get_string("annual_cycle.midmortality_partition",
                                     baranov ? "weighted_product" : "weighted_sum");
  if (midmortality_method!="weighted_product" && midmortality_method!="weighted_sum"){
          fatal("annual_cycle.midmortality_partition should be either weighted_product or weighted_sum");}
  spawning_time = p.get_int("annual_cycle.spawning_time");
  if (!valid_step(spawning_time)){
    fatal("Bad spawning time of " + itos(spawning_time) + " with " + itos(time_steps) + " time steps");}
  spawning_part_mort = p.get_constant("annual_cycle.spawning_part_mort",0.5);
  spawning_ps = new VECTOR(s.n_stocks);
  if (p.present("annual_cycle.spawning_p")){
    (*spawning_ps) = p.get_estimable("annual_cycle.spawning_p");
  } else {
    if (p.get_estimable_vector("annual_cycle.spawning_ps").size() != s.n_stocks){
      fatal("annual_cycle.spawning_ps is the wrong size");}
    (*spawning_ps) = p.get_estimable_vector("annual_cycle.spawning_ps");
  }
 
/*if (s.n_areas > 1){
    if (p.get_bool("annual_cycle.spawning_all_areas",0)){
      spawning_all_areas = 1;
      if (s.n_stocks > 1){
        fatal("Only use annual_cycle.spawning_all_areas for single-stock models");}
      spawning_areas = 0;
    } else {
      spawning_all_areas = 0;
      if (p.get_vector_of_strings("annual_cycle.spawning_areas").size() != s.n_stocks){
        fatal("annual_cycle.spawning_areas is the wrong length (should be length n_stocks)");}
      std::vector<std::string> spawn_areas = p.get_vector_of_strings("annual_cycle.spawning_areas");
      spawning_areas = new dvector(1,s.n_stocks);
      for (int i=1; i<=spawn_areas.size(); i++){
        std::string this_area = spawn_areas[i-1];
        if (!s.valid_area(this_area)){
          fatal("Unknown spawning area " + this_area);}
        (*spawning_areas)[i] = s.area_numbers[this_area];
      }
    }
  } else spawning_areas = 0;*/

	if (s.n_areas > 1){
		if(((p.present("annual_cycle.spawning_all_areas")!=0)+(p.present("annual_cycle.spawning_areas")!=0)+(p.get_command_count("spawning_grounds")>0))!=1)
			fatal("You must specify one of annual_cycle.spawning_all_areas,annual_cycle.spawning_areas, and spawning_grounds command when there are more than one area");
		if (p.get_bool("annual_cycle.spawning_all_areas",0)){
			spawning_all_areas = 1;
			if (s.n_stocks > 1)
				fatal("Only use annual_cycle.spawning_all_areas for single-stock models");
		} else if(p.present("annual_cycle.spawning_areas")) {
			spawning_all_areas = 0;
			std::vector<std::string> spawn_areas = p.get_vector_of_strings("annual_cycle.spawning_areas");
			if(spawn_areas.size()!=s.n_stocks)
				fatal("annual_cycle.spawning_areas is the wrong length (should be length n_stocks)");
			spawning_areas.resize(s.n_stocks+1);
			for(int i=1;i<=s.n_stocks;i++){
				std::string this_area = spawn_areas[i-1];
				if (!s.valid_area(this_area))
					fatal("Unknown spawning area " + this_area);
				spawning_areas[i]=std::vector<int>();
				spawning_areas[i].push_back(s.area_numbers[this_area]);
			}
		} else {
			spawning_all_areas = 0;
			spawning_areas.resize(s.n_stocks+1);
			for(int i=1;i<=s.n_stocks;i++){
				std::string command=s.n_stocks>1? "spawning_grounds["+s.stock_names[i]+"].":"spawning_grounds.";
				std::vector<std::string> spawn_areas_by_stock = p.get_vector_of_strings(command+"areas");
				spawning_areas[i]=std::vector<int>();
				for(int j=0;j<spawn_areas_by_stock.size();j++){
					std::string this_area = spawn_areas_by_stock[j];
					if (!s.valid_area(this_area))
						fatal("Unknown spawning area " + this_area);
					if(!in(spawning_areas[i],s.area_numbers[this_area]))
						spawning_areas[i].push_back(s.area_numbers[this_area]);
				}
			}
		}
	}


  if (!s.mature_partition){
    if (s.n_areas==1){
      spawning_use_total_B = p.get_bool("annual_cycle.spawning_use_total_B",0);
    } else {
      spawning_use_total_B = p.get_bool("annual_cycle.spawning_use_total_B");
    }
  }



  if(p.present("annual_cycle.semelparous_time")) {
    semelparous_time = p.get_int("annual_cycle.semelparous_time");
    if(!(s.mature_partition)) {
      fatal("Semelparous mortality is not implemented for scenarios that do not have maturity in the partition");}
    if (!valid_step(semelparous_time)){
      fatal("Bad semelparous_time of " + itos(semelparous_time) + " with " + itos(time_steps) + " time steps");}
    semelparous_mortality = p.get_estimable("annual_cycle.semelparous_mortality",1.0);
    if(semelparous_mortality <= 0.0 || semelparous_mortality >1.0) {
      fatal("Bad semelparous_mortality value in 'population.csl'. Values must be > 0 and <= 1.");}
  } else semelparous_time = 0;
  // containers for partitions partway through the mortality episode
  premortality_partition = s.partition;
  partmortality_partition = s.partition;
  // the following are used in the calculation of SSB
  spawning_sex = p.get_string("annual_cycle.spawning_sex","all");
  if(!s.sex_partition) {
    if(spawning_sex!="all") {
      fatal("The subcommand 'annual_cycle.spawning_sex' must be defined as 'all' when sex is not a member of the partition.");
    }
  } else if(!(spawning_sex=="male" || spawning_sex=="female" || spawning_sex=="all")) {
    fatal("The subcommand 'annual_cycle.spawning_sex' must be defined as either 'male', 'female', or 'all' when sex is a member of the partition.");
  }

  spawning_chars.resize(s.n_stocks+1); // +1 so indices begin at 1
  spawning_vals.resize(s.n_stocks+1);

/*for (int i=1; i<=s.n_stocks; i++){
    spawning_chars[i] = std:std::vector<int>();
    spawning_vals[i] = std::vector<int>();;
    if (s.n_areas>1){
      if (!spawning_all_areas){
        spawning_chars[i].push_back(s.character_numbers("area"));
        spawning_vals[i].push_back((int)((*spawning_areas)[i]));
      }
    }
    if (s.n_stocks>1){
      spawning_chars[i].push_back(s.character_numbers("stock"));
      spawning_vals[i].push_back(i);
    }
    if (spawning_sex!="all") {
      spawning_chars[i].push_back(s.character_numbers("sex"));
      spawning_vals[i].push_back(spawning_sex=="male"?1:2);
    }
  }*/
	for (int i=1; i<=s.n_stocks; i++){
		spawning_chars[i].push_back(std::vector<int>());
		spawning_vals[i].push_back(std::vector<int>());
		if(s.n_areas>1){
			if(!spawning_all_areas){	//s.n_stocks==1
				spawning_chars[i].resize(spawning_areas[i].size());
				spawning_vals[i].resize(spawning_areas[i].size());				
				for(int j=0;j<spawning_areas[i].size();j++){
					spawning_chars[i][j].push_back(s.character_numbers("area"));
					spawning_vals[i][j].push_back(spawning_areas[i][j]);
				}
			}
		}
		for(int j=0;j<spawning_chars[i].size();j++){
			if(s.n_stocks>1){
				spawning_chars[i][j].push_back(s.character_numbers("stock"));
				spawning_vals[i][j].push_back(i);
			}
			if (spawning_sex!="all") {
				spawning_chars[i][j].push_back(s.character_numbers("sex"));
				spawning_vals[i][j].push_back(spawning_sex=="male"?1:2);
			}
		}
	}

  DEBUG1("annual_cycle: constructing recruitment");
  if (s.n_areas > 1){
    if (p.get_vector_of_strings("annual_cycle.recruitment_areas").size() != s.n_stocks){
      fatal("annual_cycle.recruitment_areas is the wrong length (should be length n_stocks)");}
    std::vector<std::string> recruit_area_names = p.get_vector_of_strings("annual_cycle.recruitment_areas");
    recruitment_areas.resize(s.n_stocks+1);
    for (int i=1; i<=s.n_stocks; i++){
      std::string this_area = recruit_area_names[i-1];
      if (!s.valid_area(this_area)){
        fatal("Unknown recruitment area " + this_area);}
      recruitment_areas[i]=s.area_numbers[this_area];
    }
  } else {
    recruitment_areas.resize(s.n_stocks+1);
    for (int i=0; i<recruitment_areas.size(); i++){
      recruitment_areas[i] = -1;}
  }
  recruitment.resize(s.n_stocks+1);
  recruitment[0] = 0; // dummy entry
  int y_enter = p.get_int("y_enter");
  for (int i=1; i<=s.n_stocks; i++){
        if (s.n_stocks > 1){
          if (!in(p.get_command_labels("recruitment"),s.stock_names[i])){
                fatal("CASAL can't find the @recruitment block for stock " + s.stock_names[i]);}
        }
        else {
            if (0==p.get_command_count("recruitment")){
              fatal("CASAL can't find the @recruitment block");}
        }
        recruitment[i] = new Basic_recruitment<DVM>(p,s,recruitment_time,i,recruitment_areas[i],y_enter);
  }
  if (!s.size_based){
    // For age-based models we can check whether y_enter is what we think it should be
    int true_y_enter = (s.min_age + ((recruitment_time < ageing_time && ageing_time <= spawning_time) ? 1 : (recruitment_time >= ageing_time && ageing_time > spawning_time) ? -1 : 0));
    if (y_enter != true_y_enter){
      fatal("The value of y_enter appears to be incorrect. It is currently " + itos(y_enter) + ", but it should be y_enter=" + itos(true_y_enter));
      //cout << "Are you sure about y_enter = " << y_enter << "?\n\n";
    }
    if (y_enter==0 && recruitment_time<=spawning_time){
      fatal("You cannot use y_enter = 0 unless recruitment is in a later time step than spawning.");
    }
  }
  if (!s.size_based){
    DEBUG1("annual_cycle: constructing size at age");
    if (p.get_string("size_at_age_type")=="data"){
      size_at_age = new Size_at_age_from_data<DVM>(p,s,*growth_props);
    } else if (p.present("annual_growths") && !p.get_int("simulation",0)){
      size_at_age = new Size_at_age_effective_age<DVM>(p,s,*growth_props);
    } else {
      size_at_age = new Size_at_age_years_same<DVM>(p,s,*growth_props);
    }
  } else size_at_age = 0;
  if (s.mature_partition){
    DEBUG1("annual_cycle: constructing maturation");
    maturation.resize(n_maturations+1);
    maturation[0] = 0; // dummy entry
    for (int i=1; i<=n_maturations; i++){
          if (!in(p.get_command_labels("maturation"),itos(i))){
                fatal("CASAL can't find the @maturation block number " + itos(i));}
      maturation[i] = new Basic_partition_maturity<DVM>(p,s,(int)((*maturation_times)[i]),i,size_at_age);
    }
  }
  if (!s.mature_partition){
    DEBUG1("annual_cycle: constructing maturity_props");
    maturity_props = new Basic_nonpartition_maturity<DVM>(p,s);
  } else maturity_props = 0;
  if (!s.size_based){
    DEBUG1("annual_cycle: constructing ageing");
    ageing = new Basic_ageing<DVM>;
  } else ageing = 0;
  if (s.size_based){
    DEBUG1("annual_cycle: constructing growth");
    growth.resize(n_growths+1);
    growth[0] = 0; // dummy entry
    for (int i=1; i<=n_growths; i++){
          if (!in(p.get_command_labels("growth"),itos(i))){
                fatal("CASAL can't find the @growth block number " + itos(i));}
      if (p.get_string("growth[" + itos(i) + "].type") == "basic"){
        growth[i] = new Growth_years_same<DVM>(p,s,(int)((*growth_times)[i]),i);}
      else if (p.get_string("growth[" + itos(i) + "].type") == "exponential"){
        growth[i] = new Growth_years_same<DVM>(p,s,(int)((*growth_times)[i]),i);}
      else if (p.get_string("growth[" + itos(i) + "].type") == "matrix"){
        growth[i] = new Growth_years_same<DVM>(p,s,(int)((*growth_times)[i]),i);}
      else if (p.get_string("growth[" + itos(i) + "].type") == "matrix_by_sex"){
        growth[i] = new Growth_years_same<DVM>(p,s,(int)((*growth_times)[i]),i);}
      else if (p.get_string("growth[" + itos(i) + "].type") == "matrix_by_maturity"){
        growth[i] = new Growth_years_same<DVM>(p,s,(int)((*growth_times)[i]),i);}
      else if (p.get_string("growth[" + itos(i) + "].type") == "matrix_by_sex_and_maturity"){
        growth[i] = new Growth_years_same<DVM>(p,s,(int)((*growth_times)[i]),i);}
      else fatal("Unknown growth type: " + p.get_string("growth[" + itos(i) + "].type"));
    }
  }
  DEBUG1("annual_cycle: constructing mean weight");
  if (s.size_based){
    mean_weight = new Sizebased_mean_weight<DVM>(p,s);
  } else {
    mean_weight = new Agebased_mean_weight<DVM>(p,s,size_at_age);
  }
  DEBUG1("annual_cycle: constructing selectivities");
  selectivity_names = p.get_vector_of_strings("selectivity_names");
  selectivity_names.insert(selectivity_names.begin(),"");
  for (int i=1; i<selectivity_names.size(); i++){
    if (selectivity_names[i]=="none") fatal("The name of a selectivity cannot be 'none' in CASAL. Please choose a different label for your selectivity.");
    if (!in(p.get_command_labels("selectivity"),selectivity_names[i])){
      fatal("CASAL can't find the @selectivity block for selectivity " + selectivity_names[i]);}
    selectivities[selectivity_names[i]] = new Selectivity<DVM>(p,s,selectivity_names[i],size_at_age);
  }
  DEBUG1("annual_cycle: constructing mortality");
  // this is the most complicated member... one mortality object for every time step,
  // and a choice of several mortality methods (fishing / no fishing / no mortality at all,
  // Baranov / not,...)
  
  if (s.n_areas > 1){
	  if(p.present("annual_cycle.fishery_areas") && p.get_command_count("fishing_grounds") > 0){
		  fatal("Define either @annual_cycle.fishery_areas or @fishing_ground for a model with multiple areas, but not both!");
	  }
	  if(!p.present("annual_cycle.fishery_areas") && !p.get_command_count("fishing_grounds") > 0){
		  fatal("Define @annual_cycle.fishery_areas or @fishing_ground for a model with multiple areas!");
	  }
	  if(p.present("annual_cycle.fishery_areas")){
		fishery_areas = new dvector(1,n_fisheries);
		std::vector<std::string> fishery_area_names = p.get_vector_of_strings("annual_cycle.fishery_areas");
		if (fishery_area_names.size() != n_fisheries){
			fatal("Error in subcommand 'fishery_areas' of command 'annual_cycle' - wrong number of areas provided - should be " + itos(n_fisheries));
        }
		for (int i=1; i<=n_fisheries; i++){
			if (!s.valid_area(fishery_area_names[i-1])){
			fatal("Unknown fishery area " + fishery_area_names[i-1]);
			}
			(*fishery_areas)[i] = s.area_numbers[fishery_area_names[i-1]];
		}
	  } else fishery_areas = 0;
  } else fishery_areas = 0;
// Allow for the stocks to have different mortality rates
//

 int num_mort_blocks = p.get_command_count("natural_mortality");
 std::vector<std::string> nat_mortality_names = p.get_command_labels("natural_mortality");

 // N.B. If there is only one natural mortality block then by default it applies to all stocks
 if( num_mort_blocks > 1 && num_mort_blocks != s.n_stocks ){
    fatal("The number of @natural_mortality blocks (" + itos(p.get_command_count("natural_mortality")) + ") does not equal the number of stocks (" + itos(s.n_stocks) + ")\n");
 }
 // If there is more than one @natural_mortality block then they all need a stock label
 if (num_mort_blocks > 1){
   for (int i = 1; i<=nat_mortality_names.size() ; i++){
     std::string this_stock = nat_mortality_names[i-1];
     if (this_stock == "")
         fatal("You need to give a stock label for each @natural_mortality command in the population file.\n");
     if ( !s.valid_stock(this_stock) )
         fatal(this_stock + " is not a valid stock label for a @natural_mortality command in the population file.\n");
   }
 }

  mortality.resize(time_steps+1); // +1 to allow for unused [0] element
  int M_by_element = (p.present("natural_mortality.ogive_all")
                      || p.present("natural_mortality.ogive_male")
                      || p.present("natural_mortality.ogive_avg")
                      || p.present("natural_mortality.ogive_mature")
                      || p.present("natural_mortality.ogive_male_mature")
                      || num_mort_blocks > 1);

  int F_this_step, M_this_step;
  for (int i=1; i<=time_steps; i++){
    F_this_step = 0;
    M_this_step = (*M_props)[i]>0;
    for (int j=1; j<=n_fisheries; j++){
      if ((int)((*fishery_times)[j])==i){
        F_this_step = 1;
      }
    }
    if (!M_this_step && !F_this_step){
      mortality[i] = new No_mortality<DVM>(p,s,i);
    }
    else if (F_this_step){
      if (baranov){
        mortality[i] = new Baranov_fisheries<DVM>(p,s,i,
                                                  mean_weight,size_at_age,
                                                  *M_props, *fishery_times,*fishery_areas,
                                                  fishery_names,
                                                  selectivities);
      }
      else {
        mortality[i] = new Basic_fisheries<DVM>(p,s,i,
                                                mean_weight,size_at_age,
                                                *M_props, *fishery_times,*fishery_areas,
                                                fishery_names,
                                                selectivities);
      }
    }

    else if (M_by_element){
      mortality[i] = new Natural_only_by_element<DVM>(p,s,i,*M_props, size_at_age);
    }
    else {
      mortality[i] = new Natural_only_by_row<DVM>(p,s,i,*M_props);
    }
  }   // end of loop over time steps

  DEBUG1("annual_cycle: constructing disease mortality");
  if (p.present("annual_cycle.disease_mortality_time")){
    disease_time = p.get_int("annual_cycle.disease_mortality_time");
    if (disease_time < 1 || disease_time > time_steps){
      fatal("Bad disease_mortality_time of " + itos(disease_time) + " with " + itos(time_steps) + " time steps");}
    disease = new DiseaseMortality<DVM>(p,s,selectivities);
  } else {
    disease_time = 0;
    disease = 0;
  }
  DEBUG1("annual_cycle: constructing tag placement");
  if (s.n_tag_states>1){
    tagging.resize(p.get_command_count("tag")+1);
    // note there is a dummy element 0
    for (int i=1; i<=p.get_command_count("tag"); i++){
                tagging[i] = new TaggingFish<DVM>(p,s,p.get_command_labels("tag")[i-1],selectivities);
                int year = p.get_int("tag["+p.get_command_labels("tag")[i-1]+"].year");
                if (!p.get_int("simulation",0) && (year<initial || year>current)){
                        fatal("You have entered an invalid year of "+itos(year)+" in the tagging block for "+s.tag_names[i+1]+" - it should be between 'initial' and 'current'");}
        }
  }
  DEBUG1("annual_cycle: constructing tag loss");
  if (s.n_tag_states>1){
        tag_loss.resize(s.n_tag_states+1); // dummy element 0
        //      cerr << " setting first tag_loss to 0\n";
        tag_loss[1] = 0; // can't lose a tag if you haven't got one!
        for (int i=2; i<=s.n_tag_states; i++){
          // cerr << "setting tag_loss["<<i<<"]\n";
                if (p.get_int("simulation",0)) tag_loss[i] = 0;
                else tag_loss[i] = new TagLoss<DVM>(p,s,s.tag_names[i]);
        }
        // cerr << "done\n";
  }
  if (s.n_areas>1 && n_migrations > 0){
    DEBUG1("annual_cycle: constructing migration");
    migration_names = p.get_vector_of_strings("annual_cycle.migration_names");
    if (migration_names.size() != n_migrations){
      fatal("Wrong number of migration names specified: is " + itos(migration_names.size()) + ", should be " + itos(n_migrations));}
    migration_names.insert(migration_names.begin(),"");
    migrate_from = new dvector(1,n_migrations);
    migrate_to = new dvector(1,n_migrations);
    std::vector<std::string> migrate_from_names = p.get_vector_of_strings("annual_cycle.migrate_from");
    if (migrate_from_names.size()!=n_migrations){
                fatal("Error in annual_cycle.migrate_from - wrong number of source areas - should be " + itos(n_migrations));
        }
    for (int i=1; i<=n_migrations; i++){
      if (!s.valid_area(migrate_from_names[i-1])){
        fatal("Unknown migration source " + migrate_from_names[i-1]);
      }
      (*migrate_from)[i] = s.area_numbers[migrate_from_names[i-1]];
    }
    std::vector<std::string> migrate_to_names = p.get_vector_of_strings("annual_cycle.migrate_to");
    if (migrate_to_names.size()!=n_migrations){
                fatal("Error in annual_cycle.migrate_to - wrong number of destination areas - should be " + itos(n_migrations));
        }
    for (int i=1; i<=n_migrations; i++){
      if (!s.valid_area(migrate_to_names[i-1])){
        fatal("Unknown migration destination " + migrate_to_names[i-1]);
      }
      (*migrate_to)[i] = s.area_numbers[migrate_to_names[i-1]];
      if ((*migrate_from)[i] == (*migrate_to)[i]){
                  fatal("Migration labelled " + migration_names[i] + " goes to the same place it leaves from - source and destination should be different areas");
         }
    }
    migration.resize(n_migrations+1);
    migration[0] = 0; // dummy entry
    for (int i=1; i<=n_migrations; i++){
          if (!in(p.get_command_labels("migration"),migration_names[i])){
                fatal("CASAL can't find the @migration block for migration " + migration_names[i]);}
      if (p.present("migration[" + migration_names[i] + "].rates_all")
          || p.present("migration[" + migration_names[i] + "].rates_male")){
        migration[i] = new Migration_by_ogive<DVM>(p,s,(int)((*migration_times)[i]),migration_names[i],
                                                   (int)((*migrate_from)[i]),(int)((*migrate_to)[i]),
                                                   size_at_age, mean_weight);
      } else {
        migration[i] = new Migration_by_constant<DVM>(p,s,(int)((*migration_times)[i]),migration_names[i],
                                                      (int)((*migrate_from)[i]),(int)((*migrate_to)[i]), mean_weight);
      }
    }
    // check migrations for specification errors
    for (int i = 1; i<n_migrations; i++){
      int stock_i = migration[i]->stock;
      for (int j = i+1; j<=n_migrations; j++){
        int stock_j = migration[j]->stock;
        if ((*migration_times)[i] == (*migration_times)[j]){
   // The following commented code implements the constraint that no area is allowed to be
   // both a source and destination for migration (in the same time step). This was felt to be an
   // unnecessary constraint, so the code was commented out.
   //     if ((*migrate_from)[i] == (*migrate_to)[j]
   //      || (*migrate_from)[j] == (*migrate_to)[i]
   //      && (stock_i>0 && stock_j>0 && stock_i == stock_j)){
   //       fatal("No area can be both a source and destination of migration for the same stock in the same step\n");
   //     }
          if ((*migrate_from)[i] == (*migrate_from)[j]
              && (stock_i>0 && stock_j>0 && stock_i == stock_j)){
            fatal("No area can be a source of two migrations for the same stock in the same step\n");
          }
        }
      }
    }
  } else migrate_from = migrate_to = 0;
  DEBUG1("annual_cycle: constructing initialization");
  initialization.resize(s.n_stocks+1);
  initialization[0] = 0; // dummy entry
  for (int i=1; i<=s.n_stocks; i++){
        if (s.n_stocks > 1){
          if (!in(p.get_command_labels("initialization"),s.stock_names[i])){
                fatal("CASAL can't find the @initialization block for stock " + s.stock_names[i]);}
        } else {
          if (0==p.get_command_count("initialization")){
            fatal("CASAL can't find the @initialization block");}
        }
    initialization[i] = new Basic_initialization_data<DVM>(p,s,i,y_enter);
  }
  // and some working variables used in do_year
  ones = new dvector(s.col_min,s.col_max);
  *ones = 1;
  SSBs = new VECTOR(1,s.n_stocks);
  (*SSBs) = -1;
}

template<CDVM>
Basic_annual_cycle<DVM>::~Basic_annual_cycle(){
  DEBUG1("~Basic_annual_cycle");
  if (maturity_props!=0) delete maturity_props;
  if (ageing!=0) delete ageing;
  for (int i=1; i<recruitment.size(); i++){
    delete recruitment[i];}
  for (int i=1; i<growth.size(); i++){
    delete growth[i];}
  for (int i=1; i<mortality.size(); i++){
    delete mortality[i];}
  for (int i=1; i<migration.size(); i++){
    delete migration[i];}
  for (int i=1; i<maturation.size(); i++){
    delete maturation[i];}
  for (int i=1; i<tagging.size(); i++){
    delete tagging[i];}
  for (int i=1; i<tag_loss.size(); i++){
    if (tag_loss[i]!=0) delete tag_loss[i];}
  for (int i=1; i<initialization.size(); i++){
    delete initialization[i];}
  if (selectivities.size() != 0){
    for (int i=1; i<selectivity_names.size(); i++){
      delete selectivities[selectivity_names[i]];}}
  if (size_at_age!=0) delete size_at_age;
  if (mean_weight!=0) delete mean_weight;
  //if (spawning_areas!=0) delete spawning_areas;
  delete spawning_ps;
  if (growth_times!=0) delete growth_times;
  if (migration_times!=0) delete migration_times;
  if (maturation_times!=0) delete maturation_times;
  if (growth_props!=0) delete growth_props;
  delete M_props;
  delete fishery_times;
  //if (fishery_areas!=0) delete fishery_areas;
  delete ones;
  delete SSBs;
  if (migrate_from!=0) delete migrate_from;
  if (migrate_to!=0) delete migrate_to;
  if (disease!=0) delete disease;
}

//############################## REQUESTS AND RESULTS ##############################
template<CDVM>
void Basic_requests<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG1("Basic_requests::print");
  out << "Requests: \n";
  if (actual_catches)
    out << "  Record actual and specified catches\n";
  if (actual_catches_by_stock)
    out << "  Record actual catches by stock\n";
  if (actual_catches_by_area)
    out << "  Record actual catches by area\n";
  if (fishing_pressure)
    out << "  Record fishing pressures\n";
  if (numbers_tagged)
    out << "  Record numbers of fish tagged in each tagging episode\n";
  if (disease_biomass_loss)
    out << "  Record biomass of fish lost to disease in each year\n";
  if (B0){
    out << "  Record B0\n";}
  if (Binitial){
    out << "  Record Binitial\n";}
  if (Bmean){
        out << "  Record Bmean\n";}
  if (R0){
    out << "  Record R0\n";}
  if (Rinitial){
    out << "  Record Rinitial\n";}
  if (Rmean){
        out << "  Record Rmean\n";}
  if (recruitments){
    out << "  Record recruitments (as absolute numbers of fish indexed by the year in which they recruit)\n";}
  if (YCS){
    out << "  Record YCS (as deviates indexed by the year in which they are spawned)\n";}
  if (true_YCS){
    out << "  Record true YCS (YCS * CR * SR, indexed by the year in which they are spawned)\n";}
  if (Ts){
    out << "  Record climate variable T\n";}
  if (SSBs){
    out << "  Record SSBs\n";}
  out << setprecision(8);
  if (catch_at.size() > 0){
    for (int i=0; i<catch_at_labels.size(); i++){
      std::string label = catch_at_labels[i];
      out << "  Record " << label << ": ";
      catch_at[label].print(s,out);
      out << "\n";
    }
  }
  if (abundance.size() > 0){
    for (int i=0; i<abundance_labels.size(); i++){
      std::string label = abundance_labels[i];
      out << "  Record " << label << ": ";
      abundance[label].print(s,out);
      out << ".\n";
    }
  }
  if (numbers_at.size() > 0){
    for (int i=0; i<numbers_at_labels.size(); i++){
      std::string label = numbers_at_labels[i];
      out << "  Record " << label << ": ";
      numbers_at[label].print(s,out);
      out << ".\n";
    }
  }
  out << '\n';
}

template<CDVM>
Basic_requests<DVM>::~Basic_requests(){
  DEBUG1("~Basic_requests");
}

template<CDVM>
Basic_requests<DVM>::Basic_requests(Parameter_set<DVM>& p){
  // Construct the components of Basic_requests - so far there are none which need construction.
  // The Basic_requests will be filled in later by Basic_population_section::set_requests.
  DEBUG1("Basic_requests::Basic_requests");
}

template<CDVM>
void Catch_at_request<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG2("Catch_at_request::print");
  out << (sexed ? "sexed " : "unsexed ") << "catch-at-" << (at_size ? "size" : "age") << " for years " << years << "in " << ((fishery_names.size()==1) ? "fishery " : "fisheries ") << fishery_names;
  if (!s.size_based && at_size){
    out << " using size classes with minimums " << class_mins << (plus_group ? " (the last size class is a plus group)" : " (the last value is the maximum of the last size class)");
  }
}

template<CDVM>
Catch_at_request<DVM>::Catch_at_request(Parameter_set<DVM>& p, Basic_state<DVM>& s, const std::string& label)
  : command("catch_at[" + label + "].")
  , years(p.get_constant_vector(command+"years"))
  , class_mins(p.get_constant_vector(command+"class_mins",s.class_mins)){
  // Construct the catch_at_request from the Parameter_set.
  DEBUG2("Catch_at_request::Catch_at_request");
  at_size = (s.size_based ? 1 : p.get_bool(command + "at_size",0));
  sexed = p.get_bool(command + "sexed",s.sex_partition);
  fishery_names = p.get_vector_of_strings(command + "fishery");
 /* JUNK?
 for (int i=0; i<fishery_names.size(); i++){
    fisheries.push_back(s.area_numbers[fishery_names[i]]);}
    */
  plus_group = p.get_bool(command + "plus_group",s.plus_group);
  if (years.size() > 1){ // check that years are in increasing order
    for (int i=2; i<=years.indexmax(); i++){
      if (years[i] <= years[i-1]){
        fatal("Years should be increasing in catch-at request " + label);
      }
    }
  }
  years.shift(0);
}

template<CDVM>
DOUBLE Abundance_request<DVM>::get_result(Basic_state<DVM>& s, Basic_annual_cycle<DVM>& a,
                                          int year, int before_mortality){
  // Called by do_year to calculate and return the abundance.
  // This can be called either before or after mortality.
  DEBUG1("Abundance_request::get_result");
  if (!(proportion_mortality == 1 || (proportion_mortality == 0 && before_mortality))){
    // we need to back-calculate the partition partway through mortality
    s.average_partition(a.partmortality_partition,a.premortality_partition,
                        proportion_mortality,a.midmortality_method);
  } else {
    // we can just use the current partition
    a.partmortality_partition = s.partition;
  }
  // for which characters are we considering restricted values?
  std::vector<int> character_nums, character_vals;
  if (s.n_areas > 1 && area != 0){
    character_nums.push_back(s.character_numbers("area"));
    character_vals.push_back(area);
  }
  if (s.n_stocks > 1 && stock != 0){
    character_nums.push_back(s.character_numbers("stock"));
    character_vals.push_back(stock);
  }
  std::string type = biomass ? "biomass" : "numbers";
  // now calculate the abundance - four options, depending on whether a selectivity
  // ogive is used or not, and whether immature fish are included or not
  DOUBLE abundance;
  if (selectivity_name != "none" && !a.valid_selectivity(selectivity_name)){
          fatal("Selectivity not recognised: " + selectivity_name + " in abundance request");}
  if (!mature_only){
    if (selectivity_name != "none"){
      abundance = s.abundance(type, year, step, a.mean_weight, character_nums, character_vals,
                              a.partmortality_partition, a.selectivities[selectivity_name]);
    } else {
      abundance = s.abundance(type, year, step, a.mean_weight, character_nums, character_vals,
                              a.partmortality_partition);
    }
  } else if (mature_only){
    if (selectivity_name != "none"){
      abundance = s.mature_abundance(type, year, step, a.mean_weight, a.maturity_props,
                                     character_nums, character_vals, a.partmortality_partition,
                                     a.selectivities[selectivity_name]);
    } else {
      abundance = s.mature_abundance(type, year, step, a.mean_weight, a.maturity_props,
                                     character_nums, character_vals, a.partmortality_partition);
    }
  }
  return abundance;
}

template<CDVM>
void Abundance_request<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG2("Abundance_request::print");
  out << (mature_only ? "mature " : "") << (biomass ? "biomass" : "numbers") << " in years " << years;
  if (s.n_areas > 1){
    if (area > 0){
      out << "in area " + s.area_names[area] + ", ";
    }
  }
  if (s.n_stocks > 1){
    if (stock > 0){
      out << "for stock " + s.stock_names[stock] + ", ";
    }
  }
  out << "in time step " << step << ", after proportion " << proportion_mortality << " of the mortality";
  if (selectivity_name != "none"){
    out << ", applying selectivity ogive " << selectivity_name;
  }
}

template<CDVM>
Abundance_request<DVM>::Abundance_request(Parameter_set<DVM>& p, Basic_state<DVM>& s,
                                          const std::string& label)
  : command("abundance[" + label + "].")
  , years(p.get_constant_vector(command+"years")){
  // Construct the abundance_request from the Parameter_set.
  DEBUG2("Abundance_request::Abundance_request");
  step = p.get_int(command + "step");
  if (s.n_areas > 1){
    if (p.present(command+"area")){
      std::string area_name = p.get_string(command+"area");
      if (!s.valid_area(area_name)){
        fatal("Unknown area: " +area_name + " in abundance request");}
      area = s.area_numbers[area_name];
    } else area = 0;
  }
  if (s.n_stocks > 1){
    if (p.present(command+"stock")){
      std::string stock_name = p.get_string(command+"stock");
      if (!s.valid_stock(stock_name)){
        fatal("Unknown stock: " +stock_name + " in abundance request");}
      stock = s.stock_numbers[stock_name];
    } else stock = 0;
  }
  mature_only = p.get_bool(command + "mature_only",0);
  proportion_mortality = p.get_constant(command + "proportion_mortality",0.5);
  biomass = p.get_bool(command + "biomass");
  selectivity_name = p.get_string(command + "ogive","none");
  if (years.size() > 1){ // check that years are in increasing order
    for (int i=2; i<=years.indexmax(); i++){
      if (years[i] <= years[i-1]){
        fatal("Years should be increasing in abundance request " + label);
      }
    }
  }
  years.shift(0);
}

template<CDVM>
MATRIX Numbers_at_request<DVM>::get_result(Basic_state<DVM>& s, Basic_annual_cycle<DVM>& a,
                                           int year, int before_mortality){
  // Called by do_year to calculate and return the numbers-at.
  // This can be called either before or after mortality,
  // or if migration!="", either before or after a migration.
  DEBUG1("Numbers_request::get_result");
  if (migration=="" && tagging_episode==""){
    if (!(proportion_mortality == 1 || (proportion_mortality == 0 && before_mortality))){
      // we need to back-calculate the partition partway through mortality
      s.average_partition(a.partmortality_partition,a.premortality_partition,
                          proportion_mortality,a.midmortality_method);
    } else {
      // we can just use the current partition
      a.partmortality_partition = s.partition;
    }
  } else {
    // we can just use the current partition
    a.partmortality_partition = s.partition;
  }
  // for which characters are we considering restricted values?
  std::vector<int> character_nums, character_vals;
  if (s.n_areas > 1){
    character_nums.push_back(s.character_numbers("area"));
    character_vals.push_back(area);
  }
  if (s.n_stocks > 1 && stock != 0){
    character_nums.push_back(s.character_numbers("stock"));
    character_vals.push_back(stock);
  }
  if (s.n_tag_states > 1 && tag != 0){
    character_nums.push_back(s.character_numbers("tag"));
    character_vals.push_back(tag);
  }
  int numbers_at_size_in_agebased = (!s.size_based && at_size);
  // this next bit is real complicated... The request can be with or without selectivity,
  // may or may not be numbers-at-size in an age-based model, and may or may not be
  // for mature fish only. Hence eight different numbers_at-type calls.
  if (selectivity_name != "none" && !a.valid_selectivity(selectivity_name)){
      fatal("Selectivity not recognised: " + selectivity_name + " in numbers-at request");}
  MATRIX numbers_at(1,(sexed ? 2 : 1),
                    (numbers_at_size_in_agebased ? 1 : s.col_min),
                    (numbers_at_size_in_agebased ? (class_mins.size() - (plus_group ? 0 : 1))
                                                 : s.col_max));
  if (!mature_only){
    if (!numbers_at_size_in_agebased){
      if (selectivity_name != "none"){
        numbers_at = s.numbers_at(sexed, year, step,
                                  character_nums, character_vals,
                                  a.partmortality_partition, a.selectivities[selectivity_name], just_the_ogive);
      } else {
        numbers_at = s.numbers_at(sexed, year, step,
                                  character_nums, character_vals, a.partmortality_partition);
      }
    } else {
      if (selectivity_name != "none"){
        numbers_at = s.numbers_at_size_in_agebased(sexed, year, step, class_mins, plus_group,
                                                   a.size_at_age, character_nums, character_vals,
                                                   a.partmortality_partition,
                                                   a.selectivities[selectivity_name]);
      } else {
        numbers_at = s.numbers_at_size_in_agebased(sexed, year, step, class_mins, plus_group,
                                                   a.size_at_age, character_nums, character_vals,
                                                   a.partmortality_partition);
      }
    }
  } else {  // mature fish only
    if (!numbers_at_size_in_agebased){
      if (selectivity_name != "none"){
        numbers_at = s.mature_numbers_at(sexed, year, step, a.maturity_props,
                                         character_nums, character_vals,
                                         a.partmortality_partition, a.selectivities[selectivity_name], just_the_ogive);
      } else {
        numbers_at = s.mature_numbers_at(sexed, year, step, a.maturity_props,
                                         character_nums, character_vals,
                                         a.partmortality_partition);
      }
    } else {
      if (selectivity_name != "none"){
        numbers_at = s.mature_numbers_at_size_in_agebased(sexed, year, step, class_mins, plus_group,
                                                          a.maturity_props, a.size_at_age,
                                                          character_nums, character_vals,
                                                          a.partmortality_partition,
                                                          a.selectivities[selectivity_name]);
      } else {
        numbers_at = s.mature_numbers_at_size_in_agebased(sexed, year, step, class_mins, plus_group,
                                                          a.maturity_props, a.size_at_age,
                                                           character_nums, character_vals,
                                                          a.partmortality_partition);
      }
    }
  }
  return numbers_at;
}

template<CDVM>
void Numbers_at_request<DVM>::print(Basic_state<DVM>& s, ostream& out){
  DEBUG2("Numbers_at_request::print");
  out << (sexed ? "sexed " : "unsexed ") << (mature_only ? "mature " : "") << "numbers-at-" << (at_size ? "size" : "age") << " for years " << years << "in " << ((s.n_areas > 1) ? ("area " + s.area_names[area] + ", ") : "");
  if (migration=="" && tagging_episode==""){
    out << "time step " << step << ", after proportion " << proportion_mortality << " of the mortality";
  } else if (tagging_episode==""){
    out << (after ? "after " : "before ") << "migration " << migration;
  } else {
    out << "just after tagging episode " << tagging_episode;
  }
  if (s.n_stocks > 1){
    if (stock > 0){
      out << "for stock " + s.stock_names[stock] + ", ";
    }
  }
  if (selectivity_name != "none"){
    out << ", applying selectivity ogive " << selectivity_name;
  }
  if (!s.size_based && at_size){
    out << " using size classes with minimums " << class_mins << (plus_group ? " (the last size class is a plus group)" : " (the last value is the maximum of the last size class)");
  }
  if (tag){
          if (tag==1){
                  out << ", only untagged fish";
          } else {
                  out << ", only fish with tag " << s.tag_names[tag];
          }
  }
  if (just_the_ogive){
        out << " - actually this is a dummy request - we just want to see the ogive.";}
}

template<CDVM>
Numbers_at_request<DVM>::Numbers_at_request(Parameter_set<DVM>& p, Basic_state<DVM>& s,
                                            const std::string& label)
  : command("numbers_at[" + label + "].")
  , years(p.get_constant_vector(command+"years"))
  , class_mins(p.get_constant_vector(command+"class_mins",s.class_mins)){
  // Construct the numbers_at_request from the Parameter_set.
  DEBUG2("Numbers_at_request::Numbers_at_request");
  if (p.present(command + "migration")){
    migration = p.get_string(command + "migration");
    before = p.get_int(command + "before",0);
    after = p.get_int(command + "after",0);
    std::vector<std::string> migration_names = p.get_vector_of_strings("annual_cycle.migration_names");
    migration_names.insert(migration_names.begin(),"");
    if (!in(migration_names,migration)){
      fatal("Unknown migration label " + migration);}
    int migration_no = pos(migration_names,migration);
    step = (int)p.get_constant_vector("annual_cycle.migration_times")[migration_no];
    std::vector<std::string> migrate_from = p.get_vector_of_strings("annual_cycle.migrate_from");
    migrate_from.insert(migrate_from.begin(),"");
    std::string area_name = migrate_from[migration_no];
    area = s.area_numbers[area_name];
    if (s.n_stocks > 1){
      if (p.present(command+"stock")){
        std::string stock_name = p.get_string(command+"stock");
        if (!s.valid_stock(stock_name)){
           fatal("Unknown stock: " +stock_name+ " in numbers-at request");}
        stock = s.stock_numbers[stock_name];
      } else stock = 0;
    }
  } else {
        if (p.present(command+"tagging_episode")){
          tagging_episode = p.get_string(command+"tagging_episode");
          std::string tag_command = "tag["+tagging_episode+"].";
          step = p.get_int(tag_command + "step");
      if (s.n_areas > 1){
                  std::string area_name = p.get_string(tag_command + "area");
          if (!s.valid_area(area_name)){
            fatal("Unknown area: " +area_name+ " in numbers-at request");}
          area = s.area_numbers[area_name];
          }
      if (s.n_stocks > 1){
         if (p.present(tag_command+"stock")){
            std::string stock_name = p.get_string(tag_command+"stock");
            if (!s.valid_stock(stock_name)){
               fatal("Unknown stock: " +stock_name+ " in numbers-at request");}
            stock = s.stock_numbers[stock_name];
         } else stock = 0;
      }
        } else {
      step = p.get_int(command + "step");
      proportion_mortality = p.get_constant(command + "proportion_mortality",0.5);
      if (s.n_areas > 1){
        std::string area_name = p.get_string(command + "area");
        if (!s.valid_area(area_name)){
          fatal("Unknown area: " +area_name+ " in numbers-at request");}
        area = s.area_numbers[area_name];
      }
      if (s.n_stocks > 1){
        if (p.present(command+"stock")){
          std::string stock_name = p.get_string(command+"stock");
          if (!s.valid_stock(stock_name)){
             fatal("Unknown stock: " +stock_name+ " in numbers-at request");}
          stock = s.stock_numbers[stock_name];
        } else stock = 0;
      }
    }
  }
  sexed = p.get_bool(command + "sexed",s.sex_partition);
  mature_only = p.get_bool(command + "mature_only",0);
  if (p.present(command+"tag")){
          tag = s.tag_numbers[p.get_string(command+"tag")];
  } else tag=0;
  at_size = p.get_bool(command + "at_size",s.size_based);
  selectivity_name = p.get_string(command + "ogive","none");
  if (years.size() > 1){ // check that years are in increasing order
    for (int i=2; i<=years.indexmax(); i++){
      if (years[i] <= years[i-1]){
        fatal("Years should be increasing in numbers_at request " + label);
      }
    }
  }
  years.shift(0);
  plus_group = p.get_bool(command + "plus_group",s.plus_group);
  just_the_ogive = p.get_int(command + "just_the_ogive",0);
}

template<CDVM>
void Basic_population_section<DVM>::set_requests(Parameter_set<DVM>& p){
  // Fill in requests: initialize members of results as necessary.
  DEBUG0("set_requests");

  requests.actual_catches = p.get_int("requests.actual_catches",0);
  requests.actual_catches_by_stock = p.get_int("requests.actual_catches_by_stock",0);
  requests.actual_catches_by_area = p.get_int("requests.actual_catches_by_area",0);
  requests.removals = p.get_int("requests.removals",0);
  requests.discards = p.get_int("requests.discards",0);
  requests.fishing_pressure = p.get_int("requests.fishing_pressure",0);
  requests.numbers_tagged = p.get_int("requests.numbers_tagged",0);
  requests.disease_biomass_loss = p.get_int("requests.disease_biomass_loss",0);
  requests.B0 = p.get_int("requests.B0",0);
  requests.Binitial = p.get_int("requests.Binitial",0);
  requests.Bmean = p.get_int("requests.Bmean",0);
  requests.R0 = p.get_int("requests.R0",0);
  requests.Rinitial = p.get_int("requests.Rinitial",0);
  requests.Rmean = p.get_int("requests.Rmean",0);
  if ((requests.Bmean || requests.Rmean) && !p.get_bool("use_mean_YCS",0)){
    fatal("Don't ask for Bmean or Rmean as output quantities unless use_mean_YCS is defined");}
  requests.recruitments = p.get_int("requests.recruitments",0);
  requests.YCS = p.get_int("requests.YCS",0);
  requests.true_YCS = p.get_int("requests.true_YCS",0);
  requests.Ts = p.get_int("requests.Ts",0);
  requests.migration_annual_variation = p.get_int("requests.migration_annual_variation",0);

  if(requests.migration_annual_variation){
     if(annual_cycle->n_migrations==0)
	    fatal("Don't ask for migration_annual_variation unless migration is defined");
  }
  requests.SSBs = p.get_int("requests.SSBs",0);
  requests.catch_at = std::map<std::string,Catch_at_request<DVM> >();
  int n_catch_at_requests = p.get_command_count("catch_at");
  requests.catch_at_labels = p.get_command_labels("catch_at");
  for (int i=0; i<n_catch_at_requests; i++){
    std::string label = requests.catch_at_labels[i];
    requests.catch_at.insert(make_pair(label,Catch_at_request<DVM>(p,state,label)));
  }
  requests.abundance = std::map<std::string,Abundance_request<DVM> >();
  int n_abundance_requests = p.get_command_count("abundance");
  requests.abundance_labels = p.get_command_labels("abundance");
  for (int i=0; i<n_abundance_requests; i++){
    std::string label = requests.abundance_labels[i];
    requests.abundance.insert(make_pair(label,Abundance_request<DVM>(p,state,label)));
  }
  requests.numbers_at = std::map<std::string,Numbers_at_request<DVM> >();
  int n_numbers_at_requests = p.get_command_count("numbers_at");
  requests.numbers_at_labels = p.get_command_labels("numbers_at");
  for (int i=0; i<n_numbers_at_requests; i++){
    std::string label = requests.numbers_at_labels[i];
    requests.numbers_at.insert(make_pair(label,Numbers_at_request<DVM>(p,state,label)));
  }
}

template<CDVM>
void Basic_results<DVM>::empty(){
  // Zero all the components of the results object.
  actual_catches = std::map<int,std::map<std::string,DOUBLE> >();
  specified_catches = std::map<int,std::map<std::string,DOUBLE> >();
  actual_catches_by_stock = std::map<int,std::map<std::string,std::map<std::string,DOUBLE> > >();
  actual_catches_by_area = std::map<int,std::map<std::string,std::map<std::string,DOUBLE> > >();
  removals = std::map<int,std::map<std::string,DOUBLE> >();
  removals_by_stock = std::map<int,std::map<std::string,std::map<std::string,DOUBLE> > >();
  removals_by_area = std::map<int,std::map<std::string,std::map<std::string,DOUBLE> > >();
  discards = std::map<int,std::map<std::string,DOUBLE> >();
  discards_by_stock = std::map<int,std::map<std::string,std::map<std::string,DOUBLE> > >();
  discards_by_area = std::map<int,std::map<std::string,std::map<std::string,DOUBLE> > >();
  fishing_pressure = std::map<int,std::map<std::string,DOUBLE> >();
  fishing_pressure_limit_exceeded = 0;
  numbers_tagged = std::map<std::string,DOUBLE>();
  disease_biomass_loss = std::map<int,DOUBLE>();

  migration_annual_variation = std::map<int,std::map<std::string,DOUBLE> >();

  SSBs->initialize();
  recruitments->initialize();
  YCS->initialize();
  true_YCS->initialize();
  Ts->initialize();
  B0->initialize();
  Binitial->initialize();
  Bmean->initialize();
  R0->initialize();
  Rinitial->initialize();
  Rmean->initialize();
  catch_at = std::map<std::string,std::map<int,MATRIX> >();
  abundance = std::map<std::string,std::map<int,DOUBLE> >();
  numbers_at = std::map<std::string,std::map<int,MATRIX> >();
}

template<CDVM>
void Basic_results<DVM>::print(Basic_state<DVM>& s, Basic_requests<DVM>& requests, ostream& out){
  DEBUG1("Basic_results::print");
  out << "Results: \n";
  if (requests.actual_catches){
    out << "  actual_catches " << actual_catches << '\n';
    out << "  specified_catches " << specified_catches << '\n';
  }
  if (requests.actual_catches_by_stock){
    out << "  actual_catches_by_stock " << actual_catches_by_stock << '\n';
  }
  if (requests.actual_catches_by_area){
    out << "  actual_catches_by_area " << actual_catches_by_area << '\n';
  }
  if (requests.fishing_pressure){
    out << "  fishing pressure " << fishing_pressure << '\n';}
  if (fishing_pressure_limit_exceeded){
    out << "  A fishing pressure limit was exceeded.\n";
  } else {
    out << "  No fishing pressure limit was exceeded.\n";
  }
  if (requests.migration_annual_variation){
    out << "  mirgation_annual_variation " << migration_annual_variation << '\n';
  }


  if (requests.B0){
    out << "\n  B0 " << *B0 << '\n';
  }
  if (requests.Binitial){
    out << "\n  Binitial " << *Binitial << '\n';
  }
  if (requests.Bmean){
    out << "\n  Bmean " << *Bmean << '\n';
  }
  if (requests.R0){
    out << "\n  R0 " << *R0 << '\n';
  }
  if (requests.Rinitial){
    out << "\n  Rinitial " << *Rinitial << '\n';
  }
  if (requests.Rmean){
    out << "\n  Rmean " << *Rmean << '\n';
  }
  if (requests.recruitments){
    out << "\n  recruitments (as absolute numbers of fish, indexed by the year in which they recruited)\n  ";
    if (s.n_stocks>1) out << "stock";
    for (int year = recruitments->colmin(); year<=recruitments->colmax(); year++){
      out << setw(7);
      out << year << ' ';
    }
    out << "\n  ";
    for (int i=1; i<=s.n_stocks; i++){
      out << "  ";
      if (s.n_stocks>1) out << s.stock_names[i];
      for (int year = recruitments->colmin(); year<=recruitments->colmax(); year++){
        out << setw(7);
        out << (*recruitments)[i][year] << ' ';
      }
      out << "\n";
    }
  }
  if (requests.YCS){
    out << "\n  YCS (as deviates, indexed by the year in which they spawn)\n  ";
    if (s.n_stocks>1) out << "stock";
    for (int year = YCS->colmin(); year<=YCS->colmax(); year++){
      out << setw(7);
      out << year << ' ';
    }
    out << "\n  ";
    for (int i=1; i<=s.n_stocks; i++){
      out << "  ";
      if (s.n_stocks>1) out << s.stock_names[i];
      for (int year = YCS->colmin(); year<=YCS->colmax(); year++){
        out << setw(7);
        out << (*YCS)[i][year] << ' ';
      }
      out << "\n";
    }
  }
  if (requests.true_YCS){
    out << "\n  'true YCS' (YCS * CR * SR, indexed by the year in which they spawn)\n  ";
    if (s.n_stocks>1) out << "stock";
    for (int year = true_YCS->colmin(); year<=true_YCS->colmax(); year++){
      out << setw(7);
      out << year << ' ';
    }
    out << "\n  ";
    for (int i=1; i<=s.n_stocks; i++){
      out << "  ";
      if (s.n_stocks>1) out << s.stock_names[i];
      for (int year = true_YCS->colmin(); year<=true_YCS->colmax(); year++){
        out << setw(7);
        out << (*true_YCS)[i][year] << ' ';
      }
      out << "\n";
    }
  }
  if (requests.Ts){
    out << "\n  Climate data T\n  ";
    if (s.n_stocks>1) out << "stock";
    for (int year = Ts->colmin(); year<=Ts->colmax(); year++){
      out << setw(7);
      out << year << ' ';
    }
    out << "\n  ";
    for (int i=1; i<=s.n_stocks; i++){
      out << "  ";
      if (s.n_stocks>1) out << s.stock_names[i];
      for (int year = Ts->colmin(); year<=Ts->colmax(); year++){
        out << setw(7);
        out << (*Ts)[i][year] << ' ';
      }
      out << "\n";
    }
  }

  if (requests.SSBs){
    out << "\n  SSBs\n  ";
    if (s.n_stocks>1) out << "stock ";
    for (int year = SSBs->colmin(); year<=SSBs->colmax(); year++){
      out << setw(7);
      out << year << ' ';
    }
    out << "\n  ";
    for (int i=1; i<=s.n_stocks; i++){
      out << "  ";
      if (s.n_stocks>1) out << s.stock_names[i] << ' ';
      for (int year = SSBs->colmin(); year<=SSBs->colmax(); year++){
        out << setw(7);
        out << (*SSBs)[i][year] << ' ';
      }
      out << "\n";
    }
  }
  out << '\n';
  if (catch_at.size() > 0){
    for (int i=0; i<catch_at.size(); i++){
      std::string label = requests.catch_at_labels[i];
      out << "  " <<  label << ": ";
      requests.catch_at[label].print(s,out);
      out << " is:\n\n";
      out << catch_at[label] << '\n';
    }
  }
  out<< setprecision(6);
  if (abundance.size() > 0){
    for (int i=0; i<abundance.size(); i++){
      std::string label = requests.abundance_labels[i];
      out << "  " <<  label << ": ";
      requests.abundance[label].print(s,out);
      out << " : " << abundance[label] << "\n";
      out << '\n';
    }
  }
  if (numbers_at.size() > 0){
    for (int i=0; i<numbers_at.size(); i++){
      std::string label = requests.numbers_at_labels[i];
      out << "  " <<  label << ": ";
      requests.numbers_at[label].print(s,out);
      out << " is:\n\n";
      out << numbers_at[label] << '\n';
    }
  }
  if (!numbers_tagged.empty()){
         typename std::map<std::string,DOUBLE>::iterator nit;
         for (nit=numbers_tagged.begin(); nit!=numbers_tagged.end(); nit++){
                 out << "  Number of fish tagged in tagging episode " << nit->first << " : " << nit->second << '\n';
         }
  }
  if (!disease_biomass_loss.empty()){
         typename std::map<int,DOUBLE>::iterator dit;
         out << "  Year   Biomass of fish killed by disease";
         for (dit=disease_biomass_loss.begin(); dit!=disease_biomass_loss.end(); dit++){
                 out << "  " << dit->first << " " << dit->second << '\n';
         }
         out << '\n';
  }
}

template<CDVM>
Basic_results<DVM>::Basic_results(Parameter_set<DVM>& p){
  // Construct the components of Basic_results.
  // Not much to do - just allocate some vectors and matrices.
  DEBUG1("Basic_results::Basic_results");
  int n_stocks = p.get_int("n_stocks",1);
  int initial = p.get_int("initial");
  int final = p.get_int("final");
  int y_enter = p.get_int("y_enter");
  recruitments = new MATRIX(1,n_stocks,initial,final);
  YCS = new MATRIX(1,n_stocks,initial-y_enter,final-y_enter);
  true_YCS = new MATRIX(1,n_stocks,initial-y_enter,final-y_enter);
  Ts = new MATRIX(1,n_stocks,initial-y_enter,final-y_enter);
  SSBs = new MATRIX(1,n_stocks,initial,final);
  B0 = new VECTOR(1,n_stocks);
  Binitial = new VECTOR(1,n_stocks);
  Bmean = new VECTOR(1,n_stocks);
  R0 = new VECTOR(1,n_stocks);
  Rinitial = new VECTOR(1,n_stocks);
  Rmean = new VECTOR(1,n_stocks);
}

template<CDVM>
Basic_results<DVM>::~Basic_results(){
  DEBUG1("~Basic_results");
  delete SSBs;
  delete recruitments;
  delete YCS;
  delete true_YCS;
  delete Ts;
  delete B0;
  delete Binitial;
  delete Bmean;
  delete R0;
  delete Rinitial;
  delete Rmean;
}
//############################## END OF POPULATION SECTION.cpp ##############################

// Create particular instantiations of the template
template class Basic_population_section<double, dvector, dmatrix>;
template class Basic_annual_cycle<double, dvector, dmatrix>;
template class Basic_state<double, dvector, dmatrix>;
template class Basic_nonpartition_maturity<double, dvector, dmatrix>;
template class Partition<double, dvector, dmatrix>;
template class Basic_population_section<dvariable, dvv, dvm>;
template class Basic_annual_cycle<dvariable, dvv, dvm>;
template class Basic_state<dvariable, dvv, dvm>;
template class Partition<dvariable, dvv, dvm>;
