// const char* time_stamp = "$Date: 2012-03-21 09:16:46 +1300 (Wed, 21 Mar 2012) $\n";
// const char* penalties_cpp_id = "$Id: penalties.cpp 4643 2012-03-20 20:16:46Z Dunn $\n";

//############################## PENALTIES ##############################
#include "penalties.h"
#include "population_section.h"

/////////////////////////////////////////////////////////////////////////
template<CDVM>
void Penalties<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  // Place requests for results from the population section. Pass these to the population
  // section using a set_requests call.
  DEBUG1("Penalties::set_request_parameters");
  for (unsigned int i=0; i<pen.size(); i++){
    pen[i]->set_request_parameters(p);}
}

template<CDVM>
void Penalties<DVM>::evaluate(Basic_population_section<DVM>& popn,
                              Parameter_set<DVM>& e,
                              Qs<DVM>& qs){
  // Evaluate each penalty, from popn.results, e or qs.q as necessary.
  // Leave the results in 'values'.
  DEBUG0("Penalties::evaluate");
  for (unsigned int i=0; i<pen.size(); i++){
    values[i] = pen[i]->evaluate(popn,e,qs);}
}

template<CDVM>
DOUBLE Penalties<DVM>::total(){
  // Used after a 'evaluate' call. Returns the total of all the penalties.
  DEBUG2("Penalties::total");
  DOUBLE result = 0;
  for (unsigned int i=0; i<pen.size(); i++){
    result += values[i];}
  return result;
}

template<CDVM>
void Penalties<DVM>::print(int print_values, ostream& out){
  // If values!=0, print the current values of the penalties as well as what they are.
  DEBUG2("Penalties::print");
  for (unsigned int i=0; i<pen.size(); i++){
    out << pen[i]->label << " :\n";
    pen[i]->print(out);
    if (print_values){
      out << "Current value: " << values[i] << '\n';}
  }
  out << '\n';
}

template<CDVM>
Penalties<DVM>::Penalties(Parameter_set<DVM>& e){
  // Construct the penalties object from the estimation dataset.
  DEBUG0("Penalties::Penalties");
  for (int i=1; i<=e.get_command_count("ogive_smoothing_penalty"); i++){
    pen.push_back(new Ogive_smoothing_penalty< DVM>(e,i));}
  for (int i=1; i<=e.get_command_count("catch_limit_penalty"); i++){
    pen.push_back(new Catch_limit_penalty< DVM>(e,i));}
  for (int i=1; i<=e.get_command_count("vector_average_penalty"); i++){
    pen.push_back(new Vector_average_penalty< DVM>(e,i));}
  for (int i=1; i<=e.get_command_count("vector_smoothing_penalty"); i++){
    pen.push_back(new Vector_smoothing_penalty< DVM>(e,i));}
  for (int i=1; i<=e.get_command_count("element_difference_penalty"); i++){
    pen.push_back(new Element_difference_penalty< DVM>(e,i));}
  for (int i=1; i<=e.get_command_count("YCS_difference_penalty"); i++){
    pen.push_back(new YCS_difference_penalty< DVM>(e,i));}
  for (int i=1; i<=e.get_command_count("similar_qs_penalty"); i++){
    pen.push_back(new Similar_qs_penalty< DVM>(e,i));}
  for (int i=1; i<=e.get_command_count("ratio_qs_penalty"); i++){
    pen.push_back(new Ratio_qs_penalty< DVM>(e,i));}
  for (int i=1; i<=e.get_command_count("ogive_comparison_penalty"); i++){
    pen.push_back(new Ogive_comparison_penalty< DVM>(e,i));}
  for (int i=1; i<=e.get_command_count("ogive_difference_penalty"); i++){
    pen.push_back(new Ogive_difference_penalty< DVM>(e,i));}
  for (int i=1; i<=e.get_command_count("fish_tagged_penalty"); i++){
    pen.push_back(new Fish_tagged_penalty< DVM>(e,i));}
  values.resize(pen.size());
}

template<CDVM>
Penalties<DVM>::~Penalties(){
  DEBUG1("~Penalties");
  for (unsigned int i=0; i<pen.size(); i++){
    delete pen[i];}
}

template<CDVM>
Penalty<DVM>::Penalty(const std::string& _label){
  DEBUG2("Penalty::penalty");
  label = _label;
}

template<CDVM>
DOUBLE Ogive_smoothing_penalty<DVM>::evaluate(Basic_population_section<DVM>& popn,
                                              Parameter_set<DVM>& p,
                                              Qs<DVM>& qs){
  DEBUG1("Ogive_smoothing_penalty::evaluate");
  std::vector<std::string> ogives;
  ogives.push_back("ogive");
  check_parname(ogive_name, p, p, "penalty labelled " + this->label, ogives);
  if (p.get_ogive_type(ogive_name) != "allvalues" && p.get_ogive_type(ogive_name) != "allvalues_bounded"){
    fatal("Cannot apply an ogive smoothing penalty to " + ogive_name + " which is of type " + p.get_ogive_type(ogive_name) + " - this penalty is for allvalues and allvalues_bounded ogives only.");}
  VECTOR values(p.get_ogive_values(ogive_name));
  int low, high;
  low = (lower_bound >= 0) ? lower_bound : popn.state.col_min;
  high = (upper_bound >= 0) ? upper_bound : popn.state.col_max;
        // check that the bounds are within the range defined by the partition
  if(low < popn.state.col_min) {
    fatal("Lower bound on the ogive smoothing penalty " + ogive_name + " is lower than the minimum value allowed by the partition.");}
  if(high > popn.state.col_max) {
    fatal("Upper bound on the ogive smoothing penalty " + ogive_name + " is higher than the maximum value allowed by the partition.");}
  DOUBLE pen = 0;
  if(log_scale) {
    for(int i=low; i<=high; i++) {
      if(values[i]<=0)
        fatal("Unable to apply a log scale ogive_smoothing_penalty with label " + this->label + "to a value of <=0");
      values[i] = log(values[i]);
    }
  }
  for (int i=1; i<=r; i++){
    for (int j=low; j<=(high-i); j++){
      values[j] = values[j+1] - values[j];
    }
    values[high-i+1] = 0;
  }
  for (int j=low; j<=high; j++){
    pen += values[j]*values[j];}
  return pen * multiplier;
}

template<CDVM>
void Ogive_smoothing_penalty<DVM>::print(ostream& out){
  out << "Ogive smoothing penalty of " << multiplier << " x sum of squares of ";
  if(log_scale) {
    out << "Ogive smoothing penalty of " << multiplier << " x sum of squares of differences of order " << r << " of the logged values in ogive " << ogive_name << " ";
  } else {
    out << "Ogive smoothing penalty of " << multiplier << " x sum of squares of differences of order " << r << " in ogive " << ogive_name << " ";
  }
  if (lower_bound >= 0) out << "excluding ages below " << lower_bound << " ";
  if (upper_bound >= 0) out << "excluding ages above " << upper_bound << " ";
  out << '\n';
}

template<CDVM>
Ogive_smoothing_penalty<DVM>::Ogive_smoothing_penalty(Parameter_set<DVM>& e, int penalty_no)
  : Penalty<DVM>(e.get_string("ogive_smoothing_penalty["+itos(penalty_no)+"].label")){
  std::string command = "ogive_smoothing_penalty[" + itos(penalty_no) + "].";
  ogive_name = e.get_string(command+"ogive");
  multiplier = e.get_constant(command+"multiplier");
  r = e.get_int(command+"r");
  lower_bound = e.get_int(command+"lower_bound",-1);
  upper_bound = e.get_int(command+"upper_bound",-1);
  log_scale = e.get_bool(command+"log_scale");
}

template<CDVM>
void Catch_limit_penalty<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  p.put_int("requests.actual_catches",1);
}

template<CDVM>
DOUBLE Catch_limit_penalty<DVM>::evaluate(Basic_population_section<DVM>& popn,
                                          Parameter_set<DVM>& p,
                                          Qs<DVM>& qs){
  DEBUG1("Catch_limit_penalty::evaluate");
  if (!popn.annual_cycle->valid_fishery(fishery_name)){
        fatal("You have used an invalid fishery label " + fishery_name + " in the penalty labelled " + this->label);}
  if (!popn.results.fishing_pressure_limit_exceeded){ // no fishing pressure limit exceeded: no penalty
    return 0;
  } else {
    DOUBLE pen = 0;
    VECTOR actual(1,popn.results.actual_catches.size());
    VECTOR specified(1,popn.results.specified_catches.size());
    int count=1;
    typedef typename std::map<int,std::map<std::string,DOUBLE> >::iterator MAP_IT;
    for (MAP_IT i=popn.results.actual_catches.begin(); i!=popn.results.actual_catches.end(); ++i){
      actual[count++] = (i->second)[fishery_name];}
    count = 1;
    for (MAP_IT i=popn.results.specified_catches.begin(); i!=popn.results.specified_catches.end(); ++i){
      specified[count++] = (i->second)[fishery_name];}
    if (!log_scale){
      pen = sum(pow(actual-specified,2));
    } else {  // careful not to take log(0)
      for (int i=1; i<=actual.size(); i++){
        if (specified[i]>0){
          pen += pow(log(fmax(actual[i],specified[i]*0.1))-log(specified[i]),2);
        }
      }
    }
    return pen * multiplier;
  }
}

template<CDVM>
void Catch_limit_penalty<DVM>::print(ostream& out){
  out << "Catch limit penalty of " << multiplier << " x the sum of squares of ";
  if (!log_scale){
    out << "(actual catch - specified catch)";
  } else {
    out << "(log(actual catch) - log(specified catch))";
  }
  out << " for fishery " << fishery_name << " to disencourage breaking exploitation rate limits\n";
}

template<CDVM>
Catch_limit_penalty<DVM>::Catch_limit_penalty(Parameter_set<DVM>& e, int penalty_no)
  : Penalty<DVM>(e.get_string("catch_limit_penalty[" + itos(penalty_no) + "].label")){
  std::string command = "catch_limit_penalty[" + itos(penalty_no) + "].";
  log_scale = e.get_bool(command+"log_scale");
  fishery_name = e.get_string(command+"fishery");
  multiplier = e.get_constant(command+"multiplier");
}

template<CDVM>
DOUBLE Vector_average_penalty<DVM>::evaluate(Basic_population_section<DVM>& popn,
                                             Parameter_set<DVM>& p,
                                             Qs<DVM>& qs){
  DEBUG1("Vector_average_penalty::evaluate");
  std::vector<std::string> vectors;
  vectors.push_back("constant_vector");
  vectors.push_back("estimable_vector");
  check_parname(vector_name, p, p, "penalty labelled " + this->label, vectors);
  DOUBLE pen;
  VECTOR values(p.get_estimable_vector(vector_name));
  int low, high;
  low = (lower_bound >= 0) ? lower_bound : values.indexmin();
  high = (upper_bound >= 0) ? upper_bound : values.indexmax();
        // check that the bounds are within the range defined by the vector
  if(low < values.indexmin()) {
    fatal("Lower bound on the vector average penalty " + vector_name + " is lower than the minimum index value of the vector.");}
  if(high > values.indexmax()) {
    fatal("Upper bound on the vector average penalty " + vector_name + " is higher than the maximum index value of the vector.");}
  if(high <= low){
    fatal("Upper bound on the vector average penalty " + vector_name + " is lower or equal to the lower bound.");}

  DOUBLE temp_sum = 0;
  if (parameter_supplied=="l"){
    if (min(values)<=0)
      fatal("Using vector_average_penalty " + this->label + " on the log-scale has resulted in a log(0) error");
    for (int j=low; j<=high; j++)
      temp_sum += log(values[j]);
    pen = pow(temp_sum/((double) (high - low + 1)) - l, 2);
  } else if (parameter_supplied=="k"){
    for (int j=low; j<=high; j++)
      temp_sum += values[j];
    pen = pow(temp_sum/((double) (high - low + 1)) - k, 2);
  } else if (parameter_supplied=="m"){
    if ((mean(values)/m)<=0)
      fatal("Using vector_average_penalty " + this->label + " on the log-scale has resulted in a log(0) error");
    for (int j=low; j<=high; j++)
      temp_sum += values[j];
    pen = pow(log(temp_sum/((double) (high - low + 1))) / m, 2);
  }
  return pen * multiplier;
}

template<CDVM>
void Vector_average_penalty<DVM>::print(ostream& out){
  out << "Vector average penalty of " << multiplier << " x square of ";
  if (parameter_supplied=="l"){
    out << "(mean(log(" << vector_name << ")) - " << l << ") ";
  } else if (parameter_supplied=="k"){
    out << "(mean(" << vector_name << ") - " << k << ") ";
  } else if (parameter_supplied=="m"){
    out << "(log(mean(" << vector_name << ") / " << m << ")) ";
  }
  if (lower_bound >= 0) out << "excluding vector index below " << lower_bound << " ";
  if (upper_bound >= 0) out << "and excluding vector index above " << upper_bound << " ";
  out << '\n';
}

template<CDVM>
Vector_average_penalty<DVM>::Vector_average_penalty(Parameter_set<DVM>& e, int penalty_no)
  : Penalty<DVM>(e.get_string("vector_average_penalty["+itos(penalty_no)+"].label")){
  std::string command = "vector_average_penalty[" + itos(penalty_no) + "].";
  vector_name = e.get_string(command+"vector");
  multiplier = e.get_constant(command+"multiplier");
  if (e.present(command+"l")){
    l = e.get_constant(command+"l");
    parameter_supplied = "l";
  } else if (e.present(command+"k")){
    k = e.get_constant(command+"k");
    parameter_supplied = "k";
  } else {
    m = e.get_constant(command+"m");
    parameter_supplied = "m";
  }
  lower_bound = e.get_int(command+"lower_bound",-1);
  upper_bound = e.get_int(command+"upper_bound",-1);
}

template<CDVM>
DOUBLE Vector_smoothing_penalty<DVM>::evaluate(Basic_population_section<DVM>& popn,
                                             Parameter_set<DVM>& p,
                                             Qs<DVM>& qs){
  DEBUG1("vector_smoothing_penalty::evaluate");
  std::vector<std::string> vectors;
  vectors.push_back("constant_vector");
  vectors.push_back("estimable_vector");
  check_parname(vector_name, p, p, "penalty labelled " + this->label, vectors);
  VECTOR values(p.get_estimable_vector(vector_name));
  int low, high;
  low = (lower_bound >= 0) ? lower_bound : values.indexmin();
  high = (upper_bound >= 0) ? upper_bound : values.indexmax();
        // check that the bounds are within the range defined by the vector
  if(low < values.indexmin()) {
    fatal("Lower bound on the vector smoothing penalty " + vector_name + " is lower than the minimum index value of the vector.");}
  if(high > values.indexmax()) {
    fatal("Upper bound on the vector smoothing penalty " + vector_name + " is higher than the maximum index value of the vector.");}
  if(high <= low){
    fatal("Upper bound on the vector smoothing penalty " + vector_name + " is lower or equal to the lower bound.");}
  DOUBLE pen = 0;
  if(log_scale) {
    for(int i=low; i<=high; i++) {
      if(values[i]<=0)
        fatal("Unable to apply a log scale vector_smoothing_penalty with label " + this->label + "to a value of <=0");
      values[i] = log(values[i]);
    }
  }
  for (int i=1; i<=r; i++){
    for (int j=low; j<=(high-i); j++) {
      values[j] = values[j+1] - values[j];
    }
    values[high-i+1] = 0;
  }
  for (int j=low; j<=high; j++){
    pen += values[j]*values[j];}
  return pen * multiplier;
}

template<CDVM>
void Vector_smoothing_penalty<DVM>::print(ostream& out){
  if(log_scale) {
    out << "Vector smoothing penalty of " << multiplier << " x sum of squares of differences of order " << r << " of the logged values in vector " << vector_name << " ";
  } else {
    out << "Vector smoothing penalty of " << multiplier << " x sum of squares of differences of order " << r << " in vector " << vector_name << " ";
  }
  if (lower_bound >= 0) out << "excluding vector index below " << lower_bound << " ";
  if (upper_bound >= 0) out << "and excluding vector index above " << upper_bound << " ";
  out << '\n';
}

template<CDVM>
Vector_smoothing_penalty<DVM>::Vector_smoothing_penalty(Parameter_set<DVM>& e, int penalty_no)
  : Penalty<DVM>(e.get_string("vector_smoothing_penalty["+itos(penalty_no)+"].label")){
  std::string command = "vector_smoothing_penalty[" + itos(penalty_no) + "].";
  vector_name = e.get_string(command+"vector");
  multiplier = e.get_constant(command+"multiplier");
  r = e.get_int(command+"r");
  lower_bound = e.get_int(command+"lower_bound",-1);
  upper_bound = e.get_int(command+"upper_bound",-1);
  log_scale = e.get_bool(command+"log_scale");
}

template<CDVM>
DOUBLE Element_difference_penalty<DVM>::evaluate(Basic_population_section<DVM>& popn,
                                             Parameter_set<DVM>& p,
                                             Qs<DVM>& qs){
  DEBUG1("Element_difference_penalty::evaluate");
  std::vector<std::string> vectors;
  vectors.push_back("constant_vector");
  vectors.push_back("estimable_vector");
  check_parname(vector1_name, p, p, "penalty labelled " + this->label, vectors);
  check_parname(vector2_name, p, p, "penalty labelled " + this->label, vectors);
  DOUBLE pen;
  VECTOR values1(p.get_estimable_vector(vector1_name));
  VECTOR values2(p.get_estimable_vector(vector2_name));
  if (i < values1.indexmin() || i > values1.indexmax() ||
      i < values2.indexmin() || i > values2.indexmax()){
    fatal("Element difference penalty " + this->label + " : the designated element " + itos(i) + " is out of the range of at least one of the vectors.");}
  pen = pow(values1[i]-values2[i], 2);
  return pen * multiplier;
}

template<CDVM>
void Element_difference_penalty<DVM>::print(ostream& out){
  out << "Element difference penalty of " << multiplier << " x square of ";
  out << "the " << i << "th elements of vectors " << vector1_name << " and " << vector2_name << '\n';
}

template<CDVM>
Element_difference_penalty<DVM>::Element_difference_penalty(Parameter_set<DVM>& e, int penalty_no)
  : Penalty<DVM>(e.get_string("element_difference_penalty["+itos(penalty_no)+"].label")){
  std::string command = "element_difference_penalty[" + itos(penalty_no) + "].";
  vector1_name = e.get_string(command+"vector1");
  vector2_name = e.get_string(command+"vector2");
  multiplier = e.get_constant(command+"multiplier");
  i = e.get_int(command+"i");
}

template<CDVM>
void YCS_difference_penalty<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  p.put_int("requests.YCS",1);
}

template<CDVM>
DOUBLE YCS_difference_penalty<DVM>::evaluate(Basic_population_section<DVM>& popn,
                                             Parameter_set<DVM>& p,
                                             Qs<DVM>& qs){
  DEBUG1("YCS_difference_penalty::evaluate");
  if (!popn.state.valid_stock(stock1_name) || !popn.state.valid_stock(stock2_name)){
    fatal("One of the stocks " + stock1_name + " and " + stock2_name + " in penalty labelled " + this->label +" is invalid.");}
  DOUBLE pen;
  int stock1_no = popn.state.stock_numbers[stock1_name];
  int stock2_no = popn.state.stock_numbers[stock2_name];
  DOUBLE YCS1 = (*(popn.results.YCS))[stock1_no][year];
  DOUBLE YCS2 = (*(popn.results.YCS))[stock2_no][year];
  pen = pow(YCS1 - YCS2, 2);
  return pen * multiplier;
}

template<CDVM>
void YCS_difference_penalty<DVM>::print(ostream& out){
  out << "Element difference penalty of " << multiplier << " x squared difference in YCS of ";
  out << "stocks " << stock1_name << " and " << stock2_name << " for year " << year << '\n';
}

template<CDVM>
YCS_difference_penalty<DVM>::YCS_difference_penalty(Parameter_set<DVM>& e, int penalty_no)
  : Penalty<DVM>(e.get_string("YCS_difference_penalty["+itos(penalty_no)+"].label")){
  std::string command = "YCS_difference_penalty[" + itos(penalty_no) + "].";
  stock1_name = e.get_string(command+"stock1");
  stock2_name = e.get_string(command+"stock2");
  multiplier = e.get_constant(command+"multiplier");
  year = e.get_int(command+"year");
}

template<CDVM>
DOUBLE Similar_qs_penalty<DVM>::evaluate(Basic_population_section<DVM>& popn,
                                         Parameter_set<DVM>& p,
                                         Qs<DVM>& qs){
  DEBUG1("Similar_qs_penalty::evaluate");
  DOUBLE q1, q2;
  if (q_method=="free"){
    q1 = p.get_estimable("q["+q1_name+"].q");
    q2 = p.get_estimable("q["+q2_name+"].q");
  } else {
    q1 = qs.q[q1_name];
    q2 = qs.q[q2_name];
  }
  if (fmin(q1,q2)<=0) fatal("Using similar_qs_penalty " + this->label + " has resulted in a log(0) error");
  DOUBLE pen = pow(log(q1)-log(q2),2);
  return pen * multiplier;
}

template<CDVM>
void Similar_qs_penalty<DVM>::print(ostream& out){
  out << "Similar q's penalty of " << multiplier << " x the square of (" << q1_name << " - " << q2_name << ") to induce the q's to be similar\n";
}

template<CDVM>
Similar_qs_penalty<DVM>::Similar_qs_penalty(Parameter_set<DVM>& e, int penalty_no)
  : Penalty<DVM>(e.get_string("similar_qs_penalty["+itos(penalty_no)+"].label")){
  std::string command = "similar_qs_penalty[" + itos(penalty_no) + "].";
  q1_name = e.get_string(command+"q1");
  q2_name = e.get_string(command+"q2");
  multiplier = e.get_constant(command+"multiplier");
  q_method = e.get_string("q_method","nuisance");
}

template<CDVM>
DOUBLE Ratio_qs_penalty<DVM>::evaluate(Basic_population_section<DVM>& popn,
                                         Parameter_set<DVM>& p,Qs<DVM>& qs){
  DEBUG1("Ratio_qs_penalty::evaluate");
  DOUBLE q1, q2;
  if (q_method=="free"){
    q1 = p.get_estimable("q["+q1_name+"].q");
    q2 = p.get_estimable("q["+q2_name+"].q");
  } else {
    int q1_valid = 0, q2_valid = 0;
    for (int i = 0; i < qs.q_names.size(); i++) {
      if (q1_name == qs.q_names[i]) q1_valid = 1;
      if (q2_name == qs.q_names[i]) q2_valid = 1;
    }
    if (q1_valid != 1) fatal("Unable to find the catchability q1 with label " + q1_name + " from the ratio qs prior in your parameter files.");
    if (q2_valid != 1) fatal("Unable to find the catchability q2 with label " + q2_name + " from the ratio qs prior in your parameter files.");
    q1 = qs.q[q1_name];
    q2 = qs.q[q2_name];
  }
  DOUBLE pen = log(q1) + 0.5 * pow(log((q1/q2)/mu)/sigma + sigma*0.5, 2);
  return pen;
}

template<CDVM>
void Ratio_qs_penalty<DVM>::print(ostream& out){
  out << "Ratio q's penalty (lognormal, with mu = " << mu << " and cv = " << cv << ", for " << q1_name << "/" << q2_name << ") to encourage the ratio of the q's to be near mu\n";
}

template<CDVM>
Ratio_qs_penalty<DVM>::Ratio_qs_penalty(Parameter_set<DVM>& e, int penalty_no)
  : Penalty<DVM>(e.get_string("ratio_qs_penalty["+itos(penalty_no)+"].label")){
  std::string command = "ratio_qs_penalty[" + itos(penalty_no) + "].";
  q1_name = e.get_string(command+"q1");
  q2_name = e.get_string(command+"q2");
  mu = e.get_constant(command+"mu");
  cv = e.get_constant(command+"cv");
  sigma = sqrt(log(1.0+cv*cv));
  q_method = e.get_string("q_method","nuisance");
}

template<CDVM>
DOUBLE Ogive_comparison_penalty<DVM>::evaluate(Basic_population_section<DVM>& popn,
                                               Parameter_set<DVM>& p,Qs<DVM>& qs){
  DEBUG1("Ogive_comparison_penalty::evaluate");
  std::vector<std::string> ogives;
  ogives.push_back("ogive");
  check_parname(ogive_name1, p, p, "penalty labelled " + this->label, ogives);
  check_parname(ogive_name2, p, p, "penalty labelled " + this->label, ogives);
  if (!popn.state.size_based && (p.get_ogive_base(ogive_name1)==1 || p.get_ogive_base(ogive_name2)==1)){
    fatal("One or both of " + ogive_name1 + " and " + ogive_name2 + " is size-based. Size-based ogives cannot be compared by an Ogive_comparison_penalty in an age-based model.");}
  VECTOR values1(p.get_ogive_values(ogive_name1));
  VECTOR values2(p.get_ogive_values(ogive_name2));
  if (values1.size() != values2.size()){
    fatal("Ogives " + ogive_name1 + " and " + ogive_name2 + " have different sizes and cannot be compared in an Ogive_comparison_penalty");}
  DOUBLE pen = 0;
  int low, high;
  low = (lower_bound >= 0) ? lower_bound : values1.indexmin();
  high = (upper_bound >= 0) ? upper_bound : values1.indexmax();
  // check that the bounds are within the range defined by the ogives
        if(low < values1.indexmin()) {
          fatal("Lower bound on the ogive comparison penalty for " + ogive_name1 + " and " + ogive_name2 + " is lower than the minimum value of the ogives.");}
        if(high > values1.indexmax()) {
          fatal("Upper bound on the ogive comparison penalty for " + ogive_name1 + " and " + ogive_name2 + " is higher than the maximum value of the ogives.");}
  for (int i=low; i<=high; i++){
    pen += pow(fmax(values1[i]-values2[i],0),2);}
  return pen * multiplier;
}

template<CDVM>
void Ogive_comparison_penalty<DVM>::print(ostream& out){
  out << "Ogive comparison penalty of " << multiplier << " x sum of squares of max(" << ogive_name1 << " - " << ogive_name2 << ", 0) to encourage the first ogive to be less than or equal to the second ";
  if (lower_bound >= 0) out << "excluding ages below " << lower_bound << " ";
  if (upper_bound >= 0) out << "excluding ages above " << upper_bound << " ";
  out << '\n';
}

template<CDVM>
Ogive_comparison_penalty<DVM>::Ogive_comparison_penalty(Parameter_set<DVM>& e, int penalty_no)
  : Penalty<DVM>(e.get_string("ogive_comparison_penalty["+itos(penalty_no)+"].label")){
  std::string command = "ogive_comparison_penalty[" + itos(penalty_no) + "].";
  ogive_name1 = e.get_string(command+"ogive1");
  ogive_name2 = e.get_string(command+"ogive2");
  multiplier = e.get_constant(command+"multiplier");
  lower_bound = e.get_int(command+"lower_bound",-1);
  upper_bound = e.get_int(command+"upper_bound",-1);
}

template<CDVM>
DOUBLE Ogive_difference_penalty<DVM>::evaluate(Basic_population_section<DVM>& popn,
                                               Parameter_set<DVM>& p,
                                               Qs<DVM>& qs){
  DEBUG1("Ogive_difference_penalty::evaluate");
  std::vector<std::string> ogives;
  ogives.push_back("ogive");
  check_parname(ogive_name1, p, p, "penalty labelled " + this->label, ogives);
  check_parname(ogive_name2, p, p, "penalty labelled " + this->label, ogives);
  if (!popn.state.size_based && (p.get_ogive_base(ogive_name1)==1 || p.get_ogive_base(ogive_name2)==1)){
    fatal("One or both of " + ogive_name1 + " and " + ogive_name2 + " is size-based. Size-based ogives cannot be compared by an Ogive_difference_penalty in an age-based model.");}
  VECTOR values1(p.get_ogive_values(ogive_name1));
  VECTOR values2(p.get_ogive_values(ogive_name2));
  if (values1.size() != values2.size()){
    fatal("Ogives " + ogive_name1 + " and " + ogive_name2 + " have different sizes and cannot be compared in an Ogive_difference_penalty");}
  DOUBLE pen = pow(values1[class_no]-values2[class_no],2);
  return pen * multiplier;
}

template<CDVM>
void Ogive_difference_penalty<DVM>::print(ostream& out){
  out << "Ogive difference penalty of " << multiplier << " x square of " << ogive_name1 << " - " << ogive_name2 << " for age/size class " << class_no << " to encourage the two ogives to have similar values for this age/size class\n";
}

template<CDVM>
Ogive_difference_penalty<DVM>::Ogive_difference_penalty(Parameter_set<DVM>& e, int penalty_no)
  : Penalty<DVM>(e.get_string("ogive_difference_penalty["+itos(penalty_no)+"].label")){
  std::string command = "ogive_difference_penalty[" + itos(penalty_no) + "].";
  ogive_name1 = e.get_string(command+"ogive1");
  ogive_name2 = e.get_string(command+"ogive2");
  multiplier = e.get_constant(command+"multiplier");
  class_no = e.get_int(command+"class");
}

template<CDVM>
void Fish_tagged_penalty<DVM>::set_request_parameters(Parameter_set<DVM>& p){
  p.put_int("requests.numbers_tagged",1);
}

template<CDVM>
DOUBLE Fish_tagged_penalty<DVM>::evaluate(Basic_population_section<DVM>& popn,
                                               Parameter_set<DVM>& p,
                                               Qs<DVM>& qs){
  DEBUG1("Fish_tagged_penalty::evaluate");
  std::string tag_prefix="tag["+tagging_episode+"].";
  if (!p.present(tag_prefix+"number")){
    fatal("Could not find tagging episode " + tagging_episode + " named in a Fish_tagged_penalty.");}
  int nominal = p.get_int(tag_prefix+"number");
  DOUBLE actual = popn.results.numbers_tagged[tagging_episode];
  DOUBLE pen = pow(actual - nominal,2);
  return pen * multiplier;
}

template<CDVM>
void Fish_tagged_penalty<DVM>::print(ostream& out){
  out << "'Fish-must-be-tagged' penalty of " << multiplier << " x square of (actual number of tagged fish - nominal number of tagged fish) for tagging episode " << tagging_episode << '\n';
}

template<CDVM>
Fish_tagged_penalty<DVM>::Fish_tagged_penalty(Parameter_set<DVM>& e, int penalty_no)
  : Penalty<DVM>(e.get_string("fish_tagged_penalty["+itos(penalty_no)+"].label")){
  std::string command = "fish_tagged_penalty[" + itos(penalty_no) + "].";
  tagging_episode = e.get_string(command+"tagging_episode");
  multiplier = e.get_constant(command+"multiplier");
}

//############################## END OF PENALTIES.cpp ##############################

// Create particular instantiations of the template
template class Penalties<double, dvector, dmatrix>;
template class Penalties<dvariable, dvv, dvm>;
