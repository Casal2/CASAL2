// const char* time_stamp = "$Date: 2010-11-25 17:02:26 +1300 (Thu, 25 Nov 2010) $\n";
// const char* population_processes_id = "$Id: population_processes.h 3649 2010-11-25 04:02:26Z fud $\n";

#if !defined(POPULATION_PROCESSES)
#define POPULATION_PROCESSES

//############################## INDIVIDUAL POPULATION PROCESSES ##############################
#include <iostream>
#include <string>
#include <vector>
#include "population_section.h"

// Forward declarations
template <CDVM> class Stock_recruit;
template <CDVM> class Climate_recruit;
template <CDVM> class Randomiser;
template <CDVM> class Density_dependence;
template <CDVM> class Growth_curve;

/////////////////////////////////////////////////////////////////////////////////////////////
template<CDVM>
class Basic_recruitment{
  // The key function is apply(), which modifies the state object to add a year's recruitment.
  // The recruitment process is called using ->apply() from the annual_cycle,
  //
  // In deterministic simulations, we use apply_constant() instead of apply().
  //
  // The data members include
  // - R0 (which is supplied from set_initial_state() using set_R0()),
  // - YCS and T
  // - pointers to the stock-recruit and climate-recruit objects (the B0 will not
  //    be known when the Basic_recruitment is constructed and will need to be
  //    supplied from set_initial_state() using ->set_B0()).
  // - proportions, which indicates the proportions of recruits going
  //    to each element of the partition,
  // - y_enter, the time lag before a cohort enters the partition.
  // - stock, the number of the recruiting stock
  //
  // One option is to have recruitments of Rinitial for the first few years.
  //   If this is the case, it is done from set_initial_state using set_Rinitial(),
  //   which then sets the first few YCS to (Rinitial / R0), yielding recruitments of Rinitial.
  //
  // If the requests object asks for 'recruitments', 'YCS', 'true_YCS', 'Ts' to be supplied,
  //   they are filled in by apply().
  //
  // The randomise function invokes randomise_YCS.apply() and randomise_T.apply()
  //   to generate sequences of random recruitments for projections or stochastic simulations.
  //   The YCS are randomised from year 'first_random_year' on:
  //   the T's from year 'first_random_year' or 'last_T_provided + 1', whichever is later.
  //
  // BB 17/3/03 - just added changes re. Bmean/Rmean. All should only apply when
  //  the "use_mean_YCS" switch is set to 1. Also added the ybar() query function.
private:
  std::string command;
  int initial, current, final;
public:
  int apply(Basic_state<DVM>& s, int year, Basic_requests<DVM>* requests, Basic_results<DVM>* results);
  // Add recruitment to the partition of s for 'year', return a status value.
  int apply_constant(Basic_state<DVM>& s, const DOUBLE& SSB = 0,
                     Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0);
  // As per apply(), except for constant recruitment (used for deterministic simulations and calculating
  //   an unfished equilibrium). If SSB is provided, the stock-recruit relationship is applied
  //   (if there is one)
  void set_R0(const DOUBLE& R0_val);
  void set_B0(const DOUBLE& B0_val);
  void set_Rinitial(const DOUBLE& Rinitial_val);
  void set_Rmean(const DOUBLE& Rmean_val);
  void randomise(long seed);
  Stock_recruit<DVM>* stock_recruit;
  Climate_recruit<DVM>* climate_recruit;
  int stock;
  DOUBLE ybar();
  void print(Basic_state<DVM>& s, ostream& out);
  Basic_recruitment(Parameter_set<DVM>& p, Basic_state<DVM>& s, int step, int _stock,
                    int area, int _y_enter);
  ~Basic_recruitment();
private:
  DOUBLE R0, Rmean;
  VECTOR *YCS, *Ts, *CR;
  // These vectors store the YCS, T, and CR(T) terms of the recruitment equation;
  // element i is for year i.
  // Note that, for years where T is not available, T is set to 0 and CR(T) to 1.
  // So in this case CR(T) does not equal climate_recruit->CR(T)!!!
  int first_random_year;
  // This is the first year for which YCS are random in stochastic simulations and projections.
  int last_T_provided;
  int first_random_T_year;
  // This is the first year for which Ts are random in stochastic simulations and projections.
  std::vector<VECTOR> proportions;
  // proportions[i][j] is the proportion of recruits which are added to partition element [i,j].
  int y_enter;
  // the cohort spawned in year y enters the partition in year (y+y_enter).
  int n_rinitial;
  int use_mean_YCS; // use Rmean instead of R0 if this is set to 1
  DOUBLE ybar_val; // this is calculated in the constructor and returned by ybar()
  Randomiser<DVM> *randomise_YCS, *randomise_Ts;
};

template<CDVM>
class Stock_recruit{
  // The Stock_recruit class provides the interface for all the Stock_recruit methods,
  // currently Ricker and Beverton_Holt.
public:
  virtual DOUBLE SR(const DOUBLE& SSB) = 0;
  // Return SR(SSB).
  virtual void set_B0(const DOUBLE& B0_val) = 0;
  // The value of B0 may not be known when Stock_recruit::Stock_recruit is called.
  // In which case it will need to be entered later (from set_initial_state)
  virtual void print(ostream& out) = 0;
  virtual ~Stock_recruit(){};
};

template<CDVM>
class Ricker : public Stock_recruit<DVM>{
public:
  DOUBLE SR(const DOUBLE& SSB);
  void set_B0(const DOUBLE& B0_val);
  // The value of B0 may not be known when Ricker::Ricker is called.
  // In which case it will need to be entered later (from set_initial_state)
  void print(ostream& out);
  Ricker(const DOUBLE& h_val, const DOUBLE& B0_val=0);
private:
  DOUBLE h, B0;
};

template<CDVM>
class Beverton_Holt : public Stock_recruit<DVM>{
public:
  DOUBLE SR(const DOUBLE& SSB);
  void set_B0(const DOUBLE& B0_val);
  // The value of B0 may not be known when Beverton_Holt::Beverton_Holt is called.
  // In which case it will need to be entered later (from set_initial_state)
  void print(ostream& out);
  Beverton_Holt(const DOUBLE& h_val, const DOUBLE& B0_val=0);
private:
  DOUBLE h, B0;
};

template<CDVM>
class Climate_recruit{
  // The Climate_recruit class provides the interface for all the Climate_recruit methods,
  // currently Exponential, Arctan, Logistic, Identity, Linear_combination.
  // The big limitation on this class, as it stands, is that it only takes a single
  // exogenous variable.
public:
  virtual DOUBLE CR(const DOUBLE& T) = 0;
  // Return CR(T).
  virtual void print(ostream& out) = 0;
  virtual ~Climate_recruit(){};
};

template<CDVM>
class Exponential : public Climate_recruit<DVM>{
public:
  DOUBLE CR(const DOUBLE& T);
  void print(ostream& out);
  Exponential(const DOUBLE& alpha_val, const DOUBLE& beta_val);
private:
  DOUBLE alpha, beta;
};

template<CDVM>
class Arctan : public Climate_recruit<DVM>{
public:
  DOUBLE CR(const DOUBLE& T);
  void print(ostream& out);
  Arctan(const DOUBLE& alpha_val, const DOUBLE& beta_val);
private:
  DOUBLE alpha, beta;
};

template<CDVM>
class Logistic : public Climate_recruit<DVM>{
public:
  DOUBLE CR(const DOUBLE& T);
  void print(ostream& out);
  Logistic(const DOUBLE& alpha_val, const DOUBLE& beta_val, const DOUBLE& beta2_val);
private:
  DOUBLE alpha, beta, beta2;
};

template<CDVM>
class Identity : public Climate_recruit<DVM>{
public:
  DOUBLE CR(const DOUBLE& T);
  void print(ostream& out);
  Identity();
};

template<CDVM>
class Linear_combination : public Climate_recruit<DVM>{
public:
  DOUBLE CR(const DOUBLE& T);
  void print(ostream& out);
  Linear_combination(const DOUBLE& p_val);
private:
  DOUBLE p;
};

template<CDVM>
class Randomiser{
  // An abstract class, used for randomising YCS and T's in stochastic simulations.
  // The key function is 'apply' which returns a randomised set of values, given
  //  a random number seed.
  // Concrete Randomiser classes should be constructed from the population Parameter_set,
  //  a string saying what is being randomised - either "YCS" or "Ts",
  //  the name of the stock concerned, and VECTOR of the original values of the YCS or T's.
public:
  virtual void apply(VECTOR& v, int first_random_year, long seed) = 0;
  virtual void print(ostream& out = cout) = 0;
  virtual ~Randomiser(){};
};

template<CDVM>
class Lognormal_randomiser : public Randomiser<DVM>{
  // Randomise YCS and/or T's using the lognormal distribution
  //  with a specified standard deviation on the log scale (sigma_r)
  //  and an optional lag-1 autocorrelation on the log scale (rho).
public:
  void apply(VECTOR& v, int first_random_year, long seed);
  void print(ostream& out = cout);
  Lognormal_randomiser(Parameter_set<DVM>& p, const std::string& what_it_is, const std::string& command,	//Change stock to command so that it can be used for more than just recruitment
                       const VECTOR& original_values);
private:
  double sigma_r, rho, multiplier, mean_on_linear_scale, mean_on_log_scale;
};

template<CDVM>
class Lognormal_empirical_randomiser : public Randomiser<DVM>{
  // Randomise YCS and/or T's using the lognormal distribution
  //  with a standard deviation on the log scale (sigma_r) chosen to match the 'actual' YCS or T's
  //    (optionally only including a specified range of years - i.e. those for which the YCS/Ts
  //     were well estimated?)
  //  and an optional lag-1 autocorrelation on the log scale (rho).
public:
  void apply(VECTOR& v, int first_random_year, long seed);
  void print(ostream& out = cout);
  Lognormal_empirical_randomiser(Parameter_set<DVM>& p,
                                  const std::string& what_it_is, const std::string& command,	//Change stock to command so that it can be used for more than just recruitment
                                  const VECTOR& original_values);
private:
  double sigma_r, rho, multiplier, mean_on_linear_scale, mean_on_log_scale;
};

template<CDVM>
class Empirical_randomiser : public Randomiser<DVM>{
  // Randomise YCS and/or T's using the lognormal distribution
  //  with a standard deviation on the log scale (sigma_r) chosen to match the 'actual' YCS or T's
  //    (optionally only including a specified range of years - i.e. those for which the YCS/Ts
  //     were well estimated?)
  //  and an optional lag-1 autocorrelation on the log scale (rho).
public:
  void apply(VECTOR& v, int first_random_year, long seed);
  void print(ostream& out = cout);
  Empirical_randomiser(Parameter_set<DVM>& p,
                      const std::string& what_it_is, const std::string& command, //Change stock to command so that it can be used for more than just recruitment
                      const VECTOR& original_values);
  ~Empirical_randomiser();
private:
  dvector *resample_from;
  double multiplier;
};

template<CDVM>
class No_randomiser : public Randomiser<DVM>{
  // The null randomiser - returns constant values of 1 for YCS,
  // or the specified mean T for T's.
  //
  // BB - now errors out - if you are going to do stochastic simulation you should have a real randomiser
public:
  void apply(VECTOR& v, int first_random_year, long seed);
  void print(ostream& out = cout);
  No_randomiser(Parameter_set<DVM>& p,
                const std::string& what_it_is, const std::string& command, //Change stock to command so that it can be used for more than just recruitment
                const VECTOR& _original_values);
private:
  double level, multiplier;
};

template<CDVM>
class Basic_ageing{
  // The Basic_ageing class is used via ->apply(), which modifies the state object to age fish by 1 year.
  // The Basic_ageing class can use the default constructor since it contains no data.
public:
  int apply(Basic_state<DVM>& s, int year);
  // Age all fish in the partition by 1 year.
  void print(Basic_state<DVM>& s, ostream& out);
};

template<CDVM>
class Growth{
  // The Growth class specifies the interface for the growth objects which
  // inherit from it, currently including only Growth_years_same..
  // It is used for size-based models.
  // The key function is apply(), which modifies the state object for one growth episode.
  // The growth process is called using ->apply() from an annual_cycle,
  //  currently the Basic_annual_cycle.
public:
  virtual int apply(Basic_state<DVM>& s, int year) = 0;
  // Apply a growth episode to the partition of s in 'year', return a status value.
  virtual void print(Basic_state<DVM>& s, ostream& out) = 0;
  virtual ~Growth(){};
};

template<CDVM>
class Growth_years_same : public Growth<DVM>{
  // The Growth_years_same class is an implementation of the Growth class,
  // and is currently used by the basic model.
  // It is used via ->apply().
  // The big limitation of this Growth method is that it assumes growth is the
  // same in all years. If you want (e.g.) climate-dependent growth, you will need to
  // write a new method.
  // The private data members include
  // - transition_matrices: contains all the transition matrices used for the rows of
  //   the partition
  // - matrix_by_row: indicates which element of transition_matrices is applied to each
  //   row of the partition (rows which do not grow have an entry of -1)
public:
  int apply(Basic_state<DVM>& s, int year);
  void print(Basic_state<DVM>& s, ostream& out);
  Growth_years_same(Parameter_set<DVM>& p,Basic_state<DVM>& s, int step, int i);
private:
  int stock;
  std::vector<MATRIX> transition_matrices;
  std::vector<int> matrix_by_row;
  // In the growth episode, each row i of the partition is to be
  // postmultiplied by transition_matrices[matrix_by_row[i]].
  int by_sex;
  int by_maturity;
  // these are only used by the .print() function
  MATRIX make_matrix(Basic_state<DVM>& s, const VECTOR& g, const VECTOR& l,
                     const DOUBLE& cv, const DOUBLE& minsigma,
                     const std::string growth_type_name);
  // used by Growth_years_same::Growth_years_same
};

template<CDVM>
class Selectivity{
  // An object of class Selectivity can be shared by one or more fisheries and/or sets of observations.
  // The key function is get_selectivity() which returns the current selectivity. ('current' because
  //  size-based selectivity ogives in age-based models can vary from step to step, or year to year,
  //  and because of selectivity shifts.)
public:
  MATRIX& get_selectivity(int year, int step);
  std::string label;
  void print(Basic_state<DVM>& s, ostream& out = cout,
             dvector& print_sizebased_ogives_at = dvector("{-1}"));
  Selectivity(Parameter_set<DVM>& _p, Basic_state<DVM>& s, const std::string& _label,
              Size_at_age<DVM>* _size_at_age);
  // the next three members are queried by class Age_size, I don't think they are used elsewhere
  int sizebased_ogive_used;
  int sel_depends_on_sex;
  DOUBLE get_val_by_size_in_agebased(int year,int step,int row,DOUBLE size);
private:
  std::string command;
  MATRIX selectivities;
  std::vector<std::string> ogives;
  // ogives[i] is the name of the ogive for row i of the partition
  std::vector<std::string> ogive_parameter_names;
  // list of names of all the ogives used (in no particular order)
  int last_step_calculated, last_year_calculated;
  int changes_between_steps, changes_between_years;
  // We can reuse the old values of the matrix unless
  // (step != last_step_calculated && changes_between_steps) || (year != last_year_calculated && changes_between_years).
  std::vector<MATRIX> sel_by_step;
  // Even if we can't reuse the old values of the matrix,
  // if !changes_between_years, we can use the same values for every year for a given step,
  // so we store the values by step here rather than recalculating them each year.
  int do_shift;
  DOUBLE shift_a;
  // Selectivity shift parameter
  VECTOR shift_E;
  // Exogenous variable driving the selectivity shift
  Size_at_age<DVM>* size_at_age;
  Parameter_set<DVM>* p;
  int n_rows;
};

template<CDVM>
class Mortality{
  // The Mortality class specifies the interface for the mortality objects which
  //  inherit from it, currently including No_mortality, Natural_only_by_row,
  //  Natural_only_by_element, Basic_fisheries, Baranov_fisheries, Baranov_fisheries_Fsupplied.
  // There should be one mortality object per time step in the annual cycle.
  // The key function is apply(), which modifies the state object to remove a time step's
  //  mortality, and also fills in any necessary results.
  // The mortality process is called using ->apply() from an annual_cycle,
  //  currently the Basic_annual_cycle.
  // Note, get_Mt_by_row & get_Mt_by_element are shared by the inherited Mortality classes,
public:
  virtual int apply(Basic_state<DVM>& s, int year,
                    Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0,
                    double F_to_use = 0, std::map<std::string,double> *catches_this_year = 0) = 0;
  // Apply the mortality for a single time step to the partition of s for year,
  // fill in results as requested by requests,
  // return 0 if fishing pressure constraints were exceeded or 1 if not.
  // When doing yield estimates, you can supply an instantaneous mortality (can be used when
  //   there is only one fishery and the Baranov equation is used) or catches (otherwise).
  //   If you specify catches, they should satisfy (*catches_this_year)[fishery_name] = catch,
  //   and you should set F_to_use to the 0 default.
  virtual void print(Basic_state<DVM>& s, ostream& out) = 0;
  virtual ~Mortality(){};
};

template<CDVM>
class No_mortality : public Mortality<DVM>{
  // The No_mortality class is a trivial implementation of the Mortality class,
  // for time steps in which neither natural nor fishing mortality occurs,
  // and is currently used by the basic model.
  // It is used via ->apply().
  // apply() does take 'requests' and 'results' arguments but I don't think
  // there will ever be an actual need for results to be collected in a No_mortality time step.
public:
  int apply(Basic_state<DVM>& s, int year,
            Basic_requests<DVM>* requests, Basic_results<DVM>* results,
            double F_to_use = 0, std::map<std::string,double> *catches_this_year = 0);
  void print(Basic_state<DVM>& s, ostream& out);
  No_mortality(Parameter_set<DVM>& p, Basic_state<DVM>& s, int step);
};

template<CDVM>
class Natural_only_by_row : public Mortality<DVM>{
  // The Natural_only_by_row class is an implementation of the Mortality class,
  // for time steps in which no fishing mortality occurs,
  // in models where natural mortality does not depend on fish age or size,
  // and is currently used by the basic model.
  // It is used via ->apply(), which removes the natural mortality.
  // apply() does take 'requests' and 'results' arguments but I don't think
  // there will ever be an actual need for results to be collected in a
  // Natural_only_by_row time step.
  //
  // The key data member is Mt_by_row, which contains the instantaneous
  // mortality rate for each row of the partition.
public:
  int apply(Basic_state<DVM>& s, int year,
            Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0,
            double F_to_use = 0, std::map<std::string,double> *catches_this_year = 0);
  void print(Basic_state<DVM>& s, ostream& out);
  Natural_only_by_row(Parameter_set<DVM>& p, Basic_state<DVM>& s, int step, const dvector& M_props);
private:
  VECTOR Mt_by_row;
  // Mt_by_row[i] is the instantaneous mortality rate for row i of the partition
  // (the product of M and t).
  VECTOR exp_minus_Mt_by_row;
};

template<CDVM>
class Natural_only_by_element : public Mortality<DVM>{
  // The Natural_only_by_element class is an implementation of the Mortality class,
  // for time steps in which no fishing mortality occurs,
  // in models where natural mortality depends on fish age and/or size,
  // and is currently used by the basic model.
  // It is used via ->apply(), which removes the natural mortality.
  // apply() does take 'requests' and 'results' arguments but I don't think
  // there will ever be an actual need for results to be collected in a
  // Natural_only_by_element time step.
  //
  // The key data member is Mt_by_element, which contains the instantaneous
  // mortality rate for each element of the partition.
public:
  int apply(Basic_state<DVM>& s, int year,
            Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0,
            double F_to_use = 0, std::map<std::string,double> *catches_this_year = 0);
  void print(Basic_state<DVM>& s, ostream& out);
  Natural_only_by_element(Parameter_set<DVM>& p, Basic_state<DVM>& s, int step, const dvector& M_props,
                          Size_at_age<DVM>* size_at_age);
private:
  MATRIX Mt_by_element;
  // Mt_by_element[i][j] is the instantaneous mortality rate for
  // element [i,j] of the partition (the product of M and t).
  MATRIX exp_minus_Mt_by_element;
};

template<CDVM>
void get_Mt_by_element(MATRIX& Mt_by_element,Parameter_set<DVM>& p,Basic_state<DVM>& s, int step,
                       const dvector& M_props, Size_at_age<DVM>* size_at_age);

template<CDVM>
class Basic_fisheries : public Mortality<DVM>{
  // The Basic_fisheries class is an implementation of the Mortality class,
  // for time steps in which fishing mortality occurs, if the Baranov equation is not used,
  // and is currently used by the basic model.
  // It is used via ->apply(), which removes the natural mortality
  //  and updates 'results' as requested by 'requests'. (More detail here)
  //
  // The data members are
  // - Mt_by_element, which contains the instantaneous mortality rate for each
  //   element of the partition (see the Natural_only_by_element method of Mortality)
  // - catches, which contains the catch weight in each year
  // - fishery_names - each fishery has a text label, used in the inputs and outputs
  // - areas - the numbers of the areas affected by each fishery in the time step,
  //   if there is more than one area
  // - rows - says which rows of the partition are affected by each fishery - just depends
  //   on area at the moment
  // - selectivities - points to the selectivity object for each fishery
  // - a pointer to the mean weight object in the annual cycle, used to extract mean weights using
  //   mean_weight->get_row() in each time step
  // - the maximum fishing pressure limit.
public:
  int apply(Basic_state<DVM>& s, int year,
            Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0,
            double F_to_use = 0, std::map<std::string,double> *catches_this_year = 0);
  void print(Basic_state<DVM>& s, ostream& out);
  Basic_fisheries(Parameter_set<DVM>& p, Basic_state<DVM>& s, int _step,
                  Mean_weight<DVM>* _mean_weight,
                  Size_at_age<DVM>* _size_at_age,
                  const dvector& M_props, const dvector& fishery_times,
				  const dvector& fishery_areas,
                  const std::vector<std::string>& fishery_names,
                  std::map<std::string,Selectivity<DVM>*>& selectivities);
private:
  int step;
  MATRIX Mt_by_element;
  // Mt_by_element[i][j] is the instantaneous mortality rate for
  // element [i,j] of the partition (the product of M and t).
  MATRIX exp_minus_Mt_by_element, exp_minus_half_Mt_by_element;
  std::vector<dvector> catches;
  // catches[f][y] is the catch for fishery f in year y
  // (note, f = 0...(no. fisheries in this time step-1))
  std::vector<std::string> names;
  // names of the fisheries acting in this time step
  std::map<std::string,std::vector<int> > areas;
  // areas[f] is the areas which is affected by fishery f
  std::vector<dvector> rows;
  // rows[f][i]==1 if fishery f affects row i
  std::vector<Selectivity<DVM>*> selectivities;
  // selectivities[f] points to the selectivity of fishery f
  std::vector<Selectivity<DVM>*> retention_selectivities;
  // retention_selectivities[f] points to the retention_selectivity of fishery f.
  Mean_weight<DVM>* mean_weight;
  // should point to the Basic_annual_cycle::mean_weight
  Size_at_age<DVM>* size_at_age;
  // should point to the Basic_annual_cycle::size_at_age
  std::vector<double> U_max;
  // U_max[f] is the fishing pressure limit for fishery f
  int n_fisheries_this_step;
  // Temporary variables used in ::apply follow:
  dvector ones;
  DOUBLE Uobs_f, this_catch;
  // future_Us[f][y] is the exploitation rate U fishery f in year y (no catch can be provided for this year)
  // future_Us are used during a projection period (current + 1,future)
  std::vector<dvector> future_Us;
  MATRIX R;
  int limit_exceeded;
};

template<CDVM>
class Baranov_fisheries : public Mortality<DVM>{
  // The Baranov_fisheries class is an implementation of the Mortality class,
  // for time steps in which fishing mortality occurs, if the Baranov equation is used,
  // and is currently used by the basic model.
  // It is used via ->apply(), which removes the natural mortality
  //  and updates 'results' as requested by 'requests'. (More detail here)
  //
  // The data members are
  // - Mt_by_element, which contains the instantaneous mortality rate for each
  //   element of the partition (see the Natural_only_by_element method of Mortality)
  // - catches, which contains the catch weight in each year for each fishery
  // - Fs, which contains the F in each year for each fishery (typically used
  //   for early years in which catch records were not available: range of years
  //   for which 'Fs' is provided should be nonoverlapping with range for which 'catches'
  //   is provided)
  // - fishery_names - each fishery has a text label, used in the inputs and outputs
  // - areas - the numbers of the areas affected by each fishery in the time step,
  //   if there is more than one area
  // - rows - says which rows of the partition are affected by each fishery - just depends
  //   on area at the moment
  // - selectivities - points to the selectivity object for each fishery
  // - a pointer to the mean weight object in the annual cycle, used to extract mean weights using
  //   mean_weight->get_row() in each time step
  // - the maximum fishing pressure limit.
public:
  int apply(Basic_state<DVM>& s, int year,
            Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0,
            double F_to_use = 0, std::map<std::string,double> *catches_this_year = 0);
  void print(Basic_state<DVM>& s, ostream& out);
  Baranov_fisheries(Parameter_set<DVM>& p, Basic_state<DVM>& s, int _step,
                    Mean_weight<DVM>* _mean_weight,
                    Size_at_age<DVM>* _size_at_age,
                    const dvector& M_props, const dvector& fishery_times,
					const dvector& fishery_areas,
                    const std::vector<std::string>& fishery_names,
                    std::map<std::string,Selectivity<DVM>*>& selectivities);
private:
  int step;
  MATRIX Mt_by_element;
  // Mt_by_element[i][j] is the instantaneous mortality rate for
  // element [i,j] of the partition (the product of M and t).
  MATRIX exp_minus_Mt_by_element;
  std::vector<dvector> catches;
  // catches[f][y] is the catch for fishery f in year y
  // (note, f = 0...(no. fisheries in this time step-1))
   std::vector<dvector> Fs;
  // Fs[f][y] is the F for fishery f in year y (no catch can be provided for this year)
  // (note, f = 0...(no. fisheries in this time step-1))
  std::vector<dvector> future_Fs;
  // defines the Fs's used in the projection period (current + 1  to final)
  std::vector<std::string> names;
  // names of the fisheries acting in this time step
  std::map<std::string,std::vector<int> > areas;
  // areas[f] is the areas which is affected by fishery f
  std::vector<dvector> rows;
  // rows[f][i]==1 if fishery f affects row i
  std::vector<Selectivity<DVM>*> selectivities;
  // selectivities[f] points to the selectivity of fishery f
  std::vector<Selectivity<DVM>*> retention_selectivities;
  // retention_selectivities[f] points to the retention_selectivity of fishery f.
  Mean_weight<DVM>* mean_weight;
  // should point to the Basic_annual_cycle::mean_weight
  Size_at_age<DVM>* size_at_age;
  // should point to the Basic_annual_cycle::size_at_age
  std::vector<double> F_max;
  // F_max[f] is the fishing pressure limit for fishery f
  int n_fisheries_this_step;
  int limit_exceeded;
  int fishing_pressure_without_S;
};

template<CDVM>
class DiseaseMortality {
  // The DiseaseMortality class specifies the disease mortality object
  // There should be only one disease mortality event per annual_cycle
  // The key function is apply(), which modifies the state object to remove a time step's
  //  disease mortality, and also fills in any necessary results.
  // The disease mortality process is called using ->apply() from an annual_cycle,
  //  currently the Basic_annual_cycle.
  //
  // future_years, future_index can be used to specify the mortality in projections (i.e. for the
  // years from current + 1 up to final.
public:
  void apply(Basic_state<DVM>& s, int year, Mean_weight<DVM>* mean_weight = 0, Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0);
  void print(Basic_state<DVM>& s, ostream& out);
  DiseaseMortality(Parameter_set<DVM>& p, Basic_state<DVM>& s, std::map<std::string, Selectivity<DVM>*>& all_selectivities);
  ~DiseaseMortality();
private:
  DOUBLE DM;
  VECTOR *index;
  dvector *years;
  VECTOR *future_index;
  dvector *future_years;
  int step;
  Selectivity<DVM>* selectivity;
};

template<CDVM>
class TaggingFish {
  // The TaggingFish class specifies the placement of tags on fish.
  // It does not govern the recapture and observation of tags, just putting the tags on
  //  the fish in the first place - when does it happen, how many fish, where and which fish.
  // There should be one tagging-fish event per tag that can be applied (ie. @n_tags events).
  // The key function is apply(), which modifies the state object to move fish into the
  //  tagged part of the partition, and also fills in any necessary results.
public:
  std::string episode_label;
  void apply(Basic_state<DVM>& s, int _year,int _step, Basic_annual_cycle<DVM>* annual_cycle,
             Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0);
  void sizefreq_to_agefreq(Basic_state<DVM>& s, int year, int step, Basic_annual_cycle<DVM>* annual_cycle);
  void print(Basic_state<DVM>& s, ostream& out);
  TaggingFish(Parameter_set<DVM>& p, Basic_state<DVM>& s,
              std::string& _episode_label, std::map<std::string,Selectivity<DVM>*>& selectivities);
  ~TaggingFish();
  // private: - were private, but the Tag_release class needs to access them
  std::string prefix;
  std::string release_type; // "free" means that class_props is supplied - an age frequency for an age-based model
                            // or a length frequency for a length-based model, in either case potentially free parameters.
                            // "deterministic" means that a length frequency is provided (non estimable) and converted
                            // to an age frequency based on the age/length matrix.
  std::string tag_name;
  dvector class_mins;
  int plus_group;
  int step;
  int year;
  std::string area; // in an area model
  std::string stock; // in a stock model, or "" for all stocks
  std::string sex; // in a sexed model, "male" or "female" or "both"
  int mature_only; // if maturity is in the partition, 1 if mature only or 0 if all
  int number; // how many fish are tagged?
  DOUBLE mortality; // what proportion of tagged fish are removed from the partition immediately?
  std::vector<int> source_rows; // from what rows of the partition do fish move?
  std::vector<int> destination_rows; // for each source row, which row do the fish end up in?
  VECTOR class_props;
  // Not the same as for the Migration classes.
  // class_props[i] is the proportion of the fish who get tagged, who are of age/size class i.
  // so sum(class_props[i])==1.
  // or use:
  VECTOR class_props_male,class_props_female;
  dvector length_props;
  // Only for an age-based model with release_type="deterministic"-
  //   the length frequency of tagged fish, using class_mins and plus_group to indicate length classes
  // or use:
  dvector length_props_male,length_props_female;
  int sexed; // are the sexed versions of class_props and length_props used?
  std::string selectivity_name; // in deterministc tagging, selectivity to apply
  Selectivity<DVM>* selectivity;
};

template<CDVM>
class TagLoss{
// This class specifies the gradual loss of tags over time. One instance of this class
//  will be created for each of the n_tags different kinds of tag (they each have a
//  different shedding rate).
// Note that fish who lose their tags are 'killed', not moved back into the untagged
//  part of the partition. No problem with fish where the tagging proportion is so low,
//  could be an issue with other animals.
public:
  std::string tag_name;
  void apply(Basic_state<DVM>& s, int _year, int _step);
  void print(Basic_state<DVM>& s, ostream& out);
  TagLoss(Parameter_set<DVM>& p, Basic_state<DVM>& s,std::string& _tag_name);
private:
  int time_steps;
  DOUBLE shedding_rate; // a rate, not a proportion
  std::vector<double> tag_loss_props; // proportions of year's shedding occurring in each time step,
                                   // indexed 1...n_time_steps (so 0 is a dummy element). Must sum to 1.
  std::vector<int> tagged_rows; // these fish are tagged and must be killed
};

template<CDVM>
class Migration{
  // The Migration class specifies the interface for the migration objects which
  // inherit from it, currently including Migration_by_constant and Migration_by_ogive.
  // The key function is apply(), which modifies the state object for one migration.
  // The migration process is called using ->apply() from an annual_cycle,
  //  currently the Basic_annual_cycle.
  // All migration classes also inherit members relating to density dependence (which will
  //  need to be deleted if allocated).
public:
  virtual int apply(Basic_state<DVM>& s, int year,Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0) = 0;
  // Apply a migration to the partition of s in year, return a status value.
  virtual void print(Basic_state<DVM>& s, ostream& out) = 0;
  
  int stock;
  int density_dependent;
  int annual_varying;
  Density_dependence<DVM> *density_dependence;
  virtual ~Migration(){};
};

template<CDVM>
class Migration_by_constant : public Migration<DVM>{
  // The Migration_by_constant class is an implementation of the Migration class,
  // for when the rate of migration does not depend on size or age, or on maturity
  // in a model where maturity is not in the partition (otherwise use Migration_by_ogive),
  // and is currently used by the basic model.
  // It is used via ->apply().
  // The private data members include source_rows, destination_rows, migration_p,
  // which define the movements between elements of the partition in a migration episode.
public:
  int apply(Basic_state<DVM>& s, int year,Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0);
  void print(Basic_state<DVM>& s, ostream& out);
  Migration_by_constant(Parameter_set<DVM>& p,Basic_state<DVM>& s, int step, const std::string& _label,
                        int source_area, int destination_area,
                        Mean_weight<DVM> *mean_weight);
  ~Migration_by_constant();
private:
  std::string label;
  int wave;
  DOUBLE pwave;
  std::vector<int> source_rows;
  std::vector<int> destination_rows;
  std::vector<DOUBLE> migration_p;
  // For each i, migration_p[i] is the proportion of fish moving from each
  // partition[source_rows[i]][j] to each partition[destination_rows[i]][j].
  std::string source_area_name, destination_area_name;
};

template<CDVM>
class Migration_by_ogive : public Migration<DVM>{
  // The Migration_by_ogive class is an implementation of the Migration class,
  // for when the rate of migration does depend on size or age, or on maturity
  // in a model where maturity is not in the partition (otherwise use Migration_by_constant),
  // and is currently used by the basic model.
  // It is used via ->apply().
  // The private data members include source_rows, destination_rows, migration_rates,
  // which define the movements between elements of the partition in a migration episode.
public:
  int apply(Basic_state<DVM>& s, int year,Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0);
  void print(Basic_state<DVM>& s, ostream& out);
  Migration_by_ogive(Parameter_set<DVM>& p, Basic_state<DVM>& s, int step, const std::string& _label,
                     int source_area, int destination_area,
                     Size_at_age<DVM>* size_at_age,
                     Mean_weight<DVM> *mean_weight);
  ~Migration_by_ogive();
private:
  std::string label;
  int wave;
  DOUBLE pwave;
  std::vector<int> source_rows;
  std::vector<int> destination_rows;
  std::vector<VECTOR> migration_rates;
  // For each i, each migration_rates[i][j] is the proportion of fish moving from
  // partition[source_rows[i]][j] to partition[destination_rows[i]][j].
  std::string source_area_name, destination_area_name;
  VECTOR rates;
};

template<CDVM>
class Density_dependence{
  // Used by the migration classes. Calculates the density dependence factor and applies it
  //  to either a single migration rate or a vector of migration rates.
  // The initial abundances A(i,0) need to be filled in during set_initial_state
  //  by finding the unfished equilibrium state, setting 'record_initial_abundance',
  //  running the model for a year (during which the apply function records the
  //  abundance at the appropriate time), and unsetting 'record_initial_abundance' again.
public:
  DOUBLE apply(const DOUBLE& rate, Basic_state<DVM>& s, int year,Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0);
  VECTOR apply(const VECTOR& rates, Basic_state<DVM>& s, int year,Basic_requests<DVM>* requests = 0, Basic_results<DVM>* results = 0);
  int record_virgin_abundance;
  void set_initial_abundance(Basic_state<DVM>& s, int year);
  void print(ostream& out);
  void randomise(long seed);

  Density_dependence(Basic_state<DVM>& s, Parameter_set<DVM>& p, const std::string& command,
                     int _source_area, int _destination_area, int _step, const std::string& _label,
                     Mean_weight<DVM> *_mean_weight);
  ~Density_dependence();
private:
  std::string label;
  int source_area, destination_area;
  int step;
  dvector annual_variation_years;
  VECTOR annual_variation_values;
  VECTOR* annual_variation;			//redefine annual_variation to be a vector extending from initial to final so that it could be used in projections 
  DOUBLE annual_variation_bar_val;  //the mean of annual_variation_values between first_year and last year, 
									//which is applied to the migration in the unfished equilibrim (an enhancement requested by Chris Fransis)
  Randomiser<DVM> *randomise_annual_variation;
  int first_random_year;            // This is the first year for which annual_variation are random in stochastic simulations and projections.
 
  DOUBLE S, D;
  DOUBLE get_dd_factor(Basic_state<DVM>& s, int year);
  DOUBLE initial_source_abundance, initial_destination_abundance;
  Mean_weight<DVM> *mean_weight;
  std::vector<int> source_chars, destination_chars, source_vals, destination_vals;
};

template<CDVM>
class Basic_partition_maturity{
  // One of these objects implements one maturation process. They are to be used when
  // maturity is in the partition (otherwise see class Basic_nonpartition_maturity).
  // The key function is apply(), which modifies the state object for one maturation.
  // The maturation process is called using ->apply() from the Basic_annual_cycle.
  //
  // The private data members include source_rows, destination_rows, maturation_rates,
  // which define the movements between elements of the partition in a maturation episode.
public:
  int stock;
  int area;
  int apply(Basic_state<DVM>& s, int year);
  // Apply maturation to the partition of s in year, return a status value.
  void print(Basic_state<DVM>& s, ostream& out);
  VECTOR get(Basic_state<DVM>& s, int sex, std::string stock); // only used by the age-at-maturity observations type
  Basic_partition_maturity(Parameter_set<DVM>& p,Basic_state<DVM>& s, int step, int i,
                           Size_at_age<DVM>* size_at_age);
private:
  std::vector<int> source_rows;
  std::vector<int> destination_rows;
  std::vector<VECTOR> maturation_rates;
  // For each i, each maturation_rates[i][j] is the proportion of fish moving from
  // partition[source_rows[i]][j] to partition[destination_rows[i]][j].
};

template<CDVM>
class Size_at_age{
  // The Size_at_age class specifies the interface for the size-at-age objects which
  //  inherit from it, currently including Size_at_age_years_same, Size_at_age_effective_age,
  //  Size_at_age_from_data.
  // There are a number of key functions:
  // -get_mean_sizes() gives the 'current' mean sizes of fish in a row of the partition.
  //  For this to be correct, the time has to have been updated using set_time(year,step).
  //  This should be done in each time step of the annual_cycle.
  // -get_size_dist() gives the 'current' distribution of sizes at age. By default,
  //  the size class bounds specified by the "class_mins" and "plus_group" parameters are used,
  //  but different size classes can be specified.
  // -get_mean_sizes_at() and get_size_dist_at() give the mean sizes and size distribution
  //  in a specified year and time step.
  // -get_all_cvs extracts the 'current' c.v. of sizes at age for each partition element,
  //    OR the STDEV instead of the CV if 'cvs_actually_stdevs' is set!
  // -get_dist() extracts the type of distribution of sizes at age.
  // -varies_between_years() is 0 if size-at-age is the same in each year, 1 else.
  // -get_pdf extracts the value of the pdf at a particular time, for a particular size and age - used by Age_size likelihoods
  // -get_pdf_with_sizebased_sel is like get_pdf except that a size-based selectivity is applied first, which changes the size-at-age distribution - also used by Age_size likelihoods
public:
  std::string type; // "years_same" or "effective_age"
  virtual VECTOR get_mean_sizes(int row) = 0;
  // Return current mean sizes of fish in 'row' of the partition.
  // get_mean_sizes(i)[j] is the mean size of fish in partition[i][j].
  virtual MATRIX get_size_dist(int row, int _plus_group = -1, const dvector& _class_mins=dvector("{-1}"));
  // Return the current size distribution of fish in 'row' of the partition.
  // size_dist(i)[c][j] is the number of fish of size class c in partition[i][j].
  virtual VECTOR get_mean_sizes_at(int year, int step, int row) = 0;
  virtual MATRIX get_size_dist_at(int year, int step, int row, int _plus_group = -1, const dvector& _class_mins=dvector("{-1}"));
  // Return mean sizes and size distribution of fish in 'row' of the
  // partition in 'step' of 'year'. If you just want to know
  // the current mean sizes, use get_mean_sizes, get_size_dist instead.
  void set_time(int _year, int _step);
  // virtual VECTOR get_cv_by_row(); NOT ANY MORE
  // Return current cvs of size-at-age for each row of the partition.
  virtual MATRIX get_all_cvs(); // OR STDEVS IF...
  int cvs_actually_stdevs;
  int any_nonpositive_cvs; // are there?
  int cvs_by_length; // is the variation in cvs defined by length, not age?
  virtual std::string get_dist();
  // =="normal" if sizes-at-age are normally distributed or "lognormal" or "none"
  virtual int varies_between_years() = 0;
  virtual DOUBLE get_pdf(int year, int step, int row, int age, double size);
  virtual DOUBLE get_pdf_with_sizebased_sel(int year, int step, int row, int age, double size, Selectivity<DVM>* selectivity);
  virtual VECTOR get_cdf_inverse(int year, int step, int row, int age, dvector &quantiles);
  void print_every_mean_size(Basic_state<DVM>&s, ostream& out);
  virtual void print(Basic_state<DVM>& s, ostream& out) = 0;
  Size_at_age(Parameter_set<DVM>& p, Basic_state<DVM>& s);
  virtual ~Size_at_age(){};
protected:
  int year, step;
  int col_min, col_max;
  std::string dist;
  // =="normal" if sizes-at-age are normally distributed or "lognormal" or "none"
  MATRIX cv_by_element;
  // same size as the partition, contains cvs,
  // OR STDEVS if cvs_actually_stdevs is set.
  dvector class_mins;
  int plus_group;
  // class_mins[i] = min. size of size class i, except that if plus_group==0
  // then class_mins[last+1] = max. of last class.
  int initial, current, final, time_steps;
};

template<CDVM>
class Size_at_age_years_same : public Size_at_age<DVM>{
  // The Size_at_age_years_same class is an implementation of the Size_at_age class,
  //  for models where size-at-age is the same in each year.
  // The key data members are
  // - mean_sizes, which has all the size-at-age matrices for the different time step,
  // - mean_size_entry_by_step, which tells it which matrix to use for each time step,
  // - growth_props, which tells it how much to add to the age of a fish (for the
  //   purpose of calculating size) in each time step.
public:
  VECTOR get_mean_sizes(int row);
  VECTOR get_mean_sizes_at(int _year, int _step, int row);
  int varies_between_years(){return 0;}
  void print(Basic_state<DVM>& s, ostream& out);
  Size_at_age_years_same(Parameter_set<DVM>& p,Basic_state<DVM>& s,const dvector& _growth_props);
  ~Size_at_age_years_same();
private:
  std::vector<MATRIX> mean_sizes;
  dvector mean_size_entry_by_step;
  dvector growth_props;
  std::vector<Growth_curve<DVM>*> growth_curves;
  dvector curve_by_row;
  // The mean size of fish in element [i,j] of the partition at 'step' is
  // stored in mean_sizes[mean_size_entry_by_step[step]][i][j],
  // which contains the value
  // growth_curves[curve_by_row[i]]-> mean_size(j+growth_props[step]).
};

template<CDVM>
void get_size_at_age_dist(Parameter_set<DVM>& p,Basic_state<DVM>& s, std::string& dist,
                          int& plus_group, MATRIX& cv_by_element,
                          int& cvs_actually_stdevs, int& any_nonpositive_cvs, int& cvs_by_length);

template<CDVM>
void get_growth_curves(Parameter_set<DVM>& p,Basic_state<DVM>& s, std::vector<Growth_curve<DVM>*>& growth_curves, dvector& curve_by_row);

template<CDVM>
VECTOR stretch(DOUBLE v1, DOUBLE v2, int n1, int n2);

template<CDVM>
class Size_at_age_effective_age : public Size_at_age<DVM>{
  // The Size_at_age_years_same class is an implementation of the Size_at_age class,
  //  for models where size-at-age varies between years using the 'effective age' scheme.
  // The key data members are
  // - effective_age, which gives the effective age of fish by column of the
  //   partition, step, and year,
  // - growth_curves, which has all the growth curves for the rows of the partition,
  // - curve_by_row, which tells it which growth curve to use for each row.
public:
  VECTOR get_mean_sizes(int row);
  VECTOR get_mean_sizes_at(int _year, int _step, int row);
  int varies_between_years(){return 1;}
  void print(Basic_state<DVM>& s, ostream& out);
  Size_at_age_effective_age(Parameter_set<DVM>& p,Basic_state<DVM>& s,const dvector& growth_props);
  ~Size_at_age_effective_age();
private:
  std::vector<MATRIX> effective_age;
  // effective_age[step][year][j] is the effective age of fish in column j
  // of the partition in 'step' of 'year'. For all years before the
  // first year covered in effective_age[step], we use the first row of
  // effective_age[step] (this is to deal with years before we have growth data)
  std::vector<Growth_curve<DVM>*> growth_curves;
  dvector curve_by_row;
  // The size of a fish in row i of the partition at effective age e
  // is given by growth_curves[curve_by_row[i]]->mean_size(e).
};

template<CDVM>
class Size_at_age_from_data : public Size_at_age<DVM>{
  // BB, Feb 2004 - a rewrite using the new, more complex equations
  //
  // The Size_at_age_from_data class is an implementation of the Size_at_age class,
  //  under which mean size-at-age data is provided by the user for one or more years,
  //  for each age in the partition, accurate at a specified time step.
  //
  // See also the Size_at_age function print_every_mean_size, which was intended for use with this class.
public:
  VECTOR get_mean_sizes(int row);
  VECTOR get_mean_sizes_at(int _year, int _step, int row);
  int varies_between_years(){return 1;}
  void print(Basic_state<DVM>& s, ostream& out);
  Size_at_age_from_data(Parameter_set<DVM>& p,Basic_state<DVM>& s,const dvector& _growth_props);
  ~Size_at_age_from_data();
private:
  map<int,vector<dmatrix> > mean_sizes;
  int row_for_mean;
  dvector col_by_step;
  // mean_sizes[year][(int)col_by_step[step]]
  //  gives the mean size matrix in 'step' of 'year'.
  // Unless you want to get the average of the supplied years (ie. for simulation),
  //  in which case look in mean_sizes[row_for_mean][(int)col_by_step[step]]
  // This storage method cuts down on the number of partition-sized mean size matrices we have to store...
  //  Two steps with the same mean sizes (ie. on the same side of the birthday and with the same growth_props) need not be stored twice,
  int supplied_step;
  dvector supplied_years;
  std::string fillin_method;
  // can be mean, interp, interp.mean, mean.interp.
  // With mean, missing years are always replaced by the mean data for provided years.
  // With interp, both internal and external gaps are filled using interpolation.
  // With interp.mean, internal gaps are filled using interpolation and external gaps with the mean.
  // With mean.interp, internal gaps are filled with the mean and external gaps using interpolation.
  int simulation; // is it? (i.e. this model is for running to stochastic / deterministic equilibrium rather than over real years).
};

template<CDVM>
void get_mean_size_data(Parameter_set<DVM>& p, Basic_state<DVM>& s, int data_year, dmatrix& result);

template<CDVM>
class Growth_curve{
  // The Growth_curve class provides the interface for all the Growth_curve methods,
  // currently von_Bert and Schnute.
public:
  virtual DOUBLE mean_size(const DOUBLE& age) = 0;
  // Return mean size at age (may be effective age).
  virtual void print(ostream& out) = 0;
  virtual ~Growth_curve(){};
};

template<CDVM>
class von_Bert : public Growth_curve<DVM>{
public:
  DOUBLE mean_size(const DOUBLE& age);
  void print(ostream& out);
  von_Bert(const DOUBLE& _k, const DOUBLE& _t0, const DOUBLE& _Linf);
private:
  DOUBLE k, t0, Linf;
};

template<CDVM>
class Schnute : public Growth_curve<DVM>{
public:
  DOUBLE mean_size(const DOUBLE& age);
  void print(ostream& out);
  Schnute(const DOUBLE& _y1, const DOUBLE& _y2, const DOUBLE& _a, const DOUBLE& _b, const DOUBLE& _tau1, const DOUBLE& _tau2);
private:
  DOUBLE y1, y2, a, b, tau1, tau2;
};

template<CDVM>
class Mean_weight{
  // The Mean_weight class specifies the interface for the mean-weight objects which
  // inherit from it, currently including Sizebased_mean_weight and Agebased_mean_weight.
  // The key function is ->get_row(), which gives the 'current' mean weights of fish in a row
  // of the partition. ('current' in age-based models is based on the 'year' and 'step'
  // in the size-at-age object, which the Agebased_mean_weight keeps a pointer to.)
  // The Mean_weight->get_row() is called from an annual_cycle, currently the
  //  Basic_annual_cycle, and also from Mortality objects.
public:
  virtual VECTOR get_row(Basic_state<DVM>& s, int row) = 0;
  // Return current mean weights of fish in row of the partition.
  // get_row(i)[j] is the mean weight of fish in partition[i][j].
  virtual void print(Basic_state<DVM>& s, ostream& out) = 0;
  virtual ~Mean_weight(){};
};

template<CDVM>
void check_units_for_size_weight(const double a, const double b, const int stock_number,
Parameter_set<DVM>& p, Basic_state<DVM>& s, const string sex = "");

template<CDVM>
class Sizebased_mean_weight : public Mean_weight<DVM>{
  // The Sizebased_mean_weight class is an implementation of the Mean_weight class,
  // for size-based models, and is currently used by the basic model.
  // It is used via ->get_row().
  // The key data member is mean_weight_at_size, which is a matrix of mean weights
  // for each element of the partition.
public:
  VECTOR get_row(Basic_state<DVM>& s, int row);
  void print(Basic_state<DVM>& s, ostream& out);
  Sizebased_mean_weight(Parameter_set<DVM>& p,Basic_state<DVM>& s);
private:
  MATRIX mean_weight_at_size;
};

template<CDVM>
class Agebased_mean_weight : public Mean_weight<DVM>{
  // The Agebased_mean_weight class is an implementation of the Mean_weight class,
  // for age-based models, and is currently used by the basic model.
  // A bias correction is included if a c.v. of sizes-at-age is provided.
  // The bias correction is 'exact' for lognormal sizes at age, and
  // a good approximation for normal.
  // It is used via ->get_row().
  // The data members are
  // - a and b, the size-weight parameters for each row of the partition,
  // - size_at_age, a pointer to the Size_at_age object in the annual cycle.
  // Provided the size_at_age object is kept up to date, get_row returns
  //  the current mean weights at age.
public:
  VECTOR get_row(Basic_state<DVM>& s, int row);
  void print(Basic_state<DVM>& s, ostream& out);
  Agebased_mean_weight(Parameter_set<DVM>& p,Basic_state<DVM>& s,
                       Size_at_age<DVM>* _size_at_age);
private:
  dvector a, b;
  // The size-weight relationship is: weight = a * size^b.
  // a and b are vectors, such that a[i] and b[i] are for row i of the partition.
  Size_at_age<DVM>* size_at_age;
  // should point to the Basic_annual_cycle::size_at_age.
};

template<CDVM>
class Basic_nonpartition_maturity{
  // This class is used when maturity is a feature in the model but not a character
  //  in the partition. It makes the assumption that the proportion of mature fish
  //  in each element of the partition is constant in all time steps and years.
  // The key function is get_row(), which gives the proportion mature for a given
  //  row of the partition. get_row() is called from the annual_cycle.
  // The key data member is mature_by_element, which is a matrix of proportions mature
  //  for each element of the partition.
public:
  VECTOR get_row(int row);
  // Return the proportions of mature fish in each element of row.
  // get_row(i)[j] is the proportion of mature fish in element [i,j] of the partition.
  void print(Basic_state<DVM>& s,ostream& out);
  Basic_nonpartition_maturity(Parameter_set<DVM>& p,Basic_state<DVM>& s);
private:
  MATRIX mature_by_element;
  // mature_by_element[i][j] is the proportion mature for element [i,j] of the partition
};

template<CDVM>
class Basic_initialization_data{
  // Just a container for data used by Basic_population_model::set_initial_state.
private:
  std::string command;
public:
  int stock;
  DOUBLE B0, R0, Bmean, Rmean, Binitial, Rinitial;
  VECTOR *Cinitial, *Cinitial_male, *Cinitial_female;
  int Rinitial_is_deviate;
  int n_equilibrium;
  int use_mean_YCS;
  // anything which was not supplied is set to 0
  void multiply_abundance(double mult);
  void print(Basic_state<DVM>& s, ostream& out);
  Basic_initialization_data(Parameter_set<DVM>& p, Basic_state<DVM>& s, int stock, int y_enter);
  ~Basic_initialization_data();
};

//############################## END OF POPULATION_PROCESSES.h ##############################
#endif
