// const char* time_stamp = "$Date: 2007-11-15 14:37:25 +1300 (Thu, 15 Nov 2007) $\n";
// const char* likelihoods_id = "$Id: likelihoods.h 1770 2007-11-15 01:37:25Z adunn $\n";

#if !defined(LIKELIHOODS)
#define LIKELIHOODS

//############################## OBJECTIVE FUNCTIONS ##############################
#include "development.h"
#include <string>
#include <iostream>

// Forward declarations
template<CDVM> class Parameter_set;

///////////////////////////////////////////////////////////////////////////////////////
template<CDVM>
class Objective{
  // The abstract base class for all types of likelihoods.
  // Classes derived from Objective need to implement the virtual functions
  //   -value: returns the objective function value, given expected values and observations.
  //   -set_process_error: set the process error to the specified value.
  //   -get_std_devs: given the obs & fits, get the standard deviation of each element of
  //                  the observations.
  //                   Used for calculating Pearson residuals.)
  //   -get_normalised_resids: given the obs and fits, calculate the normalised residuals.
  //                           Result is undefined unless normalised_resids_defined()==1.
  //   -normalised_resids_defined: ==1 if normalised residuals are defined for this objective type.
  //   -bootstrap_observations: returns a matrix of observation values resampled around the fits,
  //                            according to the error distribution. Pass it the fits and the
  //                            random number seed (see Betadiff documentation).
  //   -print()
  // and may implement get_weights, get_ko, get_kp, get_sigmas, get_cvs, and/or get_Ns if applicable.
  // The 'type' field says what kind of objective function is being used: it should
  //   be filled in with the name of the derived class (e.g. "Normal_likelihood").
  // For relative observations, the calculation of nuisance q's occurs at a higher level:
  //   so, classes derived from Objective will be supplied with expected values which
  //   already include the factor of q.
public:
  std::string type;
  virtual DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs) = 0;
  virtual void set_process_error(DOUBLE& V) = 0;
  int has_process_error;
  std::string process_error_parname;
  DOUBLE process_error_val;
  virtual MATRIX get_std_devs(const MATRIX& obs,const MATRIX& fits) = 0;
  virtual MATRIX get_normalised_resids(const MATRIX& obs, const MATRIX& fits);
  virtual int normalised_resids_defined();
  virtual MATRIX bootstrap_observations(const MATRIX& fits, long int seed) = 0;
  virtual MATRIX& get_weights();
  virtual double  get_ko();
  virtual double  get_kp();
  virtual MATRIX& get_sigmas();
  virtual MATRIX& get_cvs();
  virtual MATRIX& get_Ns();
  virtual void print(ostream& out = cout) = 0;
  Objective<DVM>* error_dist;
  virtual ~Objective(){};
private:
// Never actually used, but avaiable for functions so-as to stop compiler complaints about not returning an appropriate variable
  MATRIX dummyM;
};

template<CDVM>
class Multinomial_likelihood : public Objective<DVM>{
  // The concrete class for multinomial likelihood functions.
  // Contains effective sample sizes N by year, robustifying constant r,
  // the obj_value() function which returns the negative-log-likelihood,
  // the get_std_devs() function which returns the standard deviation of each observation,
  // the bootstrap_observations() function which returns resampled proportions (how?),
  // and the set_process_error() function, which 'adds' a process error N.
  //
  // 21 June 2004: OBSOLETE - prefer Multinomial_withconst_likelihood which includes the initial combinatoric constant.
public:
  double r;
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  MATRIX bootstrap_observations(const MATRIX& fits, long int seed);
  MATRIX get_std_devs(const MATRIX& obs, const MATRIX& fits);
  void set_process_error(DOUBLE& V);
  MATRIX& get_Ns(){return *N;}
  void print(ostream& out = cout);
  Multinomial_likelihood(Parameter_set<DVM>& e,const std::string& command,const dvector& years);
  ~Multinomial_likelihood();
private:
  MATRIX *N;
  dmatrix *N_base;
};

template<CDVM>
class Multinomial_withconst_likelihood : public Objective<DVM>{
  // The concrete class for multinomial likelihood functions.
  // Contains effective sample sizes N by year, robustifying constant r,
  // the obj_value() function which returns the negative-log-likelihood,
  // the get_std_devs() function which returns the standard deviation of each observation,
  // the bootstrap_observations() function which returns resampled proportions (how?),
  // and the set_process_error() function, which 'adds' a process error N.
  //
  // 21 June 2004: Created to replace Multinomial_likelihood - similar but
  //  includes the initial combinatoric constant and hence supports estimated process error.
  // Note that a single N must be supplied for each year (unlike the other proportions likelihoods
  //  where a different N can be supplied for each age/size class in each year).
  //  N is still dimensioned as (years * age/size classes), for consistency, but all entries
  //   within each row are the same.
public:
  double delta;
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  MATRIX bootstrap_observations(const MATRIX& fits, long int seed);
  MATRIX get_std_devs(const MATRIX& obs, const MATRIX& fits);
  void set_process_error(DOUBLE& V);
  MATRIX& get_Ns(){return *N;}
  void print(ostream& out = cout);
  Multinomial_withconst_likelihood(Parameter_set<DVM>& e,const std::string& command,const dvector& years);
  ~Multinomial_withconst_likelihood();
private:
  MATRIX *N;
  dmatrix *N_base;
};

template<CDVM>
class Fournier_likelihood : public Objective<DVM>{
  // The concrete class for Fournier likelihood functions.
  // Contains effective sample sizes N by year,
  // the obj_value() function which returns the negative-log-likelihood,
  // the get_std_devs() function which returns the standard deviation of each observation,
  // the bootstrap_observations() function which returns resampled proportions (how?),
  // and the set_process_error() function, which 'adds' a process error N.
public:
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  MATRIX bootstrap_observations(const MATRIX& fits, long int seed);
  MATRIX get_std_devs(const MATRIX& obs, const MATRIX& fits);
  void set_process_error(DOUBLE& V);
  MATRIX& get_Ns(){return *N;}
  void print(ostream& out = cout);
  Fournier_likelihood(Parameter_set<DVM>& e,const std::string& command,const dvector& years);
  ~Fournier_likelihood();
private:
  MATRIX *N;
  dmatrix *N_base;
};

template<CDVM>
class Coleraine_likelihood : public Objective<DVM>{
  // The concrete class for Coleraine likelihood functions.
  // Contains effective sample sizes N by year,
  // the obj_value() function which returns the negative-log-likelihood,
  // the get_std_devs() function which returns the standard deviation of each observation,
  // the bootstrap_observations() function which returns resampled proportions (how?),
  // and the set_process_error() function, which 'adds' a process error N.
public:
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  MATRIX bootstrap_observations(const MATRIX& fits, long int seed);
  MATRIX get_std_devs(const MATRIX& obs, const MATRIX& fits);
  void set_process_error(DOUBLE& V);
  MATRIX& get_Ns(){return *N;}
  void print(ostream& out = cout);
  Coleraine_likelihood(Parameter_set<DVM>& e,const std::string& command,const dvector& years);
  ~Coleraine_likelihood();
private:
  MATRIX *N;
  dmatrix *N_base;
};

template<CDVM>
class Binomial_likelihood : public Objective<DVM>{
  // The concrete class for binomial likelihood functions.
  // Contains effective sample sizes N by observation, robustifying constant r,
  // the obj_value() function which returns the negative-log-likelihood,
  // the get_std_devs() function which returns the standard deviation of each observation,
  // the bootstrap_observations() function which returns resampled proportions,
  // and the set_process_error() function, which 'adds' a process error N.
  //
  // WARNING: N is not correctly estimable with this likelihood because
  //  the combinatoric constant is not included - use Binomial_exact_likelihood below.
public:
  double r;
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  MATRIX bootstrap_observations(const MATRIX& fits, long int seed);
  MATRIX get_std_devs(const MATRIX& obs, const MATRIX& fits);
  void set_process_error(DOUBLE& V);
  MATRIX& get_Ns(){return *N;}
  void print(ostream& out = cout);
  Binomial_likelihood(Parameter_set<DVM>& e,const std::string& command,const dvector& years);
  ~Binomial_likelihood();
private:
  MATRIX *N;
  dmatrix *N_base;
};

template<CDVM>
class Binomial_exact_likelihood : public Objective<DVM>{
  // Like Binomial_likelihood, but uses the exact binomial formula
  // rather than the normal approximation. The combinatoric constant
  // at the front is included (which makes N estimable).
  //
  // Delta is a robustifying constant used in the zerofun() function.
  // See the manual. If in doubt, use the default.
public:
  double delta;
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  MATRIX bootstrap_observations(const MATRIX& fits, long int seed);
  MATRIX get_std_devs(const MATRIX& obs, const MATRIX& fits);
  void set_process_error(DOUBLE& V);
  MATRIX& get_Ns(){return *N;}
  void print(ostream& out = cout);
  Binomial_exact_likelihood(Parameter_set<DVM>& e,const std::string& command,const dvector& years);
  ~Binomial_exact_likelihood();
private:
  MATRIX *N;
  dmatrix *N_base;
};

template<CDVM>
class Normal_likelihood : public Objective<DVM>{
  // The concrete class for normal likelihood functions.
  // Contains cv's by year,
  //  the obj_value() function which returns the negative-log-likelihood,
  //  the get_std_devs() function which returns the standard deviation of each observation,
  //  the get_normalised_resids() function which returns the normalised residuals,
  //  the bootstrap_observations() function which returns resampled indices,
  //  and the set_process_error() function, which 'adds' a process error cv.
  // There is one constructor used for time series,
  //  and also a couple of others only used for age/size data (so far).
public:
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  MATRIX bootstrap_observations(const MATRIX& fits, long int seed);
  MATRIX get_std_devs(const MATRIX& obs, const MATRIX& fits);
  MATRIX get_normalised_resids(const MATRIX& obs, const MATRIX& fits);
  int normalised_resids_defined(){return 1;}
  void set_process_error(DOUBLE& V);
  MATRIX& get_cvs(){return *cv;}
  void print(ostream& out = cout);
  Normal_likelihood(Parameter_set<DVM>& e,const std::string& command,const dvector& years);
  Normal_likelihood(int n_obs, const DOUBLE& cv_all);
  Normal_likelihood(const dvector& sexes,const DOUBLE& cv_male, const DOUBLE& cv_female);
  ~Normal_likelihood();
private:
  MATRIX *cv;
  MATRIX *cv_base;
};

template<CDVM>
class Lognormal_likelihood : public Objective<DVM>{
  // The concrete class for lognormal likelihood functions.
  // Contains cv's by year,
  //  the obj_value() function which returns the negative-log-likelihood,
  //  the get_std_devs() function which returns the standard deviation of each observation,
  //  the get_normalised_resids() function which returns the normalised residuals,
  //  the bootstrap_observations() function which returns resampled indices,
  //  and the set_process_error() function, which 'adds' a process error cv.
  // There is one constructor used for time series,
  //  and also a couple of others only used for age/size data (so far).
public:
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  MATRIX bootstrap_observations(const MATRIX& fits, long int seed);
  MATRIX get_std_devs(const MATRIX& obs, const MATRIX& fits);
  MATRIX get_normalised_resids(const MATRIX& obs, const MATRIX& fits);
  int normalised_resids_defined(){return 1;}
  void set_process_error(DOUBLE& V);
  MATRIX& get_cvs(){return *cv;}
  MATRIX& get_sigmas(){return *sigma;}
  void print(ostream& out = cout);
  Lognormal_likelihood(Parameter_set<DVM>& e,const std::string& command,const dvector& years);
  Lognormal_likelihood(int n_obs, const DOUBLE& cv_all);
  Lognormal_likelihood(const dvector& sexes,const DOUBLE& cv_male, const DOUBLE& cv_female);
  ~Lognormal_likelihood();
protected:
  MATRIX *cv_base;
  MATRIX *cv;
  MATRIX *sigma;
};

template<CDVM>
class Robustified_lognormal_likelihood : public Lognormal_likelihood<DVM>{
  // The concrete class for robustified lognormal likelihood functions.
public:
  double r;
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  void print(ostream& out = cout);
  Robustified_lognormal_likelihood(Parameter_set<DVM>& e,const std::string& command,const dvector& years);
};

template<CDVM>
class Normal_log_likelihood : public Objective<DVM>{
  // The concrete class for normal-log likelihood functions.
  // Contains cv's by year,
  // the obj_value() function which returns the negative-log-likelihood,
  // the get_std_devs() function which returns the standard deviation of each observation,
  // the get_normalised_resids() function which returns the normalised residuals,
  // the bootstrap_observations() function which returns resampled indices,
  // and the set_process_error() function, which 'adds' a process error cv.
public:
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  MATRIX bootstrap_observations(const MATRIX& fits, long int seed);
  MATRIX get_std_devs(const MATRIX& obs, const MATRIX& fits);
  MATRIX get_normalised_resids(const MATRIX& obs, const MATRIX& fits);
  int normalised_resids_defined(){return 1;}
  void set_process_error(DOUBLE& V);
  MATRIX& get_cvs(){return *cv;}
  MATRIX& get_sigmas(){return *sigma;}
  void print(ostream& out = cout);
  Normal_log_likelihood(Parameter_set<DVM>& e,const std::string& command,const dvector& years);
  ~Normal_log_likelihood();
private:
  dmatrix *cv_base;
  MATRIX *cv;
  MATRIX *sigma;
};

template<CDVM>
class Normal_by_stdev_likelihood : public Objective<DVM>{
  // The concrete class for normal likelihood functions,
  //  parameterized by standard deviation rather than cv.
  // Contains stdev's by year,
  // the obj_value() function which returns the negative-log-likelihood,
  // the get_std_devs() function which returns the standard deviation of each observation,
  // the bootstrap_observations() function which returns resampled indices,
  // and the set_process_error() function, which 'adds' a process error std. dev.
public:
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  MATRIX bootstrap_observations(const MATRIX& fits, long int seed);
  MATRIX get_std_devs(const MATRIX& obs, const MATRIX& fits);
  void set_process_error(DOUBLE& V);
  void print(ostream& out = cout);
  Normal_by_stdev_likelihood(Parameter_set<DVM>& e,const std::string& command,const dvector& years);
  ~Normal_by_stdev_likelihood();
private:
  MATRIX *stdev;
  dmatrix *stdev_base;
};

template<CDVM>
class User_supplied_likelihood : public Objective<DVM>{
  // This likelihood is supplied by the user through user.likelihood.cpp.
public:
  DOUBLE obj_value(const MATRIX& fits, const MATRIX& obs);
  MATRIX bootstrap_observations(const MATRIX& fits, long int seed);
  MATRIX get_std_devs(const MATRIX& obs, const MATRIX& fits);
  void set_process_error(DOUBLE& V);
  void print(ostream& out = cout){out << "user-supplied likelihood\n";}
  User_supplied_likelihood(std::string& _label);
private:
  std::string label;
// Never actually used, but avaiable for functions so-as to stop compiler complaints about not returning an appropriate variable
  MATRIX dummyM;
};

//############################### END OF LIKELIHOODS.h ##############################
#endif
