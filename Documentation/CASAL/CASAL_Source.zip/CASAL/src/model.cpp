// const char* time_stamp = "$Date: 2012-11-08 09:34:56 +1300 (Thu, 08 Nov 2012) $\n";
// const char* model_id = "$Id: model.cpp 4825 2012-11-07 20:34:56Z Dunn $\n";

//############################### #ESSENTIAL INCLUDES ##############################
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <cctype>  // for isspace()
#include <sstream>
#include <exception>
#ifdef __MINGW32__
#include <process.h>
#endif

#include "modification.txt"
#include "development.h"
#include "yields.h"
#include "output.h"
#include "observations.h"
#ifndef VERSION_H_
  #include "version.h"
#endif

#ifdef _CONSOLE
#include <windows.h>
#include "license.txt"
#else
#include "license.txt"
#endif

//############################## MAIN() ##############################
int main(int argc, char* argv[]){
  DEBUG0("main");
  // Enable calcuation of elapsed time
  time_t start_time;
  start_time = time(NULL);
  // Enable calculation of CPU time used (UNIX systems only).
  #ifndef __MINGW32__
    tms cpu_start, cpu_stop;
    times(&cpu_start);
  #endif
  // Version number
  std::string version = "2.30";
  // Print header information
  std::string CASAL_header;
  std::string CASAL_VERSION;
  CASAL_header += "CASAL (C++ algorithmic stock assessment laboratory)\n";
  // Print the command line that was invoked
  CASAL_header += "Call: ";
  for (int i=0; i<argc; i++){
    CASAL_header += argv[i];
    CASAL_header += " ";
  }
  CASAL_header += "\nDate: ";
  // Print the date and time
  time_t t;
  t = time(NULL);
  CASAL_header += ctime(&t);
  // Print the version label, based on svn_version output, from the auto-generated header file 'version.h'
  // giving the latest modification date and time of source files
  if(SOURCE_CONTROL_DATE=="") {
    CASAL_VERSION = "v" + version + ". Development version: Not to be used for assessments";
  } else {
    CASAL_VERSION = "v" + version + "-" + SOURCE_CONTROL_DATE + " " + SOURCE_CONTROL_TIME + " UTC (rev." + itos(SOURCE_CONTROL_REVISION) + ")  ";
  }
  CASAL_header += CASAL_VERSION;
  CASAL_header += "(c) Copyright 2002-2012, NIWA\n";
  if(USER_MODIFICATION_DESCRIPTION.size()>0)
    CASAL_header += "WARNING: This is a modified version of CASAL. " + USER_MODIFICATION_DESCRIPTION + '\n';
  std::ostringstream PID;
  #ifdef __MINGW32__
    char name[50];
    unsigned long sz=49;
    CASAL_header += "User name: ";
    #ifdef _CONSOLE
      GetUserName(name,&sz);
      CASAL_header += name;
    #else
      CASAL_header += getlogin();
    #endif
    CASAL_header += "\nMachine name: ";
    #ifdef _CONSOLE
      sz=49;
      GetComputerName(name,&sz);
    #else
      w32_gethostname(name, 49);
    #endif
    CASAL_header += name;
    CASAL_header += " (Microsoft Windows";
    std::ofstream supress_stderr_file ("nul");
    PID << _getpid();
  #else
    CASAL_header += "User name: ";
    // CASAL_header += getlogin(); // getlogin() fails if redirecting stdin. Use enviroment vvariable instead
    char* tt = getenv("LOGNAME");
    if (tt != NULL)
      CASAL_header += tt;
    else {
      CASAL_header += "-----";
      cerr << "Warning: CASAL was unable to obtain the user name\n";
    }
    CASAL_header += "\nMachine name: ";
    struct utsname names;
    uname(&names);
    CASAL_header += static_cast<string>(names.nodename) + " (" + static_cast<string>(names.sysname) + " " + static_cast<string>(names.release) + " " + static_cast<string>(names.machine);
    std::ofstream supress_stderr_file ("/dev/null");
    PID << getpid();
  #endif
  CASAL_header += ", PID=" + PID.str() + ")";
  CASAL_header += "\n\n";

  // value to return
  int status = STATUS_OK;

  std::string task = "";
  int do_MCMC = 0;
  int suppress_population_printing = 0;
  int do_covariance = 0;
  int simulation_length = 0;
  long int RNG_seed = 0;
  std::string machine_name = "";
  int run_no;
  int bootstraps_per_parset = 0;
  std::string bootstrap_filename_prefix="";
  std::vector<std::string> samples_filenames, objectives_filenames;
  std::string parameters_input_file="",parameters_output_file="",quantities_output_file="",subsample_file="",covariance_file="";
  int append_to_output_file = 0;
  std::string infilename_prefix="", infilename_suffix="";
  std::string population_csl="",estimation_csl="",output_csl="";

  GetPot cl(argc,argv);
  // how many tasks were requested? should be exactly 1
  int tasks_requested = cl.search("-V") + cl.search("-h") + cl.search("-r") + cl.search("-e") + cl.search("-E") + cl.search("-p") + cl.search("-m")  + cl.search("-M") + cl.search("-a") + cl.search("-C") + cl.search("-v") + cl.search("-Y") + cl.search("-P") + cl.search("-l") + cl.search("-s");
  if (tasks_requested > 1){
    cout << CASAL_header;
    fatal("Must specify exactly one of -V -h -l, -r, -e, -E, -p, -m, -M, -a, -C, -v, -Y, -P, -s");
  } else if (tasks_requested == 0){
    cout << CASAL_header;
    fatal("No valid command line options found. Use 'casal -h' for help.");
  } else if (cl.search("-V")){
    cout << CASAL_VERSION << '\n';
    exit(status);
  } else if (cl.search("-h")){
    // print a usage message
    cout << CASAL_header;
    cout << "casal [-h] [-l] [-r] [-e] [-E] [-p] [-m] [-a number] [-C filelist -S outfile] [-s number prefix] [-v outfile] [-P outfile] [-Y] [-f prefix] [-F suffix] [-q] [-Q] [-i file] [-O outfile] [-o outfile] [-I covariance_file] [-g RNG_seed] [-n name]\n";
    cout << "One task from:\n";
    cout << "-V     display CASAL version\n";
    cout << "-h     display help (this screen)\n";
    cout << "-l     display the CASAL end user licence\n";
    cout << "-r     run model\n";
    cout << "-e     point estimate\n";
    cout << "-E     point estimate using finite differences\n";
    cout << "-p     likelihood/posterior profiles\n";
    cout << "-m     do MCMC chain\n";
    cout << "-M     do MCMC chain using finite differences\n";
    cout << "-a     recover and append to MCMC chain of run 'number'\n";
    cout << "-C     combine MCMC results into subsample\n";
    cout << "-s     generate simulated observations, with number and outfile prefix\n";
    cout << "-v     get values of output quantities for posterior sample\n";
    cout << "-P     get projected outputs\n";
    cout << "-Y     do yield estimates, e.g. MCY, CAY, MSY, CSP\n";
    cout << "\nPlus any of the following:\n";
    cout << "-f     use a prefix on the input parameter filenames\n";
    cout << "-F     replace the input filename 'csl' suffix with a user defined suffix\n";
    cout << "-q     run quietly, i.e. suppress output from population section\n";
    cout << "-Q     suppress all messages and warnings, i.e. all standard error output\n";
    cout << "-i,    with -e, -E, -r, -m, -M, -P, or -Y input parameter values from file\n";
    cout << "-I,    with -m -i, or -M -i input the covariance matrix used for MCMC from file\n";
    cout << "-O,    with -r, -e, -E, or -p output parameter values to file\n";
    cout << "-o,    with -r, -e, -E, or -p output/append parameter values to file\n";
    cout << "-S,    with -C, send subsample to file\n";
    cout << "-g,    set random number generator seed\n";
    cout << "-n,    set machine name (used with -m, -M, or -a, affects chain filenames)\n\n";
    exit(status);
  }

  cout << CASAL_header;
  cout.flush();

  if(cl.search("-Q")) std::cerr.rdbuf (supress_stderr_file.rdbuf());
  if(cl.search("-f")) {
    infilename_prefix = cl.next("");
    if (infilename_prefix == "" || infilename_prefix.substr(0,1)=="-"){
      fatal("You must specify the prefix of the input parameter filenames as the argument of -f");}
    cout << "Prefix for the input parameter filenames : " << infilename_prefix << "\n\n";
  } else infilename_prefix = "";
  if(cl.search("-F")) {
    infilename_suffix = cl.next("");
    if (infilename_suffix == "" || infilename_suffix.substr(0,1)=="-"){
      fatal("You must specify the suffix of the input parameter filenames as the argument of -F");}
    cout << "Suffix for the input parameter filenames : " << infilename_suffix << "\n\n";
  } else infilename_suffix = "csl";
  estimation_csl = infilename_prefix + "estimation." + infilename_suffix;
  population_csl = infilename_prefix + "population." + infilename_suffix;
  output_csl = infilename_prefix + "output." + infilename_suffix;

  if (cl.search("-l")) {
    // This section takes the text of LICENSE, and reformats by inserting carriage returns
    // so that it looks nice on a 80 character width screen
    const int window_width=80;
  std::string formated_license,LICENSE=std::string(LICENSE1)+LICENSE2;
    int count_char=0, space_pos=0;
    for(int i=0;i<LICENSE.length();i++){
      formated_license.push_back(LICENSE[i]);
      if(count_char < window_width && LICENSE[i]!='\n'){
        if(isspace(LICENSE[i])) space_pos=formated_license.size();
        count_char++;
      } else if(LICENSE[i]=='\n') {
        count_char= 0;
      } else {
        formated_license[space_pos-1]='\n';
        count_char= formated_license.size()-space_pos;
      }
    }
    cout << formated_license << endl;
    exit(status);
  }

  if (cl.search("-r")) task = "run_model";
  else if (cl.search("-e")) task = "point_estimate";
  else if (cl.search("-E")) task = "point_estimate_finite_differences";
  else if (cl.search("-p")) task = "profile";
  else if (cl.search("-Y")) task = "yield_estimates";
  else if (cl.search("-m")) task = "MCMC";
  else if (cl.search("-M")) task = "MCMC-finite-differences";
  else if (cl.search("-s")){
        task = "bootstrap";
    bootstraps_per_parset = cl.next(-1);
    if (bootstraps_per_parset == -1) fatal("You must specify the number of simulations to be carried out with each parameter set as the first argument of -s.");
    std::string filename = cl.next("");
    if (filename=="" || filename.substr(0,1)=="-") fatal("You must specify a filename prefix for the output file(s) as the second argument of -s");
    else bootstrap_filename_prefix = filename;
  }
  else if (cl.search("-a")){
    task = "append_to_MCMC";
    run_no = cl.next(-1);
    if (run_no == -1) fatal("You must specify the number of the run to append to as the argument of -a");
  }
  else if (cl.search("-C")){
    task = "combine";
    while (1){
      std::string filename = cl.next("");
      if (filename=="" || filename.substr(0,1)=="-") break;
      else samples_filenames.push_back(filename);
    }
    if (samples_filenames.size() == 0) fatal("You must specify one or more filenames as the arguments of -C.");
  }
  else if (cl.search("-v")){
    task = "quantity_values";
    quantities_output_file = cl.next("");
    if (quantities_output_file == "" || quantities_output_file.substr(0,1)=="-"){
      fatal("You must specify the name of the file to send the results to as the argument of -v");}
  }
  else if (cl.search("-P")){
    task = "project";
    quantities_output_file = cl.next("");
    if (quantities_output_file == "" || quantities_output_file.substr(0,1)=="-"){
      fatal("You must specify the name of the file to send the results to as the argument of -P");}
  }
  if (cl.search("-q")) suppress_population_printing = 1;
  int input_file_rows=0;
  if (cl.search("-i")){
    parameters_input_file = cl.next("");
    if (parameters_input_file == "" || parameters_input_file.substr(0,1)=="-"){
      fatal("You must specify the name of the file of free parameters as the argument of -i");
    } else {
      // count the number of lines in the input file for later reference
      ifstream input_file(parameters_input_file.c_str());
      if (!input_file.good()) fatal("Failed to open " + parameters_input_file);
      std::string header;
      while(getline(input_file,header)) {
        input_file_rows++;
      }
      if(input_file_rows<=1) fatal("No data was found in the input file " + parameters_input_file); // the header is always row 1
      input_file.close();
    }
  }
  if (cl.search("-I")){
    if (parameters_input_file=="" || !(task=="MCMC" || task=="MCMC-finite-differences")){
      fatal("Only use -I in a casal -m -i, or casal -M -i run");}
    covariance_file = cl.next("");
    if (covariance_file == "" || covariance_file.substr(0,1)=="-"){
      fatal("You must specify the name of the covariance matrix file as the argument of -I");}
  }
  if (cl.search("-o")){
    parameters_output_file = cl.next("");
    append_to_output_file = 1;
    if (parameters_output_file == "" || parameters_output_file.substr(0,1)=="-"){
      fatal("You must specify the name of the file of free parameters as the argument of -o or -O");}
  }
  if (cl.search("-O")){
      parameters_output_file = cl.next("");
      append_to_output_file = 0;
      if (parameters_output_file == "" || parameters_output_file.substr(0,1)=="-"){
        fatal("You must specify the name of the file of free parameters as the argument of -o or -O");}
  }
  if (cl.search("-S")){
    subsample_file = cl.next("");
  }
  if (task=="combine" && (subsample_file=="" || subsample_file.substr(0,1)=="-")){
      fatal("With -C, you need to specify a file with -S for the posterior sample to get dumped into");}
  if (cl.search("-g")){
    RNG_seed = cl.next(-1);
    if (RNG_seed < 0) fatal("You must specify a non-negative random number seed as the argument of -g");
  } else {
    RNG_seed = (long)((long)t-(floor((double)t/100000)*100000));
  }
  cout << "Random number seed : " << RNG_seed << "\n\n";
  if (cl.search("-n")){
    machine_name = cl.next("");
    if (machine_name == "" || machine_name.substr(0,1)=="-"){
      fatal("You must specify the machine name, as the argument of -n");}
  }

  { // Read in the three parameter files (but note we read them in again later as required)
    // check for their existance (and report error if not found)
    // output any comments in the file to the std. output
    ifstream p_File(population_csl.c_str());
    ifstream e_File(estimation_csl.c_str());
    ifstream o_File(output_csl.c_str());
    if (!p_File) cerr << "Error: Cannot find the input parameter file '" << population_csl << "'\n";
    if (!e_File) cerr << "Error: Cannot find the input parameter file '" << estimation_csl << "'\n";
    if (!o_File) cerr << "Error: Cannot find the input parameter file '" << output_csl << "'\n";
    if(!o_File || !e_File || ! p_File) fatal("A fatal error has been received.");
    Parameter_set<double,dvector,dmatrix> o, e, p;
    o.read_file(output_csl,"O");
    e.read_file(estimation_csl,"E");
    p.read_file(population_csl,"P");
    if(p.present("comment") || e.present("comment") || o.present("comment")) {
      if(p.present("comment")) cout << "Comment from '" << population_csl << "': " << p.get_vector_of_strings("comment") << '\n';
      if(e.present("comment")) cout << "Comment from '" << estimation_csl << "': " << e.get_vector_of_strings("comment") << '\n';
      if(o.present("comment")) cout << "Comment from '" << output_csl << "': " << o.get_vector_of_strings("comment") << '\n';
      cout << '\n';
    }
    p_File.close();
    e_File.close();
    o_File.close();
  }

  // extract the output parameters
  Parameter_set<double,dvector,dmatrix> o;
  o.read_file(output_csl,"O");
  // print the parameters if requested
  if (o.get_bool("print.parameters",0)){
    // Need to load the population and estimation parameters from the datafiles first
    Parameter_set<double,dvector,dmatrix> e, p;
    e.read_file(estimation_csl,"E");
    cout << "Estimation parameters:\n";
    e.print();
    p.read_file(population_csl,"P");
    cout << "Population parameters:\n";
    p.print();
    cout << "Output parameters:\n";
    o.print();
  }

  cerr << CASAL_header; // print the HEADER out to std:::err for job tracking

  if (task=="profile"){
    // build the estimation section
    Print_requests print_requests(o,suppress_population_printing);
    Estimation_section<dvariable,dvv,dvm> estimation(population_csl,estimation_csl,&print_requests,0,0,0,0,RNG_seed);
    dvector parameter_values(value(estimation.free_parameters->get()));
    // if a parameter output file was requested, open it to append, or create it and write the header
    ifstream *parameters_check;
    ofstream *parameters_write;
    if (parameters_output_file!=""){
      parameters_check = new ifstream(parameters_output_file.c_str());
      if (append_to_output_file && parameters_check->good()){
        // the file already exists and should be appended to
        parameters_write = new ofstream(parameters_output_file.c_str(),ios::app);
      } else {
        // the file does not exist or should be overwritten
        // create it and write the header (estimation.profile handles the printing of the values)
        parameters_write = new ofstream(parameters_output_file.c_str());
        (*parameters_write) << estimation.free_parameters->make_file_header();
      }
      parameters_write->close();
    }
    // if a parameter input file was provided, open it and read a set of parameters,
    // which should minimise the objective function
    ifstream *input_file;
    std::string header;
    if (parameters_input_file!=""){
      input_file = new ifstream(parameters_input_file.c_str());
      if (!input_file->good()) fatal("Failed to open " + parameters_input_file);
      getline(*input_file,header);
      estimation.free_parameters->check_file_header(header);
      if(input_file_rows>2) fatal("You can supply only one line of data for the starting point of a profile.");
      if(!(estimation.free_parameters->get_input_file_by_line(input_file, parameters_input_file, parameter_values))) {
        fatal("Failed to read any values from " + parameters_input_file + ". Please check the -i file.");}
      // do the profiling starting from this minimum
      estimation.profile(parameters_output_file,parameter_values);
    } else {
      // just do the profiling
      estimation.profile(parameters_output_file);
    }
  }

  if (task=="run_model" || task=="profile"){
    int profile_requires_run=-1; // -1= not a profile; 0=profile and do a run; 1=profile and do not do a run
    if(task=="profile") {
      if (parameters_output_file!=""){
        // OK, we're doing a run using the results from a profile, but only as the user specified the -O option
        profile_requires_run=0;
        parameters_input_file=parameters_output_file;
        parameters_output_file="";
        cout << "\n\nDoing a -r run on the resulting profile estimates:\n\n";
        // Now check that the -i file has sensible values in it
        // and count the number of lines in the input file for later reference
        ifstream input_file(parameters_input_file.c_str());
        if (!input_file.good()) fatal("Failed to open " + parameters_input_file);
        std::string header;
        while(getline(input_file,header)) {
          input_file_rows++;
        }
        if(input_file_rows<=1) fatal("No data was found in the output of the profile (" + parameters_input_file + ") to do a -r run on.");
        input_file.close();
      } else {
        // no need to do a run
        profile_requires_run=1;
      }
    }
    if(profile_requires_run<1) {
      // build the estimation section
      Print_requests print_requests(o,suppress_population_printing);
      Estimation_section<double,dvector,dmatrix> estimation(population_csl,estimation_csl,&print_requests,0,0,0,0,RNG_seed);
      // also build a silent version which can be used for calculating outputs
      // without producing screeds of printing
      Print_requests quiet_print_requests(o,1);
      Estimation_section<double,dvector,dmatrix> quiet_estimation(population_csl,estimation_csl,&quiet_print_requests,0,0,0,0,RNG_seed);
       // sort out what quantities need to be output
      Quantity_requests quantity_requests(o,quiet_estimation);
      Quantity_results quantity_results;
      // if a parameter input file was provided, open it and check the header
      ifstream *input_file;
      std::string header;
      dvector parameter_values(estimation.free_parameters->get());
      if (parameters_input_file!=""){
        input_file = new ifstream(parameters_input_file.c_str());
        if (!input_file->good()) fatal("Failed to open " + parameters_input_file);
        getline(*input_file,header);
        estimation.free_parameters->check_file_header(header);
      }
      // if a parameter output file was requested, open it to append, or create it and write the header
      ifstream *parameters_check;
      ofstream *parameters_write;
      if (parameters_output_file!=""){
        parameters_check = new ifstream(parameters_output_file.c_str());
        if (append_to_output_file && parameters_check->good()){
          // the file already exists and should be appended to
          parameters_write = new ofstream(parameters_output_file.c_str(),ios::app);
        } else {
          // the file does not exist or should be overwritten
          // create it and write the header
          parameters_write = new ofstream(parameters_output_file.c_str());
          (*parameters_write) << estimation.free_parameters->make_file_header();
        }
      }
      while (1) {
        if(parameters_input_file!="") {
          // read in the input file data, line by line (and check valid number of values)
          if(!(estimation.free_parameters->get_input_file_by_line(input_file, parameters_input_file, parameter_values))) break;
          estimation.free_parameters->set(parameter_values);
        }
        if (print_requests.estimation_section){
          cout << "Estimation section :\n\n";
          estimation.print();
        }
        // run the model
        double obj_fn = estimation.get_objective_function();
        // print the objective, components and fits
        cout << "Start extracting output from here\n\n";
        // external programs ignore everything up to here
        cout << "Parameter values :\n";
        estimation.free_parameters->print(0);
        cout << "In a format suitable for -i :\n\n";
        cout << estimation.free_parameters->make_file_header();
        cout << estimation.free_parameters->get() << "\n\n";
        if (parameters_output_file!=""){
          (*parameters_write) << estimation.free_parameters->get() << "\n";
            }
        cout << "Objective function : " << obj_fn << "\n\nComponents :\n";
        estimation.print_objective_components();
        if (print_requests.fits){
          cout << "Fits : \n\n";
          estimation.observations_dataset->print(cout,1,print_requests.resids,
                                                 print_requests.pearson_resids,
                                                 print_requests.normalised_resids);
        }
        // calculate and print the output quantities
        quiet_estimation.free_parameters->set(parameter_values);
        quiet_estimation.insert_free_parameters();
        quantity_results.get(quantity_requests,quiet_estimation);
        cout << "Output quantities start here\n\n";
        quantity_results.print(quantity_requests);
        cout << "Output quantities finish here\n\n";
        // exit the loop if there is no input file
        if (parameters_input_file=="") break;
      }
      if (parameters_output_file!=""){
        parameters_write->close();
      }
      if (o.get_bool("print.unused_parameters",0)){
        // print out those parameters that were never accessed
        // popn & estim. have a chance either to be used in the ordinary model or the quiet model
        cout << "Unused parameters:\n";
        // access 'comments', if exist, so as not to be printed as 'unused'
        estimation.p.present("comment");
        estimation.e.present("comment");
        o.present("comment");
        cout << intersection<std::string>(estimation.p.get_unused(),quiet_estimation.p.get_unused());
        cout << intersection<std::string>(estimation.e.get_unused(),quiet_estimation.e.get_unused());
        cout << o.get_unused();
        cout << '\n';
      }
    }
  }

  else if (task=="point_estimate" || task=="point_estimate_finite_differences"){
    Print_requests print_requests(o,suppress_population_printing);
    do_covariance = print_requests.covariance;
    // Build the estimation section. We have to template it, either on active classes
    // if task=="point_estimate" or ordinary arithmetic classes if "point_estimate_finite_differences",
    // so we make a pointer to each and only construct the one we will actually use.
    Estimation_section<dvariable,dvv,dvm> *diff_estimation;
    Estimation_section<double,dvector,dmatrix> *nondiff_estimation;
    if (task=="point_estimate"){
      diff_estimation = new Estimation_section<dvariable,dvv,dvm>(population_csl,estimation_csl,&print_requests,0,do_covariance,0,0,RNG_seed);
    } else if (task=="point_estimate_finite_differences"){
      nondiff_estimation = new Estimation_section<double,dvector,dmatrix>(population_csl,estimation_csl,&print_requests,0,do_covariance,0,0,RNG_seed);
    }
    // also build a quiet, non-differentiable version which can be used for calculating outputs -
    //  it will run faster than the differentiable version and not produce screeds of printing
    Print_requests quiet_print_requests(o,1);
    Estimation_section<double,dvector,dmatrix> quiet_estimation(population_csl,estimation_csl,&quiet_print_requests,0,0,0,0,RNG_seed);
    int n_free_parameters = quiet_estimation.free_parameters->get().size();
    // sort out what quantities need to be output
    Quantity_requests quantity_requests(o,quiet_estimation);
    Quantity_results quantity_results;
    // if a parameter input file was provided, open it and check the header
    ifstream *input_file;
    std::string header;
    if (parameters_input_file!=""){
      input_file = new ifstream(parameters_input_file.c_str());
      if (!input_file->good()) fatal("Failed to open " + parameters_input_file);
      getline(*input_file,header);
      if (task=="point_estimate"){
        diff_estimation->free_parameters->check_file_header(header);
      } else if (task=="point_estimate_finite_differences"){
        nondiff_estimation->free_parameters->check_file_header(header);
      }
    }
    // if a parameter output file was requested, open it to append, or create it and write the header
    ifstream *parameters_check;
    ofstream *parameters_write;
    if (parameters_output_file!=""){
      parameters_check = new ifstream(parameters_output_file.c_str());
      if (append_to_output_file && parameters_check->good()){
        // the file already exists and should be appended to
        parameters_write = new ofstream(parameters_output_file.c_str(),ios::app);
      } else {
        // the file does not exist or should be overwritten
        // create it and write the header
        parameters_write = new ofstream(parameters_output_file.c_str());
        if (task=="point_estimate"){
          (*parameters_write) << diff_estimation->free_parameters->make_file_header();
        } else if (task=="point_estimate_finite_differences"){
          (*parameters_write) << nondiff_estimation->free_parameters->make_file_header();
        }
      }
    }
    dvector parameter_values(1,n_free_parameters);
    if (task=="point_estimate"){
      parameter_values = value(diff_estimation->free_parameters->get());
    } else if (task=="point_estimate_finite_differences"){
      parameter_values = nondiff_estimation->free_parameters->get();
    }
    while (1){
      // do this once, or once per line in the parameter input file
      if (parameters_input_file!=""){
        if (task=="point_estimate"){
          // read in the input file data, line by line (and check valid number of values)
          if(!(diff_estimation->free_parameters->get_input_file_by_line(input_file, parameters_input_file, parameter_values))) break;
          diff_estimation->free_parameters->set(parameter_values);
        } else if (task=="point_estimate_finite_differences"){
          // read in the input file data, line by line (and check valid number of values)
          if(!(nondiff_estimation->free_parameters->get_input_file_by_line(input_file, parameters_input_file, parameter_values))) break;
          nondiff_estimation->free_parameters->set(parameter_values);
        }
      }
      if (print_requests.estimation_section){
        cout << "Estimation section :\n\n";
        if (task=="point_estimate"){
          diff_estimation->print();
        } else if (task=="point_estimate_finite_differences"){
          nondiff_estimation->print();
        }
      }
      // do the point estimate and print the estimate, objective, components and fits
      double obj_fn;
      dvector estimated_parameters(1,n_free_parameters);
          int minimiser_return_val;
      if (task=="point_estimate"){
        obj_fn = value(diff_estimation->point_estimate(minimiser_return_val));
        estimated_parameters = value(diff_estimation->free_parameters->get());
      } else if (task=="point_estimate_finite_differences"){
        obj_fn = nondiff_estimation->point_estimate(minimiser_return_val,1,1);
        estimated_parameters = nondiff_estimation->free_parameters->get();
      }
      // set CASAL's return value
      if (minimiser_return_val > 0) status = max(status,STATUS_OK);
      else if (minimiser_return_val < 0) status = max(status,STATUS_MINIMISER_CONVERGENCE_UNCLEAR);
      else if (minimiser_return_val == 0) status = max(status,STATUS_MINIMISER_OUT_OF_ITERATIONS);
      cout << "Start extracting output from here\n\n";
      // external programs ignore everything up to here
      if (task=="point_estimate"){
        cout << "Point estimate:\n";
        diff_estimation->free_parameters->print(0);
        cout << "In a format suitable for -i :\n\n";
        cout << diff_estimation->free_parameters->make_file_header();
        cout << diff_estimation->free_parameters->get() << "\n\n";
        if (parameters_output_file!=""){
          (*parameters_write) << diff_estimation->free_parameters->get() << "\n";}
        cout << "Objective function : " << obj_fn << "\n\nComponents :\n";
        diff_estimation->print_objective_components();
        if (print_requests.fits){
          cout << "Fits : \n\n";
          diff_estimation->observations_dataset->print(cout,1,print_requests.resids,
                                                       print_requests.pearson_resids,
                                                       print_requests.normalised_resids);
        }
      } else if (task=="point_estimate_finite_differences"){
        cout << "Point estimate:\n";
        nondiff_estimation->free_parameters->print(0);
        cout << "In a format suitable for -i :\n\n";
        cout << nondiff_estimation->free_parameters->make_file_header();
        cout << nondiff_estimation->free_parameters->get() << "\n\n";
        if (parameters_output_file!=""){
          (*parameters_write) << nondiff_estimation->free_parameters->get() << "\n";
        }
        cout << "Objective function : " << obj_fn << "\n\nComponents :\n";
        nondiff_estimation->print_objective_components();
        if (print_requests.fits){
          cout << "Fits : \n\n";
          nondiff_estimation->observations_dataset->print(cout,1,print_requests.resids,
                                                 print_requests.pearson_resids,
                                                 print_requests.normalised_resids);
        }
      }
      // calculate and print the output quantities at the point estimate
      quiet_estimation.free_parameters->set(value(estimated_parameters));
      quiet_estimation.insert_free_parameters();
      quantity_results.get(quantity_requests,quiet_estimation);
      cout << "Output quantities start here\n\n";
      quantity_results.print(quantity_requests,cout);
      cout << "Output quantities finish here\n\n";
      // exit the loop if there is no input file
      if (parameters_input_file=="") break;
    }
    if (o.get_bool("print.unused_parameters",0)){
      // print out those parameters that were never accessed
      // popn & estim. have a chance either to be used in the ordinary model or the quiet model
      cout << "Unused parameters:\n";
      // access 'comments', if exist, so as not to be printed as 'unused'
      quiet_estimation.p.present("comment");
      quiet_estimation.e.present("comment");
      o.present("comment");
      if (task=="point_estimate"){
        cout << intersection<std::string>(diff_estimation->p.get_unused(),quiet_estimation.p.get_unused());
        cout << intersection<std::string>(diff_estimation->e.get_unused(),quiet_estimation.e.get_unused());
      } else if (task=="point_estimate_finite_differences"){
        cout << intersection<std::string>(nondiff_estimation->p.get_unused(),quiet_estimation.p.get_unused());
        cout << intersection<std::string>(nondiff_estimation->e.get_unused(),quiet_estimation.e.get_unused());
      }
      cout << o.get_unused();
      cout << '\n';
    }
    if (parameters_output_file!="") parameters_write->close();
  }

  else if (task=="MCMC" || task=="MCMC-finite-differences"){
    // build a differentiable estimation section to use for the initial point estimate
    do_MCMC = 1;
    do_covariance = 1;
    Print_requests print_requests(o,1);
    Estimation_section<dvariable,dvv,dvm> estimation(population_csl,estimation_csl,&print_requests,do_MCMC,do_covariance,0,0,RNG_seed);
    // Build a non-differentiable estimation section for extra speed in the chain
    Estimation_section<double,dvector,dmatrix> nondifferentiable_estimation(population_csl,estimation_csl,&print_requests,do_MCMC,do_covariance,0,0,RNG_seed);
    dmatrix *covariance;
    std::string samples_filename, objectives_filename;
    istream *samples_check, *objectives_check;
    run_no = 1;
    while (1){ // loop through potential run numbers
      if (machine_name!=""){
        samples_filename = "samples." + machine_name + "." + itos(run_no);
        objectives_filename = "objectives." + machine_name + "." + itos(run_no);
      } else {
        samples_filename = "samples." + itos(run_no);
        objectives_filename = "objectives." + itos(run_no);
      }
      // a rather crude way of checking whether the files already exist
      samples_check = new ifstream(samples_filename.c_str());
      objectives_check = new ifstream(objectives_filename.c_str());
      if (!samples_check->good() && !objectives_check->good()){
        break; // neither file already exists: use this run number
      } else {
        run_no++;
      }
    }
    // open the two output files and write headers
    ostream *samples_out, *objectives_out;
    samples_out = new ofstream(samples_filename.c_str());
    if (!samples_out->good()) fatal("Failed to open " + samples_filename);
    (*samples_out) << estimation.free_parameters->make_file_header();
    samples_out->flush();
    objectives_out = new ofstream(objectives_filename.c_str());
    if (!objectives_out->good()) fatal("Failed to open " + objectives_filename);
    (*objectives_out) << CASAL_header;
    objectives_out->flush();
    cout << "See also " << samples_filename << " and " << objectives_filename << "\n\n";
    // some printing
    if(print_requests.estimation_section){
       cout << "Estimation section :\n\n";
       estimation.print();
    }
    dvector parameter_values(value(estimation.free_parameters->get()));
    // open the parameter input file, check the header
    ifstream *input_file;
    std::string header;
    if (parameters_input_file!=""){
      input_file = new ifstream(parameters_input_file.c_str());
      if (!input_file->good()) fatal("Failed to open " + parameters_input_file);
      getline(*input_file,header);
      estimation.free_parameters->check_file_header(header);
    } else input_file = 0;
      if (covariance_file!=""){
        // Load the covariance matrix from the file into *covariance
        ifstream *cov_file;
        std::string cov_header;
        cov_file = new ifstream(covariance_file.c_str());
        if (!cov_file->good()) fatal("Failed to open " + covariance_file);
        getline(*cov_file,cov_header);
        cout << "Getting covariance matrix from file " << covariance_file << ", with header:\n" << cov_header << '\n';
        cov_file->close();
        char covariance_file_array[200];
        strcpy(covariance_file_array,covariance_file.c_str());
        dmatrix cov_from_file(covariance_file_array,1); // skip header row
        if (cov_from_file.rowsize() != cov_from_file.colsize()){
          fatal("The covariance matrix in file " + covariance_file + " does not seem to be square. Did you include a header row?");}
        if (cov_from_file.rowsize() != parameter_values.size()){
          fatal("The covariance matrix in file " + covariance_file + " is of dimension " + itos(cov_from_file.rowsize()) + " - CASAL was expecting " + itos(parameter_values.size()));}
        covariance = new dmatrix(cov_from_file);
      } else {
        // Get a point estimate: we need the covariance at the posterior mode
        //  and we may also need the position of the mode for the chain's starting location.
        // If a parameter input file was provided,
        //  use the first line for the starting point for the point estimation
        if (parameters_input_file!=""){
          // read in the input file data, line by line (and check valid number of values)
          if(!(estimation.free_parameters->get_input_file_by_line(input_file, parameters_input_file, parameter_values))) {
            fatal("Failed to read any values from " + parameters_input_file + ". Please check the -i file.");}
          if(task=="MCMC") estimation.free_parameters->set(parameter_values);
          else nondifferentiable_estimation.free_parameters->set(parameter_values);
        }
        // Do the point estimate and get the covariance matrix
        int junk_status;
        double obj_fn;
        if(task=="MCMC") {
          obj_fn = estimation.point_estimate(junk_status);
          parameter_values = value(estimation.free_parameters->get());
          covariance = new dmatrix(*(estimation.covariance));
          // print the results (except covariance which has already been printed)
          cout << "Pre-MCMC point estimate:\n\n";
          estimation.free_parameters->print(0);
          cout << "Objective function : " << obj_fn << "\n\nComponents :\n";
          estimation.print_objective_components();
        }  else { // finite differences
          obj_fn = nondifferentiable_estimation.point_estimate(junk_status,0,1);
          parameter_values = value(nondifferentiable_estimation.free_parameters->get());
          covariance = new dmatrix(*(nondifferentiable_estimation.covariance));
          // print the results (except covariance which has already been printed)
          cout << "Pre-MCMC point estimate:\n\n";
          nondifferentiable_estimation.free_parameters->print(0);
          cout << "Objective function : " << obj_fn << "\n\nComponents :\n";
          nondifferentiable_estimation.print_objective_components();
        }
      }
      // Write the covariance matrix to the objective file (we may need this to restart the chain later)
      (*objectives_out) << "Initial covariance matrix (before modifying large correlations and small nonzero variances) follows\n" << *covariance << "\n\n";
      // We will use the next line in the -i file for the start of the chain,
      //  unless there's no -i file or no next line (only possible if -I is not used).
      dvector start(1,parameter_values.size());
      int have_got_start = 0;
      if (input_file){
        (*input_file) >> start;
        if (input_file->good()) have_got_start=1;
      }
      // finish the header of the objective file
      (*objectives_out) << "Main table:\n";
      (*objectives_out) << "sample posterior prior likelihood penalties stepsize acceptance_rate stepsize_changes\n" << flush;
      // now proceed with the chain.
      if (have_got_start){
        nondifferentiable_estimation.run_MCMC(parameter_values,*covariance,*samples_out,*objectives_out,start);
      } else {
        nondifferentiable_estimation.run_MCMC(parameter_values,*covariance,*samples_out,*objectives_out);
      }
      cout << "MCMC done\n"; // wow!
    }
    else if (task=="append_to_MCMC"){
    do_MCMC = 1;
    do_covariance = 0;
    Print_requests print_requests(o,1);
    // Build a non-differentiable estimation section.
    Estimation_section<double,dvector,dmatrix> nondifferentiable_estimation(population_csl,estimation_csl,&print_requests,do_MCMC,0,0,0,RNG_seed);
    if (nondifferentiable_estimation.e.get_bool("MCMC.adaptive_covariance",0)){
      fatal("Sorry, you cannot continue a chain using -a if the original chain used adaptive covariance.");}
    // get the samples and objectives filenames: check that they both exist
    // and the samples file contains at least one sample
    std::string samples_filename, objectives_filename;
    istream *samples_check, *objectives_check;
    if (machine_name!=""){
      samples_filename = "samples." + machine_name + "." + itos(run_no);
      objectives_filename = "objectives." + machine_name + "." + itos(run_no);
    } else {
      samples_filename = "samples." + itos(run_no);
      objectives_filename = "objectives." + itos(run_no);
    }
    // a rather crude way of checking whether the files already exist
    samples_check = new ifstream(samples_filename.c_str());
    if (!samples_check->good()){
      fatal("With -a, can't find file " + samples_filename);
    }
    objectives_check = new ifstream(objectives_filename.c_str());
    if (!objectives_check->good()){
      fatal("With -a, can't find file " + objectives_filename);
    }
    dvector parameter_values(value(nondifferentiable_estimation.free_parameters->get()));
    std::string header;
    getline(*samples_check,header);
    (*samples_check) >> parameter_values;
    if (!samples_check->good()){
      fatal("With -a, " + samples_filename + " does not have any samples in it");
    }
    // Extract the last parameter values from the samples file:
    // extract the covariance matrix
    // and the last sample number, stepsize, and number of successful jumps from the objectives file.
    while (samples_check->good()){
      (*samples_check) >> parameter_values;
    }
    dmatrix covariance(1,parameter_values.size(),1,parameter_values.size());
    std::string dummy = "";  // work forward until the start of the covariance matrix
    while (dummy != "follows"){
      (*objectives_check) >> dummy;}
    (*objectives_check) >> covariance;
    // work forward until the start of the main table
    while (dummy != "table:"){
      (*objectives_check) >> dummy;}
    char junk;
    (*objectives_check) >> junk; // discard \n
    getline(*objectives_check,header); // discard header row
    dvector objectives_line(1,8);
    while (objectives_check->good()){
      (*objectives_check) >> objectives_line;}
    int sample = (int) objectives_line[1];
    double stepsize = objectives_line[6];
    int successful_jumps = (int) (sample * objectives_line[7]);
    // Open the two files to be appended to
    ostream *samples_out, *objectives_out;
    samples_out = new ofstream(samples_filename.c_str(),ios::app);
    if (!samples_out->good()) fatal("Failed to open " + samples_filename);
    objectives_out = new ofstream(objectives_filename.c_str(),ios::app);
    if (!samples_out->good()) fatal("Failed to open " + objectives_filename);
    // Continue the chain
    cout << "\nWe seem to have succeeded in continuing the MCMC run. Do check the results files to make sure they seem sensible!\n\n";
    nondifferentiable_estimation.run_MCMC(parameter_values,covariance,*samples_out,*objectives_out,parameter_values,
                                          sample, stepsize, successful_jumps);
    cout << "MCMC done\n";
  }

  else if (task=="combine"){
    do_MCMC = 1;
    // build the estimation section
    Print_requests quiet_print_requests(o,1);
    Estimation_section<double,dvector,dmatrix> estimation(population_csl,estimation_csl,&quiet_print_requests,do_MCMC,0,0,0,RNG_seed);
    // open the file to dump the posterior sample into: write the header
    ofstream subsample_out(subsample_file.c_str());
    subsample_out << estimation.free_parameters->make_file_header();
    // find the input files
    ifstream *samples_file, *objectives_file;
    for (int i=0; i<samples_filenames.size(); i++){
      if (samples_filenames[i].substr(0,7) != "samples"){
        fatal("File to combine: " + samples_filenames[i] + " does not start with \"samples\"");}
      std::string objective_file = "objectives" + samples_filenames[i].substr(7);
      objectives_filenames.push_back(objective_file);
    }
    dvector parameter_values(value(estimation.free_parameters->get()));
    // set up objects to hold all the sample points and their weights
    std::vector<dvector> sample_points;
    std::vector<double> sample_weights;
    // what do the mcmc_settings say?
    int burn_in = estimation.mcmc_settings->burn_in;
    if (burn_in < 0){ // the default
      fatal("With -C you need to specify the MCMC.burn_in parameter");}
    int keep = estimation.mcmc_settings->keep;
    int systematic = estimation.mcmc_settings->systematic;
    int prior_reweighting = estimation.mcmc_settings->prior_reweighting;
    int subsample_size = estimation.mcmc_settings->subsample_size;
    int take_subsample = (subsample_size > 0);
    if (!take_subsample && prior_reweighting){
      fatal("If you want to use prior reweighting, you have to specify the subsample size.");}
    std::string header, junk;
    double posterior, prior, new_prior;
    int first_sample = 1, sample;
    // loop over input files
    for (int i=0; i<samples_filenames.size(); i++){
      // open the file of posterior samples, extract and check the header
      samples_file = new ifstream(samples_filenames[i].c_str());
      if (!samples_file->good()) fatal("Failed to open " + samples_filenames[i]);
      getline(*samples_file,header);
      estimation.free_parameters->check_file_header(header);
      // open the file of objective values & etc., discard the header
      objectives_file = new ifstream(objectives_filenames[i].c_str());
      if (!objectives_file->good()) fatal("Failed to open " + objectives_filenames[i]);
      while (header != "Main table:") getline(*objectives_file,header); // discard down to the table
      getline(*objectives_file,junk); // discard 1 more: that brings us down to the 1st row of numbers
      cout << "Processing files " << samples_filenames[i] << " and " << objectives_filenames[i] << '\n';
      while (1){
        // do this once per line in the parameter input file:
        (*samples_file) >> parameter_values;
        if (!samples_file->good()) break;
        // discard this line if we are still in the burn-in period
        (*objectives_file) >> sample;
        getline(*objectives_file,junk);
        if (!objectives_file->good()) fatal("Failed to read enough lines from the objectives file");
        if (sample < burn_in*keep){
          // discard the line
        } else {
          sample_points.push_back(parameter_values);
          double weight;
          if (prior_reweighting){
            // apply prior reweighting to determine probability weight of this point
            // get the original prior - the 3rd entry on each line of the objectives file
            istringstream i(junk.c_str());
            i >> posterior >> prior;
            // calculate the new prior
            new_prior = estimation.free_parameters->get_prior();
            // the weight is the ratio of new to old
            weight = exp(prior - new_prior);
          } else {
            // if no prior reweighting, then weights are constant
            weight = 1;
          }
          sample_weights.push_back(weight);
        }
      }
    }
    if (!take_subsample){
      // just dump everything to the output file
      for (int i=0; i<sample_points.size(); i++){
        subsample_out << sample_points[i] << '\n';}
    } else if (take_subsample){
      if (systematic){
        // we need to systematically subsample the original samples
        double spacing = (double) sample_points.size() / (double) subsample_size;
        if (spacing < 1){
          fatal("spacing too small for systematic subsampling with -C");}
        for (int i=1; i<subsample_size; i++){
          subsample_out << sample_points[(int)floor(i*spacing)] << '\n';
        }
        subsample_out << sample_points[sample_points.size()-1] << '\n';
      } else if (!systematic){
        // we need to randomly subsample the original samples
        // move the weights into a dvector and rescale them into probabilities
        dvector weights(sample_weights.size());
        for (int i=0; i<sample_weights.size(); i++){
          weights[i+1] = sample_weights[i];}
        weights /= sum(weights);
        dvector rands(1,subsample_size);
        rands.fill_multinomial(RNG_seed,weights);
        for (int i=1; i<subsample_size; i++){
          subsample_out << sample_points[(int)rands[i]-1] << '\n';
        }
        subsample_out << sample_points[sample_points.size()-1] << '\n';
      }
    }
  }

  else if (task=="quantity_values"){
    do_MCMC = 1;
    // build the estimation section
    Print_requests quiet_print_requests(o,1);
    Estimation_section<double,dvector,dmatrix> estimation(population_csl,estimation_csl,&quiet_print_requests,do_MCMC,0,0,0,RNG_seed);
    // sort out what quantities need to be output and open a file for them
    Quantity_requests quantity_requests(o,estimation);
    Quantity_results quantity_results;
    ofstream quantities_out(quantities_output_file.c_str());
    if (!quantities_out.good()) fatal("Failed to open " + quantities_output_file);
    quantities_out << CASAL_header << "Quantity values :\n";
    cout << "See also " << quantities_output_file << "\n\n";
    // open the parameter input file and check the header
    ifstream *input_file;
    std::string header;
    dvector parameter_values(estimation.free_parameters->get());
    if (parameters_input_file=="")
      fatal("With -v, you must specify a file of parameter values using -i");
    input_file = new ifstream(parameters_input_file.c_str());
    if (!input_file->good()) fatal("Failed to open " + parameters_input_file);
    getline(*input_file,header);
    estimation.free_parameters->check_file_header(header);
    if(input_file_rows<2) fatal("No data was found in the input file " + parameters_input_file);
    int first_sample = 1;
    while (1){
      // read in the input file data, line by line (and check valid number of values)
      if(!(estimation.free_parameters->get_input_file_by_line(input_file, parameters_input_file, parameter_values))) break;
      estimation.free_parameters->set(parameter_values);
      estimation.insert_free_parameters();
      quantity_results.get(quantity_requests,estimation);
      if (first_sample){
        quantities_out << quantity_results.make_header(quantity_requests);
        quantities_out << '\n';
        first_sample = 0;
      }
      quantities_out << quantity_results.make_vector(quantity_requests);
      quantities_out << '\n';
    }
  }

  else if (task == "project"){
    // build the estimation section
    Print_requests quiet_print_requests(o,1);
    Estimation_section<double,dvector,dmatrix> estimation(population_csl,estimation_csl,&quiet_print_requests,do_MCMC,0,0,0,RNG_seed);
    // sort out what quantities need to be output and open a file for them
    Quantity_requests quantity_requests(o,estimation,1); // the 1 indicates projections
    Quantity_results quantity_results;
    ofstream quantities_out(quantities_output_file.c_str());
    if (!quantities_out.good()) fatal("Failed to open " + quantities_output_file);
    quantities_out << CASAL_header << "Quantity values :\n";
    cout << "See also " << quantities_output_file << "\n\n";
    // open the parameter input file and check the header
    ifstream *input_file;
    std::string header;
    dvector parameter_values(estimation.free_parameters->get());
    if (parameters_input_file=="")
      fatal("When projecting with -P, you must specify a file of parameter values using -i");
    input_file = new ifstream(parameters_input_file.c_str());
    if (!input_file->good()) fatal("Failed to open " + parameters_input_file);
    getline(*input_file,header);
    estimation.free_parameters->check_file_header(header);
    if(input_file_rows<2) fatal("No data was found in the input file " + parameters_input_file);
    dvector *running_total;
    int number_of_projections = 0;
    // proceed to do projections
    if (input_file_rows==2){
      // we will do multiple projections from this point estimate
      int n_projections = o.get_int("n_projections",300);
      // read in the input file data, line by line (and check valid number of values)
      if(!(estimation.free_parameters->get_input_file_by_line(input_file, parameters_input_file, parameter_values))) {
        fatal("Failed to read any values from " + parameters_input_file + ". Please check the -i file.");}
      estimation.free_parameters->set(parameter_values);
      estimation.insert_free_parameters();
      int first_projection = 1;
      for (int i=1; i<=n_projections; i++){
        // randomise the YCS and anything else that changes between projections
        estimation.population_section->annual_cycle->randomise(RNG_seed);
        // calculate and print the output quantities for this projection
        quantity_results.get(quantity_requests,estimation);
        if (first_projection){
          quantities_out << quantity_results.make_header(quantity_requests) << '\n';
          running_total = new dvector(quantity_results.n_quantities);
          *running_total = 0;
          first_projection = 0;
        }
        dvector output_quantities(quantity_results.make_vector(quantity_requests));
        quantities_out << output_quantities << '\n';
        (*running_total) += output_quantities;
        number_of_projections++;
      }
    } else if (input_file_rows>2){
      // we will do a single projection for each sample from the posterior
      int first_projection = 1;
      while (1){
        // read in the input file data, line by line (and check valid number of values)
        if(!(estimation.free_parameters->get_input_file_by_line(input_file, parameters_input_file, parameter_values))) break;
        estimation.free_parameters->set(parameter_values);
        estimation.insert_free_parameters();
        // randomise the YCS and anything else that changes between projections
        estimation.population_section->annual_cycle->randomise(RNG_seed);
        // calculate and write to file the output quantities for this projection
        quantity_results.get(quantity_requests,estimation);
        if (first_projection){
          quantities_out << quantity_results.make_header(quantity_requests) << '\n';
          running_total = new dvector(quantity_results.n_quantities);
          *running_total = 0;
          first_projection = 0;
        }
        dvector output_quantities(quantity_results.make_vector(quantity_requests));
        quantities_out << output_quantities << '\n';
        (*running_total) += output_quantities;
        number_of_projections++;
      }
    }
    dvector average(*running_total / number_of_projections);
    cout << "Projected expectations of output quantities:\n";
    cout << quantity_results.make_header(quantity_requests) << '\n';
    cout << average << '\n';
  }

  else if (task == "yield_estimates"){
    // make an unmodified Estimation_section
    Print_requests print_requests(o,suppress_population_printing);
    Estimation_section<double,dvector,dmatrix> estimation(population_csl,estimation_csl,&print_requests,0,0,0,0,RNG_seed);
    // make a whole bunch of other Estimation_sections for simulation and projection
    // do this at the start, so that if the datafiles change while the program is running,
    // it has no effect (i.e. the original versions of the datafiles are used)
    Estimation_section<double,dvector,dmatrix> *deterministic_simulate, *MCY_CAY_project, *MCY_CAY_simulate, *CSP_project;
    int do_deterministic_sims = o.get_bool("per_recruit.do_YPR_SPR",0)
      || o.get_bool("per_recruit.do_F0_1",0)
      || o.get_bool("per_recruit.do_Fmax",0)
      || o.get_bool("per_recruit.do_Fx",0)
      || o.get_bool("deterministic_MSY.do_MSY",0)
      || o.get_bool("deterministic_MSY.do_yield_vs_SSB",0);
    int do_MCY_CAY = o.get_bool("MCY_CAY.do_MCY",0) || o.get_bool("MCY_CAY.do_CAY",0) || o.get_bool("MCY_CAY.do_CBMSY",0);
    int do_CSP = o.get_bool("CSP.do_CSP",0);
    int do_yields = 1;
    int is_weightless_model = estimation.p.get_bool("weightless_model",0);
    if (do_deterministic_sims){
      // make a modified Estimation_section for simulation
      simulation_length = 1; // for deterministic sims
      deterministic_simulate = new Estimation_section<double,dvector,dmatrix>(population_csl,estimation_csl,&print_requests,0,0,do_yields,simulation_length,RNG_seed);
    }
    if (do_MCY_CAY){
      // make an unmodified Estimation_section for projection
      MCY_CAY_project = new Estimation_section<double,dvector,dmatrix>(population_csl,estimation_csl,&print_requests,0,0,do_yields,0,RNG_seed);
      // make a modified Estimation_section for simulation
      simulation_length = o.get_int("MCY_CAY.n_discard") + o.get_int("MCY_CAY.n_keep");
      MCY_CAY_simulate = new Estimation_section<double,dvector,dmatrix>(population_csl,estimation_csl,&print_requests,0,0,do_yields,simulation_length,RNG_seed);
    }
    if (do_CSP){
      // make an unmodified Estimation_section for projection in CSP
      CSP_project = new Estimation_section<double,dvector,dmatrix>(population_csl,estimation_csl,&print_requests,0,0,do_yields,0,RNG_seed);
    }
    // get a matrix of parameter values to pass to get_yields()
    dmatrix *parameter_values;
    dvector current_values(estimation.free_parameters->get());
    int n_params = current_values.size();
    if (parameters_input_file!=""){
      // get the values from the parameter input file
      // open it and check the header
      ifstream *input_file;
      input_file = new ifstream(parameters_input_file.c_str());
      if (!input_file->good()) fatal("Failed to open " + parameters_input_file);
      std::string header;
      getline(*input_file,header);
      estimation.free_parameters->check_file_header(header);
      if(input_file_rows<2) fatal("No data was found in the input file " + parameters_input_file);
      parameter_values = new dmatrix(1,input_file_rows-1,1,n_params);
      for (int i=1; i<=(input_file_rows-1); i++){
        if(!(estimation.free_parameters->get_input_file_by_line(input_file, parameters_input_file, current_values))) {
          fatal("Failed to read any values from " + parameters_input_file + ". Please check the -i file.");}
        (*parameter_values)[i] = current_values;
      }
    } else {
      fatal("When calculating yields with -Y, you must specify a file of parameter values using -i");
    }
    // now do the yield calculations
    if (do_deterministic_sims){
      if (parameter_values->rowsize() > 1){
        fatal("Cannot do per_recruit or deterministic MSY calculations when more than 1 parameter set is supplied with -i");}
      per_recruit_and_deterministic_MSY<double,dvector,dmatrix>(*deterministic_simulate,(*parameter_values)[1],o,is_weightless_model);
    }
    if (do_MCY_CAY){
      MCY_CAY<double,dvector,dmatrix>(*MCY_CAY_simulate,*MCY_CAY_project,*parameter_values,o);
    }
    if (do_CSP){
      CSP<double,dvector,dmatrix>(*CSP_project,*parameter_values,o);
    }
  }

  else if (task=="bootstrap"){
    Print_requests quiet_print_requests(o,1);
    // a parameter input file should be provided, open it and check the header
    ifstream *input_file;
    std::string header;
    if (parameters_input_file!=""){
      input_file = new ifstream(parameters_input_file.c_str());
      if (!input_file->good()) fatal("Failed to open " + parameters_input_file);
      getline(*input_file,header);
      if(input_file_rows<2) fatal("No data was found in the input file " + parameters_input_file);
    } else fatal("You need to specify an input parameter file with -i");
    // count the number of lines in the file that contain data
//    int parset_line_counter=0;
//    while(1) {
//     std::string temp_data;
//      getline(*input_file,temp_data);
//      if (!input_file->good()) break;
//      parset_line_counter++;
//    }
    // close the outfile, and reopen at the beginning
//    input_file = new ifstream(parameters_input_file.c_str());
//    getline(*input_file,header);
    int parset = 0;
    while (1){
      // build the estimation section (We rebuild it once per loop 'cos the observations get clobbered in the bootstrapping process and need to be re-read)
      Estimation_section<double,dvector,dmatrix> estimation(population_csl,estimation_csl,&quiet_print_requests,0,0,0,0,RNG_seed);
      if(parset==0) estimation.free_parameters->check_file_header(header);
      dvector parameter_values(estimation.free_parameters->get());
      // read in the input file data, line by line (and check valid number of values)
      if(!(estimation.free_parameters->get_input_file_by_line(input_file, parameters_input_file, parameter_values))) break;
      estimation.free_parameters->set(parameter_values);
      parset++;
      // run the model
      double obj_fn = estimation.get_objective_function();
      // print this set of parameters and the corresponding fits
      cout << "Parameter values :\n";
      estimation.free_parameters->print(0);
      cout << "In a format suitable for -i :\n\n";
      cout << estimation.free_parameters->make_file_header();
      cout << estimation.free_parameters->get() << "\n\n";
      if (quiet_print_requests.fits){
        cout << "Fits : \n\n";
        estimation.observations_dataset->print(cout,1,0,0,0);
      }
      // now here's the bit which does the bootstrapping and dumps it to the output file(s)
      int simset_number_prefix_width;
      int parset_number_prefix_width;
      simset_number_prefix_width = (int) floor(log10((double) bootstraps_per_parset))+1;
      parset_number_prefix_width = (int) floor(log10((double) input_file_rows))+1;
      std::vector <std::string> bootstrap_outfile_names;
      for (int i=1; i<=bootstraps_per_parset; i++){
        std::string bootstrap_outfile = bootstrap_filename_prefix;
        std::ostringstream simset_number_suffix;
        std::ostringstream parset_number_suffix;
        simset_number_suffix << std::setw(simset_number_prefix_width) << std::setfill('0') << i;
        parset_number_suffix << std::setw(parset_number_prefix_width) << std::setfill('0') << parset;
        bootstrap_outfile += ".par" + parset_number_suffix.str();
        if (bootstraps_per_parset > 1){
          bootstrap_outfile += ".sim" + simset_number_suffix.str();
        }
        bootstrap_outfile_names.push_back(bootstrap_outfile);
        ofstream outfile(bootstrap_outfile.c_str());
        outfile << "# Set " << i << '\n';
        outfile << "# Simulated observations from the following free parameter values:\n";
        outfile << "# " << estimation.free_parameters->make_file_header();
        outfile << "# " << estimation.free_parameters->get() << "\n\n";
        estimation.observations_dataset->parametric_bootstrap(RNG_seed);
        estimation.observations_dataset->write_to_file(outfile,estimation.e);
        outfile << "# Done set " << i << '\n';
        outfile.close();
      }
      cout << "Bootstrap filenames:\n" << bootstrap_outfile_names.size() << "\n" ;
      for(int i=0; i<bootstrap_outfile_names.size();++i)
        cout << bootstrap_outfile_names[i] << '\n';
    }
  }
  // Calculate CPU time (unix systems only)
  #ifndef __MINGW32__
    times(&cpu_stop);
    double cpu_time=(static_cast<double>(cpu_stop.tms_utime)+static_cast<double>(cpu_stop.tms_stime))-(static_cast<double>(cpu_start.tms_utime) + static_cast<double>(cpu_start.tms_stime));
    // Turn into seconds
    cpu_time /= static_cast<double>(sysconf(_SC_CLK_TCK));
    // Turn into hours
    cpu_time = cpu_time / 3600.0;
    int P = (int) floor(log10(cpu_time))+4;
    cerr << "Total CPU time: " << std::setprecision(P) << cpu_time << (cpu_time==1?" hour":" hours") << ".\n";
    //cout << "Total CPU time: " << std::setprecision(P) << cpu_time << (cpu_time==1?" hour":" hours") << ".\n";
  #endif
  {
    // Calculate Elasped time)
    double elapsed_time = static_cast<double>(time(NULL)-start_time);
    elapsed_time /= 3600.0;
    int P = (int) floor(log10(elapsed_time))+4;
    cerr << "Total elapsed time: " << std::setprecision(P) << elapsed_time << (elapsed_time==1?" hour":" hours") << ".\n";
    //cout << "Total elapsed time: " << std::setprecision(P) << elapsed_time << (elapsed_time==1?" hour":" hours") << ".\n";
  }
  // And exit nicely
  exit(status);
}

//############################## END OF MODEL.C ##############################
