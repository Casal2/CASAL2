// const char* time_stamp = "$Date: 2012-03-20 12:03:10 +1300 (Tue, 20 Mar 2012) $\n";
// const char* penalties_id = "$Id: penalties.h 4633 2012-03-19 23:03:10Z Dunn $\n";

#if !defined(PENALTIES)
#define PENALTIES

//############################## PENALTIES ##############################
#include <vector>
#include <string>
#include <iostream>
#include "development.h"
#include "parameter_set.h"

// Forward declarations
template<CDVM> class Basic_population_section;
template<CDVM> class Qs;

///////////////////////////////////////////////////////////////////////////
template<CDVM>
class Penalty{
  // Abstract class used to represent some form of penalty. Actual penalties
  //  belong to classes derived from class Penalty. class Penalties contains
  //  a vector of pointers to Penalty.
public:
  virtual int is_catch_limit_penalty(std::string& _fishery_name){ return 0;}
  std::string label;
  virtual void set_request_parameters(Parameter_set<DVM>& p){}
  virtual DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                          Qs<DVM>& qs) = 0;
  virtual void print(ostream& out = cout) = 0;
  Penalty(const std::string& _label);
};

template<CDVM>
class Penalties{
  // There are several different types of penalty. This is a holding object for all the Penalties
  //  used in the model. 'pen' contains pointers to the 'class Penalty' objects.
  // First use set_request_parameters() to get the requests for outputs from the population section,
  //  then call population_section.set_requests(), then after the population section has been run,
  //  use evaluate() to calculate the values of all the penalties, and dump them in 'values'.
  // evaluate() needs to be passed all the objects which could potentially be penalised.
  //  As new penalties are added, you will need to add new objects to this argument list,
  //  and hence to the argument list of Penalty::evaluate and those of all the classes
  //  derived from Penalty.
public:
  std::vector<Penalty<DVM>*> pen;
  std::vector<DOUBLE> values;
  void set_request_parameters(Parameter_set<DVM>& p);
  void evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                Qs<DVM>& qs);
  DOUBLE total();
  void print(int print_values, ostream& out = cout);
  Penalties(Parameter_set<DVM>& e);
  ~Penalties();
};

template<CDVM>
class Ogive_smoothing_penalty : public Penalty<DVM>{
  // Penalty on the sum of squared rth differences for an allvalues or allvalues_bounded ogive.
  // Encourages the ogive to be a degree (r+1) polynomial.
  // For compatibility with ohoki etc., you can choose to only apply the penalty to ogive indices
  //  within specified bounds (so, i.e. in an age-based model, some low and/or high indices
  //  are dropped off before differencing).
  // Places no requests.
public:
  DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                  Qs<DVM>& qs);
  void print(ostream& out = cout);
  Ogive_smoothing_penalty(Parameter_set<DVM>& e, int penalty_no);
private:
  double multiplier;      // multiply the penalty by this constant
  std::string ogive_name; // the name of the ogive parameter to be smoothed
  int r;                  // penalise rth differences
  int lower_bound, upper_bound; // if these are non-negative, they define the range of indices
                          // over which the penalty is calculated.
  int log_scale;              // if the penalty is to be applied in log space
};

template<CDVM>
class Catch_limit_penalty : public Penalty<DVM>{
  // Penalty on the sum of squares of (actual catch - specified catch), optionally on the log scale,
  // for a single fishery.
  // The penalty is set to 0 unless some fishing pressure limit has been exceeded
  //   (which can be for a different fishery).
public:
  int is_catch_limit_penalty(std::string& _fishery_name){_fishery_name = fishery_name; return 1;}
  void set_request_parameters(Parameter_set<DVM>& p);
  DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                  Qs<DVM>& qs);
  void print(ostream& out = cout);
  Catch_limit_penalty(Parameter_set<DVM>& e, int penalty_no);
private:
  int log_scale;            // if nonzero, calculate sum of squares on the log-scale
  double multiplier;        // multiply the penalty by this constant
  std::string fishery_name; // the name of the fishery to be penalised
};

template<CDVM>
class Vector_average_penalty : public Penalty<DVM>{
  // Penalty on the square of (mean(vector)- k), or of (mean(log(vector)) - l),
  // or of (log(mean(vector))-m).
  // Encourages the ogive to average arithmetically to k or geometrically to exp(l).
  // Places no requests.
public:
  DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                  Qs<DVM>& qs);
  void print(ostream& out = cout);
  Vector_average_penalty(Parameter_set<DVM>& e, int penalty_no);
private:
  double multiplier;       // multiply the penalty by this constant
  int lower_bound, upper_bound; // if these are non-negative, they define the range of indices over which the penalty is calculated.
  std::string vector_name; // the name of the vector parameter to be penalised
  std::string parameter_supplied; // "k", "l", or "m"
  double k, l, m;
};

template<CDVM>
class Vector_smoothing_penalty : public Penalty<DVM>{
  // Penalty on the sum of squared rth differences for a vector.
  // Encourages the vector to be a degree (r+1) polynomial.
  // You can choose to only apply the penalty to ogive indices
  //  within specified bounds (so, i.e. in an age-based model, some low and/or high indices
  //  are dropped off before differencing).
  // Places no requests.
public:
  DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                  Qs<DVM>& qs);
  void print(ostream& out = cout);
  Vector_smoothing_penalty(Parameter_set<DVM>& e, int penalty_no);
private:
  double multiplier;                      // multiply the penalty by this constant
  std::string vector_name; // the name of the vector parameters to be penalised
  int r;                  // penalise rth differences
  int lower_bound, upper_bound; // if these are non-negative, they define the range of indices
                          // over which the penalty is calculated.
  int log_scale;              // if the penalty is to be applied in log space
};

template<CDVM>
class Element_difference_penalty : public Penalty<DVM>{
  // Penalty on the square of (vector1[i]-vector2[i]).
  // Encourages the ith elements of the two vectors to be similar.
  // Places no requests.
public:
  DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                  Qs<DVM>& qs);
  void print(ostream& out = cout);
  Element_difference_penalty(Parameter_set<DVM>& e, int penalty_no);
private:
  double multiplier;                      // multiply the penalty by this constant
  std::string vector1_name, vector2_name; // the names of the vector parameters to be penalised
  int i;
};

template<CDVM>
class YCS_difference_penalty : public Penalty<DVM>{
  // Penalty on the square of the difference between the YCS of two stocks in a given year.
  // Encourages the stocks to have the same YCS for that year.
  // If the alternative YCS parameterization is used, the YCS not
  //   the Y's are penalised. (As you would hope)
  // Places a request for YCS.
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                  Qs<DVM>& qs);
  void print(ostream& out = cout);
  YCS_difference_penalty(Parameter_set<DVM>& e, int penalty_no);
private:
  double multiplier;                      // multiply the penalty by this constant
  std::string stock1_name, stock2_name;
  int year;
};

template<CDVM>
class Similar_qs_penalty : public Penalty<DVM>{
  // Penalty on the square of (log(q1) - log(q2)).
  // Encourages the q's to be similar.
  // Places no requests.
public:
  DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                  Qs<DVM>& qs);
  void print(ostream& out = cout);
  Similar_qs_penalty(Parameter_set<DVM>& e, int penalty_no);
private:
  double multiplier;             // multiply the penalty by this constant
  std::string q1_name, q2_name;  // names of the two q's
  std::string q_method;          // 'free' or 'nuisance'
};

template<CDVM>
class Ratio_qs_penalty : public Penalty<DVM>{
  // Penalty on the ratio of q1/q2).
  // Places no requests.
public:
  DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                  Qs<DVM>& qs);
  void print(ostream& out = cout);
  Ratio_qs_penalty(Parameter_set<DVM>& e, int penalty_no);
private:
  double mu;                     // mu for lognormal
  double cv;                     // cv for lognormal
  double sigma;                  // sd for lognormal
  std::string q1_name, q2_name;  // names of the two q's
  std::string q_method;          // 'free' or 'nuisance'
};

template<CDVM>
class Ogive_comparison_penalty : public Penalty<DVM>{
  // Penalty on the sum of squares of max(ogive1 - ogive2, 0).
  // Encourages ogive 1 to be at or below ogive 2.
  // Places no requests.
public:
  DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                  Qs<DVM>& qs);
  void print(ostream& out = cout);
  Ogive_comparison_penalty(Parameter_set<DVM>& e, int penalty_no);
private:
  double multiplier;                    // multiply the penalty by this constant
  std::string ogive_name1, ogive_name2; // the name of the ogive parameters to be compared
  int lower_bound, upper_bound; // if these are non-negative, they define the range of indices
                                // over which the penalty is calculated.
};

template<CDVM>
class Ogive_difference_penalty : public Penalty<DVM>{
  // Penalty on the square of ogive1[i] - ogive2[i].
  // Encourages the two ogives to have similar values for age/size class i.
  // Cannot be used for size-based ogives in an age-based model.
  // Places no requests.
public:
  DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                  Qs<DVM>& qs);
  void print(ostream& out = cout);
  Ogive_difference_penalty(Parameter_set<DVM>& e, int penalty_no);
private:
  double multiplier;                    // multiply the penalty by this constant
  std::string ogive_name1, ogive_name2; // the name of the ogive parameters to be compared
  int class_no;                         // age/size class to penalise
};

template<CDVM>
class Fish_tagged_penalty : public Penalty<DVM>{
  // Penalty on the square of (actual fish tagged - nominal fish tagged).
  // Discourages parameter values which do not leave enough fish to be tagged (in any age or size class).
  // Places a single request - for actual numbers of tagged fish.
public:
  void set_request_parameters(Parameter_set<DVM>& p);
  DOUBLE evaluate(Basic_population_section<DVM>& popn, Parameter_set<DVM>& p,
                  Qs<DVM>& qs);
  void print(ostream& out = cout);
  Fish_tagged_penalty(Parameter_set<DVM>& e, int penalty_no);
private:
  double multiplier;                    // multiply the penalty by this constant
  std::string tagging_episode;          // the tagging episode to be penalised
};

//############################## END OF PENALTIES.h ##############################
#endif
