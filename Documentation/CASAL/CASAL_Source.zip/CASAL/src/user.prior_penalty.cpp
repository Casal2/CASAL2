// const char* time_stamp = "$Date: 2011-04-01 14:43:13 +1300 (Fri, 01 Apr 2011) $\n";
// const char* user_prior_penalty_cpp_id = "$Id: user.prior_penalty.cpp 4010 2011-04-01 01:43:13Z dunn $\n";

#ifndef USER_PRIOR_PENALITY_CPP
#define USER_PRIOR_PENALITY_CPP

//############################## USER PRIOR PENALTY.cpp ##############################
#include "development.h"

////////////////////////////////////////////////////////////////////////////////////////
template<CDVM>
void user_prior_penalty(
        std::vector<std::string>& free_scalar_names,
        std::vector<DOUBLE>& free_scalar_vals,
        std::vector<std::string>& free_vector_names,
        std::vector<VECTOR>& free_vector_vals,
        std::vector<std::string>& free_ogive_names,
        std::vector<VECTOR>& free_ogive_arguments,
        std::vector<std::string>& user_scalar_names,
        std::vector<DOUBLE>& user_scalar_vals,
        std::vector<std::string>& user_vector_names,
        std::vector<VECTOR>& user_vector_vals,
        std::vector<std::string>& objective_component_names,
        std::vector<DOUBLE>& objective_component_vals){

/*
   *** TEMPLATE - BRIAN BULL, 23/5/02 ***

   Use this function to implement new priors, and new penalties on the free parameters.

   This function takes the names and values of the free parameters, and returns
    user-defined objective components (i.e. priors and penalties).

   The inputs to this function are
    (a) the names and values of the free parameters (i.e. those in @estimate blocks in your estimation.csl
        If there are free ogive parameters, only their estimable arguments are supplied - like a1, sL and sR
        for a double-normal ogive - not the actual values of the ogives.
    (b) the names and values of the user-defined parameters calculated by user.parameterisation.C (if any)
   The outputs are the labels and values of the user-defined objective components.

   You need to use the @user_components command in your estimation.csl. The arguments are the labels of the
    user-defined objective function components, i.e. they should be identical to the output parameter
    'objective_component_names' produced by this function.

   You need to use the std::vector and std::string classes
     (these are in the STL, see any good C++ book, e.g. Stroustrup)
   and DOUBLE and VECTOR, which are templates either for double and dvector or for dvariable and dvv
     (apart from double, these are Betadiff classes: see betadiff.h)

   Note that the indices of these VECTORs should always start at 1 (in this particular function)
    but the indices of the std::vectors always start at 0.
    So, the name of the first free vector parameter is free_vector_names[0],
    and its values are free_vector_vals[0][1], free_vector_vals[0][2]...
   The output arguments are passed as vectors of length 0: you need to grow them and fill them in.
*/

/*
   Insert your documentation here!
*/

  DEBUG1("user_prior_penalty");

  // remove the following line
  fatal("You are using the default 'user_prior_penalty.cpp', but have requested a user-supplied prior_penalty. You need to modify the CASAL source and recompile.");

/*
   Insert your code here!
*/

}
//############################## END OF USER PRIOR PENALTY.cpp ##############################
#endif
