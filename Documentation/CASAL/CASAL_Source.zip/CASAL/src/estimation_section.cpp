// const char* time_stamp = "$Date: 2012-12-03 12:07:06 +1300 (Mon, 03 Dec 2012) $\n";
// const char* estimation_section_cpp_id = "$Id: estimation_section.cpp 4840 2012-12-02 23:07:06Z Dunn $\n";

//############################## ESTIMATION SECTION ##############################
#include "yields.h"
#include "estimation_section.h"
#include "priors.h"
#include "penalties.h"
#include "observations.h"
#include "output.h"
#include "likelihoods.h"
#include "parameter_set.h"

#include "user.parameterisation.cpp"
#include "user.likelihood.cpp"
#include "user.prior_penalty.cpp"

////////////////////////////////////////////////////////////////////////
template<CDVM>
DOUBLE Estimation_section<DVM>::get_objective_function(){
  // Return the SS, negative-log-likelihood or negative-log-posterior.
  // In the process, fill in the objective function components in 'components'.
  // The free parameters should already have been set using free_parameters->set(v).
  DEBUG0("get_objective_function");
  int count=0;
  // First, insert the free parameters into the estimation section and population parameter set,
  // and send the population parameter set to the Population_section.
  insert_free_parameters();
  if (print_requests->parameters_every_eval){
    free_parameters->print(1,cout);}
  if (print_requests->parameter_vector_every_eval){
    cout << "parameter vector:\n";
    cout << free_parameters->make_file_header() << free_parameters->get() << "\n\n";
  }
     // This is a testing option - a simple trivariate normal likelihood.
     // If we use it, skip the next three steps.
     if (e.get_bool("trivariate_normal_test",0)){
       trivariate_normal_test();
       count = observations_dataset->objective_components.size();
     } else {

  // Second, run the population model.
  population_section->run_model();
  // Third, extract the results; if q's are nuisance then get q values; get fits
  if (q_method=="nuisance"){
    qs->get_nuisance_qs(*population_section);}
  observations_dataset->calculate_fits(*population_section);
  if (print_requests->fits_every_eval){
    cout << "Fits: \n\n";
    observations_dataset->print(cout,1,print_requests->resids,
                                print_requests->pearson_resids,print_requests->normalised_resids);
  }
  // Fourth, calculate sums of squares or likelihoods
  observations_dataset->get_objective_function();
  for (int i=0; i<observations_dataset->objective_components.size(); i++){
    components[count++] = observations_dataset->objective_components[i];
  }

     }

  // Fifth, calculate priors, if a Bayesian analysis
  if (estimator=="Bayes"){
    free_parameters->get_prior();
    for (int i=0; i<free_parameters->prior_components.size(); i++){
      components[count++] = free_parameters->prior_components[i];}
    if (q_method=="nuisance"){ // priors on q's are stored separately, in the qs object
      std::string q_name;
      for (int i=0; i<qs->q_names.size(); i++){
        q_name = qs->q_names[i];
        components[count++] = qs->q_prior_components[q_name];
      }
    }
  }
  // Sixth, add in penalties
  penalties->evaluate(*population_section,p,*qs);
  for (int i=0; i<penalties->pen.size(); i++){
    components[count++] = penalties->values[i];}
  // Seventh, add in user-defined priors or penalties
  if (user_components.size() > 0){
        std::vector<std::string> free_scalar_names, free_vector_names, free_ogive_names;
        std::vector<std::string> user_scalar_names, user_vector_names, objective_component_names;
        std::vector<DOUBLE> free_scalar_vals, user_scalar_vals, objective_component_vals;
        std::vector<VECTOR> free_vector_vals, user_vector_vals, free_ogive_arguments;
    for (int i=0; i<free_parameters->n_scalars; i++){
      free_scalar_names.push_back(free_parameters->scalar_parameter_names[i]);
          free_scalar_vals.push_back(free_parameters->get_scalar(i));
    }
    for (int i=0; i<free_parameters->n_vectors; i++){
          if (!free_parameters->vector_parameter_is_ogive[i]){
            free_vector_names.push_back(free_parameters->vector_parameter_names[i]);
            free_vector_vals.push_back(free_parameters->get_vector(i));
      } else {
            free_ogive_names.push_back(free_parameters->vector_parameter_names[i]);
            free_ogive_arguments.push_back(free_parameters->get_vector(i));
      }
    }
    if (reparameterisation){
      user_parameterisation<DVM>(free_scalar_names,free_scalar_vals,free_vector_names,free_vector_vals,
                                 user_scalar_names,user_scalar_vals,user_vector_names,user_vector_vals);
        }
    user_prior_penalty<DVM>(free_scalar_names,free_scalar_vals,
                            free_vector_names,free_vector_vals,
                                free_ogive_names,free_ogive_arguments,
                                user_scalar_names,user_scalar_vals,
                                user_vector_names,user_vector_vals,
                                objective_component_names,objective_component_vals);
        for (int i=0; i<user_components.size(); i++){
          if (!in(objective_component_names,user_components[i])){
                fatal("Return values from user_prior_penalty do not match @objective_component_names");}
    components[count++] = objective_component_vals[pos(objective_component_names,user_components[i])];
    }
  }
  // Eighth, sum the objective components.
  DOUBLE result = 0;
  for (int i=0; i<components.size(); i++){
      if (components[i]<1.0e16)
          result += components[i];
    else
      result +=1.0e16;
  }
  if (print_requests->objective_every_eval){
    cout << "Objective function: " << result << '\n';
    cout << "Components:\n";
    print_objective_components(cout);
  }
  return result;
}

template<CDVM>
void Estimation_section<DVM>::insert_free_parameters(){
  // Enter the current values of all the free population parameters into
  //   the population Parameter_set, overwriting previous values of those parameters.
  // If there is a user-supplied parameterisation, generate the old-style parameters
  //   and put them into the population Parameter_set too.
  // Apply them using set_annual_cycle() and set_requests() (the latter necessary in case
  //   selectivities of the observations have changed).
  // For each free parameter for which the 'same' subcommand was supplied,
  //   i.e. other free parameters are constrained to be the same as this parameter,
  //   enter the same values for each of those parameters as well.
  // If any free parameters are q's or b's, insert them into the Qs object.
  // If a scalar free parameter starts with "ageing_error", call ageing_error.set_error_parameters.
  // If any observations have process error, check to see whether it is estimated, and if so,
  //   add it in.
  DEBUG0("Estimation_section::insert_free_parameters");
  int count = 1;
  std::string name,type;
  Ogive<DVM>* op;
  int low,high,base;
  DOUBLE par_value;
  // insert the free scalars
  // don't insert any with 'process_error' in their names, as these are definitely not population parameters
  for (int i=0; i<free_parameters->n_scalars; i++){
    name = free_parameters->scalar_parameter_names[i];
    if (!(in(name,"process_error"))){
      par_value = free_parameters->get_scalar(i);
      p.put_estimable(name,par_value);
      if (free_parameters->scalar_same[i].size()>0){
        for (int j=0; j<free_parameters->scalar_same[i].size(); j++){
          p.put_estimable(free_parameters->scalar_same[i][j],par_value);
        }
      }
    }
  }
  // insert the free vectors and ogive arguments
  VECTOR* par_values = 0;
  for (int i=0; i<free_parameters->n_vectors; i++){
    name = free_parameters->vector_parameter_names[i];
    par_values = new VECTOR(free_parameters->get_vector(i));
    if (!free_parameters->vector_parameter_is_ogive[i]){
      p.put_estimable_vector(name,(*par_values));
      if (free_parameters->vector_same[i].size()>0){
        for (int j=0; j<free_parameters->vector_same[i].size(); j++){
          p.put_estimable_vector(free_parameters->vector_same[i][j],(*par_values));
        }
      }
    } else {
      p.put_ogive(name,*par_values);
      if (free_parameters->vector_same[i].size()>0){
        for (int j=0; j<free_parameters->vector_same[i].size(); j++){
          p.put_ogive(free_parameters->vector_same[i][j],*par_values);
        }
      }
    }
    delete par_values;
  }
  // any user-defined reparameterisations?
  if (reparameterisation){
        std::vector<std::string> new_scalar_names, new_vector_names, old_scalar_names, old_vector_names;
        std::vector<DOUBLE> new_scalar_vals, old_scalar_vals;
        std::vector<VECTOR> new_vector_vals, old_vector_vals;
    for (int i=0; i<free_parameters->n_scalars; i++){
          new_scalar_names.push_back(free_parameters->scalar_parameter_names[i]);
          new_scalar_vals.push_back(free_parameters->get_scalar(i));
    }
    for (int i=0; i<free_parameters->n_vectors; i++){
          new_vector_names.push_back(free_parameters->vector_parameter_names[i]);
          new_vector_vals.push_back(free_parameters->get_vector(i));
    }
    user_parameterisation<DVM>(new_scalar_names,new_scalar_vals,new_vector_names,new_vector_vals,
                               old_scalar_names,old_scalar_vals,old_vector_names,old_vector_vals);
    for (int i=0; i<old_scalar_vals.size(); i++){
          p.put_estimable(old_scalar_names[i],old_scalar_vals[i]);
        }
    for (int i=0; i<old_vector_vals.size(); i++){
          p.put_estimable_vector(old_vector_names[i],old_vector_vals[i]);
        }
  }
  // apply the free population parameters to the Population_section
  population_section->set_annual_cycle(p);
  population_section->set_requests(p);
  if (do_yields){
    // stop here - the remaining Estimation_section objects don't exist
    return;
  } else if (!do_yields){
    // Still need to fill in the q's and b's in the Qs object, if they are free
    // Assume here that a 'same' subcommand would never link a q or b with anything other than another q or b.
    for (int i=0; i<qs->q_names.size(); i++){
      std::string this_q = qs->q_names[i];
      if (q_method=="free"){
        if (in(free_parameters->scalar_parameter_names,"q["+this_q+"].q")){
          int j = pos(free_parameters->scalar_parameter_names,"q["+this_q+"].q");
          DOUBLE qval = free_parameters->get_scalar(j);
          qs->q[this_q] = qval;
          if (free_parameters->scalar_same[j].size()>0){
            for (int k=0; k<free_parameters->scalar_same[j].size(); k++){
              std::string same_q = free_parameters->scalar_same[j][k];
              std::string command, subcommand, label;
              decompose(same_q, command, label, subcommand);
              if (command=="q" && subcommand=="q"){
                qs->q[label] = qval;
              } else {
                fatal("You have used the 'same' subcommand with a free q, but not given an argument which is another valid q parameter q[label].q.");
              }
            }
          }
        }
      }
      if (in(free_parameters->scalar_parameter_names,"q["+this_q+"].b")){
        int j = pos(free_parameters->scalar_parameter_names,"q["+this_q+"].b");
        DOUBLE bval = free_parameters->get_scalar(j);
        qs->b[this_q] = free_parameters->get_scalar(j);
        if (free_parameters->scalar_same[j].size()>0){
          for (int k=0; k<free_parameters->scalar_same[j].size(); k++){
            std::string same_b = free_parameters->scalar_same[j][k];
            std::string command, subcommand, label;
            decompose(same_b, command, label, subcommand);
            if (command=="q" && subcommand=="b"){
                          qs->b[label] = bval;
                        } else {
                          fatal("You have used the 'same' subcommand with a curvature parameter b, but not given an argument which is another valid curvature parameter q[label].b.");
                        }
          }
        }
      }
    }
    // if any ageing error parameters are free, recalculate the ageing error misclassification matrix
    // Assume here that a 'same' subcommand would never link an ageing error parameter to any other parameter.
    if (ageing_error != 0){
      if (in(free_parameters->scalar_parameter_names,std::string("ageing_error.p1")) ||
          in(free_parameters->scalar_parameter_names,std::string("ageing_error.p2")) ||
          in(free_parameters->scalar_parameter_names,std::string("ageing_error.c"))){
        // some ageing error parameters are free
        if (ageing_error->type=="off_by_one"){
          DOUBLE p1, p2;
          if (in(free_parameters->scalar_parameter_names,std::string("ageing_error.p1"))){
            int i = pos(free_parameters->scalar_parameter_names,std::string("ageing_error.p1"));
            p1 = free_parameters->get_scalar(pos(free_parameters->scalar_parameter_names,std::string("ageing_error.p1")));
          } else p1 = e.get_constant("ageing_error.p1");
          if (in(free_parameters->scalar_parameter_names,std::string("ageing_error.p2"))){
            int i = pos(free_parameters->scalar_parameter_names,std::string("ageing_error.p2"));
            p2 = free_parameters->get_scalar(pos(free_parameters->scalar_parameter_names,std::string("ageing_error.p2")));
          } else p2 = e.get_constant("ageing_error.p2");
          ageing_error->set_off_by_one(p1,p2);
        } else if (ageing_error->type=="normal"){
          DOUBLE cv = free_parameters->get_scalar(pos(free_parameters->scalar_parameter_names,std::string("ageing_error.c")));
          ageing_error->set_normal(cv);
        } else {
          fatal("Some ageing error parameters are being estimated, yet the ageing error type is not normal or off_by_one as it should be.");
        }
      }
    }
    // if any time series has estimated process error, supply the new process errors to the Objective
    // Assume here that a 'same' subcommand would never link a process error parameter to anything but another process error of the same type.
    for (int i=0; i<observations_dataset->obs.size(); i++){
     if (observations_dataset->obs[i]->objective != 0){
      if (observations_dataset->obs[i]->objective->has_process_error){
        if (in(free_parameters->scalar_parameter_names,
               observations_dataset->obs[i]->objective->process_error_parname)){
          int j = pos(free_parameters->scalar_parameter_names,
                      observations_dataset->obs[i]->objective->process_error_parname);
          DOUBLE process_error = free_parameters->get_scalar(j);
          observations_dataset->obs[i]->objective->set_process_error(process_error);
          if (free_parameters->scalar_same[j].size()>0){
            for (int k=0; k<free_parameters->scalar_same[j].size(); k++){
              std::string same_process_error = free_parameters->scalar_same[j][k];
              std::string command, subcommand, label;
              decompose(same_process_error, command, label, subcommand);
                      // we need to set the process error of the time series with 'label' to 'process_error'
                      // if no such label, error out
                      int ok=0;
              for (int l=0; l<observations_dataset->obs.size(); l++){
                if (observations_dataset->obs[l]->label == label){
                  observations_dataset->obs[l]->objective->set_process_error(process_error);
                  ok=1;
                            }
                      }
                      if (!ok) fatal("The free process error parameter " + observations_dataset->obs[i]->objective->process_error_parname + " has an unclear 'same' subcommand");
            }
          }
        }
      }
     }
    }
    // Adding any new estimable estimation parameters? Insert them here...
  }
}

template<CDVM>
double Estimation_section<DVM>::point_estimate(int& status, int multiphase, int finite_differences){
  // Estimates the parameters so as to minimise the objective function, using Betadiff,
  //   and leaves the results in the 'free_parameters' and 'components' objects.
  //   Returns the optimal function value.
  // 'optimise' wants to be passed a function object which acts on the model and
  //   parameter values, so I've created a class 'Minimiser_interface' for this purpose.
  // If estimation is multi-phase, we need to loop through the minimiser multiple times,
  //   freeing up more parameters each time.
  // The function is complicated by the option of using finite difference gradients in the
  //  minimiser, which requires a different
  //  optimise() call.
  // Now passes back the return value of the last phase of the minimiser thru the 'status' argument...
  DEBUG0("point_estimate");
  // Get starting values
  dvector parameter_values(value(free_parameters->get()));
  int n_params = parameter_values.size();
  dvector lower_bounds(n_params);
  dvector upper_bounds(n_params);
  int max_iters = e.get_int("max_iters",300);
  int max_evals = e.get_int("max_evals",1000);
  int max_iters_intermediate = e.get_int("max_iters_intermediate",max_iters);
  int max_evals_intermediate = e.get_int("max_evals_intermediate",max_evals);
  int iters, evals;
  double obj_value;
  dmatrix *hessian;
  if (do_covariance){
    hessian = new dmatrix(1,n_params,1,n_params);
    if (covariance != 0) delete covariance;
    covariance = new dmatrix(1,n_params,1,n_params);
  } else {
    hessian = 0;
  }
  Minimiser_interface<DVM> objective;
  if (multiphase){
    // fix any parameters not estimated in the 1st phase
    for (int i=0; i<free_parameters->n_scalars; i++){
      if (free_parameters->scalar_phases[i]>1){
        free_parameters->fix_scalar(i);}
    }
    for (int i=0; i<free_parameters->n_vectors; i++){
      if (free_parameters->vector_phases[i]>1){
        free_parameters->fix_vector(i);}
    }
  }
  int n_phases;
  if (multiphase){
    n_phases = phases;
  } else {
    n_phases = 1;
  }
  // loop over phases of the minimisation (there may be only 1)
  for (int phase=1; phase<=n_phases; phase++){
    if (phase==n_phases){
      iters = max_iters;
      evals = max_evals;
    } else {
      iters = max_iters_intermediate;
      evals = max_evals_intermediate;
    }
    if (phase > 1){
      // free parameters estimated in this phase
      for (int i=0; i<free_parameters->n_scalars; i++){
        if (free_parameters->scalar_phases[i]==phase){
          free_parameters->free_scalar(i);}
      }
      for (int i=0; i<free_parameters->n_vectors; i++){
        if (free_parameters->vector_phases[i]==phase){
          free_parameters->free_vector(i);}
      }
    }
    lower_bounds = free_parameters->get_lower_bounds();
    upper_bounds = free_parameters->get_upper_bounds();
    // do the minimisation
    if (!finite_differences){
      obj_value = optimise<Estimation_section<DVM>,Minimiser_interface<DVM> >
        (*this, objective,
         parameter_values,
         lower_bounds, upper_bounds,
         status,
         0,
         iters, evals,
         grad_tol, 0,
         hessian, 0, 1);
    } else if (finite_differences){
      obj_value = optimise_finite_differences<Estimation_section<DVM>,Minimiser_interface<DVM> >
        (*this, objective,
         parameter_values,
         lower_bounds, upper_bounds,
         status,
         0,
         iters, evals,
         grad_tol, 0,
         hessian, 1, 1e-7);
    }
    free_parameters->set(parameter_values);
    cout << ((n_phases>1) ? ("In phase " + itos(phase) + " ") : "");
    if (status > 0){
      cout << "Minimiser achieved convergence after " << iters << " quasi-Newton iterations using " << evals << " objective function evaluations\n\n";
    } else if (status == 0){
      cout << "Minimiser failed to achieve convergence after " << iters << " quasi-Newton iterations using " << evals << " objective function evaluations. Consider allowing more steps.\n\n";
    } else if (status < 0){
      cout << "Minimiser convergence is unclear after " << iters << " quasi-Newton iterations using " << evals << " objective function evaluations. Treat this provisionally as a convergence failure: try restarting from the minimiser from the point at which it stopped.\n\n";
    }
  }
  if (q_method=="nuisance"){
          qs->print_bounds_check(cout);}
  free_parameters->print_bounds_check(cout);

  if (do_covariance){
    (*covariance) = inverse(*hessian);
    if(print_requests->printHessian) {
      cout << "Hessian of parameters at point estimate:\n";
      cout << (*hessian) << "\n\n";
    }
    cout << "Approximate Covariance matrix (Inverse Hessian of parameters at point estimate):\n";
    cout << (*covariance) << "\n\n";
    cout << "Correlation matrix:\n";
    cout << covariance_to_correlation(*covariance) << "\n\n";
    cout << "List of parameter names, in the same order as the rows & cols of the covariance/correlation matrices:\n";
    cout << free_parameters->make_file_header() << '\n';
  }
  if (print_requests->eigenvalues){
    cout << "Sorted list of eigenvalues of the Hessian matrix (after removing null rows and columns): " << endl;
    cout << sorted_eigenvalues(*hessian);
  }
  if(do_covariance || print_requests->eigenvalues){
    cout << "\n\n";
    delete hessian;
  }

  return obj_value;
}

template<CDVM>
void Estimation_section<DVM>::profile(string parameters_output_file, const VECTOR& minimum){
  // Calculates likelihood or posterior profiles as requested.
  // First do a point estimate: store the parameter values in a vector.
  // Then for each parameter to be profiled,
  //  -fix at a sequence of values,
  //  -at each, do a point estimate, starting from the end point of the previous point estimate.
  // There are n values of each parameter between l and u,
  //  but we reorder them: we start with the greatest value under the point estimate (if any),
  //  then go down to the lower bound, then change all the other parameters back to their
  //  values at the point estimate, then the lowest value above the point estimate (if any),
  //  then up to the upper bound.
  // The objective of doing it this way, is to start each minimisation at the end point of a
  //  successful nearby minimisation.
  // We also append the point estimate to the results, so we actually have (n+1) values
  //   in the profile.
  DEBUG0("profile");
  if(e.get_command_count("profile")<1)
    fatal("You have requested a profile, but there are no '@profile' commands in your estimation.csl file");
  DOUBLE point_estimate_objective;
  VECTOR point_estimate_values(1,free_parameters->get().size());
  if (minimum.size()==1 && minimum[1]==-1){ // was not supplied
    // do an initial point estimate
    cout << "Doing an unconstrained point estimate\n";
    int junk_status;
    point_estimate_objective = point_estimate(junk_status);
  } else {
    free_parameters->set(minimum);
    point_estimate_objective = get_objective_function();
  }
  point_estimate_values = free_parameters->get();
  VECTOR current_values(point_estimate_values);
  double l, u; int n;
  int parameter_no, element_no=0, position_count=0;
  double lower_bound, upper_bound;
  std::string name;
  std::string command;
  DOUBLE point_estimate_val;
  std::vector<double> sequence;
  std::vector<double> profile;
  std::vector<VECTOR> parameter_estimates;
  std::vector<std::string> estimables;
  estimables.push_back("estimable");
  estimables.push_back("estimable_vector");
  estimables.push_back("ogive");
  // loop over parameters to be profiled
  for (int i=1; i<=e.get_command_count("profile"); i++){
    // get the profile parameters from the parameter set
    command = "profile[" + itos(i) + "].";
    name = e.get_string(command+"parameter");
    check_parname(name, p, e, "profile block number " + itos(i), estimables);
    std::string profile_type;
    if(in(free_parameters->scalar_parameter_names,name)){
      profile_type="scalar";
      parameter_no = pos(free_parameters->scalar_parameter_names,name);
      position_count = parameter_no+1;
      lower_bound = free_parameters->scalar_priors[parameter_no]->lower_bound;
      upper_bound = free_parameters->scalar_priors[parameter_no]->upper_bound;
    } else if(in(free_parameters->vector_parameter_names,name)) {
      profile_type="vector";
      parameter_no = pos(free_parameters->vector_parameter_names,name);
      element_no = e.get_int(command+"element");
      if(element_no<=0) fatal("The value of the profile subcommand" + command + "element must be a value greater than zero.");
      if(element_no > free_parameters->vector_parameter_sizes[parameter_no])
        fatal("The value of the profile subcommand " + command + "element is greater than the length of the specified parameter vector, " + name);
      lower_bound = free_parameters->vector_priors[parameter_no]->lower_bounds[element_no];
      upper_bound = free_parameters->vector_priors[parameter_no]->upper_bounds[element_no];
      position_count=free_parameters->n_scalars;
      for (int k=0; k<parameter_no; k++){
        position_count += free_parameters->vector_parameter_sizes[k];
      }
      position_count += element_no;

    } else fatal("You have asked to profile parameter " + name + ", but you can only profile a parameter that you are estimating (ie. it must be in an @estimate block in your estimation parameter file).");
    n = e.get_int(command+"n",10);
    l = e.get_constant(command+"l",lower_bound + ((upper_bound-lower_bound)/(2*n)));
    u = e.get_constant(command+"u",upper_bound - ((upper_bound-lower_bound)/(2*n)));
    // set up the sequence of values over which to do the profile
    sequence = std::vector<double>();
    point_estimate_val = point_estimate_values[position_count]; // +1 because this VECTOR starts at 1
    double val;
    int less_than_point = 0; // number of values in the profile which are less than the point estimate
    for (int j=n; j>=1; j--){
      val = l+(j-1)*(u-l)/(n-1);
      if (val < point_estimate_val){
        sequence.push_back(val);
        less_than_point++;}
    }
    for (int j=1; j<=n; j++){
      val = l+(j-1)*(u-l)/(n-1);
      if (val >= point_estimate_val){
        sequence.push_back(val);}
    }
    // go ahead and compute the profile
    profile = std::vector<double>();
    parameter_estimates = std::vector<VECTOR>();
    for (int j=0; j<less_than_point; j++){
      if(profile_type=="scalar") {
        current_values[position_count] = sequence[j]; // +1 because this VECTOR starts at 1
        free_parameters->set(current_values);
        free_parameters->fix_scalar(parameter_no);
        cout << "Doing a point estimate fixing the scalar parameter " << name << " at " << sequence[j] << "\n";
      } else if(profile_type=="vector") {
        current_values[position_count] = sequence[j]; // +1 because this VECTOR starts at 1
        free_parameters->set(current_values);
        free_parameters->fix_vector(parameter_no,element_no);
        cout << "Doing a point estimate fixing the vector parameter " << name << "[" << element_no << "]" << " at " << sequence[j] << "\n";
      }
      int junk_status;
      profile.push_back(point_estimate(junk_status,0));  // single-phase estimation
      parameter_estimates.push_back(free_parameters->get());
    }
    current_values = point_estimate_values;
    for (int j=less_than_point; j<n; j++){
      if(profile_type=="scalar") {
        current_values[position_count] = sequence[j]; // +1 because this VECTOR starts at 1
        free_parameters->set(current_values);
        free_parameters->fix_scalar(parameter_no);
        cout << "Doing a point estimate fixing the scalar parameter " << name << " at " << sequence[j] << "\n";
      } else if(profile_type=="vector") {
        current_values[position_count] = sequence[j]; // +1 because this VECTOR starts at 1
        free_parameters->set(current_values);
        free_parameters->fix_vector(parameter_no,element_no);
        cout << "Doing a point estimate fixing the vector parameter " << name << "[" << element_no << "]" << " at " << sequence[j] << "\n";
      }
      int junk_status;
      profile.push_back(point_estimate(junk_status,0));  // single-phase estimation
      parameter_estimates.push_back(free_parameters->get());
    }
    if(profile_type=="scalar") free_parameters->free_scalar(parameter_no);
    else if(profile_type=="vector") free_parameters->free_vector(parameter_no);
    // Output the results, sorted from lowest to highest parameter value.
    //  Insert the point estimate into the profile.
    cout << "Profile of parameter " << name << ":\nValue  Objective\n";
    for (int j=(less_than_point-1); j>=0; j--){
      cout << sequence[j] << " " << profile[j] << '\n';}
    cout << point_estimate_val << " " << point_estimate_objective << '\n';
    for (int j=less_than_point; j<n; j++){
      cout << sequence[j] << " " << profile[j] << '\n';}
    cout << '\n';
    // Output the parameter estimates similarly.
    if(profile_type=="scalar") cout << "Parameter estimates for profile of parameter " << name << ":\n";
    else if(profile_type=="vector") cout << "Parameter estimates for profile of parameter " << name << "[" << element_no << "]:\n";
    cout << free_parameters->make_file_header();
    for (int j=(less_than_point-1); j>=0; j--){
      cout << parameter_estimates[j] << '\n';}
    cout << point_estimate_values << '\n';
    for (int j=less_than_point; j<n; j++){
      cout << parameter_estimates[j] << '\n';}
    cout << '\n';
    // if output_parameter_file defined, then open file stream, print out parameter estimates
    if (parameters_output_file!=""){
      ifstream *parameters_check;
      ofstream *parameters_write;
      parameters_check = new ifstream(parameters_output_file.c_str());
      if (parameters_check->good()) {
        parameters_write = new ofstream(parameters_output_file.c_str(),ios::app);
      }
      for (int j=(less_than_point-1); j>=0; j--){
        (*parameters_write) << parameter_estimates[j] << '\n';}
      (*parameters_write) << point_estimate_values << '\n';
      for (int j=less_than_point; j<n; j++){
        (*parameters_write) << parameter_estimates[j] << '\n';}
      parameters_write->close();
    }
  }
}

template<CDVM>
void Estimation_section<DVM>::run_MCMC(const dvector& posterior_mode,
                                                           const dmatrix& _covariance,
                                                           ostream& samples_out,
                                                           ostream& objectives_out,
                                                           const dvector& _start,
                                                           int starting_sample,
                                                           double starting_stepsize,
                                                           int starting_successful_jumps){
  // Generate the MCMC chain. Posterior samples go to samples_out,
  // sample number, posterior, prior, likelihood, combined penalties and stepsize go to objectives_out.
  // See mcmc_settings for the various MCMC details, except for the starting point
  //  and covariance matrix which are provided as arguments.
  // If no starting point _start is specified, it starts at the posterior mode or at a random point,
  //  as specified by the parameters.
  // starting_sample, starting_stepsize, starting_successful_jumps
  //  are used only when appending to an existing chain.
  //  they are simply the last recorded in the existing file.
  DEBUG0("Estimation_section::run_MCMC");
  if (estimator != "Bayes"){
        fatal("You can only run a MCMC chain in a Bayesian analysis");}
  int n_params = posterior_mode.size();
  int n_free_params = n_params;
  dmatrix covariance(_covariance);
  dvector start(1,n_params);
  if (_start.size()!=1 || _start[1]!=-1){
    // starting values provided
    start = _start;
  } else {
    if (mcmc_settings->start == 0){
      // start at the point estimate
      start = posterior_mode;
    } else {
      // start at a randomly generated location near the point estimate
      start.fill_mvnorm(RNG_seed, posterior_mode, covariance * mcmc_settings->start);
      int tries=0;
      while (!free_parameters->within_bounds(start)){
        tries++;
        if (tries==1000) fatal("can't find a point within the free parameter bounds");
        // try again until we get a point within the bounds
        cerr << "trying to find a point within the free parameter bounds\n";
        start.fill_mvnorm(RNG_seed, posterior_mode, covariance * mcmc_settings->start);
        cerr << "latest guess:\n";
        cerr << start << '\n';
        cerr << " bounds:\n";
        cerr << free_parameters->get_lower_bounds() << '\n';
        cerr << free_parameters->get_upper_bounds() << '\n';
        cerr << '\n';
      }
    }
  }
  // Identify parameters which are fixed during the MCMC. Set them to their
  // values at the posterior mode, unless starting values were provided,
  // in which case set them to their starting values. They will be fixed
  // at these values by setting their variances and all their covariances to 0
  // (in tweak_covariance_matrix)
  dvector zeros(1,n_params);
  zeros = 0;
  dvector values_to_fix_at(1,n_params);
  if (_start.size()!=1 || _start[1]!=-1){
    values_to_fix_at = start;
  } else {
    values_to_fix_at = posterior_mode;
  }
  int count = 1;
  for (int i=0; i<free_parameters->n_scalars; i++){
    if (free_parameters->scalar_MCMC_fixed[i]){
      // this scalar parameter should be fixed during MCMC
      start[count] = values_to_fix_at[count];
      n_free_params--;
    }
    count++;
  }
  for (int i=0; i<free_parameters->n_vectors; i++){
    if (free_parameters->vector_MCMC_fixed[i]){
      // this vector parameter should be fixed during MCMC
      for (int j=1; j<=free_parameters->vector_parameter_sizes[i]; j++){
        start[count+j-1] = values_to_fix_at[count+j-1];
        n_free_params--;
      }
    }
    count+=free_parameters->vector_parameter_sizes[i];
  }
  cout << "Bounds on free parameters:\n";
  cout << free_parameters->get_lower_bounds() << '\n';
  cout << free_parameters->get_upper_bounds() << '\n';
  cout << '\n';
  // Alter the covariance matrix
  // Reduce correlations greater in magnitude than 0.8 to 0.8
  // Increase very small nonzero variances
  // Set entries corresponding to fixed parameters to 0
  tweak_covariance_matrix(covariance);
  cout << "Covariance matrix to be used in proposal distribution:\n" << covariance << '\n';
  // define variables used in the main loop
  dvector parameter_values(start);
  dvector candidate_values(start);
  int n_rands = 1000;
  dmatrix all_candidates(1,n_params,0,n_rands-1);
  dvector checks(0,n_rands-1);
  double stepsize;
  DOUBLE old_posterior, posterior, prior, likelihood, combined_penalties; // all on negative-log scale
  DOUBLE r;
  double acceptance_rate;
  int successful_jumps_at_last_adapt = 0, last_adapt = 0;
  int covariance_adaptations = 0;
  // set the stepsize
  if (starting_stepsize > 0){
    stepsize = starting_stepsize;
  } else {
    stepsize = mcmc_settings->stepsize;
    if (stepsize == 0){ // use the default
      stepsize = 2.4 / sqrt((double)n_free_params);}
  }
  // if we are appending to an existing chain, generate a new set of random numbers
  // otherwise this is done in the main loop below, every n_rands iterations
  if (starting_sample > 0){
    if (mcmc_settings->proposal_t){
      all_candidates.fill_mvt(RNG_seed,zeros,covariance*stepsize,mcmc_settings->df);
    } else {
      all_candidates.fill_mvnorm(RNG_seed,zeros,covariance*stepsize);
    }
    checks.fill_randu(RNG_seed);
  }
  // prepare a data object to hold a sample from the chain used for adaptive covariance
  dmatrix *chain_sample;
  int points_in_chain_sample=0;
  int transitions_in_chain_sample=0;
  int jump=0;
  if (mcmc_settings->adaptive_covariance){
          chain_sample = new dmatrix(1,(int)max(*(mcmc_settings->adapt_covariance_at)-mcmc_settings->adaptive_covariance_discard),1,n_params);
  } else {
          chain_sample=0;
  }
  // get the posterior, prior, likelihood and penalties at the initial point
  cout << "MCMC starting point:\n\n";
  cout << free_parameters->make_file_header() << parameter_values << "\n\n";
  cout.flush();
  free_parameters->set(parameter_values);
  posterior = get_objective_function();
  prior = free_parameters->get_prior();
  combined_penalties = penalties->total();
  likelihood = posterior - prior - combined_penalties;
  // now enter the main loop for the chain
  int successful_jumps = starting_successful_jumps;
  int sample = starting_sample;
  while (sample < mcmc_settings->length){
    sample++;
    if (mcmc_settings->adaptive_covariance){
      // does the covariance matrix need adjusting?
      if (in(*(mcmc_settings->adapt_covariance_at),sample)){
        // It does. Check that there have been enough transitions so far
        if (transitions_in_chain_sample < mcmc_settings->adaptive_covariance_transitions){
                        fatal("We have reached the first adaptive covariance point. There have only been " + itos(transitions_in_chain_sample) + " successful transitions so far. This is an error as you stated that at least " + itos(mcmc_settings->adaptive_covariance_transitions) + " are required. Try decreasing the stepsize or using a different starting point.");
                }
                // Take a subsample of the chain, on which to base the covariance matrix.
                dmatrix chain_subsample(1,1000,1,n_params);
                if (points_in_chain_sample < 1000){
                        fatal("The first adaptive covariance point is too early, there are less than 1000 points in the subsample of the chain. Make it later.");
                } else {
                        double spacing = points_in_chain_sample / 1000;
                        for (int i=1; i<=1000; i++){
                                int number_to_use = (int)ceil(i * spacing);
                                chain_subsample[i] = (*chain_sample)[number_to_use];
                        }
                }
                // Estimate the covariance matrix.
                covariance = sample_covariance(chain_subsample);
        // Reduce correlations greater in magnitude than 0.8 to 0.8
        // Increase very small nonzero variances
        // Set entries corresponding to fixed parameters to 0
                tweak_covariance_matrix(covariance);
                cout << "Covariance matrix has been altered at iteration " << sample << " to\n" << covariance << '\n';
                covariance_adaptations++;
        // the stepsize also needs adjusting
                stepsize = mcmc_settings->adaptive_covariance_stepsize;
        if (stepsize == 0){ // use the default
          stepsize = 2.4 / sqrt((double)n_free_params);}
        successful_jumps_at_last_adapt = successful_jumps;
        last_adapt = sample;
        cout << "New stepsize is " << stepsize << '\n';
      }
        } else if (mcmc_settings->adaptive_stepsize){
      // does the stepsize need adjusting?
      if (in(*(mcmc_settings->adapt_at),sample)){
        acceptance_rate = ((double)(successful_jumps - successful_jumps_at_last_adapt))
                          / (sample - last_adapt);
        if (acceptance_rate > 0.5){
          cout << "Acceptance rate since last adjustment is " << acceptance_rate;
          cout << " : doubling stepsize\n\n";
          stepsize *= 2;
        } else if (acceptance_rate < 0.2){
          cout << "Acceptance rate since last adjustment is " << acceptance_rate;
          cout << " : halving stepsize\n\n";
          stepsize /= 2;
        }
        successful_jumps_at_last_adapt = successful_jumps;
        last_adapt = sample;
      }
    }
    // get a batch of random numbers every 'n_candidates' iterations
    if (sample % n_rands == 1){
      if (mcmc_settings->proposal_t){
        all_candidates.fill_mvt(RNG_seed,zeros,covariance*stepsize,mcmc_settings->df);
      } else {
        all_candidates.fill_mvnorm(RNG_seed,zeros,covariance*stepsize);
      }
      checks.fill_randu(RNG_seed);
    }
    // get the candidate point, test it, potentially jump
    candidate_values = parameter_values + extract_column(all_candidates, sample % n_rands);
    // reject it unless it is within the bounds
    if (free_parameters->within_bounds(candidate_values)){
      free_parameters->set(candidate_values);
      old_posterior = posterior;
      posterior = get_objective_function();
      if (posterior < old_posterior){
        r = 1;
      } else {
        r = exp(old_posterior - posterior);
      }
      if (checks[sample % n_rands] < r){
        // accept the candidate point
        parameter_values = candidate_values;
        successful_jumps++;
        prior = free_parameters->get_prior();
        combined_penalties = penalties->total();
        likelihood = posterior - prior - combined_penalties;
        jump = 1;
      } else {
        // reject the candidate point
        posterior = old_posterior;
        jump = 0;
        int inspect_oob_candidates=0;
        if (inspect_oob_candidates){
          cerr << "latest candidate:\n";
          cerr << candidate_values << '\n';
          cerr << " bounds:\n";
          cerr << free_parameters->get_lower_bounds() << '\n';
          cerr << free_parameters->get_upper_bounds() << '\n';
          cerr << '\n';
        }
      }
    }
    if (mcmc_settings->adaptive_covariance){
          // we may need to record this point for use later
          if (max(*(mcmc_settings->adapt_covariance_at)) > sample){
                if (sample > mcmc_settings->adaptive_covariance_discard){
             // yep, we do
             points_in_chain_sample++;
             transitions_in_chain_sample += jump;
             (*chain_sample)[points_in_chain_sample] = parameter_values;
                } else if (sample == mcmc_settings->adaptive_covariance_discard){
                   // error out if the chain has not moved yet
                   if (successful_jumps == 0){
                           fatal("The chain has reached the end of the adaptive-covariance discard period. We require that the chain moves at least once in this period but it has not. This is a fatal error. Try starting from a different point or decreasing the initial stepsize.\n");
                   }
                }
      }
        }
    if (sample % mcmc_settings->keep == 0){
      // output this point
      samples_out << parameter_values << '\n';
      samples_out.flush();
      acceptance_rate = ((double) successful_jumps) / sample;
      objectives_out << sample << ' ' << posterior << ' ' << prior << ' ' << likelihood << ' ' << combined_penalties << ' ' << stepsize << ' ' << acceptance_rate << ' ' << covariance_adaptations << '\n';
      objectives_out.flush();
    }
  }
  if (chain_sample!=0) delete chain_sample;
  // chain complete!
}

template<CDVM>
void Estimation_section<DVM>::tweak_covariance_matrix(dmatrix& covariance){
  // Reduce correlations greater in magnitude than 0.8 to 0.8
  // Increase very small nonzero variances
  // Set entries corresponding to fixed parameters to 0
  // Note this operates on the upper triangular part of the matrix, and then
  // is applied to the lower triangle at the end of the function
  DEBUG2("Estimation_section::tweak_covariance_matrix");
  // Adjust any correlations of magnitude greater than max_cor down to max_cor.
  double max_cor = mcmc_settings->max_cor;
  std::string covariance_adjustment_method = mcmc_settings->covariance_adjustment_method;
  double min_diff = mcmc_settings->min_diff;
  int n_params = covariance.colsize();
  dvector zeros(1,n_params);
  zeros = 0;
  for (int i=1; i<n_params; i++){
    for (int j=i+1; j<=n_params; j++){
      if (covariance[i][j] / sqrt(covariance[i][i] * covariance[j][j]) > max_cor){
        covariance[i][j] = max_cor * sqrt(covariance[i][i] * covariance[j][j]);
      }
      if (covariance[i][j] / sqrt(covariance[i][i] * covariance[j][j]) < -max_cor){
        covariance[i][j] = -max_cor * sqrt(covariance[i][i] * covariance[j][j]);
      }
    }
  }
  // Adjust any nonzero variances less than min_diff x the difference between the bounds on the parameter.
  dvector difference_between_bounds(free_parameters->get_upper_bounds() - free_parameters->get_lower_bounds());
  for (int i=1; i<=n_params; i++){
    if (covariance[i][i] < min_diff*difference_between_bounds[i] && covariance[i][i]!=0){
      if(covariance_adjustment_method=="covariance") {
        double multiply_covariance = (sqrt(min_diff)*difference_between_bounds[i])/sqrt(covariance[i][i]);
        for (int j=1; j<=n_params; j++) {
          covariance[i][j] = covariance[i][j]* multiply_covariance;
          covariance[j][i] = covariance[j][i]* multiply_covariance;
        }
      } else if(covariance_adjustment_method=="correlation") {
          // covariance[i][i] = 0.0001*difference_between_bounds[i];
          covariance[i][i] = min_diff*difference_between_bounds[i];
      } else fatal("Unknown covariance adjustment method");
    }
  }
  int count = 1;
  for (int i=0; i<free_parameters->n_scalars; i++){
    if (free_parameters->scalar_MCMC_fixed[i]){
      // this scalar parameter should be fixed during MCMC
      covariance[count] = zeros;
      covariance.colfill(count,zeros);
    }
    count++;
  }
  for (int i=0; i<free_parameters->n_vectors; i++){
    if (free_parameters->vector_MCMC_fixed[i]){
      // this vector parameter should be fixed during MCMC
      for (int j=1; j<=free_parameters->vector_parameter_sizes[i]; j++){
        covariance[count+j-1] = zeros;
        covariance.colfill(count+j-1,zeros);
      }
    }
    count+=free_parameters->vector_parameter_sizes[i];
  }
  // now apply upper triangle changes to the lower triangle of the covariance matrix
  // (note: should not be used by CASAL, but will help intrepretation!)
  //for (int i=1; i<n_params; i++){
  //  for (int j=i+1; j<=n_params; j++) {
  //    covariance[j][i] = covariance[i][j];
  // }
  //}
}

template<CDVM>
void Estimation_section<DVM>::trivariate_normal_test(){
  // This is a function used in testing, called by get_objective_function().
  // It replaces the specified likelihood by a simple trivariate normal.
  // This is good for testing things like MCMC 'cos it's easy to see
  // whether the results are right.
  // Use it by inserting the '@trivariate_normal_test 1' command in estimation.csl,
  // putting three parameters '@x', '@y', '@z' in population.csl,
  // and an '@estimate' block for each in estimation.csl.
  // The estimation.csl should contain at least one set of observations: they will
  // not be used but we need a likelihood object to exist to put the trivariate normal
  // likelihood into.
  DEBUG0("trivariate_normal_test");
  VECTOR xyz(1,3);
  xyz[1] = p.get_estimable("x");
  xyz[2] = p.get_estimable("y");
  xyz[3] = p.get_estimable("z");
  dmatrix cov("{1,0.424,0.071}{0.424,2,0.6}{0.071,0.6,0.5}");
  dvector mean("{2,1,3}");
  components[0] = 0.5 * ((xyz-mean) * (inverse(cov) * (xyz-mean)));
  for (int i=1; i<observations_dataset->objective_components.size(); i++){
    components[i] = 0;
  }
}

template<CDVM>
void Estimation_section<DVM>::print_objective_components(ostream& out){
  DEBUG2("Estimation_section::print_objective_components");
  for (int i=0; i<components.size(); i++){
    out << setw(50);
    out << component_names[i].c_str();
    out << " ";
    out << components[i] << '\n';
  }
  out << "\n";
}

template<CDVM>
void Estimation_section<DVM>::print(ostream& out){
  DEBUG2("Estimation_section::print");
  if (!do_yields){
    out << "Objective function: " << estimator << '\n';
    if (do_MCMC) out << "Using MCMC\n";
    if (grad_tol != 2e-3){
      out << "\nMinimiser convergence threshold: " << grad_tol << "\n\n";}
    out << "\nObservations:\n\n";
    observations_dataset->print(out);
    out << "\nAgeing_error:\n";
    ageing_error->print(out);
    out << "Free parameters:\n\n";
    free_parameters->print(1,out);
    out << "Q's:\n";
    qs->print(out);
    out << "Penalties:\n";
    penalties->print(0,out);
    out << "Components of the objective function are:\n";
    for (int i=0; i<component_names.size(); i++){
      out << "  " << component_names[i] << '\n';
    }
    out << '\n';
    if (do_MCMC){
      out << "MCMC settings : \n";
      mcmc_settings->print(out);
    }
  } else if (do_yields){
    out << "Free parameters:\n\n";
    free_parameters->print(1,out);
  }
  if (RNG_seed >= 0){
    out << "Random number seed : " << RNG_seed << "\n\n";
  }
  out << '\n';
}

template<CDVM>
Estimation_section<DVM>::Estimation_section(
                   const std::string& population_file, const std::string& estimation_file,
                   Print_requests *_print_requests,
                   int _do_MCMC, int _do_covariance, int _do_yields, int _simulation_length,
                   long int _RNG_seed){
  // construct the Estimation_section, including the Population_section
  // if _do_MCMC, we will need to do MCMC
  // if _do_covariance, we will need to calculate an approximate covariance matrix
  // if _do_yields, we are doing simulations or projections for yield analysis and can do without
  //   many of the components of the estimation section, so exit the constructor halfway;
  // if _simulation_length > 0, we are working in an abstract simulation period and should
  //   change 'initial', 'current', etc. accordingly,
  DEBUG0("Estimation_section::Estimation_section");
  print_requests = _print_requests;
  // Load the population and estimation parameter sets from files.
  p.read_file(population_file,"P");
  e.read_file(estimation_file,"E");
  estimator = e.get_string("estimator");
//  if (estimator!="Bayes" && estimator!="likelihood" && estimator!="least_squares"){
//    fatal("unknown estimator " + estimator + ", use 'likelihood', 'least_squares' or 'Bayes'");}
  if (estimator!="Bayes" && estimator!="likelihood"){
    fatal("unknown estimator " + estimator + ", use 'likelihood' or 'Bayes'");}
  do_MCMC = _do_MCMC;
  do_covariance = _do_covariance;
  simulation_length = _simulation_length;
  do_yields = _do_yields;
  if (simulation_length != 0){
    // tell the population_section we are covering an abstract simulation period
    p.put_int("simulation",1);
    // Change the range of years to cover a simulation period
    // from 0 (for deterministic simulations) through 1 to simulation_length (for stochastic simulations)

  p.put_int("original_initial",p.get_int("initial"));
  p.put_int("original_current",p.get_int("current"));
  p.put_int("original_final",p.get_int("final"));
  p.put_int("initial",0);
  p.put_int("current",simulation_length);
  p.put_int("final",simulation_length);
  }
  covariance = 0;
  RNG_seed = _RNG_seed;
  q_method = e.get_string("q_method","nuisance");
  // Construct the main objects in the estimation section.
  population_section = new Basic_population_section<DVM>(p,print_requests);
  // There should be at least one @estimate block
  if (e.get_command_count("estimate")==0){
    fatal("You need to provide at least one @estimate command.");}
  free_parameters = new Free_parameters<DVM>(q_method,e,p);
  // 'Very easily addable' material
  reparameterisation = e.get_bool("user_parameterisation",0);
  user_components = e.get_vector_of_strings("user_components",std::vector<std::string>());
  if (!do_yields){
    // The rest of the estimation section is not necessary if we're doing yield calculations
    ageing_error = new Ageing_error<DVM>(e,*population_section);
    observations_dataset = new Observations_dataset<DVM>(*population_section,ageing_error,e);
    observations_dataset->set_request_parameters(p);
    penalties = new Penalties<DVM>(e);
    // warn the user if there is a fishery without a Catch_limit_penalty
    std::vector<std::string> fisheries_with_penalty;
    for (int i=0; i<penalties->pen.size(); i++){
                std::string fishery_name;
                if (penalties->pen[i]->is_catch_limit_penalty(fishery_name)){
                        fisheries_with_penalty.push_back(fishery_name);
                }
        }
        int n_fisheries = population_section->annual_cycle->n_fisheries;
        for (int i=1; i<=n_fisheries; i++){
                if (!in(fisheries_with_penalty,population_section->annual_cycle->fishery_names[i])){
                        cerr << "Warning: you have not put a Catch_limit_penalty for fishery " << population_section->annual_cycle->fishery_names[i] << ". You probably want to add one.\n";
                }
        }
    penalties->set_request_parameters(p);
    population_section->set_requests(p);
    qs = new Qs<DVM>(q_method,*observations_dataset,e);
    if (do_MCMC){
      mcmc_settings = new MCMC_settings<DVM>(e);
    } else {
      mcmc_settings = 0;
    }
    // Identify the names of the components of the objective function
    for (int i=0; i<observations_dataset->obs.size(); i++){
      component_names.push_back(observations_dataset->obs[i]->label);
    }
    if (estimator == "Bayes"){
      for (int i=0; i<free_parameters->n_scalars; i++){
        component_names.push_back("prior_on_" + free_parameters->scalar_parameter_names[i]);
      }
      for (int i=0; i<free_parameters->n_vectors; i++){
        component_names.push_back("prior_on_" + free_parameters->vector_parameter_names[i]);
      }
      if (q_method == "nuisance"){
        // priors on nuisance q's are stored in the q's object
        for (int i=0; i<qs->q_names.size(); i++){
          component_names.push_back("prior_on_q_" + qs->q_names[i]);
        }
      }
    }
    for (int i=0; i<penalties->pen.size(); i++){
      component_names.push_back(penalties->pen[i]->label);
    }
    for (int i=0; i<user_components.size(); i++){
          component_names.push_back(user_components[i]);
        }
    components.resize(component_names.size());
    phases = 1; // how many phases in point estimation?
    int this_phase;
    for (int i=1; i<=e.get_command_count("estimate"); i++){
      this_phase = e.get_int("estimate[" + itos(i) + "].phase",1);
      if (this_phase < 1){
        fatal("Non-positive phase of " + itos(this_phase) + " in multi-phase point estimation.");}
      phases = (int)fmax(phases,this_phase);
    }
    grad_tol = e.get_constant("grad_tol",2e-3);
    if (grad_tol > 2e-3){
                cerr << "You have increased the grad_tol parameter over the default of 2e-3. Optimiser accuracy may be reduced.\n";}
  } else if (do_yields){ // most of the components are unnecessary
    ageing_error = 0;
    observations_dataset = 0;
    penalties = 0;
    mcmc_settings = 0;
    qs = 0;
  }
}

template<CDVM>
Estimation_section<DVM>::~Estimation_section(){
  DEBUG1("~Estimation_section");
  if (free_parameters != 0) delete free_parameters;
  if (population_section != 0) delete population_section;
  if (ageing_error != 0) delete ageing_error;
  if (observations_dataset != 0) delete observations_dataset;
  if (penalties != 0) delete penalties;
  if (qs != 0) delete qs;
  if (mcmc_settings != 0) delete mcmc_settings;
  if (covariance != 0) delete covariance;
}

//############################## Q'S ##############################
template<CDVM>
void Qs<DVM>::get_nuisance_qs(Basic_population_section<DVM>& popn){
  // Set all q's to 1, call calculate_fits() for each relative Observations pointed to in ts_ptrs,
  // use the fits, obs, and objective members to calculate nuisance q's,
  // if they are outside the bounds then change them to the nearest bound,
  // fill them in in the Qs.q object,
  // and in a Bayesian analysis, fill in q_prior_components.
  DEBUG1("Qs::get_nuisance_qs");
  // loop over q's
  for (int i=0; i<q_names.size(); i++){
    std::string q_name = q_names[i];
    std::vector<Observations<DVM>*> q_time_series = ts_ptrs[q_name];
    // set this q to 1 and get E for each time series sharing this q
    q[q_name] = 1;
    for (int j=0; j<q_time_series.size(); j++){
      q_time_series[j]->calculate_fits(popn);}
    // use fits, obs, and objective members of these Observations to calculate the nuisance q
    std::string objective_type = ts_objectives[q_name];
    std::string prior_type = q_priors[q_name]->type;
    Objective<DVM>* obj;
    DOUBLE value;
    if (objective_type == "Normal_likelihood" && (prior_type == "None" || prior_type == "Uniform_prior")){
      DOUBLE s1 = 0, s2 = 0;
      double n = 0;
      for (int j=0; j<q_time_series.size(); j++){
        obj = q_time_series[j]->objective;
        for (int y=1; y<=q_time_series[j]->fits->rowmax(); y++){
                  //if (min((*(q_time_series[j]->fits))[y]) <= 0){
                  //        fatal("A relative observation has nonpositive fits");}
          for (int z=1; z<=q_time_series[j]->fits->colmax(); z++){
        //richard test
            (*(q_time_series[j]->fits))[y][z]=zerofun((*(q_time_series[j]->fits))[y][z],ZERO);
            n++;
            s1 += (*(q_time_series[j]->obs))[y][z] / (obj->get_cvs()[y][z] * obj->get_cvs()[y][z] * (*(q_time_series[j]->fits))[y][z]);
            s2 += pow((*(q_time_series[j]->obs))[y][z] / (obj->get_cvs()[y][z] * (*(q_time_series[j]->fits))[y][z]), 2);
          }
        }
      }
      value = (-s1 + sqrt(s1*s1 + 4*n*s2)) / (2*n);
    } else if ((objective_type == "Lognormal_likelihood" || objective_type == "Robustified_lognormal_likelihood") && (prior_type == "None" || prior_type == "Uniform_prior")){
      DOUBLE s3 = 0, s4 = 0;
      double n = 0;
      for (int j=0; j<q_time_series.size(); j++){
        obj = q_time_series[j]->objective;
        for (int y=1; y<=q_time_series[j]->fits->rowmax(); y++){
                  //if (min((*(q_time_series[j]->fits))[y]) <= 0){
                  //        fatal("A relative observation has nonpositive fits");}
          for (int z=1; z<=q_time_series[j]->fits->colmax(); z++){
        //richard test
            (*(q_time_series[j]->fits))[y][z]=zerofun((*(q_time_series[j]->fits))[y][z],ZERO);
            n++;
            s3 += log((*(q_time_series[j]->obs))[y][z] / (*(q_time_series[j]->fits))[y][z]) / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
            s4 += 1 / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
          }
        }
      }
      value = exp((0.5*n + s3) / s4);
    } else if (objective_type == "Normal_log_likelihood" && (prior_type == "None" || prior_type == "Uniform_prior")){
      DOUBLE s3 = 0, s4 = 0;
      for (int j=0; j<q_time_series.size(); j++){
        obj = q_time_series[j]->objective;
        for (int y=1; y<=q_time_series[j]->fits->rowmax(); y++){
                  //if (min((*(q_time_series[j]->fits))[y]) <= 0){
                  //        fatal("A relative observation has nonpositive fits");}
          for (int z=1; z<=q_time_series[j]->fits->colmax(); z++){
        //richard test
            (*(q_time_series[j]->fits))[y][z]=zerofun((*(q_time_series[j]->fits))[y][z],ZERO);
            s3 += log((*(q_time_series[j]->obs))[y][z] / (*(q_time_series[j]->fits))[y][z]) / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
            s4 += 1 / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
          }
        }
      }
      value = exp(s3 / s4);
    } else if (objective_type == "Normal_likelihood" && (prior_type == "Uniform_log_prior")){
      DOUBLE s1 = 0, s2 = 0;
      double n = 0;
      for (int j=0; j<q_time_series.size(); j++){
        obj = q_time_series[j]->objective;
        for (int y=1; y<=q_time_series[j]->fits->rowmax(); y++){
                  //if (min((*(q_time_series[j]->fits))[y]) <= 0){
                  //        fatal("A relative observation has nonpositive fits");}
          for (int z=1; z<=q_time_series[j]->fits->colmax(); z++){
        //richard test
            (*(q_time_series[j]->fits))[y][z]=zerofun((*(q_time_series[j]->fits))[y][z],ZERO);
            n++;
            s1 += (*(q_time_series[j]->obs))[y][z] / (obj->get_cvs()[y][z] * obj->get_cvs()[y][z] * (*(q_time_series[j]->fits))[y][z]);
            s2 += pow((*(q_time_series[j]->obs))[y][z] / (obj->get_cvs()[y][z] * (*(q_time_series[j]->fits))[y][z]), 2);
          }
        }
      }
      value = (-s1 + sqrt(s1*s1 + 4*(n+1)*s2)) / (2*(n+1));
    } else if ((objective_type == "Lognormal_likelihood" || objective_type == "Robustified_lognormal_likelihood") && (prior_type == "Uniform_log_prior")){
      DOUBLE s3 = 0, s4 = 0;
      double n = 0;
      for (int j=0; j<q_time_series.size(); j++){
        obj = q_time_series[j]->objective;
        for (int y=1; y<=q_time_series[j]->fits->rowmax(); y++){
                  //if (min((*(q_time_series[j]->fits))[y]) <= 0){
                  //        fatal("A relative observation has nonpositive fits");}
          for (int z=1; z<=q_time_series[j]->fits->colmax(); z++){
        //richard test
            (*(q_time_series[j]->fits))[y][z]=zerofun((*(q_time_series[j]->fits))[y][z],ZERO);
            n++;
            s3 += log((*(q_time_series[j]->obs))[y][z] / (*(q_time_series[j]->fits))[y][z]) / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
            s4 += 1 / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
          }
        }
      }
      value = exp((0.5*n - 1 + s3) / s4);
    } else if ((objective_type == "Lognormal_likelihood" || objective_type == "Robustified_lognormal_likelihood") && (prior_type == "Lognormal_prior")){
      DOUBLE s3 = 0, s4 = 0;
      double n = 0;
      for (int j=0; j<q_time_series.size(); j++){
        obj = q_time_series[j]->objective;
        for (int y=1; y<=q_time_series[j]->fits->rowmax(); y++){
                  //if (min((*(q_time_series[j]->fits))[y]) <= 0){
                  //        fatal("A relative observation has nonpositive fits");}
          for (int z=1; z<=q_time_series[j]->fits->colmax(); z++){
        //richard test
            (*(q_time_series[j]->fits))[y][z]=zerofun((*(q_time_series[j]->fits))[y][z],ZERO);
            n++;
            s3 += log((*(q_time_series[j]->obs))[y][z] / (*(q_time_series[j]->fits))[y][z]) / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
            s4 += 1 / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
          }
        }
      }
      DOUBLE mu_q = q_priors[q_name]->get_mu();
      DOUBLE cv_q = q_priors[q_name]->get_cv();
      DOUBLE var_q = log(1+cv_q*cv_q);
      value = exp((0.5*n - 1.5 + log(mu_q)/var_q + s3) / (s4 + 1/var_q));
    } else if (objective_type == "Normal_log_likelihood" && (prior_type == "Uniform_log_prior")){
      DOUBLE s3 = 0, s4 = 0;
      for (int j=0; j<q_time_series.size(); j++){
        obj = q_time_series[j]->objective;
        for (int y=1; y<=q_time_series[j]->fits->rowmax(); y++){
                  //if (min((*(q_time_series[j]->fits))[y]) <= 0){
                  //        fatal("A relative observation has nonpositive fits");}
          for (int z=1; z<=q_time_series[j]->fits->colmax(); z++){
        //richard test
            (*(q_time_series[j]->fits))[y][z]=zerofun((*(q_time_series[j]->fits))[y][z],ZERO);
            s3 += log((*(q_time_series[j]->obs))[y][z] / (*(q_time_series[j]->fits))[y][z]) / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
            s4 += 1 / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
          }
        }
      }
      value = exp((s3 - 1) / s4);
    } else if (objective_type == "Normal_log_likelihood" && (prior_type == "Lognormal_prior")){
      DOUBLE s3 = 0, s4 = 0;
      for (int j=0; j<q_time_series.size(); j++){
        obj = q_time_series[j]->objective;
        for (int y=1; y<=q_time_series[j]->fits->rowmax(); y++){
                  //if (min((*(q_time_series[j]->fits))[y]) <= 0){
                  //        fatal("A relative observation has nonpositive fits");}
          for (int z=1; z<=q_time_series[j]->fits->colmax(); z++){
        //richard test
            (*(q_time_series[j]->fits))[y][z]=zerofun((*(q_time_series[j]->fits))[y][z],ZERO);
        s3 += log((*(q_time_series[j]->obs))[y][z] / (*(q_time_series[j]->fits))[y][z]) / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
            s4 += 1 / (obj->get_sigmas()[y][z] * obj->get_sigmas()[y][z]);
          }
        }
      }
      DOUBLE mu_q = q_priors[q_name]->get_mu();
      DOUBLE cv_q = q_priors[q_name]->get_cv();
      DOUBLE var_q = log(1+cv_q*cv_q);
      value = exp((- 1.5 + log(mu_q)/var_q + s3) / (s4 + 1/var_q));
    } else {
      fatal("Unrecognised combination in get_nuisance_qs: objective_type = " + objective_type + " prior_type = " + prior_type);
    }
    // check bounds and adjust if necessary
    if (q_priors[q_name]->lower_bound > value){
      value = q_priors[q_name]->lower_bound;
    } else if (q_priors[q_name]->upper_bound <= value){
      value = q_priors[q_name]->upper_bound;
    }
   // fill in the result in qs;
    q[q_name] = value;
    if (bayesian && method=="nuisance"){
      // fill in q_prior_components with the prior density at the nuisance q's.
      q_prior_components[q_name] = q_priors[q_name]->prior(value);
    }
  }
}

template<CDVM>
int Qs<DVM>::any_relative_indices(){
  // are there any? 1 if so, 0 if not
  DEBUG2("Qs::any_relative_indices");
  return (q.size()>0);
}

template<CDVM>
void Qs<DVM>::print_bounds_check(ostream& out){
  // print out a warning message if any of the q's are within 10^-6 of their bounds
  DEBUG2("Qs::print_bounds_check");
  for (int i=0; i<q_names.size(); i++){
    DOUBLE q_val = q[q_names[i]];
    DOUBLE lbd = q_priors[q_names[i]]->lower_bound;
    DOUBLE ubd = q_priors[q_names[i]]->upper_bound;
    if (ubd - lbd > 2e-6){
          if (q_val < (lbd + 1e-6)){
                out << q_names[i] << " is at the lower bound\n";}
          if (q_val > (ubd - 1e-6)){
                out << q_names[i] << " is at the upper bound\n";}
        }
  }
  out << '\n';
}

template<CDVM>
void Qs<DVM>::print(ostream& out){
  DEBUG2("Qs::print");
  out << "qs are";
  if (method=="free"){
    out << " treated as ordinary free parameters";}
  else if (method=="nuisance"){
    out << " nuisance parameters";}
  out << '\n';
  std::string q_name;
  for (int i=0; i<q_names.size(); i++){
    q_name = q_names[i];
    out << q_name;
    if (method=="free"){
      out << " has current value " << q[q_name] << "\n";}
    if (curvature){
      out << " has current curvature parameter " << b[q_name] << " with q_type '" << q_type << "'\n";}
    if (method!="free"){
      if (q_priors[q_name]->type=="None"){
        out << " has ";
      } else {
        out << " has prior ";
      }
      q_priors[q_name]->print(out);
    }
  }
  out << '\n';
}

template<CDVM>
Qs<DVM>::~Qs(){
  DEBUG1("~Qs");
  for (int i=0; i<q_names.size(); i++){
    delete q_priors[q_names[i]];}
}

template<CDVM>
Qs<DVM>::Qs(const std::string& _method,
                                Observations_dataset<DVM>& o,
                                Parameter_set<DVM>& e){
  DEBUG2("Qs::Qs");
  // Construct the Qs object.
  // For each relative time series in obs,
  //   set the Qs_ptr of the time_series to point to this Qs object
  //   check whether it has curvature (and its q_type)
  //   create entries in q and b, if this q has not already been entered
  //   if q's are nuisance, stash the time series pointer in ts_ptrs,
  //                        stash the time series objective function type in ts_objectives.
  // Then for each q,
  //   extract the starting value for q if method="free", and the starting value for b if (curvature),
  //     and the bounds on q, and priors in a Bayesian analysis, if method!="free",
  //     from the estimation Parameter_set,
  //   if method=="nuisance", check whether the prior is compatible with the
  //    objective function on the observations(some combinations don't lead to an
  //    analytic solution for the modal q).
  method = _method;
  if (method != "free" && method != "nuisance"){
    fatal("q_method of " + method + " not recognised: use free or nuisance");}
  curvature = 0;
  Observations<DVM>* t;
  for (int i=0; i<o.obs.size(); i++){
    if (o.obs[i]->relative()){
      // it is a relative time series
      t = static_cast<Observations<DVM>*>(o.obs[i]);
      t->set_qs_ptr(this);
      if (t->curvature()){
        curvature = 1;}
      std::string q_name = t->get_q_name();
      if (!in(q,q_name)){
        q.insert(make_pair(q_name,0));
        b.insert(make_pair(q_name,1));
        q_names.push_back(q_name);
      }
      if (method=="nuisance"){
        ts_ptrs[q_name].push_back(t);
        if (t->objective->type=="normal-by-stdev"){
          fatal("Can't calculate nuisance q's for normal likelihoods parameterized by the std. dev. yet");}
    if (t->objective->type=="user-supplied"){
      fatal("Can't calculate nuisance q's for time series with user-supplied likelihoods.");}
        if (!in(ts_objectives,q_name)){
          ts_objectives.insert(make_pair(q_name,t->objective->type));
        } else {
          if (ts_objectives[q_name] != t->objective->type){
            fatal("All observations sharing q " + q_name + " should have the same objective function");}
        }
      }
    }
  }
  std::string q_name;
  q_type = e.get_string("q_type","standard");
  if(!(q_type=="standard" || q_type=="scaled")) {
    fatal("q_type must be either 'standard' or 'scaled'");}
  bayesian = e.get_string("estimator")=="Bayes";
  for (int i=0; i<q_names.size(); i++){
    q_name = q_names[i];
    std::string command = "q[" + q_name + "].";
    if (method=="free"){
      q[q_name] = e.get_constant(command+"q");
    }
    if (curvature){
      b[q_name] = e.get_constant(command+"b",1);
    }
    if (method != "free") {
      // for nuisance q's, store the bounds / priors on q in the Qs object
      // start by finding the @estimate command referring to this q
      for (int i=1; i<=e.get_command_count("estimate"); i++){
        command = "estimate["+itos(i)+"].";
        if (e.get_string(command+"parameter")==("q["+q_name+"].q")){
          break;
        } else if (i==e.get_command_count("estimate")){
          fatal("did not find an @estimate block for parameter q["+q_name+"].q");
        }
      }
      double lower_bound = e.get_constant(command+"lower_bound");
      double upper_bound = e.get_constant(command+"upper_bound");
      if (!bayesian){  // no prior just bounds
        q_priors.insert(make_pair(q_name,
                                  new Scalar_prior<DVM>(lower_bound,upper_bound)));
      } else {
        std::string prior = e.get_string(command+"prior");
        if (prior=="uniform"){
          q_priors.insert(make_pair(q_name,
                                    new Uniform_prior<DVM>(lower_bound,upper_bound)));
        } else if (prior=="uniform-log"){
          q_priors.insert(make_pair(q_name,
                                    new Uniform_log_prior<DVM>(lower_bound,upper_bound)));
        } else if (prior=="normal"){
          q_priors.insert(make_pair(q_name,
                                    new Normal_prior<DVM>(lower_bound,upper_bound,
                                                          e.get_constant(command+"mu"),
                                                          e.get_constant(command+"cv"))));
        } else if (prior=="normal-by-stdev"){
          q_priors.insert(make_pair(q_name,
                                    new Normal_prior<DVM>(lower_bound,upper_bound,
                                                          e.get_constant(command+"mu"),
                                                          e.get_constant(command+"stdev"))));
        } else if (prior=="lognormal"){
          q_priors.insert(make_pair(q_name,
                                    new Lognormal_prior<DVM>(lower_bound,upper_bound,
                                                             e.get_constant(command+"mu"),
                                                             e.get_constant(command+"cv"))));
        } else fatal("Unknown prior for q " + q_name + " : " + prior);
        if (method=="nuisance") q_prior_components.insert(make_pair(q_name,0));
      }
    }
    if (method=="nuisance"){
      if (q_priors[q_name]->type == "Normal_prior" ||
          q_priors[q_name]->type == "Normal_by_stdev_prior" ||
          ts_objectives[q_name] == "Normal_likelihood" && q_priors[q_name]->type == "Lognormal_prior"){
        fatal("For nuisance q " + q_name + " the prior type " + q_priors[q_name]->type + " is not compatible with the objective function type " + ts_objectives[q_name]);
      }
    }
  }
}

//############################## PARAMETERS ##############################
template<CDVM>
VECTOR Free_parameters<DVM>::get(){
  // get the free parameters
  DEBUG2("Free_parameters::get");
  return (*values);
}

template<CDVM>
DOUBLE Free_parameters<DVM>::get_scalar(int i){
  // get the value of scalar parameter i (i = 0,1,2...)
  DEBUG2("Free_parameters::get_int");
  return (*values)[i+1];
}

template<CDVM>
VECTOR Free_parameters<DVM>::get_vector(int i){
  // get the value of vector parameter i (i = 0,1,2...)
  DEBUG2("Free_parameters::get_vector");
  VECTOR result(1,vector_parameter_sizes[i]);
  int count = n_scalars;
  for (int j=0; j<i; j++){
    count += vector_parameter_sizes[j];}
  for (int j=1; j<=result.size(); j++){
    result[j] = (*values)[count+j];}
  return result;
}

template<CDVM>
void Free_parameters<DVM>::set(const VECTOR& v){
  // set the free parameters to v
  DEBUG2("Free_parameters::set");
  (*values) = v;
}

template<CDVM>
dvector Free_parameters<DVM>::get_lower_bounds(){
  // get the lower bounds as a single vector
  DEBUG2("Free_parameters::get_lower_bounds");
  dvector lower_bounds(1,values->size());
  int count = 1;
  for (int i=0; i<n_scalars; i++){
    lower_bounds[count++] = scalar_priors[i]->lower_bound;
  }
  for (int i=0; i<n_vectors; i++){
    for (int j=1; j<=vector_parameter_sizes[i]; j++){
      lower_bounds[count++] = vector_priors[i]->lower_bounds[j];
    }
  }
  return lower_bounds;
}

template<CDVM>
dvector Free_parameters<DVM>::get_upper_bounds(){
  // get the upper bounds as a single vector
  DEBUG2("Free_parameters::get_upper_bounds");
  dvector upper_bounds(1,values->size());
  int count = 1;
  for (int i=0; i<n_scalars; i++){
    upper_bounds[count++] = scalar_priors[i]->upper_bound;
  }
  for (int i=0; i<n_vectors; i++){
    for (int j=1; j<=vector_parameter_sizes[i]; j++){
      upper_bounds[count++] = vector_priors[i]->upper_bounds[j];
    }
  }
  return upper_bounds;
}

template<CDVM>
int Free_parameters<DVM>::within_bounds(const VECTOR& v){
  // Return 1 if this parameter vector is within the bounds or 0 if not.
  DEBUG2("Free_parameters::within_bounds");
  dvector lower_bounds(get_lower_bounds());
  dvector upper_bounds(get_upper_bounds());
  for (int i=1; i<=lower_bounds.size(); i++){
    if (lower_bounds[i] > v[i] || upper_bounds[i] < v[i]){
      return 0;
    }
  }
  return 1;
}

template<CDVM>
void Free_parameters<DVM>::fix_scalar(int par_no){
  // Fix scalar parameter par_no (of 0, 1, 2...) by setting the lower and
  // upper bound equal to the current value.
  DEBUG2("Free_parameters::fix_scalar");
  double current = value(get_scalar(par_no));
  scalar_priors[par_no]->upper_bound = current;
  scalar_priors[par_no]->lower_bound = current;
}

template<CDVM>
void Free_parameters<DVM>::fix_vector(int par_no){
  // Fix vector parameter par_no (of 0, 1, 2...) by setting the lower and
  // upper bounds equal to the current values.
  DEBUG2("Free_parameters::fix_vector");
  dvector current(value(get_vector(par_no)));
  vector_priors[par_no]->upper_bounds = current;
  vector_priors[par_no]->lower_bounds = current;
}

template<CDVM>
void Free_parameters<DVM>::fix_vector(int par_no, int element_no){
  // Fix vector parameter par_no (of 0, 1, 2...) by setting the lower and
  // upper bounds equal to the current values, but for the specified element only
  DEBUG2("Free_parameters::fix_vector");
  dvector current(value(get_vector(par_no)));
  for(int i=1; i<=current.size(); i++) {
    if(i==element_no) {
      vector_priors[par_no]->upper_bounds[i] = current[i];
      vector_priors[par_no]->lower_bounds[i] = current[i];
    }
  }
}


template<CDVM>
void Free_parameters<DVM>::free_scalar(int par_no){
  // Reverse fix_scalar(par_no).
  DEBUG2("Free_parameters::free_scalar");
  scalar_priors[par_no]->upper_bound = scalar_original_upper_bounds[par_no];
  scalar_priors[par_no]->lower_bound = scalar_original_lower_bounds[par_no];
}

template<CDVM>
void Free_parameters<DVM>::free_vector(int par_no){
  // Reverse fix_vector(par_no).
  DEBUG2("Free_parameters::free_vector");
  vector_priors[par_no]->upper_bounds = vector_original_upper_bounds[par_no];
  vector_priors[par_no]->lower_bounds = vector_original_lower_bounds[par_no];
}

template<CDVM>
DOUBLE Free_parameters<DVM>::get_prior(){
  // Returns the negative-log-prior, and puts its components in 'prior_components'.
  DEBUG0("Free_parameters::get_prior");
  DOUBLE par_value;
  int count = 0;
  for (int i=0; i<n_scalars; i++){
    par_value = get_scalar(i);
    prior_components[count++] = scalar_priors[i]->prior(par_value);
  }
  VECTOR* par_values;
  for (int i=0; i<n_vectors; i++){
    par_values = new VECTOR(get_vector(i));
    prior_components[count++] = vector_priors[i]->prior(*par_values);
    delete par_values;
  }
  DOUBLE prior = 0;
  for (int i=0; i<prior_components.size(); i++){
    prior += prior_components[i];}
  return prior;
}

template<CDVM>
void Free_parameters<DVM>::check_file_header(const std::string& header){
  // is this a valid header for an input file, as produced by make_file_header()?
  // error out if not.
  DEBUG1("Free_parameters::check_file_header");
  istringstream header_stream((header+" ").c_str());
  std::string entry;
  int size;
  for (int i=0; i<n_scalars; i++){
    header_stream >> entry;
    if (header_stream.fail()) fatal("header line too short:\nreceived\n" + header + "\nexpected\n" + make_file_header());
    if (entry!=scalar_parameter_names[i]) fatal("bad header line:\ndidn't expect " + entry + "\nreceived\n" + header + "\nexpected\n" + make_file_header());
  }
  for (int i=0; i<n_vectors; i++){
    header_stream >> entry;
    if (header_stream.fail()) fatal("header line too short:\nreceived\n" + header + "\nexpected\n" + make_file_header());
    if (entry!=vector_parameter_names[i]) fatal("bad header line:\ndidn't expect " + entry + "\nreceived\n" + header + "\nexpected\n" + make_file_header());
    header_stream >> entry;
    if (header_stream.fail()) fatal("header line too short:\nreceived\n" + header + "\nexpected\n" + make_file_header());
    size = stoi(entry);
    if (size!=vector_parameter_sizes[i]) fatal("bad header line:\ndidn't expect " + entry + "\nreceived\n" + header + "\nexpected\n" + make_file_header());
  }
  header_stream >> entry;
  if (!header_stream.fail()) fatal("header line too long:\nreceived\n" + header + "\nexpected\n" + make_file_header());
}

template<CDVM>
int Free_parameters<DVM>::get_input_file_by_line(ifstream* input_file, std::string parameters_input_file, dvector& parameter_values) {
  // read in the input file by line, and return 0 if end of file
  static int input_file_line_counter=0;
  int input_line_word_counter=0;
  std::string this_line;
  input_file_line_counter ++;
  getline(*input_file,this_line);
  if (!input_file->good() || this_line=="" ) return(0);
  istringstream ss((this_line + " ").c_str());
  double test_val;
  while(ss >> test_val) {
    input_line_word_counter++;
  }
  if(input_line_word_counter!=parameter_values.size()) fatal("Line " + itos(input_file_line_counter+1) + " of the input file " + parameters_input_file + " has an incorrect number of values. Found " + itos(input_line_word_counter) + ", but there should be " + itos(parameter_values.size()) + ".");
  ss.clear();
  ss.seekg(ios_base::beg);
  ss >> parameter_values;
  return(1);
}

template<CDVM>
std::string Free_parameters<DVM>::make_file_header(){
  // generate and return a header for an input file, as read by check_file_header().
  DEBUG1("Free_parameters::make_file_header");
  std::string result = "";
  for (int i=0; i<n_scalars; i++){
    result += scalar_parameter_names[i] + " ";
  }
  for (int i=0; i<n_vectors; i++){
    result += vector_parameter_names[i] + " ";
    result += itos(vector_parameter_sizes[i]) + " ";
  }
  result += "\n";
  return result;
}

template<CDVM>
void Free_parameters<DVM>::print_bounds_check(ostream& out){
  // print out a warning message if any of the (non-fixed) free parameters are
  // at or very near to their bounds
  DEBUG2("Free_parameters::print_bounds_check");
  int print_bound_error_message=0;
  for (int i=0; i<n_scalars; i++){
    DOUBLE val = get_scalar(i);
    DOUBLE lbd = scalar_priors[i]->lower_bound;
    DOUBLE ubd = scalar_priors[i]->upper_bound;
    DOUBLE tol = fmax(2e-4,(ubd-lbd)*0.001);
    if (ubd - lbd > (2*tol)){
      if ((val < (lbd + tol)) || (val > (ubd - tol))){
        if(print_bound_error_message==0) {
          out << "The following parameters were estimated at or near a bound:\n";
          out << "Parameter        Estimate  lower_bound  upper_bound\n";
          print_bound_error_message=1;
        }
        out << scalar_parameter_names[i] << "  " << val << "  " << lbd << "  " << ubd << "\n";;
      }
    }
  }
  for (int i=0; i<n_vectors; i++){
    VECTOR vals(get_vector(i));
    VECTOR lbds(vector_priors[i]->lower_bounds);
    VECTOR ubds(vector_priors[i]->upper_bounds);
    vector<int> vector_entry;
    for (int j=1; j<=vals.size(); j++){
      DOUBLE tol = fmax(2e-4,(ubds[j]-lbds[j])*0.001);
      if (ubds[j] - lbds[j] > (2*tol)){
        if ((vals[j] < (lbds[j] + tol)) || (vals[j] > (ubds[j] - tol))) {
          if(print_bound_error_message==0) {
            out << "The following parameters were estimated at or near a bound:\n";
            out << "Parameter        Estimate  lower_bound  upper_bound\n";
            print_bound_error_message=1;
          }
          out << vector_parameter_names[i] << "[" << j << "]"<< "  " << vals[j] << "  " << lbds[j] << "  " << ubds[j] << "\n";;
        }
      }
    }
  }
  out << '\n';
}

template<CDVM>
void Free_parameters<DVM>::print(int priors, ostream& out){
  DEBUG2("Free_parameters::print_prior");
  for (int i=0; i<n_scalars; i++){
    out << scalar_parameter_names[i] << '\n';
    if (priors) scalar_priors[i]->print(out);
    out << "current value: " << get_scalar(i) << "\n";
    out << "lower bound: " << scalar_priors[i]->lower_bound << "\n";
    out << "upper bound: " << scalar_priors[i]->upper_bound << "\n\n";
  }
  for (int i=0; i<n_vectors; i++){
    out << vector_parameter_names[i] << (vector_parameter_is_ogive[i] ? " (parameters)" : "") << '\n';
    if (priors) vector_priors[i]->print(out);
    out << "current values: " << get_vector(i) << "\n";
    out << "lower bounds: " << vector_priors[i]->lower_bounds << "\n";
    out << "upper bounds: " << vector_priors[i]->upper_bounds << "\n\n";
  }
  out << '\n';
}

template<CDVM>
Free_parameters<DVM>::Free_parameters(const std::string& q_method,
                                                         Parameter_set<DVM>& e,
                                                         Parameter_set<DVM>& p){
  // Construct the Free_parameters object
  // from the 'estimate' blocks in the estimation Parameter_set e
  // and the starting values in the population Parameter_set p.
  DEBUG0("Free_parameters::Free_parameters");
  // Work through to see how many parameters there are;
  // stash them in a std::vector<double> and a std::vector<dvector> as we go.
  int parameter_count = 0;
  std::vector<double> scalar_parameter_values;
  std::vector<dvector> vector_parameter_values;
  std::string command, type, parameter_name, ogive_parameter_name;
  int is_vector, is_ogive;
  int size;
  int bayesian = (e.get_string("estimator")=="Bayes");
  std::vector<std::string> estimable_types;
  estimable_types.push_back("estimable");
  estimable_types.push_back("estimable_vector");
  estimable_types.push_back("ogive");
  std::string partype, sametype;
  n_scalars = n_vectors = 0;
  std::vector<string> check_same_parameters;
  for (int i=1; i<=e.get_command_count("estimate"); i++){
    // keep a list of all estimated parameters for later checking that no parameter is both estimated and a 'same' parameter
    command = "estimate[" + itos(i) + "].";
    check_same_parameters.push_back(e.get_string(command + "parameter"));
  }
  for (int i=1; i<=e.get_command_count("estimate"); i++){
    command = "estimate[" + itos(i) + "].";
    parameter_name = e.get_string(command + "parameter");
    if (parameter_name.substr(0,2)=="q[" && q_method != "free"){
      // Do nothing - unless q's are ordinary free parameters, we don't want them here.
      std::vector<std::string> sames = e.get_vector_of_strings(command + "same",std::vector<std::string>());
      if (sames.size()!=0){
        for (int j=0; j<sames.size(); j++){
          for(int k=0; k<check_same_parameters.size(); k++) {
            if (sames[j] == check_same_parameters[k]){
              fatal("You are have specified the parameter " + sames[j] + " twice, in the 'same' subcommand in estimate block " + itos(i) + ", and as a free parameter in another estimate block.");
            }
          }
        }
      }
    } else {
      partype = check_parname(parameter_name, p, e, "estimate block number " + itos(i), estimable_types);
      is_vector = (partype!="estimable");
      is_ogive = (partype=="ogive");
      if (is_vector || is_ogive){
        vector_parameter_names.push_back(parameter_name);
        vector_parameter_is_ogive.push_back(is_ogive);
        n_vectors++;
        std::vector<std::string> sames = e.get_vector_of_strings(command + "same",std::vector<std::string>());
        if (sames.size()!=0){
          for (int j=0; j<sames.size(); j++){
            sametype = check_parname(sames[j], p, e, "'same' subcommand in estimate block number " + itos(i), estimable_types);
            if (sametype!=partype){
              fatal("You have specified parameter " + sames[j] + " in the 'same' subcommand in estimate block number " + itos(i) + ". This is not the same type as the estimated parameter itself, " + parameter_name);
            }
            for(int k=0; k<check_same_parameters.size(); k++) {
              if (sames[j] == check_same_parameters[k]){
                fatal("You are have specified the parameter " + sames[j] + " twice, in the 'same' subcommand in estimate block " + itos(i) + ", and as a free parameter in another estimate block.");
              }
            }
          }
        }
        vector_same.push_back(sames);
        vector_phases.push_back(e.get_int(command+"phase",1));
        vector_MCMC_fixed.push_back(e.get_bool(command+"MCMC_fixed",0));
        dvector* par_values;
        if (e.present(parameter_name)){ // this vector parameter is in the estimation Parameter_set
          if (is_ogive){
            par_values = new dvector(value(e.get_ogive_free_parameters(parameter_name)));
          } else {
            par_values = new dvector(e.get_constant_vector(parameter_name));
          }
        } else {                        // this vector parameter is in the population Parameter_set
          if (is_ogive){
            par_values = new dvector(value(p.get_ogive_free_parameters(parameter_name)));
          } else {
            par_values = new dvector(p.get_constant_vector(parameter_name));
          }
        }
        vector_parameter_values.push_back(*par_values);
        size = par_values->size();
        vector_parameter_sizes.push_back(size);
        dvector lower_bound(e.get_constant_vector(command+"lower_bound"));
        dvector upper_bound(e.get_constant_vector(command+"upper_bound"));
        // check the lengths of the bounds, and that the initial values are within the bounds
        if (lower_bound.size() != size){
          fatal("Lower bounds on " + parameter_name + " are the wrong length\n");}
        if (upper_bound.size() != size){
          fatal("Upper bounds on " + parameter_name + " are the wrong length\n");}
        for (int j=1; j<=size; j++){
          if (lower_bound[j] > (*par_values)[j]){
            fatal("Entry " + itos(j) + " of the lower bounds on " + parameter_name + " is higher (at " + dtos(lower_bound[j]) + ") than the parameter_value (of " + dtos((*par_values)[j]) + ")");}
          if (upper_bound[j] < (*par_values)[j]){
            fatal("Entry " + itos(j) + " of the upper bounds on " + parameter_name + " is lower (at " + dtos(upper_bound[j]) + ") than the parameter_value (of " + dtos((*par_values)[j]) + ")");}
        }
        vector_original_lower_bounds.push_back(lower_bound);
        vector_original_upper_bounds.push_back(upper_bound);
        if (!bayesian){
          vector_priors.push_back(new Vector_prior<DVM>(lower_bound,upper_bound));
        } else {
          type = e.get_string(command + "prior");
          if (type == "uniform"){
            vector_priors.push_back(new Uniform_vector_prior<DVM>(lower_bound,upper_bound));
          } else if (type == "uniform-log"){
            vector_priors.push_back(new Uniform_log_vector_prior<DVM>(lower_bound,upper_bound));
          } else if (type == "normal"){
            vector_priors.push_back(new Normal_vector_prior<DVM>(lower_bound, upper_bound,
                                                      e.get_constant_vector(command + "mu"),
                                                      e.get_constant_vector(command + "cv")));
          } else if (type == "normal-by-stdev"){
            vector_priors.push_back(new Normal_by_stdev_vector_prior<DVM>(lower_bound, upper_bound,
                                                      e.get_constant_vector(command + "mu"),
                                                      e.get_constant_vector(command + "stdev")));
          } else if (type == "lognormal"){
            vector_priors.push_back(new Lognormal_vector_prior<DVM>(lower_bound, upper_bound,
                                                      e.get_constant_vector(command + "mu"),
                                                      e.get_constant_vector(command + "cv")));
          } else if (type == "normal-log"){
            vector_priors.push_back(new Normal_log_vector_prior<DVM>(lower_bound, upper_bound,
                                                      e.get_constant_vector(command + "m"),
                                                      e.get_constant_vector(command + "s")));
          } else if (type == "beta"){
            vector_priors.push_back(new Beta_vector_prior<DVM>(lower_bound, upper_bound,
                                                      e.get_constant_vector(command + "mu"),
                                                      e.get_constant_vector(command + "stdev"),
                                                      e.get_constant_vector(command + "A",0),
                                                      e.get_constant_vector(command + "B",1)));
          } else if (type == "normal-AR"){
            vector_priors.push_back(new Normal_AR_prior<DVM>(lower_bound, upper_bound,
                                                      e.get_constant(command + "mu"),
                                                      e.get_constant(command + "cv"),
                                                      e.get_constant(command + "rho")));
          } else if (type == "normal-log-AR"){
            vector_priors.push_back(new Normal_log_AR_prior<DVM>(lower_bound, upper_bound,
                                                      e.get_constant(command + "m"),
                                                      e.get_constant(command + "s"),
                                                      e.get_constant(command + "r")));
          } else if (type == "normal-log-mean1-AR"){
            vector_priors.push_back(new Normal_log_mean1_AR_prior<DVM>(lower_bound, upper_bound,
                                                      e.get_constant(command + "s"),
                                                      e.get_constant(command + "r")));
          } else fatal("Unknown prior " + type + " for parameter " + parameter_name);
        }
        delete par_values;
      } else if (!is_vector && !is_ogive){  // it's a scalar parameter
        size = 1;
        scalar_parameter_names.push_back(parameter_name);
        n_scalars++;
        std::vector<std::string> sames = e.get_vector_of_strings(command + "same",std::vector<std::string>());
        if (sames.size()!=0){
          for (int j=0; j<sames.size(); j++){
            sametype = check_parname(sames[j], p, e, "'same' subcommand in estimate block number " + itos(i), estimable_types);
            if (sametype!=partype){
              fatal("You have specified parameter " + sames[j] + " in the 'same' subcommand in estimate block number " + itos(i) + ". This is not the same type as the estimated parameter itself, " + parameter_name);
            }
            for(int k=0; k<check_same_parameters.size(); k++) {
              if (sames[j] == check_same_parameters[k]){
                fatal("You are have specified the parameter " + sames[j] + " twice, in the 'same' subcommand in estimate block " + itos(i) + ", and as a free parameter in another estimate block.");
              }
            }
          }
        }
        scalar_same.push_back(sames);
        scalar_phases.push_back(e.get_int(command+"phase",1));
        scalar_MCMC_fixed.push_back(e.get_bool(command+"MCMC_fixed",0));
        double par_value;
        if (e.present(parameter_name)){ // this scalar parameter is in the estimation Parameter_set
          par_value = e.get_constant(parameter_name);
        } else {                        // this scalar parameter is in the population Parameter_set
          par_value = p.get_constant(parameter_name);
        }
        scalar_parameter_values.push_back(par_value);
        double lower_bound = e.get_constant(command+"lower_bound");
        double upper_bound = e.get_constant(command+"upper_bound");
        // check that the initial values are within the bounds
        if (lower_bound > par_value){
          fatal("The lower bound on " + parameter_name + " is higher (at " + dtos(lower_bound) + ") than the parameter_value (of " + dtos(par_value) + ")");}
        if (upper_bound < par_value){
          fatal("The upper bound on " + parameter_name + " is lower (at " + dtos(upper_bound) + ") than the parameter_value (of " + dtos(par_value) + ")");}
        scalar_original_lower_bounds.push_back(lower_bound);
        scalar_original_upper_bounds.push_back(upper_bound);
        if (!bayesian){
          scalar_priors.push_back(new Scalar_prior<DVM>(lower_bound,upper_bound));
        } else {
          type = e.get_string(command + "prior");
          if (type == "uniform"){
            scalar_priors.push_back(new Uniform_prior<DVM>(lower_bound,upper_bound));
          } else if (type == "uniform-log"){
            scalar_priors.push_back(new Uniform_log_prior<DVM>(lower_bound,upper_bound));
          } else if (type == "normal"){
            scalar_priors.push_back(new Normal_prior<DVM>(lower_bound, upper_bound,
                                                          e.get_constant(command + "mu"),
                                                          e.get_constant(command + "cv")));
          } else if (type == "normal-by-stdev"){
            scalar_priors.push_back(new Normal_by_stdev_prior<DVM>(lower_bound, upper_bound,
                                                                   e.get_constant(command + "mu"),
                                                                   e.get_constant(command + "stdev")));
          } else if (type == "lognormal"){
            scalar_priors.push_back(new Lognormal_prior<DVM>(lower_bound, upper_bound,
                                                             e.get_constant(command + "mu"),
                                                             e.get_constant(command + "cv")));
          } else if (type == "normal-log"){
            scalar_priors.push_back(new Normal_log_prior<DVM>(lower_bound, upper_bound,
                                                              e.get_constant(command + "m"),
                                                              e.get_constant(command + "c")));
          } else if (type == "beta"){
            scalar_priors.push_back(new Beta_prior<DVM>(lower_bound, upper_bound,
                                                        e.get_constant(command + "mu"),
                                                        e.get_constant(command + "stdev"),
                                                        e.get_constant(command + "A",0),
                                                        e.get_constant(command + "B",1)));
          } else fatal("Unknown prior " + type + " for parameter " + e.get_string(command + "parameter"));
        }
      }
      parameter_count += size;
    }
  }
  // Now, compact the std::vectors<double> and <dvector> into a single VECTOR.
  values = new VECTOR(1,parameter_count);
  int count=1;
  for (int i=0; i<n_scalars; i++){
    (*values)[count++] = scalar_parameter_values[i];
  }
  for (int i=0; i<n_vectors; i++){
    for (int j=1; j<=vector_parameter_values[i].size(); j++){
      (*values)[count++] = vector_parameter_values[i][j];
    }
  }
  if (bayesian){
    prior_components.resize(n_scalars+n_vectors);}
}

template<CDVM>
Free_parameters<DVM>::~Free_parameters(){
  DEBUG1("~Free_parameters");
  for (int i=0; i<n_scalars; i++){
    delete scalar_priors[i];}
  for (int i=0; i<n_vectors; i++){
    delete vector_priors[i];}
  delete values;
}

//############################## AGEING ERROR ##############################
template<CDVM>
void Ageing_error<DVM>::apply(MATRIX& numbers_at_age){
  // Postmultiply the numbers-at-age by the misclassification matrix.
  // I've got a feeling that this is inefficient. Could we do better by exploiting sparsity???
  DEBUG1("Ageing_error::apply");
  numbers_at_age = numbers_at_age * (*misclassification);
}

template<CDVM>
void Ageing_error<DVM>::set_off_by_one(const DOUBLE& p1, const DOUBLE& p2){
  DEBUG2("Ageing_error::set_off_by_one");
  misclassification->initialize();
  (*misclassification)[min_age][min_age] = 1-p2;
  (*misclassification)[min_age][min_age+1] = p2;
  for (int i=min_age+1; i<max_age; i++){
    (*misclassification)[i][i-1] = p1;
    (*misclassification)[i][i] = 1-p1-p2;
    (*misclassification)[i][i+1] = p2;
  }
  (*misclassification)[max_age][max_age-1] = p1;
  if (plus_group){
    (*misclassification)[max_age][max_age] = 1-p1;
  } else {
    (*misclassification)[max_age][max_age] = 1-p1-p2;
  }
  if (k>0){  // actually the youngest ages have no misclassification
    for (int i=min_age; i<k; i++){
      (*misclassification)[i] = 0;
      (*misclassification)[i][i] = 1;
    }
  }
}

template<CDVM>
void Ageing_error<DVM>::set_normal(const DOUBLE& cv){
  DEBUG2("Ageing_error::set_normal");
  dvector class_mins(1,max_age-min_age+2-plus_group);
  for (int i=1; i<=max_age-min_age+1; i++){
    class_mins[i] = (min_age+i-1) - 0.5;}
  if (!plus_group) class_mins[class_mins.size()] = (class_mins[class_mins.size()-1]+1);
  for (int i=min_age; i<=max_age; i++){
    (*misclassification)[i] = distribution<DVM>(class_mins,plus_group,"normal",i,i*cv);}
}

template<CDVM>
void Ageing_error<DVM>::print(ostream& out){
  DEBUG2("Ageing_error::print");
  if (ageing_error){
    out << "  Misclassification matrix:\n" << (*misclassification) << "\n\n";
  } else {
    out << "  None\n\n";
  }
}

template<CDVM>
Ageing_error<DVM>::Ageing_error(Parameter_set<DVM>& e, Basic_population_section<DVM>& popn){
  // Construct the misclassification matrix from the estimation parameter set.
  // Grab the number of age classes from the population section.
  DEBUG0("Ageing_error::Ageing_error");
  ageing_error = 1;
  type = e.get_string("ageing_error.type","none");
  if (type!="none" && popn.state.size_based){
          fatal("You cannot use ageing error in a size-based model");}
  if (type=="none"){
    ageing_error = 0;
    misclassification = 0;
  } else {
    min_age = popn.state.col_min;
    max_age = popn.state.col_max;
    if (max_age==min_age) fatal("Need more than one age class if you are going to have ageing error");
    plus_group = popn.state.plus_group;
    misclassification = new MATRIX(min_age,max_age,min_age,max_age);
    if (type=="off_by_one"){
      DOUBLE p1 = e.get_estimable("ageing_error.p1");
      DOUBLE p2 = e.get_estimable("ageing_error.p2");
      k = e.get_int("ageing_error.k",0);
      set_off_by_one(p1,p2);
    } else if (type=="normal"){
      DOUBLE cv = e.get_estimable("ageing_error.c");
      set_normal(cv);
    } else if (type=="misclassification_matrix"){
      // grab the matrix; check row lengths and sums
      dvector *row;
      for (int i=min_age; i<=max_age; i++){
        row = new dvector(e.get_constant_vector("ageing_error." + itos(i)));
        if (row->size() != max_age-min_age+1){
          fatal("Row " + itos(i) + " of the ageing error misclassification matrix has the wrong length (" + itos(row->size()) + ", should be " + itos(max_age-min_age+1) + ")");}
        // three decimals places lower bound for error of sum
        if ( fabs(sum(*row) - 1.0) >= 5e-4 ){
          cout << "Row " << i << " of the ageing error misclassification matrix adds up to " << sum(*row) << ", should it sum to 1?\n";}
        (*misclassification)[i] = (*row);
        delete row;
      }
    } else fatal("Unrecognised ageing error type "+ type);
  }
}

template<CDVM>
Ageing_error<DVM>::~Ageing_error(){
  DEBUG1("~Ageing_error");
  delete misclassification;
};

//############################## MCMC SETTINGS ##############################
template<CDVM>
void MCMC_settings<DVM>::print(ostream& out){
  DEBUG2("MCMC_settings::print");
  if (start == 0){
    out << "MCMC starts from the posterior mode";
  } else {
    out << "MCMC starts from a random point near the mode, using a covariance matrix which is the covariance matrix at the mode multiplied by " << start;
  }
  out << " but this can be overridden if the user specifies a starting point using -i.\n";
  out << "Maximum length of chain: " << length << '\n';
  if (burn_in >= 0){
    out << "Length of burn-in: " << burn_in << '\n';}
  if (keep != 1){
    out << "Only samples of number evenly divisible by " << keep << " are recorded.\n";
  }
  if (proposal_t){
    out << "Proposal distribution is multivariate t with " << df << " df.\n";
  }
  out << "Correlations of absolute magnitude greater than " << max_cor << " in the covariance matrix of the proposal distribution are changed to have magnitude " << max_cor << ".\n";
  if(covariance_adjustment_method!="none")
    out << "Nonzero variances less than " << min_diff << " of the range of their parameter bounds in the covariance matrix of the proposal distribution are modified.\n";
  if (stepsize > 0){
    out << "The initial stepsize is " << stepsize << ".\n";
  } else {
    out << "The initial stepsize is the default of 2.4 / sqrt(number of free parameters).\n";
  }
  if (adaptive_stepsize) out << "Stepsize is adjusted at iterations " << *adapt_at << ".\n";
  if (adaptive_covariance){
          out << "Covariance matrix is adjusted at iterations " << *adapt_covariance_at << ".\n";
          out << " When this happens, the stepsize is reset to " << adaptive_covariance_stepsize << "\n";
          out << " The new covariance is based on the estimated covariance of a portion of the chain.\n";
          out << " This portion does not include the first " << adaptive_covariance_discard << " iterations.\n";
          out << " There must be at least " << adaptive_covariance_transitions << " successful steps in this portion of chain.\n";
  }
  if (machine_names.size()>0){
    out << "Machine names: " << machine_names << '\n';
  }
  if (prior_reweighting) out << "Prior reweighting is to be used. \n";
  if (subsample_size>0) out << "A " << (systematic ? "systematic" : "random") << " subsample of size " << subsample_size << " is to be generated.\n";
}

template<CDVM>
MCMC_settings<DVM>::MCMC_settings(Parameter_set<DVM>& e){
  DEBUG1("MCMC_settings");
  start = e.get_constant("MCMC.start");
  length = e.get_int("MCMC.length");
  keep = e.get_int("MCMC.keep",1);
  burn_in = e.get_int("MCMC.burn_in",-1);
  long samples_to_drop = burn_in * keep;
  if (samples_to_drop > length){
          fatal("You have set your MCMC 'burn-in' parameter too high. Remember it is in multiples of 'keep' , so right now you are going to drop " + itos(burn_in) + " * " + itos(keep) + " iterations.");
  }
  proposal_t = e.get_bool("MCMC.proposal_t",0);
  if (proposal_t){
    df = e.get_int("MCMC.df",4);}
  max_cor = e.get_constant("MCMC.max_cor",0.8);
  covariance_adjustment_method = e.get_string("MCMC.covariance_adjustment","correlation");
  min_diff = e.get_constant("MCMC.min_diff",0.0001);
  stepsize = e.get_constant("MCMC.stepsize",0);
  adaptive_stepsize = e.get_bool("MCMC.adaptive_stepsize",0);
  if (adaptive_stepsize){
    adapt_at = new dvector(e.get_constant_vector("MCMC.adapt_at"));
    if (max(*adapt_at) > burn_in * keep){
                cerr << "You have set the MCMC burn_in period at " << burn_in << " samples spaced by "
                     << keep << " i.e. " << burn_in * keep << " iterations. But the stepsize is still adapting at "
                     << max(*adapt_at) << " iterations. You should increase the burn-in period.\n";
        }
  }
  adaptive_covariance = e.get_bool("MCMC.adaptive_covariance",0);
  if (adaptive_covariance){
    adapt_covariance_at = new dvector(e.get_constant_vector("MCMC.adapt_covariance_at"));
    if (max(*adapt_covariance_at) > burn_in * keep){
                cerr << "You have set the MCMC burn_in period at " << burn_in << " samples spaced by "
                     << keep << " i.e. " << burn_in * keep << " iterations. But the covariance is still adapting at "
                     << max(*adapt_covariance_at) << " iterations. You should increase the burn-in period.\n";
    }
        adaptive_covariance_stepsize = e.get_constant("MCMC.adaptive_covariance_stepsize",0);
        adaptive_covariance_discard = e.get_int("MCMC.adaptive_covariance_discard");
        adaptive_covariance_transitions = e.get_int("MCMC.adaptive_covariance_transitions");
  }
  machine_names = e.get_vector_of_strings("MCMC.machine_names",std::vector<std::string>());
  subsample_size = e.get_int("MCMC.subsample_size",-1);
  systematic = e.get_bool("MCMC.systematic",0);
  prior_reweighting = e.get_bool("MCMC.prior_reweighting",0);
  if (systematic && prior_reweighting){
    fatal("You can't set both MCMC.systematic and MCMC.prior_reweighting.");}
};
////////////////////////////////////////////////////////////////////////

// Create particular instantiations of the template
template class Estimation_section<double, dvector, dmatrix>;
template class Estimation_section<dvariable, dvv, dvm>;
template class Free_parameters<double, dvector, dmatrix>;
template class Free_parameters<dvariable, dvv, dvm>;
template class Ageing_error<double, dvector, dmatrix>;
template class Ageing_error<dvariable, dvv, dvm>;
