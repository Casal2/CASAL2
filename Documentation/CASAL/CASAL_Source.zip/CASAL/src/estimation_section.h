// const char* time_stamp = "$Date: 2007-11-21 15:46:32 +1300 (Wed, 21 Nov 2007) $\n";
// const char* estimation_section_id = "$Id: estimation_section.h 1797 2007-11-21 02:46:32Z adunn $\n";

#if !defined(ESTIMATION_SECTION)
#define ESTIMATION_SECTION

//############################## ESTIMATION SECTION ##############################
#include <iostream>
#include <string>
#include "development.h"
#include "population_section.h"
#include "parameter_set.h"

// Forward declarations
template<CDVM> class Basic_population_section;
template<CDVM> class Free_parameters;
template<CDVM> class Observations_dataset;
template<CDVM> class Ageing_error;
template<CDVM> class Qs;
template<CDVM> class Penalties;
class Print_requests;
template<CDVM> class MCMC_settings;
template<CDVM> class Scalar_prior;
template<CDVM> class Vector_prior;
template<CDVM> class Observations;


////////////////////////////////////////////////////////////////////////////////////
template<CDVM>
class Estimation_section{
  // This class contains pointers to:
  //   -an Observations_dataset object containing all the observations
  //   -a Qs object containing the values of the q's and curvature parameters b,
  //     plus, if q's are nuisance, the bounds, & priors if applicable, on q
  //   -a Free_parameters object containing the current values of the free parameters,
  //     and their bounds, and priors if applicable
  //   -a Population_section
  //   -a Penalties object describing all the penalties to the objective function
  //   -a Print_requests object describing the things the estimation and population sections
  //     should print out as they go
  //   -a MCMC_settings object if applicable.
  //
  //  and
  //   -population, estimation, and output Parameter_sets (p, e, and o)
  //   -get_objective_function() which calculates the SS, negative-log-likelihood or -posterior,
  //     and fills in 'components'
  //   -insert() which is used to copy values out of the Free_parameters into the model. It
  //     inserts all the current free parameter values into the population Parameter_set and
  //     applies them using set_annual_cycle: it packs estimated q's and b's into the Qs object:
  //     if the overall_variability is free, applies it to the Observations_dataset object:
  //     if ageing error parameters are free, applies them to the Ageing_error object.
  //     In general insert() is responsible for copying all free parameters into the model.
  //     It does this automatically for all population parameters, but whenever a new
  //     estimable estimation parameter is added, it will need to be added into insert().
  //   -point_estimate() which estimates the parameters so as to minimise the objective
  //     function, using Betadiff, leaves the results in the 'free_parameters' object,
  //     stores the covariance in 'covariance' if requested, and returns the optimal function value.
  //   -profile() which does likelihood / posterior profiles
  //   -run_MCMC() which generates a Markov chain. The 'start' argument is optional (without it,
  //    the chain starts at or near the point estimate as specified by the parameters) and the
  //    last three arguments are only used when appending to an existing chain.
  //
  // The Estimation_section is constructed from the filenames from which to extract p and e,
  //    plus a pointer to a Print_requests object,
  //    plus several arguments specifying what the estimation section will be used for.
public:
  std::string estimator;
  std::string q_method;
  int do_MCMC, do_covariance, do_yields, simulation_length;
  double grad_tol;
  long int RNG_seed;
  Basic_population_section<DVM>* population_section;
  Free_parameters<DVM>* free_parameters;
  std::vector<DOUBLE> components;
  std::vector<std::string> component_names;
  dmatrix *covariance;
  Observations_dataset<DVM>* observations_dataset;
  Ageing_error<DVM>* ageing_error;
  Qs<DVM>* qs;
  Penalties<DVM>* penalties;
  Print_requests* print_requests;
  MCMC_settings<DVM>* mcmc_settings;
  Parameter_set<DVM> p;
  Parameter_set<DVM> e;
  int reparameterisation;
  std::vector<std::string> user_components;
  DOUBLE get_objective_function();
  void insert_free_parameters();
  double point_estimate(int& status, int multiphase = 1, int finite_differences = 0);
  int phases;
  void profile(string parameters_output_file = "", const VECTOR& minimum = VECTOR("{-1}"));
  void run_MCMC(const dvector& posterior_mode, const dmatrix& _covariance,
                ostream& samples_out, ostream& objectives_out, const dvector& _start = dvector("{-1}"),
                int starting_sample = 0, double starting_stepsize = 0, int starting_successful_jumps = 0);
  void tweak_covariance_matrix(dmatrix& covariance); // used by run_MCMC
  void trivariate_normal_test();
  void print_objective_components(ostream& out = cout);
  void print(ostream& out = cout);
  Estimation_section(const std::string& population_file, const std::string& estimation_file,
                     Print_requests *_print_requests,
                     int _do_MCMC, int _do_covariance, int _do_yields = 0, int _simulation_length = 0,
                     long int _RNG_seed = 0);
  ~Estimation_section();
};


//############################## PARAMETERS ##############################
template<CDVM>
class Free_parameters{
  // This object contains the names and current values of the free parameters,
  //  their phases, in point estimation,
  //  the bounds on them, and in a Bayesian analysis, the priors.
  // The only free parameters not stored here are the q's, iff they are treated as
  //  nuisance parameters.
  //
  // get() gets the current values of the free parameters.
  // get_scalar(i) the current value of scalar parameter i (i=0,1,...) and similarly get_vector(i).
  // set() sets the free parameters to a VECTOR of values.
  // get_lower_bounds() and get_upper_bounds() return vectors containing the bounds
  //  (used by the minimiser): within_bounds() checks whether a vector of parameter values
  //  is within the bounds or not.
  // fix_scalar() and fix_vector() fix parameters by setting the lower and upper bounds
  //  equal at the current parameter values; free_scalar() and free_vector() revert to the original.
  //
  // get_prior() returns the negative-log-prior and fills in its components in 'prior_components'.
  //
  // We store the current values in a single VECTOR, which is the concatenation of
  //  all scalar and vector parameters. This is a nasty way to store data; we use it
  //  because the Betadiff minimiser wants to be given a vector of independent variables.
  //
  // 'scalar_same[i]' stores the names of parameters which are constrained to be the same as
  //  'scalar_parameter_names[i]'; ditto 'vector_same[i]' and 'vector_parameter_names[i]'.
  //
  // 'scalar_phases' and 'vector_phases' store the phases at which each parameter is estimated.
  //
  // 'scalar_MCMC_fixed' and 'vector_MCMC_fixed' indicate whether each parameter is fixed during MCMC.
  //
  // The 'check_file_header' and 'make_file_header' functions are used for files
  //  of free parameter values. 'make_file_header' returns a string which can be used
  //  as the header row of an output file. 'check_file_header' takes the header row
  //  of an input file, checks that it is valid, errors out if not.
  //
  // As implemented here, this class does not provide for joint priors. May need to be modified later.
public:
  int n_scalars;
  std::vector<std::string> scalar_parameter_names;
  std::vector<Scalar_prior<DVM>*> scalar_priors;
  std::vector<std::vector<std::string> > scalar_same;
  std::vector<int> scalar_phases;
  std::vector<int> scalar_MCMC_fixed;
  int n_vectors;
  std::vector<std::string> vector_parameter_names;
  std::vector<int> vector_parameter_sizes;
  std::vector<int> vector_parameter_is_ogive;
  std::vector<Vector_prior<DVM>*> vector_priors;
  std::vector<std::vector<std::string> > vector_same;
  std::vector<int> vector_phases;
  std::vector<int> vector_MCMC_fixed;
  VECTOR get();
  DOUBLE get_scalar(int i);
  VECTOR get_vector(int i);
  void set(const VECTOR& v);
  dvector get_lower_bounds();
  dvector get_upper_bounds();
  int within_bounds(const VECTOR& v);
  void fix_scalar(int par_no);
  void fix_vector(int par_no);
  void fix_vector(int par_no, int element_no);
  void free_scalar(int par_no);
  void free_vector(int par_no);
  std::vector<DOUBLE> prior_components;
  DOUBLE get_prior();
  void check_file_header(const std::string& header);
  int get_input_file_by_line(ifstream* input_file, std::string parameters_input_file, dvector& parameter_values);
  std::string make_file_header();
  void print_bounds_check(ostream& out = cout);
  void print(int priors = 1, ostream& out = cout);
  Free_parameters(const std::string& q_method, Parameter_set<DVM>& e, Parameter_set<DVM>& p);
  ~Free_parameters();
private:
  VECTOR *values;
  std::vector<double> scalar_original_lower_bounds;
  std::vector<double> scalar_original_upper_bounds;
  std::vector<dvector> vector_original_lower_bounds;
  std::vector<dvector> vector_original_upper_bounds;
};


//############################## Minimiser interface ##############################
template<CDVM>
class Minimiser_interface{
  // Used as an interface between the Estimation_section and the Betadiff function 'optimise'.
public:
  DOUBLE operator()(Estimation_section<double,dvector,dmatrix>& est,
                    const dvector& par_values){
    DEBUG2("Minimiser_interface::operator()");
    est.free_parameters->set(par_values);
    return est.get_objective_function();
  }
  DOUBLE operator()(Estimation_section<dvariable,dvv,dvm>& est,
                    const dvv& par_values){
    DEBUG2("Minimiser_interface::operator()");
    est.free_parameters->set(par_values);
    return est.get_objective_function();
  }
  DOUBLE operator()(Estimation_section<double,dvector,dmatrix>& est,
                    const dvv& par_values){
    // this should never happen, we put it in to make the code compile
    fatal("weird error");
  return 0;
  }
  DOUBLE operator()(Estimation_section<dvariable,dvv,dvm>& est,
                    const dvector& par_values){
    // this should never happen, we put it in to make the code compile
    fatal("weird error");
  return 0;
  }
};


//############################## Q'S ##############################
template<CDVM>
class Qs{
  // Contains q and b parameters used in calculating the fits to relative observations.
  // The values of q and b can be inserted into the Qs object by some higher level function,
  //  and the Observations objects can then extract them (by name).
  // The Qs object also has the get_nuisance_qs function which calls calculate_fits() for each
  //  relative Observations, uses the results to calculate nuisance q's, fills them in
  //  in the Qs.q object, and in a Bayesian analysis, fills in q_prior_components.
  // Construct the Qs object from an Observations_dataset object, which tells it
  //  what q's there are, and fills in pointers to the Qs in all Observations observations
  //  and vice versa: then from the estimation parameters it extracts q's if method="free"
  //  (these starting values are not needed for "nuisance"),
  //  and bounds, and priors in a Bayesian analysis, on q, if method is not "free"
  //  (if "free" then the bounds and priors are kept with those of the rest of the free parameters),
  //  and curvature parameters b, if given.
public:
  std::string method;              // "free","nuisance"
  int curvature;                   // does any relative time series have curvature?
  std::string q_type;              // if curvature, what is the q_type ('standard' or 'scaled')
  std::vector<std::string> q_names;// all the q's
  std::map<std::string,DOUBLE> q;  // contains the current values of q, by name
  std::map<std::string,DOUBLE> b;  // contains the current values of b, by name
                                   //  (all 1 if !curvature)
  void get_nuisance_qs(Basic_population_section<DVM>& popn);
  std::map<std::string, Scalar_prior<DVM>*> q_priors;
  int bayesian;
  std::map<std::string,DOUBLE> q_prior_components;
  int any_relative_indices();
  std::map<std::string, std::vector<Observations<DVM>*> > ts_ptrs;
  // ts_ptrs[name] is a vector of pointers to the Observations sharing the q called 'name'.
  // Used by get_nuisance_qs()
  std::map<std::string, std::string> ts_objectives;
  // ts_objectives[name] says what kind of objective function is being used by the
  //  Observations sharing the q called 'name'.
  // They should all have the same objective function (this is checked by Qs::Qs).
  void print_bounds_check(ostream& out = cout);
  void print(ostream& out = cout);
  Qs(const std::string& _method, Observations_dataset<DVM>& o,
     Parameter_set<DVM>& e);
  ~Qs();
};


//############################## AGEING ERROR ##############################
template<CDVM>
class Ageing_error{
  // This class is used to contain the misclassification matrix and apply it to
  //  a set of numbers-at-age data. Currently, the same ageing error regime is applied
  //  in each year. The misclassification matrix can be specified in several different ways.
  // If 'ageing_error' is set to 0, 'misclassification' need not be specified and 'apply'
  //  will not be called.
  // set_off_by_one and set_normal are used to construct the misclassification matrix.
public:
  int ageing_error;
  // is there any ageing error?
  std::string type;
  // can be "none", "off_by_one", "normal", "misclassification_matrix"
  int min_age, max_age, plus_group;
  MATRIX* misclassification;
  // The [i,j]th element is the probability of classifying a fish of age i as age j.
  void apply(MATRIX& numbers_at_age);
  void set_off_by_one(const DOUBLE& p1, const DOUBLE& p2);
  void set_normal(const DOUBLE& cv);
  void print(ostream& out = cout);
  Ageing_error(Parameter_set<DVM>& e, Basic_population_section<DVM>& popn);
  ~Ageing_error();
private:
  int k;
};


//############################## MCMC SETTINGS ##############################
template<CDVM>
class MCMC_settings{
  // Holds parameters relating to the MCMC process.
public:
  double start; // If 0, start at the posterior mode. If >0, this is the factor by which the
                // covariance matrix at the posterior mode should
                // be multiplied when drawing a random starting point.
                // In either case, the user can override by providing
                // an input file containing the starting point.
  int length;  // the length of the chain, unless you interrupt it first
  int keep;    // record only samples of numbers n such that n is evenly divisible by keep
  int proposal_t; // should the multivariate t be used as the proposal distribution (rather than MVN)?
  int df; // if so, how many df should be used?
  double max_cor; // maximum absolute correlation in the covariance matrix of the proposal distn
  std::string covariance_adjustment_method;  //method for adjustment of small variance/correlations of covariance matrix
  double min_diff; // minimum diff of the covariance matrix of the proposal distn (either a min sd. or min correlation
  double stepsize;   // the initial stepsize. If 0, the default of 2.4/sqrt(n. free params) is used.
  int adaptive_stepsize; // should the MCMC stepsize be altered during the run?
  dvector *adapt_at; // if so, at what iterations?
  int adaptive_covariance; // should the MCMC covariance matrix be altered during the run?
  dvector *adapt_covariance_at; // if so, at what iterations?
  double adaptive_covariance_stepsize;   // The new stepsize used whenever the covariance matrix is altered.
  int adaptive_covariance_discard; // the initial portion of the chain discarded before estimating the covariance matrix, when adaptive covariance is used
  int adaptive_covariance_transitions; // the chain must move at least this many times in the portion of the chain used for estimating the covariance matrix, when adaptive covariance is used
  std::vector<std::string> machine_names; // these are inserted into the names of MCMC results
                                          // files; they are only used by the code when trying
                                          // to find all the results files for a given run.
  int burn_in; // the length of the burn-in period
  int subsample_size; // how big a subsample should be collected from the results files?
  int systematic; // should the posterior subsampling be systematic?
  int prior_reweighting; // should the posterior subsample be generated using prior reweighting?
  void print(ostream& out = cout);
  MCMC_settings(Parameter_set<DVM>& e);
};

//############################## END OF ESTIMATION_SECTION.h ##############################
#endif
