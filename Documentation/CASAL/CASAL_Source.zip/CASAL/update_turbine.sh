# /bin/bash
cp ~/CASAL/src/casal /data01/fisheries-modelling/bin/casalv230

