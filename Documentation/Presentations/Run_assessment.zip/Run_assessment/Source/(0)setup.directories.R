
#
# DIR hold pathnames for functions, models, and results
#


DIR         <- list()

DIR$Models  <-  "Models/"	# holds directories of input files
DIR$Data    <-  "Data/"
DIR$Figures <-  "Figures/"
DIR$Tables  <-  "Tables/"

DIR$AssessmentCode <- "Source/Casal2_functions/"	#aux functions to Casal2 R library