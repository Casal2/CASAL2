#
# plot biomass adn catches for hake HAK 1 assessment
#

DIR

#CPUE + 95% CI assuming normal dist.
cpue <- read.table(paste0(DIR$Data,"CPUE.txt"),T)
cpue$error_value <- sqrt(cpue$error_value^2 + 0.1^2) #add process error
plot(c(1991,2017),c(0,1.74),pch=" ",las=1,xlab="Year",ylab="CPUE")
lines(cpue$year,cpue$obs,lwd=2)

segments(cpue$year,cpue$obs - 2 * cpue$obs * cpue$error_value,y1=cpue$obs + 2 * cpue$obs * cpue$error_value)

#survey

sur <- read.table(paste0(DIR$Data,"survey.biomass.txt"),T)
sur$error_value <- sqrt(sur$error_value^2 + 0.2^2) #add process error
plot(c(1991,2017),c(0,8000),pch=" ",las=1,xlab="Year",ylab="Biomass (t)")
lines(sur$year,sur$obs,lwd=2)

segments(sur$year,sur$obs - 2 * sur$obs * sur$error_value,y1=sur$obs + 2 * sur$obs * sur$error_value)

#catch

catch <- read.table(paste0(DIR$Data,"catch.txt"),T)
plot(c(1974,2018),c(0,4000),pch=" ",las=1,xlab="Year",ylab="Catch (t)")
lines(catch$year,catch$subaF,lwd=2)

lines(cpue$year,cpue$obs*2000,lwd=2,lty=2,col=2)
