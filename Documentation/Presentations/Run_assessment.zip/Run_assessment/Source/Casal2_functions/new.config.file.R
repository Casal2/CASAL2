# write.config 

write.config <- function(config,	# R object of base config
			preFix	= "",	# identify new version of input files; default assumes a new directory
			newModel	# dir to write new config file to; must exist
		){

#
# add another config file, updated to reflect new alternative fixed parameter(s)
# 	add preFix onto subordinate file names 
#	also onto config file name
# Assume that this contains "!include" commands only
#	
# Note that subordinate files in config must  
#	have filenames changed too with the preFix 
#	(i.e., replicate all these files and then change parameters and write back out again)
#	Done outside of this function

# Returns: vector of filenames found in config

#preFix   <- "M.0.3."
# write.config(config,preFix,"HAK.M.0.3.")
#newModel <- thisModel
#assmue all !include lines

IN <- substr(config,1,8) =="!include"	#"!include" must be at the start of the line
config[IN]
#in testing:
# [1] "!include \"Population.csl2\"\t# Stream this file, as is,into casal2"
# [2] "!include \"Estimation.csl2\"\t# These names are convention only;"   
# [3] "!include \"Observation.csl2\"\t#\thelps make model readable"         
# [4] "!include \"Reports.csl2\"\t\t#\tuse one file if you must" 

strsplit(config[IN][1],"\"")
# in testing:
#[[1]]
#[1] "!include "                             
#[2] "Population.csl2"                       
#[3] "\t# Stream this file, as is,into casal2"

#strsplit(config[IN][1],"\"")[[1]][2] #[1] "Population.csl2"


# add preFix to subordinate input filenames in config & then write out new config file

sub.filenames     <- NULL	#save filenames
new.sub.filenames <- NULL	#save new filenames

lines <- c(1:length(config))[IN]
for(ii in lines){
	thisLine  		<- strsplit(config[ii],"\"")
	tmp       		<- thisLine[[1]][2]	#file name
	sub.filenames 		<- c(sub.filenames , tmp)
	tmp       		<- paste0(preFix,tmp)
	new.sub.filenames 	<- c(new.sub.filenames , tmp)

	thisLine[[1]][2] <- tmp

	config[ii] <- paste0(thisLine[[1]], collapse="\"")
	}
config

new.config.name <- paste0(newModel,"/",preFix,"config.csl2")

cat(config[1],"\n",file=new.config.name)
for(ii in 2:length(config))
	cat(config[ii],"\n",file=new.config.name,append=T)

print(paste("new config file ",new.config.name, "written to directory ", newModel))

return(data.frame(	filename     = I(sub.filenames),
			new.filename = I(new.sub.filenames) )) 
}


