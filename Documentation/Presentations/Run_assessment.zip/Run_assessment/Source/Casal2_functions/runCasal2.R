runCasal2 <- function(modelPath	=".", 	# model directory pathname, default current directory
		modelPrefix    	= "", 	# Prefix for config filename
		modelExtension  = "csl2",	# Not needed?
		wait 		= FALSE, 
		runType		="e", 	# run type
		input 		= "", 	# Start parameter values filename ("-i" format)
		output 		= "",	# Output filenames for -o option (MPD in "-i" format)
		output.type	= "o",	#   use "t" for tabular output from mcmc run
		Casal2		= "casal2"	# exe to use. Default is installed version. Or, e.g., "./casal2new.exe"
		){
  # runs config file = <modelPath>/<modelPrefix>config.csl2
	# other files specified in config file
  # example: 
  # runCasal2()	#using config.csl2 is in current directory
  # 
 # Sys.which("casal2")	#which executables that can be run

    	cat(paste0("Running in ",runType, " mode for model ", modelPrefix, "config.", modelExtension, ". ", ifelse(wait, "Waiting...", "")))


    	config.name <- paste0("\"", modelPath,"/", modelPrefix, "config.", modelExtension, "\"")
                        
	cat("\n config filename ",config.name,"\n")
	args <- paste0(" -c ",config.name,
			 ifelse(input=="","", paste0(" -i ", file.path(modelPath, input), " "))
			, " -",  runType, 
                         ifelse(output=="", "", paste0(" -",output.type," ", file.path(modelPath, output))))
	stdout <- file.path(modelPath, paste0(modelPrefix,runType, ".out.txt"))
	stderr <-  file.path(modelPath, paste0(modelPrefix,runType,".err.txt"))

	cat("\n  Command is : \n ",Casal2, args," > ",stdout," 2> ",stderr,"\n")

    	err <- system2(command = Casal2 , 
            args   = args, 
            stdout = stdout, 
            stderr = stderr, wait=wait)

    	if(err != 0) return(paste("Casal2 failed, system2 error code is ",err))
}
