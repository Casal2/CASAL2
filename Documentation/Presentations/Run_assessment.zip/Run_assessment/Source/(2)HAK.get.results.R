
#
# HAK test case
# 	table of parameter estimates, log-liklihoods
# 	plot fits to obervations
# 	plot SSB, YCS
#

#library(casal)
library(Casal2)
library(xtable)
## bring in functions

source(paste0(DIR$AssessmentCode,"obj.R"))
resultsFile  <- paste0(thisModel,"/e.out.txt")

cas2_mpd = Casal2::extract.mpd(resultsFile)
# Read 3448 items

 names(cas2_mpd)
# [1] "Init"                       "state1"                    
# [3] "state2"                     "age_length_weight_male_1"  
# [5] "age_length_weight_female_1" "age_length_weight_male_2"  
# [7] "age_length_weight_female_2" "estimated_values"          
# [9] "estimated_summary"          "obj_fun"                   
#[11] "Hess"                       "Covar"                     
#[13] "Recruitment"                "Fishing"                   
#[15] "maturity_sel_m"             "maturity_sel_f"            
#[17] "subaFsel"                   "subaTANselA"               
#[19] "CPUE"                       "subaOBSage"                
#[21] "subaTANbiomassDEC"          "subaTANageDEC"             
#[23] "subaTANqA"                  "CPUEq"                     
#[25] "SSB"                        "Ageing"                    
#[27] "One"                        "messages_encountered" 

# plot SSB
cas2_ssb = plot.derived_quantities(cas2_mpd, "SSB", plot.it = F)

par(mfrow = c(1,2))
ymax <- max(cas2_ssb[,"SSB"])*1.2
plot(rownames(cas2_ssb), cas2_ssb[,"SSB"], ylim = c(0,ymax), lwd = 2, type = "l",
     xlab = "years", ylab = "SSB",las=1)

plot.fits (cas2_mpd,"CPUE",las=2)

#plot.fits (cas2_mpd,"subaTANbiomassDEC",las=2)

#plot.fits (cas2_mpd,"subaOBSage",plot.it = FALSE)



#Objective function

cas2_obj = split_obj(cas2_mpd, label = "obj_fun") ## custom function,
cas2_obj




############other plots etc
## Recruitment
xxx <- plot.ycs (cas2_mpd,"Recruitment",las=1)
plot(cas2_mpd$Recruitment$ycs_years, cas2_mpd$Recruitment$true_ycs, ylab  = "True YCS", xlab = "years",
      type="l",col = "black", lwd =2 ,lty = 1,las=1)




tab = xtable(cas2_obj, digits = 8, caption = "Casal2 objective function contributions for the main data sets.")

print(tab)
% latex table generated in R 3.6.3 by xtable 1.8-4 package
% Thu Dec 30 14:28:05 2021
\begin{table}[ht]
\centering
\begin{tabular}{rlr}
  \hline
 & Label & Value \\ 
  \hline
1 & subaTANbiomassDEC & -15.23024800 \\ 
  2 & subaTANageDEC & 388.95100000 \\ 
  3 & subaOBSage & 397.14183000 \\ 
  4 & CPUE & -30.37154500 \\ 
  5 & B0 & 10.89640000 \\ 
  6 & CPUE\_q & -10.58300000 \\ 
  7 & subaTANA\_q & -1.78570000 \\ 
  8 & fishery\_sel\_a50 & 0.00000000 \\ 
  9 & fishery\_sel\_ato95 & 0.00000000 \\ 
  10 & survey\_sel\_a50 & 0.00000000 \\ 
  11 & survey\_sel\_ato95 & 0.00000000 \\ 
  12 & CPUE\_process\_error & -1.67926000 \\ 
  13 & rec\_ycs & -28.31493590 \\ 
  14 & Total Objective & 709.02400000 \\ 
   \hline
\end{tabular}
\caption{Comparison of Casal2 and CASAL
             objective function contributions for the main data sets.} 
\end{table}



#
# read in csl2 files & write them out again
#

library(help="Casal2" )

extract.csl2.file
write.csl2.file 

xxx <- extract.csl2.file("Population.csl2", path = paste0(thisModel,"/"))


#
# config alteration
#

config <- readLines(paste0(thisModel,"/config.csl2")) #,what=character())
config


#test code
source(paste0(DIR$AssessmentCode,"new.config.file.R"))


#
# copy & change name for input file according to the new config file
#


preFix       <- "M.0.3."
newModelPath <- paste0(thisModel,".",preFix)


if(!dir.exists(newModelPath)){dir.create(newModelPath)}

subordinate.files <- write.config(config,preFix,newModelPath)	# adapt config into <preFix>config.csl2
							# using preFIx and writes it out into nextModel
							# Returns subordinate filenames for code below

subordinate.files
#           filename           new.filename
# 1  Population.csl2  M.0.3.Population.csl2
# 2  Estimation.csl2  M.0.3.Estimation.csl2
# 3 Observation.csl2 M.0.3.Observation.csl2
# 4     Reports.csl2     M.0.3.Reports.csl2

# copy sub files into new model dir (may be the same as the old one)
for(f in 1:nrow(subordinate.files)){
  # i've had trouble with file.copy not overwritting the original even with overwrite=TRUE
  ## so.. removing them first to make sure

  newFile  <- file.path(newModelPath, subordinate.files$new.filename[f])
#paste0(newPrefix, modelFiles[f], ".", newExtension))
  baseFile <- file.path(thisModel,subordinate.files$filename[f])
# paste0(basePrefix, modelFiles[f], ".", baseExtension))
  suppressWarnings(file.remove(newFile))	# new dir then no files & a warning is generated
  file.copy(from = baseFile, to = newFile)
}


#
# read in file with M and change and write it out
# (here, M.0.3.Population.csl2)

#read file in
xxx <- extract.csl2.file(file.path(thisModel,subordinate.files$filename[1]))	#Population.csl2
# Read 174 items
# [1] "The 'csl' input parameter file has 21 commands, and 168 lines"
# [1] "Equilibrium_phase"
# [1] "Jul_Jan"
# ...
# [1] "CPUEq"


#change M  (note in Recruitment section
names(xxx$'process[Recruitment]')	#Note naming convestions in ''
#  [1] "type"                  "categories"            "proportions"          
#  [4] "b0"                    "standardise_ycs_years" "ycs_values"           
#  [7] "ycs_years"             "steepness"             "ssb"                  
# [10] "age"

names(xxx$'process[Fishing]')
# [1] "type"                  "m"                     "time_step_proportions"
# [4] "relative_m_by_age"     "categories"            "Table"

xxx$'process[Fishing]'$m $value <- 0.30	# Change natural mortality; note syntax


#write out again

write.csl2.file(xxx, file.path(newModelPath, subordinate.files$new.filename[1]))

