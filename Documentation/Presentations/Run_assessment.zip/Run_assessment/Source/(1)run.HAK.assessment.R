
#
# demostrate Casal2 assessment using hake test case 
#

source(paste0(DIR$AssessmentCode,"runCasal2.R")


# input files are in Models/HAK/
inputDir   <- "HAK"	#dir in Models that hols input files
thisModel  <- paste0(DIR$Models,inputDir)  #pathname to HAK

runCasal2(thisModel,Casal2="./casal2new.exe")	# using config.csl2

#
# check Models/HAK/e.err.txt file to see if it ran correctly
# Results are in Models/HAK/e.out.txt


#
# change M to 0.30
#

runCasal2(newModelPath, modelPrefix = "M.0.30.",Casal2="./casal2new.exe")	# using config.csl2


