#!/bin/bash
grep \$Id $1
