long ASLdate_ASL = 20130622;
