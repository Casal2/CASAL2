addpath /home/amart/work/projects/CASAL2/dev/casal2-development/ThirdParty/cppad/Ipopt-releases-3.12.4/lib
