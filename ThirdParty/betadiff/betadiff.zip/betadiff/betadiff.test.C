// const char* time_stamp = "$Date: 2006-08-08 15:18:31 +1200 (Tue, 08 Aug 2006) $\n";

#include "betadiff.h"

class Model{}; // nothing to it in this particular case
class Objective{
 public:
  dvariable operator()(Model& m,const dvv& x);
};

int main(){
  // reading vectors from a string
  dvv stringtest("{100,5,20}");
  cout << stringtest << '\n';
  // reading vectors from file
  stringtest.fill("testfile.dat");
  cout << stringtest << '\n';
  // reading matrices from a string
  dvm test1("{1,2,3}{2,3,4}");
  cout << test1 << '\n';
  // reading matrices from file
  dmatrix test2("testfile.mat",1);
  cout << test2 << '\n';
  // arithmetic
  dvariable w, x, y, z;
  w = 0; x = 1; y = 2; z = 3;
  double a, b, c, d;
  a = 0; b = 1; c = 2; d = 3;
  cout << x + y + z*b + z*y << '\n';
  cout << sin(x) << '\n';
  cout << pow(z,y) << ' ' << pow(z,c) << '\n';
  dvv v1(stringtest);
  dvector v2(value(stringtest));
  cout << v1 << ' ' << v1 + v1 << ' ' << v1 + v2 << '\n';
  cout << elem_prod(v1,test1[1]) << ' ' << test1 * v1 << '\n';
  // random number generation
  dvv randtests(15);
  long int seed=100;
  randtests.fill_randu(seed);
  cout << randtests << '\n';
  seed=1;
  randtests.fill_randu(seed);
  cout << randtests << '\n';
  seed=0;
  randtests.fill_randu(seed);
  cout << randtests << '\n';
  randtests.fill_randn(seed);
  cout << randtests << '\n';
  dvector for_mn(1,3); for_mn[1]=0.6; for_mn[2]=0.3; for_mn[3]=0.1; //same result if indices (2,4)
  randtests.fill_multinomial(seed,for_mn); cout << randtests << '\n';
  cout << randtests << '\n';
  // means and standard deviations
  cout << "mean " << mean(randtests) << " stdev " << std_dev(randtests) << '\n';
  // vector size
  dvv lv(5);
  lv.initialize();
  cout << "length of lv is " << lv.size() << '\n';
  cout << "lv is " << lv << " and starts at " << lv.indexmin() << '\n';
  // matrix size
  dvm lm(1,2,4,6);
  lm.initialize();
  cout << "size of lm is " << lm.rowsize() << " by " << lm.colsize() << '\n';
  cout << "index ranges are " << lm.rowmin() << " to " << lm.rowmax() << " and " << lm.colmin() << " to " << lm.colmax() << '\n';
  // index a vector by a scalar
  lv.fill("{3,4,5,6,7}");
  int i = 2;
  cout << lv[i] << '\n';
  lv[i] = 2;
  cout << lv << '\n';
  // index a vector by a vector
  dvector iv("{1,3,5}");
  cout << lv[iv] << '\n';
  // index a matrix by two scalars
  cout << test1[2][2] << '\n';
  test1[2][2] = test1[2][1];
  cout << test1 << '\n';
  test1[1] = iv;
  cout << test1 << '\n';
  // test the optimiser, and hence the gradient calculations
  dmatrix hessian(1,3,1,3);
  dvector start("{1,2,3}");
  dvector lower_bounds("{0,0,0}");
  dvector upper_bounds("{5,5,5}");
  Model model;
  Objective objective;
  int maxit = 3, maxeval = 5;
  int status;
  optimise<Model,Objective>(model,objective,start,lower_bounds,upper_bounds,
          status,100,maxit,maxeval,2e-3,0,
          &hessian,0,1);
  cerr << "done optimisation\n";
  cout << start << ' ' << hessian << ' ' << '\n';
  // tapestats - see ADOL-C
  int counts[11];
  tapestats(0,counts);
  cout << counts[0] << " " << counts[1] << " " << counts[2] << " " << counts[7] << '\n';
  // boundp
  dvariable bounded=boundpin(14,10,20);
  cout << bounded << " ";
  dvariable zpen = 0;
  cout << boundp(bounded,10,20,zpen) << '\n';
  cout << zpen << "\n";
  cout << boundp(0.999,10,20,zpen) << '\n';
  cout << zpen << "\n";
  cout << boundp(1.2,10,20,zpen) << '\n';
  cout << zpen << "\n";
  // some passive matrix operations
  dmatrix a1(1,3,1,3),a2(2,4,2,4),bm(3,2);
  dvector v(3);
  dvariable xin = 2;
  a1.rowfill_seqadd(1,1,3); a1.rowfill_seqadd(2,2,3); a1.rowfill_seqadd(3,3,3);
  a2.rowfill_seqadd(2,1,1); a2.rowfill_seqadd(3,2,1); a2.rowfill_seqadd(4,3,1);
  bm.colfill_randu(1,1);
  bm.colfill_randbi(2,1,0.2);
  v.fill("{2,1,0}");
  cout << '\n'<< a1 << '\n'<< a2 << '\n'<< bm;
  cout << v << '\n';
  cout << '\n'<< a1+a2 << '\n';
  cout << a1+2*a2 << '\n';
  cout << a1+1 << '\n';
  cout << a1+xin<< '\n';
  cout << '\n'<< a1*a2 << '\n'<< a1*bm << '\n'<< a1*v << '\n'; // << v*a1 << bm*a1
  cout << '\n'<< elem_div(a1,a2) << '\n' << elem_prod(a1,a2) << '\n';
  cout << norm(a1) << ' ' << norm2(a2) << ' ' << rowsum(a1) << ' ' << colsum(a2) << '\n';
  cout << '\n'<< identity_matrix(1,3) << extract_diagonal(a1) << '\n';
  // multivariate normal generation
  dvector mean("{1,2,3}");
  dmatrix covar("{1,0.707,0.141}{0.707,2,0.6}{0.141,0.6,0.5}");
  dmatrix rands(1,3,1,100);
  dmatrix cholmat(1,3,1,3);
  cout << chol(covar,cholmat);
  cout << "\n" << cholmat << "\n";
  dmatrix temp("{1,2,3}{2,1,4}{3,4,2}");
  cout << chol(temp ,cholmat);
  cout << "\n" << cholmat << "\n";
  rands.fill_mvnorm(0,mean,covar);
  cout << rands << "\n\n";
  rands.fill_mvnorm(0,mean,covar);
  cout << rands << "\n\n";
  dvector randsv(1,3);
  randsv.fill_mvnorm(2,mean,covar);
  cout << randsv << "\n\n";
  // matrix inversion
  dmatrix hessian2("{2,0.5,0}{0.5,1,0}{0,0,0}");
  cout << inverse(hessian2) << '\n';
  return 0;
}

dvariable Objective::operator()(Model& m, const dvv& x){
  dvm m2("{1,2,3}{4,5,6}");
  x[3] = x[3] + x[1];
  m2[2] = x;
  m2[1][2] = x[2];
  m2[1][1] = 3;
  dvv y(m2[1]);
  y += m2[1];
  y[2] += m2[2][2];
  y *= x;
  y[1] = pow(y[1],x[2]);
  dvariable d = x[2];
  y[2] += sin(d);
  dvariable z;
  z = pow(y[1]-mean(y),2) + pow(y[2]-mean(y),2) + pow(y[3]-mean(y),2);
  return z;
}
