#ifndef _TAYUTIL_H_
#define _TAYUTIL_H_

/*
   --------------------------------------------------------------
   File tayutil.h of ADOL-C version 1.8.0         as of Nov/30/98
   --------------------------------------------------------------
   tayutil.h defines the prototypes for the functions from 
   tayutil.c.  See tayutil.c for an explanation of the 
   functionality of these routines.

   Last changes: 
     981130 olvo: automatic cleanup from utils.C moved here
     980921 olvo: new interface of void overwrite_scaylor(..) to
                  allow correction of old overwrite in store
     980708 olvo  new:  void overwrite_scaylor(..)

   --------------------------------------------------------------
*/

/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/*                                                        PUBLIC EXPORTS */
#include <stdlib.h>
#include <vector>


/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/*                                                  ADOL-C INTERNAL EXPORTS */
#ifdef _ADOLC_SRC_


#ifdef __cplusplus
/****************************************************************************/
/****************************************************************************/
/*                                                       Now the C++ THINGS */



/****************************************************************************/
/****************************************************************************/
/*                                                         Now the C THINGS */
void write_scaylors(std::vector<double>, int, int);
extern "C" {
#endif


/****************************************************************************/
#ifndef __STDC__
   //int unlink(char *); //richard test
#endif


/****************************************************************************/
/*                                                            CONTROL STUFF */
int taylor_access();
void close_taylor();
void taylor_begin( int, double**,int );
void taylor_close( int, int, int );
void taylor_back ( revreal*, int*, int*, int* );
void taylor_back2( revreal**, int*, int*, int* );


/****************************************************************************/
/*                                                                   WRITEs */
void write_taylor( locint, int );
void write_scaylor( revreal );
/* olvo 980708 new nl */
void overwrite_scaylor( revreal, revreal* );
void write_scaylors( double*, int );


/****************************************************************************/
/*                                                                     GETs */
void get_taylor( locint );
void get_taylors( locint, int );

/****************************************************************************/
/*                                                               THAT'S ALL */
#ifdef __cplusplus
}
#endif

#endif /* _ADOLC_SRC_ */

#endif

