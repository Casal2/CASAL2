#define _ADOLC_SRC_

#include "dvlparms.h" /* Developers Parameters */
#include "usrparms.h" /* Users Parameters */
#include "interfaces.h"
//#include "oplate.h"
#include "adalloc.h"
#include "taputil.h"
#include "tayutil.h"

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define __null 0


static short tag;

static int for_location_cnt;
static int dep_cnt;
static int ind_cnt;
// 429 "uni5_for.cpp"
int hov_forward(
   short tnum,
   int depcheck,
   int indcheck,
   int gdegree,
   int p,
                 double *basepoint,
   double ***argument,
                 double *valuepoint,
   double ***taylors)




{


  unsigned char operation;
  int tape_stats[13];
  int ret_c =3;

  unsigned int size = 0;
  unsigned int res = 0;
  unsigned int arg = 0;
  unsigned int arg1 = 0;
  unsigned int arg2 = 0;
  unsigned int checkSize;

  double coval = 0, *d = 0;

  int indexi = 0, indexd = 0;


  int i, j, l, ls;


  double r0, x, y, divs;
  int op_buffer, loc_buffer, real_buffer, even, flag;
  static int fax, kax, pax;


  static double *T0;





  static double **T;
  static double *Ttemp;

  double *Tres, *Targ, *Targ1, *Targ2, *Tqo;

  double *TresOP, *TresOP2, *zOP;
  double *TargOP, *Targ1OP, *Targ2OP, *TqoOP;

  double T0temp;




  static double *z;
  int k = gdegree;
// 502 "uni5_for.cpp"
  int pk = k*p;
// 527 "uni5_for.cpp"
  tag = tnum;

  tapestats(tag,tape_stats);
  ind_cnt = tape_stats[0];
  dep_cnt = tape_stats[1];
  for_location_cnt = tape_stats[2];
  op_buffer = tape_stats[4];
  loc_buffer = tape_stats[5];
  real_buffer = tape_stats[6];
// 547 "uni5_for.cpp"
  set_buf_size(op_buffer,loc_buffer,real_buffer);

  if ((depcheck != dep_cnt)||(indcheck != ind_cnt))
  { fprintf((DIAG_OUT),"ADOL-C error: forward sweep on tape %d  aborted!\n",tag);
    fprintf((DIAG_OUT),"Number of dependent and/or independent variables passed"
                   " to forward is\ninconsistant with number"
                   " recorded on tape %d \n",tag);
    exit (-1);
  }
// 658 "uni5_for.cpp"
  if (k > kax || for_location_cnt > fax || p > pax)
  { if (kax || pax || fax)
    { free((char*) T0);
      free((char*) *T); free((char*) T);
      free((char*) z);
      free((char*) Ttemp);
    }
    T0 = myalloc1(for_location_cnt);
    T = myalloc2(for_location_cnt,p*k);
    z = myalloc1(k);
    Ttemp = myalloc1(p*k);
    kax = k;
    fax = for_location_cnt;
    pax = p ;
  }
// 682 "uni5_for.cpp"
  init_for_sweep(tag);

  operation=*g_op_ptr++;
  while (operation !=35)
  {
   switch (operation){






      case 37:
        get_op_block_f();
        operation=*g_op_ptr++;

        break;


      case 38:
        get_loc_block_f();
        break;


      case 39:
        get_val_block_f();
        break;

      case 36:
      case 35:
 break;






      case 102:
        arg = *g_loc_ptr++;

        if (T0[arg] != 0)
   {

         
          end_sweep();
          return (-1);
        }
        ret_c = 0;
        break;


      case 103:
        arg = *g_loc_ptr++;

        if (T0[arg] == 0)
   {

         
          end_sweep();
          return (-1);
        }
        break;


      case 104:
        arg = *g_loc_ptr++;

        if (T0[arg] > 0)
   {

         
          end_sweep();
          return (-1);
        }
        if (T0[arg] == 0)
          ret_c = 0;
        break;


      case 105:
        arg = *g_loc_ptr++;

        if (T0[arg] <= 0)
   {

         
          end_sweep();
          return (-1);
        }
        break;


      case 106:
        arg = *g_loc_ptr++;

        if (T0[arg] < 0)
   {

         
          end_sweep();
          return (-1);
        }
        if (T0[arg] == 0)
          ret_c = 0;
        break;


      case 107:
        arg = *g_loc_ptr++;

        if (T0[arg] >= 0)
   {

         
          end_sweep();
          return (-1);
        }
        break;






      case 4:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = T0[arg];

 Targ = T[arg];
        Tres = T[res];

        for (l=0; l<pk; l++)
   *Tres++ = *Targ++;


 break;


      case 5:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

 T0[res] = coval;

        Tres = T[res];

        for (l=0; l<pk; l++)
   *Tres++ = 0;


 break;


      case 92:

        res = *g_loc_ptr++;

       

 T0[res] = 0.0;

        Tres = T[res];

        for (l=0; l<pk; l++)
   *Tres++ = 0;


 break;


      case 91:

        res = *g_loc_ptr++;

       

 T0[res] = 1.0;

        Tres = T[res];

        for (l=0; l<pk; l++)
   *Tres++ = 0;


 break;


      case 2:

        res = *g_loc_ptr++;

       

 T0[res] = basepoint[indexi];

 Tres = T[res];

        for (l=0; l<p; l++)
          for (i=0; i<k; i++)
       *Tres++ = argument[indexi][l][i];


 ++indexi;
 break;


      case 3:

 res = *g_loc_ptr++;

        valuepoint[indexd] = T0[res];

 Tres = T[res];

        if (taylors != 0 )
          for (l=0; l<p; l++)
            for (i=0; i<k; i++)
       taylors[indexd][l][i] = *Tres++;


 indexd++;
 break;






      case 6:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res] += coval;
 break;


      case 7:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] += T0[arg];

        Tres = T[res];
 Targ = T[arg];

        for (l=0; l<pk; l++)
   *Tres++ += *Targ++;


 break;


      case 8:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

 T0[res] -= coval;
 break;


      case 9:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

 T0[res] -= T0[arg];

 Tres = T[res];
 Targ = T[arg];

        for (l=0; l<pk; l++)
   *Tres++ -= *Targ++;


 break;


      case 10:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

 T0[res] *= coval;

 Tres = T[res];

        for (l=0; l<pk; l++)
     *Tres++ *= coval;


 break;


      case 11:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       


 Tres = T[res];
 Targ = T[arg];

        Tres += pk-1;
        Targ += pk-1;

        for (l=p-1; l>=0; l--)
   for (i=k-1; i>=0; i--)
   { *Tres = T0[res]**Targ-- + *Tres*T0[arg];

            TresOP = Tres-i;
            TargOP = Targ;

            for (j=0;j<i;j++)
              *Tres += (*TresOP++) * (*TargOP--);
            Tres--;

   }


        T0[res] *= T0[arg];
 break;


      case 95:
        res = *g_loc_ptr++;

       

        T0[res]++;
 break;


      case 96:
        res = *g_loc_ptr++;

       

        T0[res]--;
 break;






      case 12:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = T0[arg1] + T0[arg2];

 Tres = T[res];
 Targ1 = T[arg1];
 Targ2 = T[arg2];

        for (l=0; l<pk; l++)
   *Tres++ = *Targ1++ + *Targ2++;


 break;


      case 13:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res] = T0[arg] + coval;

 Tres = T[res];
 Targ = T[arg];

        for (l=0; l<pk; l++)
   *Tres++ = *Targ++;


 break;


      case 14:

        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = T0[arg1] - T0[arg2];

        Tres = T[res];
 Targ1 = T[arg1];
 Targ2 = T[arg2];

        for (l=0; l<pk; l++)
   *Tres++ = *Targ1++ - *Targ2++;


 break;


      case 15:

        arg =*g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res] = coval - T0[arg];

        Tres = T[res];
        Targ = T[arg];

        for (l=0; l<pk; l++)
   *Tres++ = -*Targ++;


 break;


      case 16:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       


        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];


        Tres += pk-1;
        Targ1 += pk-1;
        Targ2 += pk-1;

        for (l=p-1; l>=0; l--)
          for (i=k-1; i>=0; i--)
   { *Tres = T0[arg1]**Targ2-- + *Targ1--*T0[arg2];

            Targ1OP = Targ1-i+1;
            Targ2OP = Targ2;

            for (j=0;j<i;j++)
              *Tres += (*Targ1OP++) * (*Targ2OP--);
            Tres--;

          }


        T0[res] = T0[arg1] * T0[arg2];
 break;


      case 17:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res] = T0[arg] * coval;

        Tres = T[res];
        Targ = T[arg];

        for (l=0; l<pk; l++)
   *Tres++ = *Targ++ * coval;


 break;


      case 18:

        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       


 divs = 1.0 / T0[arg2];


        T0[res] = T0[arg1] / T0[arg2];

        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        for (l=0; l<p; l++)
          for (i=0; i<k; i++)
   {

            zOP = z+i;
            (*zOP--) = -(*Targ2) * divs;


            *Tres = *Targ1++ * divs + T0[res] * (-*Targ2++ * divs);


            TresOP = Tres-i;

     for (j=0;j<i;j++)
       *Tres += (*TresOP++) * (*zOP--);
            Tres++;

   }


 break;


      case 19:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       


        if (arg == res)
        {
 }


 divs = 1.0 / T0[arg];


        T0[res] = coval / T0[arg];

        Tres = T[res];
        Targ = T[arg];

        for (l=0; l<p; l++)
          for (i=0; i<k; i++)
   {

            zOP = z+i;
            (*zOP--) = -(*Targ) * divs;


            *Tres = T0[res] * (-*Targ++ * divs);


            TresOP = Tres-i;

     for (j=0;j<i;j++)
       *Tres += (*TresOP++) * (*zOP--);
            Tres++;

   }


 break;






      case 98:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
       

        T0[res] = T0[arg];

 Tres = T[res];
 Targ = T[arg];

        for (l=0; l<pk; l++)
   *Tres++ = *Targ++;


 break;


      case 97:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = -T0[arg];

 Tres = T[res];
 Targ = T[arg];

        for (l=0; l<pk; l++)
   *Tres++ = -*Targ++;


 break;






      case 20:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = exp(T0[arg]);

 Tres = T[res];
 Targ = T[arg];

        for (l=0; l<p; l++)
          for (i=0; i<k; i++)
   {

            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ);


            *Tres = T0[res] * *Targ++;


            TresOP = Tres-i;

            *Tres *= (i+1);
     for (j=0;j<i;j++)
       *Tres += (*TresOP++) * (*zOP--);
     *Tres++ /= (i+1);

          }



 break;


      case 22:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       
       

 T0[arg2] = cos(T0[arg1]);
 T0[res] = sin(T0[arg1]);

 Tres = T[res];
 Targ1 = T[arg1];
        Targ2 = T[arg2];

        for (l=0; l<p; l++)
          for (i=0; i<k; i++)
   {

            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);


            *Targ2 = -T0[res] * *Targ1;
            *Tres = T0[arg2] * *Targ1++;


            TresOP = Tres-i;
            Targ2OP = Targ2-i;

            *Tres *= (i+1);
            *Targ2 *= (i+1);
     for (j=0;j<i;j++)
     { *Tres += (*Targ2OP++) * (*zOP);
              *Targ2 -= (*TresOP++) * (*zOP--);
     }
     *Targ2++ /= (i+1);
     *Tres++ /= (i+1);

   }


 break;


      case 21:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       
       

        T0[arg2] = sin(T0[arg1]);
        T0[res] = cos(T0[arg1]);

 Tres = T[res];
 Targ1 = T[arg1];
 Targ2 = T[arg2];

        for (l=0; l<p; l++)
          for (i=0; i<k; i++)
   {

            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);


            *Targ2 = T0[res] * *Targ1;
            *Tres = -T0[arg2] * *Targ1++;


            TresOP = Tres-i;
            Targ2OP = Targ2-i;

            *Tres *= (i+1);
            *Targ2 *= (i+1);
     for (j=0;j<i;j++)
     { *Tres -= (*Targ2OP++) * (*zOP);
              *Targ2 += (*TresOP++) * (*zOP--);
     }
     *Targ2++ /= (i+1);
     *Tres++ /= (i+1);

   }


 break;


      case 23:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res]=atan(T0[arg1]);

        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        for (l=0; l<p; l++)
        { for (i=0; i<k; i++)
   {

            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);


            *Tres = T0[arg2] * *Targ1++;


            Targ2OP = Targ2;

            *Tres *= (i+1);
     for (j=0;j<i;j++)
       *Tres += (*Targ2OP++) * (*zOP--);
     *Tres++ /= (i+1);

   }
          Targ2 += k;
        }


 break;


      case 26:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = asin(T0[arg1]);

        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        if (T0[arg1] == 1.0)
          for (l=0; l<p; l++)
          { for (i=0; i<k; i++)
              if (*Targ1 > 0.0)
              { r0 = make_nan();
                Targ1 += k-i;
                break;
              }
              else
                if (*Targ1 < 0.0)
                { r0 = make_inf();
                  Targ1 += k-i;
                  break;
                }
                else
                { r0 = 0.0;
                  Targ1++;
                }
            *Tres = r0;
            Tres += k;
          }
        else
          if (T0[arg1] == -1.0)
            for (l=0; l<p; l++)
            { for (i=0; i<k; i++)
                if (*Targ1 > 0.0)
                { r0 = make_inf();
                  Targ1 += k-i;
                  break;
                }
                else
                  if (*Targ1 < 0.0)
                  { r0 = make_nan();
                    Targ1 += k-i;
                    break;
                  }
                  else
                  { r0 = 0.0;
                    Targ1++;
                  }
              *Tres = r0;
              Tres += k;
            }
          else
            for (l=0; l<p; l++)
            { for (i=0; i<k; i++)
              {

                zOP = z+i;
                (*zOP--) = (i+1) * (*Targ1);


                *Tres = T0[arg2] * *Targ1++;


                Targ2OP = Targ2;

                *Tres *= (i+1);
           for (j=0;j<i;j++)
           *Tres += (*Targ2OP++) * (*zOP--);
         *Tres++ /= (i+1);

       }
              Targ2 += k;
            }


 break;


      case 27:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = acos(T0[arg1]);

        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        if (T0[arg1] == 1.0)
          for (l=0; l<p; l++)
          { for (i=0; i<k; i++)
              if (*Targ1 > 0.0)
              { r0 = make_nan();
                Targ1 += k-i;
                break;
              }
              else
                if (*Targ1 < 0.0)
                { r0 = -make_inf();
                  Targ1 += k-i;
                  break;
                }
                else
                { r0 = 0.0;
                  Targ1++;
                }
            *Tres = r0;
            Tres += k;
          }
        else
          if (T0[arg1] == -1.0)
            for (l=0; l<p; l++)
            { for (i=0; i<k; i++)
                if (*Targ1 > 0.0)
                { r0 = -make_inf();
                  Targ1 += k-i;
                  break;
                }
                else
                  if (*Targ1 < 0.0)
                  { r0 = make_nan();
                    Targ1 += k-i;
                    break;
                  }
                  else
                  { r0 = 0.0;
                    Targ1++;
                  }
              *Tres = r0;
              Tres += k;
            }
          else
            for (l=0; l<p; l++)
            { for (i=0; i<k; i++)
       {

                zOP = z+i;
                (*zOP--) = (i+1) * (*Targ1);


                *Tres = T0[arg2] * *Targ1++;


                Targ2OP = Targ2;

                *Tres *= (i+1);
           for (j=0;j<i;j++)
           *Tres += (*Targ2OP++) * (*zOP--);
         *Tres++ /= (i+1);

       }
              Targ2 += k;
            }


 break;
// 1880 "uni5_for.cpp"
      case 24:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       


 Tres = T[res];
 Targ = T[arg];

        divs = 1.0 / T0[arg];
        for (l=0; l<p; l++)
        { if (T0[arg] == 0.0)
          { TargOP = Targ;
            for (i=0; i<k; i++)
            { if (*TargOP++ < 0.0)
              { divs = make_nan();
                break;
              }
     }
          }


          for (i=0; i<k; i++)
   { *Tres = *Targ++ * divs;

            TresOP = Tres - i;
            zOP = z+i;

            (*zOP--) = *Tres;
     (*Tres) *= i+1;
      for (j=0;j<i;j++)
       (*Tres) -= (*zOP--) * (*TresOP++) * (j+1);
     *Tres++ /= i+1;

          }
        }


        T0[res] = log(T0[arg]);
 break;


      case 25:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       


        if (arg == res)
        {
 }


        T0temp = T0[arg];


        T0[res] = pow(T0[arg], coval);

 Tres = T[res];
 Targ = T[arg];

        if (T0temp == 0.0)
          for (l=0; l<p; l++)
          { for (i=0; i<k; i++)
            { if (*Targ > 0.0)
              { if (coval <= 0.0)
           r0 = make_nan();
                else
                  if (coval > 1.0)
                    r0 = 0.0;
                  else
                    if (coval == 1.0)
               r0 = 1.0 ;
                    else
               r0 = make_inf();
                Targ += k-i;
                break;
              }
              else
                if (*Targ < 0.0)
                { r0 = make_nan();
                  Targ += k-i;
                  break;
                }
                else
                { r0 = 0.0;
                  Targ++;
         }
            }
     *Tres++ = r0;

            for (i=1;i<k;i++)
            { *Tres++ = make_nan();
     }

          }
        else
   { r0 = 1.0 / T0temp;
          for (l=0; l<p; l++)
            for (i=0; i<k; i++)
            {

              zOP = z+i;
              (*zOP--) = (*Targ) * r0;


              *Tres = T0[res] * *Targ++ * coval * r0;


              TresOP = Tres-i;

        (*Tres) *= i+1;
       y = coval*i -1;
              for (j=0;j<i;j++)
              { *Tres += (*TresOP++) * (*zOP--) * y;
  y -= coval + 1;
       }
       *Tres++ /= (i+1);

     }
        }


 break;


      case 28:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = sqrt(T0[arg]);

        Targ = T[arg];
 Tres = T[res];

        for (l=0; l<p; l++)
        { TargOP = Targ;
          if (T0[arg] == 0.0)
          { r0 = 0.0;
            for (i=0; i<k; i++)
     { if (*Targ>0.0)
              { r0 = make_inf();
                Targ += k-i;
                break;
              }
              else
               if (*Targ<0.0)
               { r0 = make_nan();
                 Targ += k-i;
                 break;
               }
               else
                 Targ++;
            }
          }
          else
          { r0 = 0.5/T0[res];
          }
          Targ = TargOP;

   even = 1;
          for (i=0; i<k; i++)
   { *Tres = r0 * *Targ++;

            TresOP = Tres-i;
            TresOP2 = Tres-1;

            x = 0;
            for (j=1;2*j-1<i;j++)
              x += (*TresOP++) * (*TresOP2--);
     x *= 2;
     if (!even)
              x += (*TresOP) * (*TresOP2);
     even = !even;
     *Tres++ -= r0*x;

   }
        }


 break;


      case 32:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (*g_real_ptr++!=T0[arg1])
   {

         
          end_sweep();
          return -2;
        }
        coval = *g_real_ptr++;

       

        T0[res] = coval;

        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        for (l=0; l<p; l++)
        { for (i=0; i<k; i++)
   {

            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);


            *Tres = T0[arg2] * *Targ1++;


            Targ2OP = Targ2;

            *Tres *= (i+1);
     for (j=0;j<i;j++)
       *Tres += (*Targ2OP++) * (*zOP--);
     *Tres++ /= (i+1);

   }
          Targ2 += k;
        }


 break;


      case 100:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       




        if (T0[arg1] > T0[arg2])
        { if (coval)
            if ((ret_c) > (2)) (ret_c) = (2);
        }
        else
          if (T0[arg1] < T0[arg2])
          { if (!coval)
              if ((ret_c) > (2)) (ret_c) = (2);
          }
          else
            if (arg1 != arg2)
              if ((ret_c) > (1)) (ret_c) = (1);


        Targ1 = T[arg1];
        Targ2 = T[arg2];
        Tres = T[res];

        Tqo = __null;
        if (T0[arg1] > T0[arg2])
          Tqo = Targ2;
        else
          if (T0[arg1] < T0[arg2])
            Tqo = Targ1;

        for (l=0; l<p; l++)
        { Targ = Tqo;
          if (Targ == __null)
          { Targ1OP = Targ1;
            Targ2OP = Targ2;
            for (i=0; i<k; i++)
            { if (*Targ1 > *Targ2)
              { Targ = Targ2OP;
                Targ1 += k-i;
                Targ2 += k-i;
                break;
              }
              else
                if (*Targ1 < *Targ2)
                { Targ = Targ1OP;
                  Targ1 += k-i;
                  Targ2 += k-i;
                  break;
                }
              Targ1++; Targ2++;
            }
            if (Targ == __null)
              Targ = Targ1OP;
   }

          for (i=0; i<k; i++)
            *Tres++ = *Targ++;

          if (Tqo)
          { Tqo += k;
   }
        }


        T0[res] = ((T0[arg2]<T0[arg1])?T0[arg2]:T0[arg1]);
        break;


      case 101:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       




        if (T0[arg] < 0.0)
        { if (coval)
            if ((ret_c) > (2)) (ret_c) = (2);
        }
        else
          if (T0[arg] > 0.0)
          { if (!coval)
              if ((ret_c) > (2)) (ret_c) = (2);
          }


        Tres = T[res];
        Targ = T[arg];

        y = 0.0;
        if (T0[arg] != 0.0)
          if (T0[arg] < 0.0)
            y = -1.0;
          else
            y = 1.0;

        for (l=0; l<p; l++)
        { x = y;
          for (i=0; i<k; i++)
          { if ((x == 0.0) && (*Targ != 0.0))
            { if ((ret_c) > (1)) (ret_c) = (1);
              if (*Targ < 0.0)
                x = -1.0;
              else
                x = 1.0;
            }
            *Tres++ = x * *Targ++;
          }
        }


        T0[res] = fabs(T0[arg]);
        break;


      case 115:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res]=ceil(T0[arg]);

        if (coval != T0[res])
          if ((ret_c) > (2)) (ret_c) = (2);

        Tres = T[res];

        for (l=0; l<pk; l++)
          *Tres++ = 0.0;


        break;


      case 116:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res] = floor(T0[arg]);

        if (coval != T0[res])
          if ((ret_c) > (2)) (ret_c) = (2);

        Tres = T[res];

        for (l=0; l<pk; l++)
          *Tres++ = 0.0;


        break;






      case 70:
        arg = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       



        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        if (T0[arg] > 0)
          for (l=0; l<pk; l++)
            *Tres++ = *Targ1++;
        else
          for (l=0; l<pk; l++)
            *Tres++ = *Targ2++;


        if (T0[arg] > 0)
        { if (coval <= 0.0)
            if ((ret_c) > (2)) (ret_c) = (2);
          T0[res] = T0[arg1];
        }
        else
        { if (coval > 0.0)
            if ((ret_c) > (2)) (ret_c) = (2);
          if (T0[arg] == 0)
            if ((ret_c) > (0)) (ret_c) = (0);
          T0[res] = T0[arg2];
        }
        break;


      case 71:
        arg = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       



        Tres = T[res];
        Targ1 = T[arg1];

        if (T0[arg] > 0)
          for (l=0; l<pk; l++)
            *Tres++ = *Targ1++;


        if (T0[arg] > 0)
 { if (coval <= 0.0)
            if ((ret_c) > (2)) (ret_c) = (2);
          T0[res] = T0[arg1];
        }
        else
          if (T0[arg] == 0)
            if ((ret_c) > (0)) (ret_c) = (0);
        break;






      case 52:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
         
          T0[res] = T0[arg];

          Targ = T[arg];
          Tres = T[res];

          for (l=0; l<pk; l++)
     *Tres++ = *Targ++;


          res++; arg++;
       }
        break;


      case 53:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        d = get_val_v_f(size);

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = *d++;

          Tres = T[res];

          for (l=0; l<pk; l++)
     *Tres++ = 0;


          res++;
        }
        break;


      case 54:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = basepoint[indexi];

          Tres = T[res];

          for (l=0; l<p; l++)
            for (i=0; i<k; i++)
              *Tres++ = argument[indexi][l][i];


          ++indexi;
          res++;
        }
        break;


      case 55:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {

          valuepoint[indexd] = T0[res];

          Tres = T[res];

          if (taylors != 0 )
            for (l=0; l<p; l++)
              for (i=0; i<k; i++)
         taylors[indexd][l][i] = *Tres++;


          indexd++;
          res++;
        }
        break;






      case 59:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        for (ls=0; ls<size; ls++)
        {
         
   T0[res] += T0[arg];

          Tres = T[res];
          Targ = T[arg];

          for (l=0; l<pk; l++)
     *Tres++ += *Targ++;


          res++; arg++;
        }
        break;


      case 57:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] -= T0[arg];

          Tres = T[res];
          Targ = T[arg];

          for (l=0; l<pk; l++)
     *Tres++ -= *Targ++;


          res++; arg++;
        }
        break;


      case 61:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] *= coval;

          Tres = T[res];

          for (l=0; l<pk; l++)
       *Tres++ *= coval;


          res++;
        }
        break;


      case 62:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;



        checkSize = res+size;

        for (ls=0; ls<size; ls++)
        { if (res == arg)
            res++;
          if (res == checkSize)
            res = arg;


         


          Tres = T[res];
          Targ = T[arg];

          Tres += pk-1;
          Targ += pk-1;

          for (l=p-1; l>=0; l--)
     for (i=k-1; i>=0; i--)
     { *Tres = T0[res]**Targ-- + *Tres*T0[arg];

              TresOP = Tres-i;
              TargOP = Targ;

              for (j=0;j<i;j++)
                *Tres += (*TresOP++) * (*TargOP--);
              Tres--;

     }


          T0[res] *= T0[arg];
          res++;
        }
       break;






      case 40:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = T0[arg1] + T0[arg2];

          Tres = T[res];
          Targ1 = T[arg1];
          Targ2 = T[arg2];

          for (l=0; l<pk; l++)
     *Tres++ = *Targ1++ + *Targ2++;


          res++; arg1++; arg2++;
        }
        break;


      case 42:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = T0[arg1] - T0[arg2];

          Tres = T[res];
          Targ1 = T[arg1];
          Targ2 = T[arg2];

          for (l=0; l<pk; l++)
     *Tres++ = *Targ1++ - *Targ2++;


          res++; arg1++; arg2++;
        }
        break;


      case 45:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

 T0temp = 0.0;



        if ( ((res >= arg1) && (res < arg1+size))
            || ((res >= arg2) && (res < arg2+size)) )
 { TresOP = Ttemp;
          flag = 1;
 }
        else
        { TresOP = T[res];
          flag = 0;
 }

        Tres = TresOP;
        for (l=0; l<pk; l++)
          *Tres++ = 0.0;


        for (ls=0; ls<size; ls++)
        {

          Tres = TresOP;
          Targ1 = T[arg1];
          Targ2 = T[arg2];


          Tres += pk-1;
          Targ1 += pk-1;
          Targ2 += pk-1;

          for (l=p-1; l>=0; l--)
            for (i=k-1; i>=0; i--)
     { *Tres += T0[arg1]**Targ2-- + *Targ1--*T0[arg2];

              Targ1OP = Targ1-i+1;
              Targ2OP = Targ2;

              for (j=0;j<i;j++)
                *Tres += (*Targ1OP++) * (*Targ2OP--);
              Tres--;

            }

          T0temp += T0[arg1] * T0[arg2];
          arg1++; arg2++;
        }


        T0[res] = T0temp;

        if (flag)
 { Tres = T[res];
          Tqo = TresOP;

          for (l=0; l<pk; l++)
            *Tres++ = *Tqo++;
 }

 break;


      case 47:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;



        checkSize = res+size;

        for (ls=0; ls<size; ls++)
        { if (res == arg2)
          { res++; arg1++;
   }
          if (res == checkSize)
          { arg1 -= res-arg2;
            res = arg2;
   }


         


          Tres = T[res];
          Targ1 = T[arg1];
          Targ2 = T[arg2];


          Tres += pk-1;
          Targ1 += pk-1;
          Targ2 += pk-1;

          for (l=p-1; l>=0; l--)
            for (i=k-1; i>=0; i--)
     { *Tres = T0[arg1]**Targ2-- + *Targ1--*T0[arg2];

              Targ1OP = Targ1-i+1;
              Targ2OP = Targ2;

              for (j=0;j<i;j++)
                *Tres += (*Targ1OP++) * (*Targ2OP--);
              Tres--;

            }


          T0[res] = T0[arg1] * T0[arg2];
          res++; arg1++;
        }
        break;


      case 48:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = T0[arg] * coval;

          Tres = T[res];
          Targ = T[arg];

          for (l=0; l<pk; l++)
     *Tres++ = *Targ++ * coval;


          res++; arg++;
        }
        break;


      case 60:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;


        divs = 1.0 / T0[arg2];




        checkSize = res+size;

        for (ls=0; ls<size; ls++)
        { if (res == arg2)
          { res++; arg1++;
   }
          if (res == checkSize)
          { arg1 -= res-arg2;
            res = arg2;
   }


         

          T0[res] = T0[arg1] / T0[arg2];

          Tres = T[res];
          Targ1 = T[arg1];
          Targ2 = T[arg2];

          for (l=0; l<p; l++)
            for (i=0; i<k; i++)
     {

              zOP = z+i;
              (*zOP--) = -(*Targ2) * divs;



              *Tres = *Targ1++ * divs + T0[res] * (-*Targ2++ * divs);


              TresOP = Tres-i;

       for (j=0;j<i;j++)
         *Tres += (*TresOP++) * (*zOP--);
              Tres++;

     }


          res++; arg1++;
        }
        break;






      case 75:
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        arg = arg2 + (int)(T0[arg1]);

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);


       

        T0[res] = T0[arg];

        Tres = T[res];
        Targ = T[arg];

        for (l=0; l<pk; l++)
          *Tres++ = *Targ++;


        break;


      case 76:
        arg2 = *g_loc_ptr++;
 arg1 = *g_loc_ptr++;
        arg = *g_loc_ptr++;

        res = arg2 + (int)(T0[arg1]);

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

       

        T0[res] = T0[arg];

        Tres = T[res];
        Targ = T[arg];

        for (l=0; l<pk; l++)
          *Tres++ = *Targ++;


        break;


      case 77:
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;

        arg = arg2+(int)(T0[arg1]);

       

        T0[arg] = *g_real_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        Targ = T[arg];

        for (l=0; l<pk; l++)
          *Targ++ = 0;


        break;


      case 72:
 fprintf((stderr),"doing m_subscript\n"); exit(12);
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        arg = arg2 + (int)(T0[arg1])*size;

 if (T0[arg1] != (int)T0[arg1]){
   fprintf((stderr),"T0[arg1] is not an integer in m_subscript in uni5_for.c\n"); exit(12);}

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = T0[arg];

          Tres = T[res];
          Targ = T[arg];

          for (l=0; l<pk; l++)
            *Tres++ = *Targ++;


         res++; arg++;
        }
        break;


      case 73:
 fprintf((stderr),"doing m_subscript_l\n"); exit(12);
        arg2 = *g_loc_ptr++;
 arg1 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        arg = *g_loc_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        res = arg2 + (int)(T0[arg1])*size;
        for (ls=0; ls<size; ls++)
        {

          T0[res] = T0[arg];

          Tres = T[res];
          Targ = T[arg];

          for (l=0; l<pk; l++)
            *Tres++ = *Targ++;


          res++; arg++;
        }
        break;


      case 74:
 fprintf((stderr),"doing m_subscript_ld\n"); exit(12);
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        d = get_val_v_f(size);

        res = arg2 + (int)(T0[arg1])*size + arg;
        for (ls=0; ls<size; ls++)
        {

          T0[res] = d[ls];

          Tres = T[res];

          for (l=0; l<pk; l++)
            *Tres++ = 0.0;


          res++;
        }
        break;






      case 90:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        d = get_val_v_f(size);

        for (ls=0;ls<size;ls++)
        { T0[res]=*d;

          Tres = T[res];

          for (l=0; l<pk; l++)
            *Tres++ = 0;


          res++; d++;
        }
        break;


      case 1:
        arg1=*g_loc_ptr++;
        arg2=*g_loc_ptr++;
// 3019 "uni5_for.cpp"
   break;


      default:


        fprintf((DIAG_OUT),"ADOL-C fatal error in " "hov_forward" " ("
                       "uni5_for.cpp"
                       ") : no such operation %d\n", operation);
 exit(12);
 break;

      }


      operation=*g_op_ptr++;
    }







  end_sweep();
  return ret_c;
}






