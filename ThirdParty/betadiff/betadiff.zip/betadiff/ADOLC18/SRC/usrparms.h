#ifndef _USRPARMS_H_
#define _USRPARMS_H_

#ifdef _CRAY
#define KUPE
#else
#define NOTKUPE
#endif
/* BB:
  locint is now unsigned short on Kupe or unsigned int elsewhere (was short unsigned int)
  BUFSIZE and TBUFSIZE have been much increased
  OP_BUFSIZE, LOC_BUFSIZE, REAL_BUFSIZE introduced
  On Kupe, the FNAME arguments are now /dmf/home/bull/adolc_dumps/
  */

/*
   ----------------------------------------------------------------
   File usrparms.h of ADOL-C version 1.8.0          as of Nov/30/98
   ----------------------------------------------------------------

   usrparms.h contains the parameters which might affect
   the performance of the ADOL-C system.  Intended to be tweeked by
   users and local maintainence personal.

   Last changes:
       981130 olvo   Fortran types
       981030 olvo   bufsize --> BUFSIZE & TBUFSIZE
       980723 olvo   new: DIAG_OUT as standard output
                          FNAME3   as vs output
   ----------------------------------------------------------------
*/
/*** ADOL-C ERROR VALUE */
#define ADOLC_ERROR_VAL 12

/****************************************************************************/
#define BUFSIZE 67108864  // 64M
#define OP_BUFSIZE 67108864
#define LOC_BUFSIZE 67108864
#define REAL_BUFSIZE 67108864
#define TBUFSIZE 67108864

/****************************************************************************/
/* ADOL-C data types  */
#ifdef KUPE
#define locint unsigned short
#else
#define locint unsigned int
#endif
// Originally a locint was an unsigned short.
// If you change this, you may need to change the definition of maxloc in adouble.C
// to 2^(sizeof(locint)*8) - 1.
#define revreal double

/****************************************************************************/
/* Definition of inf and NaN                                               */
#define inf_num 1.0 /* don't undefine these;  on non-IEEE machines */
#define inf_den 0.0 /* change the values to get small fractions    */
#define non_num 0.0 /* (inf_num/inf_den) and (non_num/non_den)     */
#define non_den 0.0 /* respectively, see the documentation         */

/****************************************************************************/
/* File names                                                               */
// #ifdef KUPE
// #define FNAME3       "/dmf/home/bull/adolc_dumps/_adol-vs_tape."
// #define FNAME2       "/dmf/home/bull/adolc_dumps/_adol-rl_tape."
// #define FNAME1       "/dmf/home/bull/adolc_dumps/_adol-in_tape."
// #define FNAME        "/dmf/home/bull/adolc_dumps/_adol-op_tape."
// #else
#define FNAME3 "_Casal2_adol-vs_tape.tmp"
#define FNAME2 "_Casal2_adol-rl_tape.tmp"
#define FNAME1 "_Casal2_adol-in_tape.tmp"
#define FNAME "_Casal2_adol-op_tape.tmp"
// #endif

/****************************************************************************/
/* Enable/disable DEBUG for hard debugging                                  */
/* #define DEBUG */

/****************************************************************************/
/* Enable/disable asinh, acosh,atanh, erf                                   */
/* #define ATRIG_ERF */

/****************************************************************************/
/* Standard output used for diagnostics by ADOL-C,                          */
/* e.g. stdout or stderr or whatever file identifier                        */
#define DIAG_OUT stdout

/****************************************************************************/
/* Types used by Fortran callable versions of functions */
#define fint long
#define fdouble double

/****************************************************************************/
/* That's all                                                               */
#endif
