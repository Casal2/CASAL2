#ifndef _USRPARMS_H_
#define _USRPARMS_H_

#ifdef _CRAY
#define KUPE
#else
#define NOTKUPE
#endif
 /* BB:
   locint is now unsigned short on Kupe or unsigned int elsewhere (was short unsigned int)
   BUFSIZE and TBUFSIZE have been much increased
   OP_BUFSIZE, LOC_BUFSIZE, REAL_BUFSIZE introduced
   On Kupe, the FNAME arguments are now /dmf/home/bull/adolc_dumps/
   */

/*
   ----------------------------------------------------------------
   File usrparms.h of ADOL-C version 1.8.0          as of Nov/30/98
   ----------------------------------------------------------------

   usrparms.h contains the parameters which might affect
   the performance of the ADOL-C system.  Intended to be tweeked by
   users and local maintainence personal.

   Last changes:
       981130 olvo   Fortran types
       981030 olvo   bufsize --> BUFSIZE & TBUFSIZE
       980723 olvo   new: DIAG_OUT as standard output
                          FNAME3   as vs output
   ----------------------------------------------------------------
*/
/*** ADOL-C ERROR VALUE */
#define ADOLC_ERROR_VAL 12

/****************************************************************************/
/* Buffer size for tapes                                                    */
#define BUFSIZE 1073741824 // (this value does not work in GitHub Actions ->) 2147000000 // 8388608 //1048576  //200000  /* 16384, 65536 or  524288  */

// BB added
#define OP_BUFSIZE   1073741824 // (this value does not work in GitHub Actions ->) 2147000000 // 8388608 // 1048576// 400000
#define LOC_BUFSIZE  1073741824 // (this value does not work in GitHub Actions ->) 2147000000 // 8388608 // 1048576 //400000
#define REAL_BUFSIZE 1073741824 // (this value does not work in GitHub Actions ->) 2147000000 // 8388608 // 1048576 // 400000



/****************************************************************************/
/* Buffer size for temporary Taylor store                                   */
#define TBUFSIZE  1073741824 // (this value does not work in GitHub Actions ->) 2147000000 // 8388608 // 1048576 //400000   /* 16384 or  524288  */


/****************************************************************************/
/* ADOL-C data types  */
#ifdef KUPE
#define locint      unsigned short
#else
#define locint      unsigned int
#endif
  // Originally a locint was an unsigned short.
  // If you change this, you may need to change the definition of maxloc in adouble.C
  // to 2^(sizeof(locint)*8) - 1.
#define revreal     double

/****************************************************************************/
/* Definition of inf and NaN                                               */
#define inf_num     1.0  /* don't undefine these;  on non-IEEE machines */
#define inf_den     0.0  /* change the values to get small fractions    */
#define non_num     0.0  /* (inf_num/inf_den) and (non_num/non_den)     */
#define non_den     0.0  /* respectively, see the documentation         */


/****************************************************************************/
/* File names                                                               */
//#ifdef KUPE
//#define FNAME3       "/dmf/home/bull/adolc_dumps/_adol-vs_tape."
//#define FNAME2       "/dmf/home/bull/adolc_dumps/_adol-rl_tape."
//#define FNAME1       "/dmf/home/bull/adolc_dumps/_adol-in_tape."
//#define FNAME        "/dmf/home/bull/adolc_dumps/_adol-op_tape."
//#else
#define FNAME3       "_adol-vs_tape."
#define FNAME2       "_adol-rl_tape."
#define FNAME1       "_adol-in_tape."
#define FNAME        "_adol-op_tape."
//#endif

/****************************************************************************/
/* Enable/disable DEBUG for hard debugging                                  */
/* #define DEBUG */


/****************************************************************************/
/* Enable/disable asinh, acosh,atanh, erf                                   */
/* #define ATRIG_ERF */


/****************************************************************************/
/* Standard output used for diagnostics by ADOL-C,                          */
/* e.g. stdout or stderr or whatever file identifier                        */
#define DIAG_OUT stdout


/****************************************************************************/
/* Types used by Fortran callable versions of functions */
#define fint long
#define fdouble double


/****************************************************************************/
/* That's all                                                               */
#endif


