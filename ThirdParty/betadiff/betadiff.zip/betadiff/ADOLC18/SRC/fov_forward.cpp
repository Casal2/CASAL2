#define _ADOLC_SRC_

#include "dvlparms.h" /* Developers Parameters */
#include "usrparms.h" /* Users Parameters */
#include "interfaces.h"
//#include "oplate.h"
#include "adalloc.h"
#include "taputil.h"
#include "tayutil.h"

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define __null 0

static short tag;

static int for_location_cnt;
static int dep_cnt;
static int ind_cnt;

int fov_forward(
   short tnum,
   int depcheck,
   int indcheck,
   int p, double *basepoint,
   double **argument,
   double *valuepoint,
   double **taylors)
{

  unsigned char operation;
  int tape_stats[13];
  int ret_c =3;

  unsigned int size = 0;
  unsigned int res = 0;
  unsigned int arg = 0;
  unsigned int arg1 = 0;
  unsigned int arg2 = 0;
  unsigned int checkSize;

  double coval = 0, *d = 0;

  int indexi = 0, indexd = 0;
  int i, j, l, ls;

  double r0, x, y, divs;
  int op_buffer, loc_buffer, real_buffer, even, flag;
  static int fax, kax, pax;

  static double *T0;
  static double **T;
  static double *Ttemp;

  double *Tres, *Targ, *Targ1, *Targ2, *Tqo;
  double *TresOP, *TresOP2, *zOP;
  double *TargOP, *Targ1OP, *Targ2OP, *TqoOP;

  double T0temp;
  tag = tnum;

  tapestats(tag,tape_stats);
  ind_cnt = tape_stats[0];
  dep_cnt = tape_stats[1];
  for_location_cnt = tape_stats[2];
  op_buffer = tape_stats[4];
  loc_buffer = tape_stats[5];
  real_buffer = tape_stats[6];
  set_buf_size(op_buffer,loc_buffer,real_buffer);

  if ((depcheck != dep_cnt)||(indcheck != ind_cnt))
  { fprintf((DIAG_OUT),"ADOL-C error: forward sweep on tape %d  aborted!\n",tag);
    fprintf((DIAG_OUT),"Number of dependent and/or independent variables passed"
                   " to forward is\ninconsistant with number"
                   " recorded on tape %d \n",tag);
    exit (-1);
  }
  if (p > pax || for_location_cnt > fax)
  { if (pax || fax)
    { free((char*) T0);
      free((char*) *T); free((char*) T);
      free((char*) Ttemp);
    }
    T0 = myalloc1(for_location_cnt);
    T = myalloc2(for_location_cnt,p);
    Ttemp = myalloc1(p);
    pax = p;
    fax = for_location_cnt;
  }
  init_for_sweep(tag);

  operation=*g_op_ptr++;
  while (operation !=35)
  {
   switch (operation){

      case 37:
        get_op_block_f();
        operation=*g_op_ptr++;

        break;

      case 38:
        //get_loc_block_f();
        break;


      case 39:
        get_val_block_f();
        break;

      case 36:
      case 35:
 break;
      case 102:
        arg = *g_loc_ptr++;

        if (T0[arg] != 0) {
         
          end_sweep();
          return (-1);
        }
        ret_c = 0;
        break;
      case 103:
        arg = *g_loc_ptr++;

        if (T0[arg] == 0)  {
          end_sweep();
          return (-1);
        }
        break;
      case 104:
        arg = *g_loc_ptr++;

        if (T0[arg] > 0)   {
          end_sweep();
          return (-1);
        }
        if (T0[arg] == 0)
          ret_c = 0;
        break;

      case 105:
        arg = *g_loc_ptr++;

        if (T0[arg] <= 0)   {
          end_sweep();
          return (-1);
        }
        break;

      case 106:
        arg = *g_loc_ptr++;

        if (T0[arg] < 0)  {

          end_sweep();
          return (-1);
        }
        if (T0[arg] == 0)
          ret_c = 0;
        break;

      case 107:
        arg = *g_loc_ptr++;

        if (T0[arg] >= 0)   {
         
          end_sweep();
          return (-1);
        }
        break;

	  case 4:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = T0[arg];

 Targ = T[arg];
        Tres = T[res];

        for (l=0; l<p; l++)
   *Tres++ = *Targ++;


 break;


      case 5:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

 T0[res] = coval;

        Tres = T[res];

        for (l=0; l<p; l++)
   *Tres++ = 0;


 break;


      case 92:

        res = *g_loc_ptr++;

       

 T0[res] = 0.0;

        Tres = T[res];

        for (l=0; l<p; l++)
   *Tres++ = 0;


 break;


      case 91:

        res = *g_loc_ptr++;

       

 T0[res] = 1.0;

        Tres = T[res];

        for (l=0; l<p; l++)
   *Tres++ = 0;


 break;


      case 2:

        res = *g_loc_ptr++;

       

 T0[res] = basepoint[indexi];

 Tres = T[res];

        for (l=0; l<p; l++)
         
       *Tres++ = argument[indexi][l];


 ++indexi;
 break;


      case 3:

 res = *g_loc_ptr++;

        valuepoint[indexd] = T0[res];

 Tres = T[res];

        if (taylors != 0 )
          for (l=0; l<p; l++)
           
       taylors[indexd][l] = *Tres++;


 indexd++;
 break;






      case 6:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res] += coval;
 break;


      case 7:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] += T0[arg];

        Tres = T[res];
 Targ = T[arg];

        for (l=0; l<p; l++)
   *Tres++ += *Targ++;


 break;


      case 8:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

 T0[res] -= coval;
 break;


      case 9:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

 T0[res] -= T0[arg];

 Tres = T[res];
 Targ = T[arg];

        for (l=0; l<p; l++)
   *Tres++ -= *Targ++;


 break;


      case 10:

        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

 T0[res] *= coval;

 Tres = T[res];

        for (l=0; l<p; l++)
     *Tres++ *= coval;


 break;


      case 11:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       


 Tres = T[res];
 Targ = T[arg];

        Tres += p-1;
        Targ += p-1;

        for (l=p-1; l>=0; l--)
  
   { *Tres-- = T0[res]**Targ-- + *Tres*T0[arg];
 #if 0
            TresOP = Tres-i;
            TargOP = Targ;

            for (j=0;j<i;j++)
              *Tres += (*TresOP++) * (*TargOP--);
            Tres--;
 #endif
   }


        T0[res] *= T0[arg];
 break;


      case 95:
        res = *g_loc_ptr++;

       

        T0[res]++;
 break;


      case 96:
        res = *g_loc_ptr++;

       

        T0[res]--;
 break;






      case 12:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = T0[arg1] + T0[arg2];

 Tres = T[res];
 Targ1 = T[arg1];
 Targ2 = T[arg2];

        for (l=0; l<p; l++)
   *Tres++ = *Targ1++ + *Targ2++;


 break;


      case 13:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res] = T0[arg] + coval;

 Tres = T[res];
 Targ = T[arg];

        for (l=0; l<p; l++)
   *Tres++ = *Targ++;


 break;


      case 14:

        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = T0[arg1] - T0[arg2];

        Tres = T[res];
 Targ1 = T[arg1];
 Targ2 = T[arg2];

        for (l=0; l<p; l++)
   *Tres++ = *Targ1++ - *Targ2++;


 break;


      case 15:

        arg =*g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res] = coval - T0[arg];

        Tres = T[res];
        Targ = T[arg];

        for (l=0; l<p; l++)
   *Tres++ = -*Targ++;


 break;


      case 16:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       


        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];


        Tres += p-1;
        Targ1 += p-1;
        Targ2 += p-1;

        for (l=p-1; l>=0; l--)
         
   { *Tres-- = T0[arg1]**Targ2-- + *Targ1--*T0[arg2];
 #if 0
            Targ1OP = Targ1-i+1;
            Targ2OP = Targ2;

            for (j=0;j<i;j++)
              *Tres += (*Targ1OP++) * (*Targ2OP--);
            Tres--;
 #endif
          }


        T0[res] = T0[arg1] * T0[arg2];
 break;


      case 17:

        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res] = T0[arg] * coval;

        Tres = T[res];
        Targ = T[arg];

        for (l=0; l<p; l++)
   *Tres++ = *Targ++ * coval;


 break;


      case 18:

        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       


 divs = 1.0 / T0[arg2];


        T0[res] = T0[arg1] / T0[arg2];

        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        for (l=0; l<p; l++)
         
   {
 #if 0
            zOP = z+i;
            (*zOP--) = -(*Targ2) * divs;
 #endif

            *Tres++ = *Targ1++ * divs + T0[res] * (-*Targ2++ * divs);

 #if 0
            TresOP = Tres-i;

     for (j=0;j<i;j++)
       *Tres += (*TresOP++) * (*zOP--);
            Tres++;
 #endif
   }


 break;


      case 19:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       


        if (arg == res)
        {
 }


 divs = 1.0 / T0[arg];


        T0[res] = coval / T0[arg];

        Tres = T[res];
        Targ = T[arg];

        for (l=0; l<p; l++)
         
   {
 #if 0
            zOP = z+i;
            (*zOP--) = -(*Targ) * divs;
 #endif

            *Tres++ = T0[res] * (-*Targ++ * divs);

 #if 0
            TresOP = Tres-i;

     for (j=0;j<i;j++)
       *Tres += (*TresOP++) * (*zOP--);
            Tres++;
 #endif
   }


 break;






      case 98:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
       

        T0[res] = T0[arg];

 Tres = T[res];
 Targ = T[arg];

        for (l=0; l<p; l++)
   *Tres++ = *Targ++;


 break;


      case 97:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = -T0[arg];

 Tres = T[res];
 Targ = T[arg];

        for (l=0; l<p; l++)
   *Tres++ = -*Targ++;


 break;






      case 20:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = exp(T0[arg]);

 Tres = T[res];
 Targ = T[arg];

        for (l=0; l<p; l++)
         
   {
 #if 0
            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ);
 #endif

            *Tres++ = T0[res] * *Targ++;

 #if 0
            TresOP = Tres-i;

            *Tres *= (i+1);
     for (j=0;j<i;j++)
       *Tres += (*TresOP++) * (*zOP--);
     *Tres++ /= (i+1);
 #endif
          }



 break;


      case 22:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       
       

 T0[arg2] = cos(T0[arg1]);
 T0[res] = sin(T0[arg1]);

 Tres = T[res];
 Targ1 = T[arg1];
        Targ2 = T[arg2];

        for (l=0; l<p; l++)
         
   {
 #if 0
            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);
 #endif

            *Targ2++ = -T0[res] * *Targ1;
            *Tres++ = T0[arg2] * *Targ1++;

 #if 0
            TresOP = Tres-i;
            Targ2OP = Targ2-i;

            *Tres *= (i+1);
            *Targ2 *= (i+1);
     for (j=0;j<i;j++)
     { *Tres += (*Targ2OP++) * (*zOP);
              *Targ2 -= (*TresOP++) * (*zOP--);
     }
     *Targ2++ /= (i+1);
     *Tres++ /= (i+1);
 #endif
   }


 break;


      case 21:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       
       

        T0[arg2] = sin(T0[arg1]);
        T0[res] = cos(T0[arg1]);

 Tres = T[res];
 Targ1 = T[arg1];
 Targ2 = T[arg2];

        for (l=0; l<p; l++)
         
   {
 #if 0
            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);
 #endif

            *Targ2++ = T0[res] * *Targ1;
            *Tres++ = -T0[arg2] * *Targ1++;

 #if 0
            TresOP = Tres-i;
            Targ2OP = Targ2-i;

            *Tres *= (i+1);
            *Targ2 *= (i+1);
     for (j=0;j<i;j++)
     { *Tres -= (*Targ2OP++) * (*zOP);
              *Targ2 += (*TresOP++) * (*zOP--);
     }
     *Targ2++ /= (i+1);
     *Tres++ /= (i+1);
 #endif
   }


 break;


      case 23:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res]=atan(T0[arg1]);

        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        for (l=0; l<p; l++)
        {
   {
 #if 0
            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);
 #endif

            *Tres++ = T0[arg2] * *Targ1++;

 #if 0
            Targ2OP = Targ2;

            *Tres *= (i+1);
     for (j=0;j<i;j++)
       *Tres += (*Targ2OP++) * (*zOP--);
     *Tres++ /= (i+1);
 #endif
   }
         
        }


 break;


      case 26:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = asin(T0[arg1]);

        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        if (T0[arg1] == 1.0)
          for (l=0; l<p; l++)
          {
              if (*Targ1 > 0.0)
              { r0 = make_nan();
                Targ1++;
                ;
              }
              else
                if (*Targ1 < 0.0)
                { r0 = make_inf();
                  Targ1++;
                  ;
                }
                else
                { r0 = 0.0;
                  Targ1++;
                }
            *Tres = r0;
            Tres++;
          }
        else
          if (T0[arg1] == -1.0)
            for (l=0; l<p; l++)
            {
                if (*Targ1 > 0.0)
                { r0 = make_inf();
                  Targ1++;
                  ;
                }
                else
                  if (*Targ1 < 0.0)
                  { r0 = make_nan();
                    Targ1++;
                    ;
                  }
                  else
                  { r0 = 0.0;
                    Targ1++;
                  }
              *Tres = r0;
              Tres++;
            }
          else
            for (l=0; l<p; l++)
            {
              {
 #if 0
                zOP = z+i;
                (*zOP--) = (i+1) * (*Targ1);
 #endif

                *Tres++ = T0[arg2] * *Targ1++;

 #if 0
                Targ2OP = Targ2;

                *Tres *= (i+1);
           for (j=0;j<i;j++)
           *Tres += (*Targ2OP++) * (*zOP--);
         *Tres++ /= (i+1);
 #endif
       }
             
            }


 break;


      case 27:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = acos(T0[arg1]);

        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        if (T0[arg1] == 1.0)
          for (l=0; l<p; l++)
          {
              if (*Targ1 > 0.0)
              { r0 = make_nan();
                Targ1++;
                ;
              }
              else
                if (*Targ1 < 0.0)
                { r0 = -make_inf();
                  Targ1++;
                  ;
                }
                else
                { r0 = 0.0;
                  Targ1++;
                }
            *Tres = r0;
            Tres++;
          }
        else
          if (T0[arg1] == -1.0)
            for (l=0; l<p; l++)
            {
                if (*Targ1 > 0.0)
                { r0 = -make_inf();
                  Targ1++;
                  ;
                }
                else
                  if (*Targ1 < 0.0)
                  { r0 = make_nan();
                    Targ1++;
                    ;
                  }
                  else
                  { r0 = 0.0;
                    Targ1++;
                  }
              *Tres = r0;
              Tres++;
            }
          else
            for (l=0; l<p; l++)
            {
       {
 #if 0
                zOP = z+i;
                (*zOP--) = (i+1) * (*Targ1);
 #endif

                *Tres++ = T0[arg2] * *Targ1++;

 #if 0
                Targ2OP = Targ2;

                *Tres *= (i+1);
           for (j=0;j<i;j++)
           *Tres += (*Targ2OP++) * (*zOP--);
         *Tres++ /= (i+1);
 #endif
       }
             
            }


 break;
      case 24:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       


 Tres = T[res];
 Targ = T[arg];

        divs = 1.0 / T0[arg];
        for (l=0; l<p; l++)
        { if (T0[arg] == 0.0)
          { TargOP = Targ;
           
            { if (*TargOP++ < 0.0)
              { divs = make_nan();
                ;
              }
     }
          }


         
   { *Tres++ = *Targ++ * divs;
 #if 0
            TresOP = Tres - i;
            zOP = z+i;

            (*zOP--) = *Tres;
     (*Tres) *= i+1;
      for (j=0;j<i;j++)
       (*Tres) -= (*zOP--) * (*TresOP++) * (j+1);
     *Tres++ /= i+1;
 #endif
          }
        }


        T0[res] = log(T0[arg]);
 break;


      case 25:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       


        if (arg == res)
        {
 }


        T0temp = T0[arg];


        T0[res] = pow(T0[arg], coval);

 Tres = T[res];
 Targ = T[arg];

        if (T0temp == 0.0)
          for (l=0; l<p; l++)
          {
            { if (*Targ > 0.0)
              { if (coval <= 0.0)
           r0 = make_nan();
                else
                  if (coval > 1.0)
                    r0 = 0.0;
                  else
                    if (coval == 1.0)
               r0 = 1.0 ;
                    else
               r0 = make_inf();
                Targ++;
                ;
              }
              else
                if (*Targ < 0.0)
                { r0 = make_nan();
                  Targ++;
                  ;
                }
                else
                { r0 = 0.0;
                  Targ++;
         }
            }
     *Tres++ = r0;
 #if 0
            for (i=1;i<k;i++)
            { *Tres++ = make_nan();
     }
 #endif
          }
        else
   { r0 = 1.0 / T0temp;
          for (l=0; l<p; l++)
           
            {
 #if 0
              zOP = z+i;
              (*zOP--) = (*Targ) * r0;
 #endif

              *Tres++ = T0[res] * *Targ++ * coval * r0;

 #if 0
              TresOP = Tres-i;

        (*Tres) *= i+1;
       y = coval*i -1;
              for (j=0;j<i;j++)
              { *Tres += (*TresOP++) * (*zOP--) * y;
  y -= coval + 1;
       }
       *Tres++ /= (i+1);
 #endif
     }
        }


 break;


      case 28:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

        T0[res] = sqrt(T0[arg]);

        Targ = T[arg];
 Tres = T[res];

        for (l=0; l<p; l++)
        { TargOP = Targ;
          if (T0[arg] == 0.0)
          { r0 = 0.0;
           
     { if (*Targ>0.0)
              { r0 = make_inf();
                Targ++;
                ;
              }
              else
               if (*Targ<0.0)
               { r0 = make_nan();
                 Targ++;
                 ;
               }
               else
                 Targ++;
            }
          }
          else
          { r0 = 0.5/T0[res];
          }
          Targ = TargOP;

   even = 1;
         
   { *Tres++ = r0 * *Targ++;
 #if 0
            TresOP = Tres-i;
            TresOP2 = Tres-1;

            x = 0;
            for (j=1;2*j-1<i;j++)
              x += (*TresOP++) * (*TresOP2--);
     x *= 2;
     if (!even)
              x += (*TresOP) * (*TresOP2);
     even = !even;
     *Tres++ -= r0*x;
 #endif
   }
        }


 break;


      case 32:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if (*g_real_ptr++!=T0[arg1])
   {

         
          end_sweep();
          return -2;
        }
        coval = *g_real_ptr++;

       

        T0[res] = coval;

        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        for (l=0; l<p; l++)
        {
   {
 #if 0
            zOP = z+i;
     (*zOP--) = (i+1) * (*Targ1);
 #endif

            *Tres++ = T0[arg2] * *Targ1++;

 #if 0
            Targ2OP = Targ2;

            *Tres *= (i+1);
     for (j=0;j<i;j++)
       *Tres += (*Targ2OP++) * (*zOP--);
     *Tres++ /= (i+1);
 #endif
   }
         
        }


 break;


      case 100:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       




        if (T0[arg1] > T0[arg2])
        { if (coval)
            if ((ret_c) > (2)) (ret_c) = (2);
        }
        else
          if (T0[arg1] < T0[arg2])
          { if (!coval)
              if ((ret_c) > (2)) (ret_c) = (2);
          }
          else
            if (arg1 != arg2)
              if ((ret_c) > (1)) (ret_c) = (1);


        Targ1 = T[arg1];
        Targ2 = T[arg2];
        Tres = T[res];

        Tqo = __null;
        if (T0[arg1] > T0[arg2])
          Tqo = Targ2;
        else
          if (T0[arg1] < T0[arg2])
            Tqo = Targ1;

        for (l=0; l<p; l++)
        { Targ = Tqo;
          if (Targ == __null)
          { Targ1OP = Targ1;
            Targ2OP = Targ2;
           
            { if (*Targ1 > *Targ2)
              { Targ = Targ2OP;
                Targ1++;
                Targ2++;
                ;
              }
              else
                if (*Targ1 < *Targ2)
                { Targ = Targ1OP;
                  Targ1++;
                  Targ2++;
                  ;
                }
              Targ1++; Targ2++;
            }
            if (Targ == __null)
              Targ = Targ1OP;
   }

         
            *Tres++ = *Targ++;

          if (Tqo)
          { Tqo++;
   }
        }


        T0[res] = ((T0[arg2]<T0[arg1])?T0[arg2]:T0[arg1]);
        break;


      case 101:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       




        if (T0[arg] < 0.0)
        { if (coval)
            if ((ret_c) > (2)) (ret_c) = (2);
        }
        else
          if (T0[arg] > 0.0)
          { if (!coval)
              if ((ret_c) > (2)) (ret_c) = (2);
          }


        Tres = T[res];
        Targ = T[arg];

        y = 0.0;
        if (T0[arg] != 0.0)
          if (T0[arg] < 0.0)
            y = -1.0;
          else
            y = 1.0;

        for (l=0; l<p; l++)
        { x = y;
         
          { if ((x == 0.0) && (*Targ != 0.0))
            { if ((ret_c) > (1)) (ret_c) = (1);
              if (*Targ < 0.0)
                x = -1.0;
              else
                x = 1.0;
            }
            *Tres++ = x * *Targ++;
          }
        }


        T0[res] = fabs(T0[arg]);
        break;


      case 115:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res]=ceil(T0[arg]);

        if (coval != T0[res])
          if ((ret_c) > (2)) (ret_c) = (2);

        Tres = T[res];

        for (l=0; l<p; l++)
          *Tres++ = 0.0;


        break;


      case 116:
        arg = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       

        T0[res] = floor(T0[arg]);

        if (coval != T0[res])
          if ((ret_c) > (2)) (ret_c) = (2);

        Tres = T[res];

        for (l=0; l<p; l++)
          *Tres++ = 0.0;


        break;






      case 70:
        arg = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       



        Tres = T[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];

        if (T0[arg] > 0)
          for (l=0; l<p; l++)
            *Tres++ = *Targ1++;
        else
          for (l=0; l<p; l++)
            *Tres++ = *Targ2++;


        if (T0[arg] > 0)
        { if (coval <= 0.0)
            if ((ret_c) > (2)) (ret_c) = (2);
          T0[res] = T0[arg1];
        }
        else
        { if (coval > 0.0)
            if ((ret_c) > (2)) (ret_c) = (2);
          if (T0[arg] == 0)
            if ((ret_c) > (0)) (ret_c) = (0);
          T0[res] = T0[arg2];
        }
        break;


      case 71:
        arg = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

       



        Tres = T[res];
        Targ1 = T[arg1];

        if (T0[arg] > 0)
          for (l=0; l<p; l++)
            *Tres++ = *Targ1++;


        if (T0[arg] > 0)
 { if (coval <= 0.0)
            if ((ret_c) > (2)) (ret_c) = (2);
          T0[res] = T0[arg1];
        }
        else
          if (T0[arg] == 0)
            if ((ret_c) > (0)) (ret_c) = (0);
        break;






      case 52:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
         
          T0[res] = T0[arg];

          Targ = T[arg];
          Tres = T[res];

          for (l=0; l<p; l++)
     *Tres++ = *Targ++;


          res++; arg++;
       }
        break;


      case 53:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        d = get_val_v_f(size);

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = *d++;

          Tres = T[res];

          for (l=0; l<p; l++)
     *Tres++ = 0;


          res++;
        }
        break;


      case 54:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = basepoint[indexi];

          Tres = T[res];

          for (l=0; l<p; l++)
           
              *Tres++ = argument[indexi][l];


          ++indexi;
          res++;
        }
        break;


      case 55:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {

          valuepoint[indexd] = T0[res];

          Tres = T[res];

          if (taylors != 0 )
            for (l=0; l<p; l++)
             
         taylors[indexd][l] = *Tres++;


          indexd++;
          res++;
        }
        break;






      case 59:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        for (ls=0; ls<size; ls++)
        {
         
   T0[res] += T0[arg];

          Tres = T[res];
          Targ = T[arg];

          for (l=0; l<p; l++)
     *Tres++ += *Targ++;


          res++; arg++;
        }
        break;


      case 57:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] -= T0[arg];

          Tres = T[res];
          Targ = T[arg];

          for (l=0; l<p; l++)
     *Tres++ -= *Targ++;


          res++; arg++;
        }
        break;


      case 61:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] *= coval;

          Tres = T[res];

          for (l=0; l<p; l++)
       *Tres++ *= coval;


          res++;
        }
        break;


      case 62:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;



        checkSize = res+size;

        for (ls=0; ls<size; ls++)
        { if (res == arg)
            res++;
          if (res == checkSize)
            res = arg;


         


          Tres = T[res];
          Targ = T[arg];

          Tres += p-1;
          Targ += p-1;

          for (l=p-1; l>=0; l--)
    
     { *Tres-- = T0[res]**Targ-- + *Tres*T0[arg];
 #if 0
              TresOP = Tres-i;
              TargOP = Targ;

              for (j=0;j<i;j++)
                *Tres += (*TresOP++) * (*TargOP--);
              Tres--;
 #endif
     }


          T0[res] *= T0[arg];
          res++;
        }
       break;






      case 40:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = T0[arg1] + T0[arg2];

          Tres = T[res];
          Targ1 = T[arg1];
          Targ2 = T[arg2];

          for (l=0; l<p; l++)
     *Tres++ = *Targ1++ + *Targ2++;


          res++; arg1++; arg2++;
        }
        break;


      case 42:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = T0[arg1] - T0[arg2];

          Tres = T[res];
          Targ1 = T[arg1];
          Targ2 = T[arg2];

          for (l=0; l<p; l++)
     *Tres++ = *Targ1++ - *Targ2++;


          res++; arg1++; arg2++;
        }
        break;


      case 45:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

       

 T0temp = 0.0;



        if ( ((res >= arg1) && (res < arg1+size))
            || ((res >= arg2) && (res < arg2+size)) )
 { TresOP = Ttemp;
          flag = 1;
 }
        else
        { TresOP = T[res];
          flag = 0;
 }

        Tres = TresOP;
        for (l=0; l<p; l++)
          *Tres++ = 0.0;


        for (ls=0; ls<size; ls++)
        {

          Tres = TresOP;
          Targ1 = T[arg1];
          Targ2 = T[arg2];


          Tres += p-1;
          Targ1 += p-1;
          Targ2 += p-1;

          for (l=p-1; l>=0; l--)
           
     { *Tres-- += T0[arg1]**Targ2-- + *Targ1--*T0[arg2];
 #if 0
              Targ1OP = Targ1-i+1;
              Targ2OP = Targ2;

              for (j=0;j<i;j++)
                *Tres += (*Targ1OP++) * (*Targ2OP--);
              Tres--;
 #endif
            }

          T0temp += T0[arg1] * T0[arg2];
          arg1++; arg2++;
        }


        T0[res] = T0temp;

        if (flag)
 { Tres = T[res];
          Tqo = TresOP;

          for (l=0; l<p; l++)
            *Tres++ = *Tqo++;
 }

 break;


      case 47:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;



        checkSize = res+size;

        for (ls=0; ls<size; ls++)
        { if (res == arg2)
          { res++; arg1++;
   }
          if (res == checkSize)
          { arg1 -= res-arg2;
            res = arg2;
   }


         


          Tres = T[res];
          Targ1 = T[arg1];
          Targ2 = T[arg2];


          Tres += p-1;
          Targ1 += p-1;
          Targ2 += p-1;

          for (l=p-1; l>=0; l--)
           
     { *Tres-- = T0[arg1]**Targ2-- + *Targ1--*T0[arg2];
 #if 0
              Targ1OP = Targ1-i+1;
              Targ2OP = Targ2;

              for (j=0;j<i;j++)
                *Tres += (*Targ1OP++) * (*Targ2OP--);
              Tres--;
 #endif
            }


          T0[res] = T0[arg1] * T0[arg2];
          res++; arg1++;
        }
        break;


      case 48:
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        coval = *g_real_ptr++;

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = T0[arg] * coval;

          Tres = T[res];
          Targ = T[arg];

          for (l=0; l<p; l++)
     *Tres++ = *Targ++ * coval;


          res++; arg++;
        }
        break;


      case 60:
        arg1 = *g_loc_ptr++;
        arg2 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;


        divs = 1.0 / T0[arg2];




        checkSize = res+size;

        for (ls=0; ls<size; ls++)
        { if (res == arg2)
          { res++; arg1++;
   }
          if (res == checkSize)
          { arg1 -= res-arg2;
            res = arg2;
   }


         

          T0[res] = T0[arg1] / T0[arg2];

          Tres = T[res];
          Targ1 = T[arg1];
          Targ2 = T[arg2];

          for (l=0; l<p; l++)
           
     {
 #if 0
              zOP = z+i;
              (*zOP--) = -(*Targ2) * divs;
 #endif


              *Tres++ = *Targ1++ * divs + T0[res] * (-*Targ2++ * divs);

 #if 0
              TresOP = Tres-i;

       for (j=0;j<i;j++)
         *Tres += (*TresOP++) * (*zOP--);
              Tres++;
 #endif
     }


          res++; arg1++;
        }
        break;






      case 75:
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        res = *g_loc_ptr++;

        arg = arg2 + (int)(T0[arg1]);

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);


       

        T0[res] = T0[arg];

        Tres = T[res];
        Targ = T[arg];

        for (l=0; l<p; l++)
          *Tres++ = *Targ++;


        break;


      case 76:
        arg2 = *g_loc_ptr++;
 arg1 = *g_loc_ptr++;
        arg = *g_loc_ptr++;

        res = arg2 + (int)(T0[arg1]);

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

       

        T0[res] = T0[arg];

        Tres = T[res];
        Targ = T[arg];

        for (l=0; l<p; l++)
          *Tres++ = *Targ++;


        break;


      case 77:
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;

        arg = arg2+(int)(T0[arg1]);

       

        T0[arg] = *g_real_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        Targ = T[arg];

        for (l=0; l<p; l++)
          *Targ++ = 0;


        break;


      case 72:
 fprintf((stderr),"doing m_subscript\n"); exit(12);
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        arg = arg2 + (int)(T0[arg1])*size;

 if (T0[arg1] != (int)T0[arg1]){
   fprintf((stderr),"T0[arg1] is not an integer in m_subscript in uni5_for.c\n"); exit(12);}

        for (ls=0; ls<size; ls++)
        {
         

          T0[res] = T0[arg];

          Tres = T[res];
          Targ = T[arg];

          for (l=0; l<p; l++)
            *Tres++ = *Targ++;


         res++; arg++;
        }
        break;


      case 73:
 fprintf((stderr),"doing m_subscript_l\n"); exit(12);
        arg2 = *g_loc_ptr++;
 arg1 = *g_loc_ptr++;
        size = *g_loc_ptr++;
        arg = *g_loc_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        res = arg2 + (int)(T0[arg1])*size;
        for (ls=0; ls<size; ls++)
        {

          T0[res] = T0[arg];

          Tres = T[res];
          Targ = T[arg];

          for (l=0; l<p; l++)
            *Tres++ = *Targ++;


          res++; arg++;
        }
        break;


      case 74:
 fprintf((stderr),"doing m_subscript_ld\n"); exit(12);
        arg2 = *g_loc_ptr++;
        arg1 = *g_loc_ptr++;
        arg = *g_loc_ptr++;
        size = *g_loc_ptr++;

        if ( (int)(T0[arg1]) != (int)(*g_real_ptr++) )
          if ((ret_c) > (2)) (ret_c) = (2);

        d = get_val_v_f(size);

        res = arg2 + (int)(T0[arg1])*size + arg;
        for (ls=0; ls<size; ls++)
        {

          T0[res] = d[ls];

          Tres = T[res];

          for (l=0; l<p; l++)
            *Tres++ = 0.0;


          res++;
        }
        break;






      case 90:
        size = *g_loc_ptr++;
        res = *g_loc_ptr++;
        d = get_val_v_f(size);

        for (ls=0;ls<size;ls++)
        { T0[res]=*d;

          Tres = T[res];

          for (l=0; l<p; l++)
            *Tres++ = 0;


          res++; d++;
        }
        break;


      case 1:
        arg1=*g_loc_ptr++;
        arg2=*g_loc_ptr++;
   break;


      default:


        fprintf((DIAG_OUT),"ADOL-C fatal error in " "fov_forward" " ("
                       "uni5_for.cpp"
                       ") : no such operation %d\n", operation);
 exit(12);
 break;

      }
      operation=*g_op_ptr++;
    }

  end_sweep();
  return ret_c;
}





