#define _ADOLC_SRC_

#include "dvlparms.h" /* Developers Parameters */
#include "usrparms.h" /* Users Parameters */
#include "interfaces.h"
//#include "oplate.h"
#include "adalloc.h"
#include "taputil.h"
#include "tayutil.h"

#include <stdio.h>
#include <math.h>

#define __null 0


static short tag;

static int rev_location_cnt;
static int dep_cnt;
static int ind_cnt;
// 256 "fo_rev.c"
int fov_reverse(short tnum,
                int depen,
                int indep,
                int nrows,
                double **lagrange,
                double **results)



{


  unsigned char operation;
  int tape_stats[13];
  int ret_c=3;

  unsigned int size = 0;
  unsigned int res = 0;
  unsigned int arg = 0;
  unsigned int arg1 = 0;
  unsigned int arg2 = 0;

  double coval = 0, *d = 0;

  int indexi = 0, indexd = 0;


  int i, j, l, ls;


  double x, y, r0, r_0;
  int op_buffer,loc_buffer,real_buffer;
  static int kax, rax, pax;
  int taycheck;
  int numdep,numind;
  double aTmp;
// 300 "fo_rev.c"
  static double *T;
// 309 "fo_rev.c"
  static double** A;
  static double *Atemp;

  double *Ares, *Aarg, *Aarg1, *Aarg2, *Aqo;
// 326 "fo_rev.c"
  int p = nrows;
// 352 "fo_rev.c"
  tag = tnum;

  tapestats(tag,tape_stats);
  ind_cnt = tape_stats[0];
  dep_cnt = tape_stats[1];
  rev_location_cnt = tape_stats[2];
  op_buffer = tape_stats[4];
  loc_buffer = tape_stats[5];
  real_buffer = tape_stats[6];

  set_buf_size(op_buffer,loc_buffer,real_buffer);

  if ((depen != dep_cnt)||(indep != ind_cnt))
  { fprintf((DIAG_OUT),"ADOL-C error: Reverse sweep on tape %d  aborted!\n",tag);
    fprintf((DIAG_OUT),"Number of dependent and/or independent variables "
             "passed to reverse is\ninconsistent with number "
             "recorded on tape %d \n",tag);
    exit (-1);
  }

  indexi = ind_cnt - 1;
  indexd = dep_cnt - 1;
// 402 "fo_rev.c"
  if (rev_location_cnt > rax || p > pax)
  { if (rax || pax)
    { free((char *) Atemp);
      free((char *) T);
      free((char *) *A); free((char*) A);
    }
    Atemp = myalloc1(p);
    T = (double *)malloc(sizeof(double)*rev_location_cnt);
    if (T == __null)
    { fprintf((DIAG_OUT),"ADOL-C error: cannot allocate %i bytes!\n",
              sizeof(double)*rev_location_cnt);
      exit (-1);
    }
    A = myalloc2(rev_location_cnt,p);
    rax = rev_location_cnt;
    pax = p;
  }





  taylor_back(T,&numdep,&numind,&taycheck);

  if (taycheck < 0)
  { fprintf((DIAG_OUT),"\n ADOL-C error: reverse fails because it was not"
                   " preceeded\nby a forward sweep with degree>0, keep=1!\n");
    exit(12);
  };

  if((numdep != depen)||(numind != indep))
  { fprintf((DIAG_OUT), "\n ADOL-C error: reverse fails on tape %d because the"
                    " number of\nindependent and/or dependent variables"
                    " given to reverse are\ninconsistent with that of the"
                    " internal taylor array.\n",tag);
    exit(12);
  }






  init_rev_sweep(tag);

  operation=*(--g_op_ptr);
  while (operation != 36)
  {
    switch (operation) {






      case 37:
        get_op_block_r();
        operation = *(--g_op_ptr);

        break;


      case 38:
        get_loc_block_r();
        break;


      case 39:
        get_val_block_r();
        break;


      case 36:
      case 35:
 break;






      case 102 :
        arg = *(--g_loc_ptr);

        ret_c = 0;
        break;


      case 103 :
      case 105 :
      case 107 :
        arg = *(--g_loc_ptr);
        break;


      case 106 :
      case 104 :
        arg = *(--g_loc_ptr);

       

        if (T[arg] == 0)
          ret_c = 0;
        break;






      case 4:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Aarg = A[arg];
 Ares = A[res];

        for (l=0; l<p; l++)
        { *Aarg++ += *Ares;
          *Ares++ = 0.0;
        }

 get_taylor(res);
 break;


      case 5:

        res = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];

        for (l=0; l<p; l++)
          *Ares++ = 0.0;

        get_taylor(res);
 break;


      case 92:
      case 91:
        res = *(--g_loc_ptr);

 Ares = A[res];

        for (l=0; l<p; l++)
          *Ares++ = 0.0;

        get_taylor(res);
 break;


      case 2:

        res = *(--g_loc_ptr);

 Ares = A[res];

        for (l=0; l<p; l++)
          results[l][indexi] = *Ares++;

        get_taylor(res);
 indexi--;
 break;


      case 3:

        res = *(--g_loc_ptr);

 Ares = A[res];

        for (l=0; l<p; l++)
          *Ares++ = lagrange[l][indexd];

 indexd--;
 break;






      case 6:

        res = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 get_taylor(res);
 break;


      case 7:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];;

        for (l=0; l<p; l++)
          *Aarg++ += *Ares++;

 get_taylor(res);
 break;


      case 8:

        res = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 get_taylor(res);
 break;


      case 9:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];

        for (l=0; l<p; l++)
          *Aarg++ -= *Ares++;

 get_taylor(res);
 break;


      case 10:

        res = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];

        for (l=0; l<p; l++)
          *Ares++ *= coval;

 get_taylor(res);
 break;


      case 11:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

  get_taylor(res);

 Ares = A[res];
        Aarg = A[arg];
       


        for (l=0; l<p; l++)
        { aTmp = *Ares;

   *Ares++ = aTmp * T[arg];
   *Aarg++ += aTmp * T[res];
        }
        break;


      case 95:
      case 96:
        res = *(--g_loc_ptr);

 get_taylor(res);
 break;






      case 12:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 Ares = A[res];
 Aarg1 = A[arg1];
 Aarg2 = A[arg2];

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg1++ += aTmp;
          *Aarg2++ += aTmp;
        }

       get_taylor(res);
 break;


      case 13:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];
 Aarg = A[arg];

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg++ += aTmp;
        }

       get_taylor(res);
 break;


      case 14:

        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 Ares = A[res];
 Aarg1 = A[arg1];
 Aarg2 = A[arg2];

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg1++ += aTmp;
          *Aarg2++ -= aTmp;
        }

        get_taylor(res);
 break;


      case 15:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];
 Aarg = A[arg];

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg++ -= aTmp;
        }

        get_taylor(res);
 break;


      case 16:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

        get_taylor(res);

 Ares = A[res];
 Aarg2 = A[arg2];
 Aarg1 = A[arg1];
       


        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg2++ += aTmp * T[arg1];
   *Aarg1++ += aTmp * T[arg2];
        }
        break;


      case 17:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];
 Aarg = A[arg];

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg++ += coval * aTmp;
        }

        get_taylor(res);
 break;


      case 18:

        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 Ares = A[res];
 Aarg2 = A[arg2];
 Aarg1 = A[arg1];

       


 r_0 = -T[res];
        get_taylor(res);
        r0 = 1.0 / T[arg2];
 r_0 *= r0;

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg1++ += aTmp * r0;
   *Aarg2++ += aTmp * r_0;
        }

        break;


      case 19:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];
 Aarg = A[arg];

       


        r0 = -T[res];
        if (arg == res)
          get_taylor(arg);
        r0 /= T[arg];

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg++ += aTmp * r0;
        }

        get_taylor(res);
        break;






      case 98:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg++ += aTmp;
        }

       get_taylor(res);
 break;


      case 97:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg++ -= aTmp;
        }

       get_taylor(res);
 break;






      case 20:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];
       

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg++ += aTmp * T[res];
        }

  get_taylor(res);
        break;


      case 22:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 Ares = A[res];
 Aarg1 = A[arg1];
       

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg1++ += aTmp * T[arg2];
        }

        get_taylor(res);
        get_taylor(arg2);

 break;


      case 21:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 Ares = A[res];
 Aarg1 = A[arg1];
       

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg1++ -= aTmp * T[arg2];
        }

        get_taylor(res);
        get_taylor(arg2);

 break;


      case 23:
      case 26:
      case 27:
      case 29:
      case 30:
      case 31:
      case 114:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

        get_taylor(res);

        Ares = A[res];
        Aarg1 = A[arg1];
       

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg1++ += aTmp * T[arg2];
        }
 break;


      case 24:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

        get_taylor(res);

 Ares = A[res];
 Aarg = A[arg];


        r0 = 1.0/T[arg];

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg++ += aTmp * r0;
        }
 break;


      case 25:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];
 Aarg = A[arg];
       
       


        r0 = T[res];
        if (arg == res)
          get_taylor(arg);
        if (T[arg] == 0.0)
          r0 = 0.0;
        else
          r0 *= coval/T[arg];

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg++ += aTmp * r0;
        }

        get_taylor(res);
        break;


      case 28:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];
       

        if (T[res] == 0.0)
          r0 = 0.0;
        else
          r0 = 0.5 / T[res];

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg++ += aTmp * r0;
        }

        get_taylor(res);
        break;


      case 32:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];
 Aarg1 = A[arg1];
       

        for (l=0; l<p; l++)
        { aTmp = *Ares;
          *Ares++ = 0.0;
          *Aarg1++ += aTmp * T[arg2];
        }

       get_taylor(res);
 break;


      case 100:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        get_taylor(res);

        Aarg1 = A[arg1];
        Aarg2 = A[arg2];
        Ares = A[res];
       
       

        if (T[arg1] > T[arg2])
          for (l=0; l<p; l++)
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((coval) && (aTmp))
              if ((ret_c) > (2)) (ret_c) = (2);
            *Aarg2++ += aTmp;
          }
        else
          if (T[arg1] < T[arg2])
            for (l=0; l<p; l++)
            { aTmp = *Ares;
              *Ares++ = 0.0;
              if ((!coval) && (aTmp))
                if ((ret_c) > (2)) (ret_c) = (2);
              *Aarg1++ += aTmp;
            }
          else
          {
            for (l=0; l<p; l++)
            { aTmp = *Ares / 2.0;
              *Ares++ = 0.0;
              *Aarg2++ += aTmp;
              *Aarg1++ += aTmp;
            }
            if (arg1 != arg2)
              if ((ret_c) > (1)) (ret_c) = (1);
          }
        break;


      case 101:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        get_taylor(res);

        Ares = A[res];
        Aarg = A[arg];
       

        if (T[arg] < 0.0)
          for (l=0; l<p; l++)
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((coval) && (aTmp))
              if ((ret_c) > (2)) (ret_c) = (2);
            *Aarg++ -= aTmp;
          }
        else
          if (T[arg] > 0.0)
            for (l=0; l<p; l++)
            { aTmp = *Ares;
              *Ares++ = 0.0;
              if ((!coval) && (aTmp))
                if ((ret_c) > (2)) (ret_c) = (2);
              *Aarg++ += aTmp;
            }
          else
            for (l=0; l<p; l++)
            { aTmp = *Ares;
              *Ares++ = 0.0;
              if (aTmp)
                if ((ret_c) > (1)) (ret_c) = (1);
            }
        break;


      case 115:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        get_taylor(res);

        Ares = A[res];
       

        coval = (coval != ceil(T[arg]) );

        for (l=0; l<p; l++)
        { if ((coval) && (*Ares))
            if ((ret_c) > (2)) (ret_c) = (2);
          *Ares++ = 0.0;
        }
        break;


      case 116:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        get_taylor(res);

        Ares = A[res];
        Aarg = A[arg];
       

        coval = ( coval != floor(T[arg1]) );

        for (l=0; l<p; l++)
        { if ( (coval) && (*Ares) )
            if ((ret_c) > (2)) (ret_c) = (2);
          *Ares++ = 0.0;
 }
        break;






      case 70:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 get_taylor(res);

        Aarg1 = A[arg1];
 Ares = A[res];
        Aarg2 = A[arg2];
       


        if (T[arg] > 0.0)
        { if (res != arg1)
            for (l=0; l<p; l++)
            { if ((coval <= 0.0) && (*Ares))
                if ((ret_c) > (2)) (ret_c) = (2);
              *Aarg1++ += *Ares;
              *Ares++ = 0.0;
     }
          else
            for (l=0; l<p; l++)
              if ((coval <= 0.0) && (*Ares++))
                if ((ret_c) > (2)) (ret_c) = (2);
 }
        else
        { if (res != arg2)
            for (l=0; l<p; l++)
            { if ((coval <= 0.0) && (*Ares))
                if ((ret_c) > (2)) (ret_c) = (2);
              *Aarg2++ += *Ares;
              *Ares++ = 0.0;
     }
          else
            for (l=0; l<p; l++)
              if ((coval <= 0.0) && (*Ares++))
                if ((ret_c) > (2)) (ret_c) = (2);
 }
        break;


      case 71:
        res = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        get_taylor(res);

        Aarg1 = A[arg1];
 Ares = A[res];
       


        if (T[arg] > 0.0)
        { if (res != arg1)
            for (l=0; l<p; l++)
            { if ((coval <= 0.0) && (*Ares))
                if ((ret_c) > (2)) (ret_c) = (2);
              *Aarg1++ += *Ares;
              *Ares++ = 0.0;
     }
          else
            for (l=0; l<p; l++)
              if ((coval <= 0.0) && (*Ares++))
                if ((ret_c) > (2)) (ret_c) = (2);
 }
        else
          if (T[arg] == 0.0)
            for (l=0; l<p; l++)
              if (*Ares++)
                if ((ret_c) > (0)) (ret_c) = (0);
        break;






      case 52:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 res += size;
 arg += size;
        for (ls=size; ls>0; ls--)
 { res--;
   arg--;


          Aarg = A[arg];
   Ares = A[res];

          for (l=0; l<p; l++)
   { *Aarg++ += *Ares;
     *Ares++ = 0.0;
   }

   get_taylor(res);
   }
 break;


      case 53:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        d = get_val_v_r(size);

        res += size;
        d += size;
 for (ls=size; ls>0; ls--)
 { res--;
   coval = *(--d);


   Ares = A[res];

   for (l=0; l<p; l++)
     *Ares++ = 0.0;

   get_taylor(res);
 }
 break;


      case 54:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);

        res += size;
 for (ls=size; ls>0; ls--)
 { res--;


   Ares = A[res];

   for (l=0; l<p; l++)
     results[l][indexi] = *Ares++;
   indexi--;

   get_taylor(res);
        }
 reset_val_r();
 break;


      case 55:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);

        res += size;
 for (ls=size; ls>0; ls--)
 { res--;


   Ares = A[res];

          for (l=0; l<p; l++)
            *Ares++ = lagrange[l][indexd];
   indexd--;
 }
 break;






      case 59:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

        res += size;
        arg += size;
 for (ls=size; ls>0; ls--)
 { res--;
   arg--;


          Ares = A[res];
   Aarg = A[arg];

   for (l=0; l<p; l++)
     *Aarg++ += *Ares++;

          get_taylor(res);
 }
 break;


      case 57:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

        res += size;
        arg += size;
 for (ls=size; ls>0; ls--)
 { res--;
   arg--;


   Ares = A[res];
   Aarg = A[arg];

   for (l=0; l<p; l++)
     *Aarg++ -= *Ares++;

          get_taylor(res);
 }
 break;


      case 61:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        res += size;
 for (ls=size; ls>0; ls--)
        { res--;



   Ares = A[res];

          for (l=0; l<p; l++)
            *Ares++ *= coval;

   get_taylor(res);
        }
 break;


      case 62:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);



        if ((arg >= res) && (arg < res+size))
 {

   get_taylor(arg);

   Aarg = A[arg];
         

          for (l=0; l<p; l++)
            *Aarg++ *= 2.0 * T[arg];
 }

 res += size;
        for (ls=size; ls>0; ls--)
 { res--;


          if (res == arg)
            continue;


   get_taylor(res);

   Aarg = A[arg];
   Ares = A[res];
         
         

          for (l=0; l<p; l++)
          { r0 = *Ares;

            *Ares++ = r0 * T[arg];
            *Aarg++ += r0 * T[res];
          }
 }
 break;






      case 40:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 res += size;
 arg1 += size;
 arg2 += size;
        for (ls=size; ls>0; ls--)
 { arg2--;
   arg1--;
   res--;


   Ares = A[res];
   Aarg1 = A[arg1];
   Aarg2 = A[arg2];

   for (l=0; l<p; l++)
   { aTmp = *Ares;
            *Ares++ = 0.0;
            *Aarg1++ += aTmp;
            *Aarg2++ += aTmp;
          }

         get_taylor(res);
 }
 break;


      case 42:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 res += size;
 arg1 += size;
 arg2 += size;
        for (ls=size; ls>0; ls--)
 { arg2--;
   arg1--;
   res--;


   Ares = A[res];
   Aarg1 = A[arg1];
   Aarg2 = A[arg2];

   for (l=0; l<p; l++)
   { aTmp = *Ares;
            *Ares++ = 0.0;
            *Aarg1++ += aTmp;
            *Aarg2++ -= aTmp;
          }

          get_taylor(res);
 }
 break;


      case 45:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

        get_taylor(res);


        Aqo = Atemp;
 Ares = A[res];
        for (l=0; l<p; l++)
 { *Aqo++ = *Ares;
          *Ares++ = 0.0;
 }

 for (ls=0; ls<size; ls++)
 {
   Aarg2 = A[arg2];
   Aarg1 = A[arg1];
          Aqo = Atemp;
  
  


   for (l=0; l<p; l++)
          { *Aarg2++ += *Aqo * T[arg1];
     *Aarg1++ += *Aqo++ * T[arg2];
          }

          arg1++; arg2++;
 }
 break;


      case 47:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);



        if ((arg2 >= res) && (arg2 < res+size))
 {

       get_taylor(arg2);

   Aarg1 = A[arg1+res-arg2];
   Aarg2 = A[arg2];
  
  

          for (l=0; l<p; l++)
          { *Aarg1++ += *Aarg2 * T[arg2];
     *Aarg2++ *= T[arg1];
          }
 }

        res += size;
        arg1 += size;
 for (ls=size; ls>0; ls--)
 { arg1--;
   res--;

          if (res == arg2)
            continue;


       get_taylor(res);

   Ares = A[res];
   Aarg2 = A[arg2];
   Aarg1 = A[arg1];
  
  

          for (l=0; l<p; l++)
          { aTmp = *Ares;
            *Ares++ = 0.0;
            *Aarg2++ += aTmp * T[arg1];
     *Aarg1++ += aTmp * T[arg2];
          }
 }
 break;


      case 48:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        res += size;
        arg += size;
 for (ls=size; ls>0; ls--)
 { arg--;
   res--;



   Ares = A[res];
   Aarg = A[arg];

          for (l=0; l<p; l++)
          { aTmp = *Ares;
            *Ares++ = 0.0;
            *Aarg++ += coval * aTmp;
          }

          get_taylor(res);
        }
 break;


      case 60:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);



        if ((arg2 >= res) && (arg2 < res+size))
 {

   Aarg2 = A[arg2];
   Aarg1 = A[arg1+res-arg2];
  


   r_0 = -T[arg2];
          get_taylor(arg2);
          r0 = 1.0 / T[arg2];
    r_0 *= r0;

          for (l=0; l<p; l++)
          { *Aarg1++ += *Aarg2 * r0;
     *Aarg2++ *= r_0;
          }
 }

        res += size;
        arg1 += size;
 for (ls=size; ls>0; ls--)
 { arg1--;
   res--;

          if (res == arg2)
            continue;


   Ares = A[res];
   Aarg2 = A[arg2];
   Aarg1 = A[arg1];
  
  


   r_0 = -T[res];
          get_taylor(res);
          r0 = 1.0 / T[arg2];
    r_0 *= r0;

          for (l=0; l<p; l++)
          { aTmp = *Ares;
            *Ares++ = 0.0;
            *Aarg1++ += aTmp * r0;
     *Aarg2++ += aTmp * r_0;
          }
 }
 break;






      case 75:
        res = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);



        arg = arg2 + (int)(T[arg1]);


        get_taylor(res);

 Aarg = A[arg];
 Ares = A[res];

        for (l=0; l<p; l++)
        { if (((int)(coval) != (int)(T[arg1])) && (*Ares))
            if ((ret_c) > (2)) (ret_c) = (2);

          *Aarg++ += *Ares;
          if (arg != res)
            *Ares++ = 0;
          else
            *Ares++;
        }

 break;


      case 76:
        arg = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);



        res = arg2 + (int)(T[arg1]);

 get_taylor(res);

 Ares = A[res];
 Aarg = A[arg];

 for (l=0; l<p; l++)
        { if (((int)(coval) != (int)(T[arg1])) && (*Ares))
            if ((ret_c) > (2)) (ret_c) = (2);

          *Aarg++ += *Ares;
          if(arg != res)
            *Ares++ = 0;
          else
            *Ares++;
        }
 break;


      case 77:
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);
        coval = *(--g_real_ptr);



        arg = arg2 + (int)(T[arg1]);

        get_taylor(arg);

        if((int)(coval)!=(int)(T[arg1]))
          if ((ret_c) > (2)) (ret_c) = (2);

 Aarg = A[arg];

        for (l=0; l<p; l++)
   *Aarg++ = 0.0;
 break;


      case 72:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);



        arg = arg2 + ((int)(T[arg1]) + 1)*size;
        res += size;
        for (ls=size; ls>0; ls--)
        { res--; arg--;


          get_taylor(res);

          Aarg = A[arg];
   Ares = A[res];

          for (l=0; l<p; l++)
          { if (((int)(coval)!=(int)(T[arg1])) && (*Ares))
              if ((ret_c) > (2)) (ret_c) = (2);
            *Aarg++ += *Ares;
            if (arg != res)
              *Ares++ = 0;
            else
              *Ares++;
          }
        }
 break;


      case 73:
        arg = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);



        res = arg2 + ((int)(T[arg1]) + 1)*size;
        arg += size;
        for (ls=size; ls>0; ls--)
        { arg--; res--;

          get_taylor(res);

          Aarg = A[arg];
          Ares = A[res];

          for (l=0; l<p; l++)
          { if (((int)(coval) != (int)(T[arg1])) && (*Ares))
              if ((ret_c) > (2)) (ret_c) = (2);
            *Aarg++ += *Ares;
            if (arg != res)
              *Ares++ = 0;
            else
              *Ares++;
          }
        }
 break;


      case 74:
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);

        d = get_val_v_r(size);
        coval = *(--g_real_ptr);



        if ((int)(coval) != (int)(T[arg1]))
          if ((ret_c) > (2)) (ret_c) = (2);

        res = arg2 + ((int)(T[arg1]) + 1)*size + arg;
        for (ls=size; ls>0; ls--)
        { res--;

          get_taylor(res);

          Ares = A[res];

          for (l=0; l<p; l++)
            *Ares++ = 0.0;
        }
 break;






      case 90:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        d = get_val_v_r(size);

        res += size;
 for (ls=size; ls>0; ls--)
 { res--;

          Ares = A[res];

          for (l=0; l<p; l++)
            *Ares++ = 0.0;
        }
        break;


      case 1:
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 for (j=arg1;j<=arg2;j++)
 { Aarg1 = A[j];

          for (l=0; l<p; l++)
            *Aarg1++ = 0.0;

          get_taylor(j);
 }
 break;


      default:


        fprintf((DIAG_OUT),"ADOL-C fatal error in " "fov_reverse" " ("
                "fo_rev.c"
                ") : no such operation %d\n", operation);
 exit(12);
 break;
      }


      operation=*(--g_op_ptr);
    }

  end_sweep();
  return ret_c;
}






