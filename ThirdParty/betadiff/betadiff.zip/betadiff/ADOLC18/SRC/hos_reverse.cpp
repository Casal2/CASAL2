#define _ADOLC_SRC_

#include "dvlparms.h" /* Developers Parameters */
#include "usrparms.h" /* Users Parameters */
#include "interfaces.h"
//#include "oplate.h"
#include "adalloc.h"
#include "taputil.h"
#include "tayutil.h"
#include "convolut.h"

#include <stdio.h>
#include <math.h>

#define __null 0


static short tag;

static int rev_location_cnt;
static int dep_cnt;
static int ind_cnt;





int hos_reverse(short tnum,
                int depen,
                int indep,
                int degre,
                double *lagrange,
                double **results)
// 297 "ho_rev.c"
{


  unsigned char operation;
  int tape_stats[13];
  int ret_c=3;

  unsigned int size = 0;
  unsigned int res = 0;
  unsigned int arg = 0;
  unsigned int arg1 = 0;
  unsigned int arg2 = 0;

  double coval = 0, *d = 0;

  int indexi = 0, indexd = 0;


  int i, j, l, ls;


  double x, y, r0, r_0;
  int op_buffer,loc_buffer,real_buffer;
  static int kax, rax, pax;
  int taycheck;
  int numdep,numind;
  double aTmp;




  static double **T;
  static double *Ttemp;
  static double *Ttemp2;
  double *Tres, *Targ, *Targ1, *Targ2, *Tqo;
// 342 "ho_rev.c"
  static double** A;
  static double *Atemp;

  double *Ares, *Aarg, *Aarg1, *Aarg2, *Aqo;

  static double *Atemp2;
  double *AP1, *AP2;




  int k = degre + 1;
  int k1 = k + 1;
  double comp;
// 390 "ho_rev.c"
  tag = tnum;

  tapestats(tag,tape_stats);
  ind_cnt = tape_stats[0];
  dep_cnt = tape_stats[1];
  rev_location_cnt = tape_stats[2];
  op_buffer = tape_stats[4];
  loc_buffer = tape_stats[5];
  real_buffer = tape_stats[6];

  set_buf_size(op_buffer,loc_buffer,real_buffer);

  if ((depen != dep_cnt)||(indep != ind_cnt))
  { fprintf((DIAG_OUT),"ADOL-C error: Reverse sweep on tape %d  aborted!\n",tag);
    fprintf((DIAG_OUT),"Number of dependent and/or independent variables "
             "passed to reverse is\ninconsistent with number "
             "recorded on tape %d \n",tag);
    exit (-1);
  }

  indexi = ind_cnt - 1;
  indexd = dep_cnt - 1;







  if (k > kax || rev_location_cnt > rax)
  { if (rax || kax)
    { free((char*) Atemp);
      free((char*) Atemp2);
      free((char*) Ttemp);
      free((char*) *T); free((char*) T);
      free((char*) *A); free((char*) A);
    }
    Atemp = myalloc1(k1);
    Atemp2 = myalloc1(k1);
    A = myalloc2(rev_location_cnt,k1);
    Ttemp = (double *)malloc(k*sizeof(double));
    Ttemp2 = (double *)malloc(k*sizeof(double));
    T = (double**)malloc(rev_location_cnt*sizeof(double*));
    Tqo = (double *)malloc(rev_location_cnt*k*sizeof(double));
    if ((T == __null)||(Tqo == __null)||(Ttemp == __null))
    { fprintf((DIAG_OUT),"ADOL-C error: cannot allocate %i + %i + %i bytes!\n",
              k*sizeof(double),rev_location_cnt*sizeof(double*),
              rev_location_cnt*k*sizeof(double));
      exit (-1);
    }
    for(i=0;i<rev_location_cnt;i++)
    { T[i] = Tqo;
      Tqo += k;
    }
    kax = k;
    rax = rev_location_cnt;
  }
// 484 "ho_rev.c"
  taylor_back2(T,&numdep,&numind,&taycheck);

  if(taycheck != degre)
  { fprintf((DIAG_OUT),"\n ADOL-C error: reverse fails because it was not"
                   " preceeded\nby a forward sweep with degree>%i,"
                   " keep=%i!\n",degre,degre+1);
    exit(12);
  };

  if((numdep != depen)||(numind != indep))
  { fprintf((DIAG_OUT),"\n ADOL-C error: reverse fails on tape %d because the"
                   " number of\nindependent and/or dependent variables"
                   " given to reverse are\ninconsistent with that of the"
                   "  internal taylor array.\n",tag);
    exit(12);
  }






  init_rev_sweep(tag);

  operation=*(--g_op_ptr);
  while (operation != 36)
  {
    switch (operation) {






      case 37:
        get_op_block_r();
        operation = *(--g_op_ptr);

        break;


      case 38:
        get_loc_block_r();
        break;


      case 39:
        get_val_block_r();
        break;


      case 36:
      case 35:
 break;






      case 102 :
        arg = *(--g_loc_ptr);

        ret_c = 0;
        break;


      case 103 :
      case 105 :
      case 107 :
        arg = *(--g_loc_ptr);
        break;


      case 106 :
      case 104 :
        arg = *(--g_loc_ptr);

        if (*T[arg] == 0)
          ret_c = 0;
        break;






      case 4:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Aarg = A[arg];
 Ares = A[res];

       
          if (0 == *Ares)
   { {}
            {}
   }
   else
   { if ((*Aarg) < (*Ares)) (*Aarg) = (*Ares);
     Aarg++; *Ares++ = 0.0;
     for (i=0; i<k; i++)
     {
              *Aarg++ += *Ares;
              *Ares++ = 0.0;
     }
          }

 get_taylors(res,k);
 break;


      case 5:

        res = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        Ares = A[res];

        for (l=0; l<k1; l++)
   *Ares++ = 0.0;

        get_taylors(res,k);
 break;


      case 92:
      case 91:
        res = *(--g_loc_ptr);

        Ares = A[res];

        for (l=0; l<k1; l++)
   *Ares++ = 0.0;

        get_taylors(res,k);
 break;


      case 2:

        res = *(--g_loc_ptr);

        Ares = A[res];

       
        {
 #if 0
          if (nonzero)
     nonzero[l][indexi] = (int)*Ares;
 #endif
   Ares++;
   for (i=0; i<k; i++)
     results[indexi][i] = *Ares++;
        }

        get_taylors(res,k);
 indexi--;
 break;


      case 3:

        res = *(--g_loc_ptr);

        Ares = A[res];

       
        { *(++Ares) = lagrange[indexd];

          if (*Ares)
            *(--Ares) = 1.0;
          else
            --Ares;
   {}
        }
 indexd--;
 break;






      case 6:

        res = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 get_taylors(res,k);
 break;


      case 7:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];;

       
          if (0 == *Ares)
   { {}
            {}
          }
          else
          { if ((*Aarg) < (*Ares)) (*Aarg) = (*Ares);
            Aarg++; Ares++;
            for (i=0; i<k; i++)
              *Aarg++ += *Ares++;
          }

 get_taylors(res,k);
 break;


      case 8:

        res = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 get_taylors(res,k);
 break;


      case 9:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];

       
          if (0==*Ares)
          { {}
            {}
          }
          else
          { if ((*Aarg) < (*Ares)) (*Aarg) = (*Ares);
            Aarg++; Ares++;
            for (i=0; i<k; i++)
              *Aarg++ -= *Ares++;
          }

 get_taylors(res,k);
 break;


      case 10:

        res = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];

       
          if ( 0 == *Ares++ )
            {}
   else
            for (i=0; i<k; i++)
       *Ares++ *= coval;

 get_taylors(res,k);
 break;


      case 11:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

  get_taylors(res,k);

 Ares = A[res];
        Aarg = A[arg];
        Aqo = Atemp;
 Tres = T[res];
 Targ = T[arg];

       
        { if (0 == *Ares)
   { {}
            {}
   }
   else
   { if ((*Ares) < (2.0)) (*Ares) = (2.0);
            if ((*Aarg) < (*Ares)) (*Aarg) = (*Ares);
            Aarg++; Ares++;
            conv(k,Ares,Targ,Atemp);
            if(arg != res)
            { inconv(k,Ares,Tres,Aarg);
              for (i=0; i<k; i++)
                *Ares++ = *Aqo++;
            }
            else
              for (i=0; i<k; i++)
                *Ares++ = 2.0 * *Aqo++;
            {}
          }
        }
        break;


      case 95:
      case 96:
        res = *(--g_loc_ptr);

 get_taylors(res,k);
 break;






      case 12:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 Ares = A[res];
 Aarg1 = A[arg1];
 Aarg2 = A[arg2];

       
          if (0 == *Ares)
          { {}
            {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg1) < (aTmp)) (*Aarg1) = (aTmp);
            if ((*Aarg2) < (aTmp)) (*Aarg2) = (aTmp);
            Aarg2++; Aarg1++;
            for (i=0; i<k; i++)
            { aTmp = *Ares;
              *Ares++ = 0.0;
              *Aarg1++ += aTmp;
       *Aarg2++ += aTmp;
            }
          }

    get_taylors(res,k);
 break;


      case 13:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];
 Aarg = A[arg];

       
          if (0 == *Ares)
          { {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
            Aarg++;
            for (i=0; i<k; i++)
            { aTmp = *Ares;
              *Ares++ = 0.0;
              *Aarg++ += aTmp;
            }
          }

  get_taylors(res,k);
 break;


      case 14:

        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 Ares = A[res];
 Aarg1 = A[arg1];
 Aarg2 = A[arg2];

       
          if (0 == *Ares)
          { {}
            {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg1) < (aTmp)) (*Aarg1) = (aTmp);
            if ((*Aarg2) < (aTmp)) (*Aarg2) = (aTmp);
            Aarg2++; Aarg1++;
            for (i=0; i<k; i++)
            { aTmp = *Ares;
              *Ares++ = 0.0;
              *Aarg1++ += aTmp;
              *Aarg2++ -= aTmp;
            }
          }

        get_taylors(res,k);
 break;


      case 15:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];
 Aarg = A[arg];

       
          if (0 == *Ares)
          { {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
            Aarg++;
            for (i=0; i<k; i++)
            { aTmp = *Ares;
              *Ares++ = 0.0;
              *Aarg++ -= aTmp;
            }
          }

  get_taylors(res,k);
 break;


      case 16:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

       get_taylors(res,k);

 Ares = A[res];
 Aarg2 = A[arg2];
 Aarg1 = A[arg1];
 Targ1 = T[arg1];
 Targ2 = T[arg2];

       
          if (0 == *Ares)
          { {}
            {}
            {}
          }
          else
          { comp = (*Ares > 2.0) ? *Ares : 2.0 ;
            *Ares++ = 0.0;
            if ((*Aarg1) < (comp)) (*Aarg1) = (comp);
            if ((*Aarg2) < (comp)) (*Aarg2) = (comp);
            Aarg1++; Aarg2++;

            copyAndZeroset(k,Ares,Atemp);
            inconv(k,Atemp,Targ1,Aarg2);
            inconv(k,Atemp,Targ2,Aarg1);

            {}
            {}
            {}
          }
        break;


      case 17:

        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];
 Aarg = A[arg];

       
          if (0 == *Ares)
          { {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
            Aarg++;
            for (i=0; i<k; i++)
            { aTmp = *Ares;
              *Ares++ = 0.0;
              *Aarg++ += coval * aTmp;
            }
          }

  get_taylors(res,k);
 break;


      case 18:

        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 Ares = A[res];
 Aarg2 = A[arg2];
 Aarg1 = A[arg1];
 Tres = T[res];
 Targ2 = T[arg2];


        if (arg2 == res)
 { for (i=0; i<k; i++)
            Ttemp2[i] = Tres[i];
          Tres = Ttemp2;
         get_taylors(res,k);
        }


       
        { if (0 == *Ares)
   { {}
     {}
     {}
   }
   else
   { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg1) < (3.0)) (*Aarg1) = (3.0);
     if ((*Aarg1) < (aTmp)) (*Aarg1) = (aTmp);
     if ((*Aarg2) < (3.0)) (*Aarg2) = (3.0);
     if ((*Aarg2) < (aTmp)) (*Aarg2) = (aTmp);
     Aarg1++; Aarg2++;


            recipr(k,1.0,Targ2,Ttemp);
            conv(k,Ttemp,Tres,Atemp2);

            copyAndZeroset(k,Ares,Atemp);
            inconv(k,Atemp,Ttemp,Aarg1);
            deconv(k,Atemp,Atemp2,Aarg2);

            {}
            {}
            {}
          }
        }

     if (res != arg2)
          get_taylors(res,k);
        break;


      case 19:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];
 Aarg = A[arg];
 Tres = T[res];
 Targ = T[arg];


        if (arg == res)
 { for (i=0; i<k; i++)
            Ttemp2[i] = Tres[i];
          Tres = Ttemp2;
       get_taylors(arg,k);
 }


       
        { if (0 == *Ares)
          { {}
     {}
          }
          else
   { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
            if ((*Aarg) < (3.0)) (*Aarg) = (3.0);
            Aarg++;


            recipr(k,1.0,Targ,Ttemp);
            conv(k,Ttemp,Tres,Atemp);

            deconv0(k,Ares,Atemp,Aarg);

            {}
            {}
          }
        }

  get_taylors(res,k);
        break;






      case 98:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];

       
          if (0 == *Ares)
          { {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
            Aarg++;
            for (i=0; i<k; i++)
            { aTmp = *Ares;
              *Ares++ = 0.0;
              *Aarg++ += aTmp;
            }
          }

  get_taylors(res,k);
 break;


      case 97:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];

       
          if (0 == *Ares)
          { {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
            Aarg++;
            for (i=0; i<k; i++)
            { aTmp = *Ares;
              *Ares++ = 0.0;
              *Aarg++ -= aTmp;
            }
          }

  get_taylors(res,k);
 break;






      case 20:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];
        Tres = T[res];
 Targ = T[arg];

       
        { if (0 == *Ares)
   { {}
            {}
          }
          else
   { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
            if ((*Aarg) < (4.0)) (*Aarg) = (4.0);
            Aarg++;

            inconv0(k,Ares,Tres,Aarg);

            {}
            {}
          }
        }

        get_taylors(res,k);
        break;


      case 22:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 Ares = A[res];
 Aarg1 = A[arg1];
 Targ2 = T[arg2];

       
        { if (0 == *Ares)
          { {}
     {}
          }
          else
   { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg1) < (aTmp)) (*Aarg1) = (aTmp);
            if ((*Aarg1) < (4.0)) (*Aarg1) = (4.0);
            Aarg1++;

            inconv0(k,Ares,Targ2,Aarg1);

            {}
            {}
          }
        }

        get_taylors(res,k);
        get_taylors(arg2,k);

 break;


      case 21:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 Ares = A[res];
 Aarg1 = A[arg1];
 Targ2 = T[arg2];

       
        { if (0 == *Ares)
   { {}
            {}
   }
          else
   { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg1) < (aTmp)) (*Aarg1) = (aTmp);
            if ((*Aarg1) < (4.0)) (*Aarg1) = (4.0);
            Aarg1++;

            deconv0(k,Ares,Targ2,Aarg1);

            {}
            {}
          }
        }

        get_taylors(res,k);
        get_taylors(arg2,k);

 break;


      case 23:
      case 26:
      case 27:
      case 29:
      case 30:
      case 31:
      case 114:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

        get_taylors(res,k);

        Ares = A[res];
        Aarg1 = A[arg1];
        Targ2 = T[arg2];

       
        { if (0 == *Ares)
          { {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg1) < (aTmp)) (*Aarg1) = (aTmp);
            if ((*Aarg1) < (4.0)) (*Aarg1) = (4.0);
            Aarg1++;

            inconv0(k,Ares,Targ2,Aarg1);

            {}
            {}
          }
        }
 break;


      case 24:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

        get_taylors(res,k);

 Ares = A[res];
 Aarg = A[arg];
 Targ = T[arg];


       
        { if (0 == *Ares)
          { {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
            if ((*Aarg) < (4.0)) (*Aarg) = (4.0);
            Aarg++;


            recipr(k,1.0,Targ,Ttemp);

            inconv0(k,Ares,Ttemp,Aarg);

            {}
            {}
          }
        }
 break;


      case 25:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 Targ = T[arg];
 Tres = T[res];
 Ares = A[res];
 Aarg = A[arg];


        if (arg == res)
 { for (i=0; i<k; i++)
            Ttemp2[i] = Tres[i];
          Tres = Ttemp2;
       get_taylors(arg,k);
 }


       
          if (0 == *Ares)
          { {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
            if ((*Aarg) < (4.0)) (*Aarg) = (4.0);
            Aarg++;


            divide(k,Tres,Targ,Ttemp);
            for (i=0;i<k;i++)
              Ttemp[i] *= coval;

            inconv0(k,Ares,Ttemp,Aarg);

            {}
            {}
          }

   get_taylors(res,k);
        break;


      case 28:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 Ares = A[res];
 Aarg = A[arg];
 Tres = T[res];


       
          if (0 == *Ares)
          { {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
            if ((*Aarg) < (4.0)) (*Aarg) = (4.0);
            Aarg++;


            recipr(k,0.5,Tres,Ttemp);

            inconv0(k,Ares,Ttemp,Aarg);

            {}
            {}
          }

   get_taylors(res,k);
        break;


      case 32:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);
        coval = *(--g_real_ptr);

 Ares = A[res];
 Aarg1 = A[arg1];
 Targ2 = T[arg2];

       
          if (0 == *Ares)
          { {}
            {}
          }
          else
          { aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg1) < (aTmp)) (*Aarg1) = (aTmp);
            if ((*Aarg1) < (4.0)) (*Aarg1) = (4.0);
            Aarg1++;

            inconv0(k,Ares,Targ2,Aarg1);

            {}
            {}
          }

       get_taylors(res,k);
       break;


      case 100:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

   get_taylors(res,k);

        Aarg1 = A[arg1];
        Aarg2 = A[arg2];
        Ares = A[res];
        Targ1 = T[arg1];
        Targ2 = T[arg2];
        AP1 = __null;
        AP2 = Ares;

        if (Targ1[0] > Targ2[0])
        {
          { if ((coval) && (*AP2))
              if ((ret_c) > (2)) (ret_c) = (2);
            {}
          }
          AP1 = Aarg2;
          arg = 0;
        }
        else
          if (Targ1[0] < Targ2[0])
          {
            { if ((!coval) && (*AP2))
                if ((ret_c) > (2)) (ret_c) = (2);
              {}
            }
            AP1 = Aarg1;
            arg = 0;
          }
          else
            for (i=1;i<k;i++)
            { if (Targ1[i] > Targ2[i])
              {
                { if (*AP2)
                    if ((ret_c) > (1)) (ret_c) = (1);
                  {}
  }
                AP1 = Aarg2;
                arg = i+1;
              }
              else
                if (Targ1[i] < Targ2[i])
                {
                  { if (*AP2)
                      if ((ret_c) > (1)) (ret_c) = (1);
                    {}
       }
                  AP1 = Aarg1;
                  arg = i+1;
                }
              if (AP1 != __null)
                break;
            }

        if (AP1 != __null)
         
          { if (0 == *Ares)
            { {}
              {};
            }
            else
            { aTmp = *Ares;
              *Ares++ = 0.0;
              if (arg)
                *AP1 = 5.0;
              else
                if ((*AP1) < (aTmp)) (*AP1) = (aTmp);
              AP1++;
              for (i=0;i<k;i++)
       { aTmp = *Ares;
                *Ares++ = 0.0;
                *AP1++ += aTmp;
              }
            }
          }
        else
        {
          { if (0 == *Ares)
            { {}
              {}
              {}
            }
            else
            { aTmp = *Ares;
              *Ares++ = 0.0;
              if ((*Aarg1) < (aTmp)) (*Aarg1) = (aTmp);
              if ((*Aarg2) < (aTmp)) (*Aarg2) = (aTmp);
              Aarg1++; Aarg2++;
              for (i=0;i<k;i++)
              { aTmp = *Ares;
                *Ares++ = 0.0;
                *Aarg1++ += aTmp/2;
                *Aarg2++ += aTmp/2;
              }
            }
          }
          if (arg1 != arg2)
            if ((ret_c) > (1)) (ret_c) = (1);
        }
        break;



      case 101:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

   get_taylors(res,k);

        Ares = A[res];
        Aarg = A[arg];
        Targ = T[arg];

        x = 0.0;
        j = 0;
        for (i=0;i<k;i++)
          if ( (x == 0.0) && (Targ[i] != 0.0) )
          { j = i;
            if (Targ[i] < 0.0)
              x = -1.0;
            else
              x = 1.0;
          }
       
          if (0 == *Ares)
          { {}
            {}
          }
          else
          { if (Targ[0] == 0.0)
            { *Ares++ = 0.0; *Aarg++ = 5.0;
            }
            else
            { aTmp = *Ares;
              *Ares++ = 0.0;
              if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
              Aarg++;
            }
            if(Targ[0] == 0.0)
              if ((ret_c) > (1)) (ret_c) = (1);
            for (i=0;i<j;i++)
              *Ares++ = 0.0;
            Aarg += j;
            for (i=j;i<k;i++)
            { aTmp = *Ares;
              *Ares++ = 0.0;
              if ( (coval) && (x<0) && (aTmp) )
                if ((ret_c) > (2)) (ret_c) = (2);
              if ( (!coval) && (x>0) && (aTmp))
                if ((ret_c) > (2)) (ret_c) = (2);
              *Aarg++ += x * aTmp;
            }
          }
        break;


      case 115:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

   get_taylors(res,k);

        coval = (coval != ceil(*T[arg]) );

        Ares = A[res];

       
          if (0 == *Ares)
          { {}
            {}
          }
          else
          { *Ares++ = 0.0; *Aarg++ = 5.0;
            for (i=0; i<k; i++)
            { if ((coval) && (*Ares))
                if ((ret_c) > (2)) (ret_c) = (2);
              *Ares++ = 0.0;
            }
     {}
          }
        break;


      case 116:
        res = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

   get_taylors(res,k);

        coval = ( coval != floor(*T[arg]) );

        Ares = A[res];
        Aarg = A[arg];

       
          if (0 == *Ares)
          { {}
            {}
          }
          else
          { *Ares = 0.0; *Aarg++ = 5.0;
            for (i=0; i<k; i++)
            { if ( (coval) && (*Ares) )
                if ((ret_c) > (2)) (ret_c) = (2);
              *Ares++ = 0.0;
            }
            {}
          }
        break;






      case 70:
        res = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 get_taylors(res,k);

        Aarg1 = A[arg1];
 Ares = A[res];
        Aarg2 = A[arg2];
        Targ = T[arg];


        if (*Targ > 0.0)
 { if (res != arg1)
           
            { if (0 == *Ares)
              { {}
                {}
              }
              else
              { if (coval <= 0.0)
                  if ((ret_c) > (2)) (ret_c) = (2);
                if ((*Aarg1) < (*Ares)) (*Aarg1) = (*Ares);
                *Ares++ = 0.0;
                Aarg1++;
                for (i=0; i<k; i++)
                { *Aarg1++ += *Ares;
                  *Ares++ = 0;
                }
              }
     }
          else
           
            { if ((coval <= 0.0) && (*Ares))
                if ((ret_c) > (2)) (ret_c) = (2);
              {}
     }
        }
        else
 { if (res != arg2)
           
            { if (0 == *Ares)
              { {}
                {}
              }
              else
              { if (*Targ == 0.0)
                { if ((ret_c) > (0)) (ret_c) = (0);
                  *Aarg1 = 5.0; *Aarg2++ = 5.0;
                }
                else
                { if (coval <= 0.0)
                  if ((ret_c) > (2)) (ret_c) = (2);
                  if ((*Aarg2) < (*Ares)) (*Aarg2) = (*Ares);
                  Aarg2++;
                }
                *Ares++ = 0.0;

                for (i=0; i<k; i++)
                { *Aarg2++ += *Ares;
                  *Ares++ = 0;
                }
              }
              {}
     }
          else
           
            { if (*Ares)
              { if (*Targ == 0.0)
                { if ((ret_c) > (0)) (ret_c) = (0);
                  *Aarg1 = 5.0; *Aarg2 = 5.0;
                }
                else
                  if (coval <= 0.0)
                    if ((ret_c) > (2)) (ret_c) = (2);
              }
              {}
              {}
              {}
     }
        }
      break;


      case 71:
        res = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

 get_taylors(res,k);

 Aarg1 = A[arg1];
 Ares = A[res];
        Targ = T[arg];


        if (*Targ == 0.0)
        {
          { if (*Ares)
              *Aarg1 = 5.0;
            {}
            {}
          }
          if ((ret_c) > (0)) (ret_c) = (0);
        }
        else
          if (*Targ > 0.0)
          { if (res != arg1)
             
              { if (0 == *Ares)
                { {}
                  {}
                }
                else
                { if (coval <= 0.0)
                    if ((ret_c) > (2)) (ret_c) = (2);
                  if ((*Aarg1) < (*Ares)) (*Aarg1) = (*Ares);
                  *Ares++ = 0.0;
                  Aarg1++;
                  for (i=0; i<k; i++)
                  { (*Aarg1++) += *Ares;
                    *Ares++ = 0;
                  }
         }
       }
            else
             
              { if ((coval <= 0.0) && (*Ares))
                  if ((ret_c) > (2)) (ret_c) = (2);
                {}
       }
          }
 break;






      case 52:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

 res += size;
 arg += size;
        for (ls=size; ls>0; ls--)
 { res--;
   arg--;


   Aarg = A[arg];
   Ares = A[res];

         
            if (0 == *Ares)
     { {}
              {}
     }
     else
     { if ((*Aarg) < (*Ares)) (*Aarg) = (*Ares);
       Aarg++; *Ares++ = 0.0;
       for (i=0; i<k; i++)
       {
                *Aarg++ += *Ares;
                *Ares++ = 0.0;
       }
            }

   get_taylors(res,k);
        }
 break;


      case 53:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        d = get_val_v_r(size);

        res += size;
        d += size;
 for (ls=size; ls>0; ls--)
 { res--;
   coval = *(--d);


          Ares = A[res];

          for (l=0; l<k1; l++)
     *Ares++ = 0.0;

   get_taylors(res,k);
 }
 break;


      case 54:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);

        res += size;
 for (ls=size; ls>0; ls--)
 { res--;


   Ares = A[res];

         
          {
 #if 0
            if (nonzero)
       nonzero[l][indexi] = (int)*Ares;
 #endif
     Ares++;
     for (i=0; i<k; i++)
       results[indexi][i] = *Ares++;
          }

          get_taylors(res,k);
          indexi--;
        }
        reset_val_r();
 break;


      case 55:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);

        res += size;
 for (ls=size; ls>0; ls--)
 { res--;


   Ares = A[res];

         
          { *(++Ares) = lagrange[indexd];

            if (*Ares)
              *(--Ares) = 1.0;
            else
              --Ares;
            Ares += k1;
          }
          indexd--;
 }
 break;






      case 59:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

        res += size;
        arg += size;
 for (ls=size; ls>0; ls--)
 { res--;
   arg--;


          Ares = A[res];
   Aarg = A[arg];

         
            if (0 == *Ares)
     { {}
              {}
            }
            else
            { if ((*Aarg) < (*Ares)) (*Aarg) = (*Ares);
              Aarg++; Ares++;
              for (i=0; i<k; i++)
                *Aarg++ += *Ares++;
            }

   get_taylors(res,k);
 }
 break;


      case 57:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);

        res += size;
        arg += size;
 for (ls=size; ls>0; ls--)
 { res--;
   arg--;


          Ares = A[res];
   Aarg = A[arg];

         
            if (0==*Ares)
            { {}
              {}
            }
            else
            { if ((*Aarg) < (*Ares)) (*Aarg) = (*Ares);
              Aarg++; Ares++;
              for (i=0; i<k; i++)
                *Aarg++ -= *Ares++;
            }

     get_taylors(res,k);
 }
 break;


      case 61:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        res += size;
 for (ls=size; ls>0; ls--)
 { res--;



   Ares = A[res];

         
            if ( 0 == *Ares++ )
              {}
            else
              for (i=0; i<k; i++)
         *Ares++ *= coval;

   get_taylors(res,k);
 }
 break;


      case 62:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);



        if ((arg >= res) && (arg < res+size))
 {

   get_taylors(arg,k);

   Targ = T[arg];
   Aarg = A[arg];
   Aqo = Atemp;

         
           if (0 == *Aarg)
    { {}
    }
    else
    { if ((*Aarg) < (2.0)) (*Aarg) = (2.0);
      Aarg++;
      conv(k,Aarg,Targ,Atemp);
      for (i=0; i<k; i++)
        *Aarg++ = 2.0 * *Aqo++;
    }
 }

        res += size;
 for (ls=size; ls>0; ls--)
 { res--;


          if (res == arg)
            continue;


   get_taylors(res,k);

          Tres = T[res];
   Targ = T[arg];;
   Aarg = A[arg];
   Ares = A[res];
   Aqo = Atemp;

         
           if (0 == *Ares)
    { {}
      {}
    }
    else
    { if ((*Ares) < (2.0)) (*Ares) = (2.0);
      if ((*Aarg) < (*Ares)) (*Aarg) = (*Ares);
      Aarg++; Ares++;
      conv(k,Ares,Targ,Atemp);
      if(arg != res)
      { inconv(k,Ares,Tres,Aarg);
        for (i=0; i<k; i++)
   *Ares++ = *Aqo++;
      }
      else
        for (i=0; i<k; i++)
   *Ares++ = 2.0 * *Aqo++;
      {}
    }
 }
 break;






      case 40:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 res += size;
 arg1 += size;
 arg2 += size;
 for (ls=size; ls>0; ls--)
 { arg2--;
   arg1--;
   res--;


   Ares = A[res];
   Aarg1 = A[arg1];
   Aarg2 = A[arg2];

         
            if (0 == *Ares)
            { {}
              {}
              {}
            }
            else
            { aTmp = *Ares;
              *Ares++ = 0.0;
              if ((*Aarg1) < (aTmp)) (*Aarg1) = (aTmp);
              if ((*Aarg2) < (aTmp)) (*Aarg2) = (aTmp);
              Aarg2++; Aarg1++;
              for (i=0; i<k; i++)
              { aTmp = *Ares;
                *Ares++ = 0.0;
                *Aarg1++ += aTmp;
         *Aarg2++ += aTmp;
              }
            }

      get_taylors(res,k);
        }
 break;


      case 42:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 res += size;
 arg1 += size;
 arg2 += size;
 for (ls=size; ls>0; ls--)
 { arg2--;
   arg1--;
   res--;


   Ares = A[res];
   Aarg1 = A[arg1];
   Aarg2 = A[arg2];

         
            if (0 == *Ares)
            { {}
              {}
              {}
            }
            else
            { aTmp = *Ares;
              *Ares++ = 0.0;
              if ((*Aarg1) < (aTmp)) (*Aarg1) = (aTmp);
              if ((*Aarg2) < (aTmp)) (*Aarg2) = (aTmp);
              Aarg2++; Aarg1++;
              for (i=0; i<k; i++)
              { aTmp = *Ares;
                *Ares++ = 0.0;
                *Aarg1++ += aTmp;
                *Aarg2++ -= aTmp;
              }
            }
      get_taylors(res,k);
        }
 break;


      case 45:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

        get_taylors(res,k);


        Aqo = Atemp;
 Ares = A[res];
        for (l=0; l<k1; l++)
 { *Aqo++ = *Ares;
          *Ares++ = 0.0;
 }

 for (ls=0; ls<size; ls++)
 {
   Aarg2 = A[arg2];
   Aarg1 = A[arg1];
          Aqo = Atemp;
   Targ1 = T[arg1];
   Targ2 = T[arg2];

         
            if (0 == *Aqo)
            { {}
              {}
              {}
            }
            else
            { comp = (*Aqo > 2.0) ? *Aqo : 2.0 ;
              if ((*Aarg1) < (comp)) (*Aarg1) = (comp);
              if ((*Aarg2) < (comp)) (*Aarg2) = (comp);
              Aarg1++; Aarg2++; Aqo++;

              inconv(k,Aqo,Targ1,Aarg2);
              inconv(k,Aqo,Targ2,Aarg1);

              {}
              {}
              {}
            }
          arg1++; arg2++;
 }
        break;


      case 47:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);



        if ((arg2 >= res) && (arg2 < res+size))
 {

      get_taylors(arg2,k);

   Aarg1 = A[arg1+res-arg2];
   Aarg2 = A[arg2];
   Targ2 = T[arg2];
   Targ1 = T[arg1+res-arg2];

         
            if (0 == *Aarg2)
            { {}
              {}
            }
            else
            { if ((*Aarg1) < (*Aarg2)) (*Aarg1) = (*Aarg2);
              Aarg1++; Aarg2++;

              copyAndZeroset(k,Aarg2,Atemp);
              inconv(k,Atemp,Targ1,Aarg2);
              inconv(k,Atemp,Targ2,Aarg1);

              {}
              {}
            }
 }

        res += size;
        arg1 += size;
 for (ls=size; ls>0; ls--)
 { arg1--;
   res--;

          if (res == arg2)
            continue;


      get_taylors(res,k);

          Ares = A[res];
   Aarg1 = A[arg1];
   Aarg2 = A[arg2];
   Targ2 = T[arg2];
   Targ1 = T[arg1];

         
            if (0 == *Ares)
            { {}
              {}
              {}
            }
            else
            { comp = (*Ares > 2.0) ? *Ares : 2.0 ;
              *Ares++ = 0.0;
              if ((*Aarg1) < (comp)) (*Aarg1) = (comp);
              if ((*Aarg2) < (comp)) (*Aarg2) = (comp);
              Aarg1++; Aarg2++;

              copyAndZeroset(k,Ares,Atemp);
              inconv(k,Atemp,Targ1,Aarg2);
              inconv(k,Atemp,Targ2,Aarg1);

              {}
              {}
              {}
            }
 }
 break;


      case 48:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        res += size;
        arg += size;
 for (ls=size; ls>0; ls--)
 { arg--;
   res--;



   Ares = A[res];
   Aarg = A[arg];

         
            if (0 == *Ares)
            { {}
              {}
            }
            else
            { aTmp = *Ares;
              *Ares++ = 0.0;
              if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
              Aarg++;
              for (i=0; i<k; i++)
              { aTmp = *Ares;
                *Ares++ = 0.0;
                *Aarg++ += coval * aTmp;
              }
            }

    get_taylors(res,k);
 }
 break;


      case 60:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);



        if ((arg2 >= res) && (arg2 < res+size))
 {

   Aarg2 = A[arg2];
   Aarg1 = A[arg1+res-arg2];
   Targ2 = T[arg2];

   for (i=0; i<k; i++)
            Ttemp2[i] = Targ2[i];
          Tres = Ttemp2;

    get_taylors(arg2,k);


         
            if (0 == *Aarg2)
     { {}
       {}
     }
     else
     { if ((*Aarg2) < (3.0)) (*Aarg2) = (3.0);
       if ((*Aarg1) < (*Aarg2)) (*Aarg1) = (*Aarg2);
       Aarg1++; Aarg2++;


              recipr(k,1.0,Targ2,Ttemp);
              conv(k,Ttemp,Tres,Atemp2);

              copyAndZeroset(k,Aarg2,Atemp);
              inconv(k,Atemp,Ttemp,Aarg1);
              deconv(k,Atemp,Atemp2,Aarg2);

              {}
              {}
            }
 }

 res += size;
        arg1 += size;
 for (ls=size; ls>0; ls--)
 { arg1--;
   res--;

          if (res == arg2)
            continue;


   Ares = A[res];
   Aarg2 = A[arg2];
   Aarg1 = A[arg1];
   Tres = T[res];
   Targ2 = T[arg2];


         
            if (0 == *Ares)
     { {}
       {}
       {}
     }
     else
     { aTmp = *Ares;
              *Ares++ = 0.0;
              if ((*Aarg1) < (3.0)) (*Aarg1) = (3.0);
       if ((*Aarg1) < (aTmp)) (*Aarg1) = (aTmp);
       if ((*Aarg2) < (3.0)) (*Aarg2) = (3.0);
       if ((*Aarg2) < (aTmp)) (*Aarg2) = (aTmp);
       Aarg1++; Aarg2++;


              recipr(k,1.0,Targ2,Ttemp);
              conv(k,Ttemp,Tres,Atemp2);

              copyAndZeroset(k,Ares,Atemp);
              inconv(k,Atemp,Ttemp,Aarg1);
              deconv(k,Atemp,Atemp2,Aarg2);

              {}
              {}
              {}
            }

    get_taylors(res,k);
 }
 break;






      case 75:
        res = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        arg = arg2 + (int)(T[arg1][0]);


        get_taylors(res,k);

 Aarg = A[arg];
 Ares = A[res];

       
          if (0 == *Ares)
   { {}
     {}
   }
   else
   { if ((int)(coval) != (int)(T[arg1][0]))
              if ((ret_c) > (2)) (ret_c) = (2);
     aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
     Aarg++;

     for (i=0; i<k; i++)
     { *Aarg++ += *Ares;
              if (arg != res)
  *Ares++ = 0;
              else
                Ares++;
            }
   }
 break;


      case 76:
        arg = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        res = arg2 + (int)(T[arg1][0]);

 get_taylors(res,k);

 Aarg = A[arg];
 Ares = A[res];


          if (0==*Ares)
   { {}
     {}
   }
   else
   { if ((int)(coval) != (int)(T[arg1][0]))
              if ((ret_c) > (2)) (ret_c) = (2);
     aTmp = *Ares;
            *Ares++ = 0.0;
            if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
     Aarg++;

     for (i=0; i<k; i++)
     { *Aarg++ += *Ares;
              if (res != arg)
  *Ares++ = 0;
              else
                Ares++;
            }
   }
 break;


      case 77:
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);
        coval = *(--g_real_ptr);

        arg = arg2 + (int)(T[arg1][0]);

        get_taylors(arg,k);

        if((int)(coval)!=(int)(T[arg1][0]))
          if ((ret_c) > (2)) (ret_c) = (2);

 Aarg = A[arg];;

        for (l=0; l<k1; l++)
   *Aarg++ = 0.0;

 break;


      case 72:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        res += size;
        arg = arg2 + ((int)(T[arg1][0]) + 1)*size;
        for (ls=size; ls>0; ls--)
        { res--; arg--;


          get_taylors(res,k);

          Aarg = A[arg];
   Ares = A[res];

         
            if (0 == *Ares)
            { {}
              {}
            }
            else
            { if ((int)(coval)!=(int)(T[arg1][0]))
                if ((ret_c) > (2)) (ret_c) = (2);
              aTmp = *Ares;
              *Ares++ = 0.0;
              if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
              Aarg++;

              for (i=0; i<k; i++)
              { *Aarg++ += *Ares;
                if (arg != res)
                  *Ares++ = 0;
                else
                  Ares++;
              }
            }
        }
 break;


      case 73:
        arg = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);
        coval = *(--g_real_ptr);

        res = arg2 + ((int)(T[arg1][0]) + 1)*size;
        arg += size;
        for (ls=size; ls>0; ls--)
        { arg--; res--;

          get_taylors(res,k);

          Aarg = A[arg];
          Ares = A[res];

         
            if (0 == *Ares)
            { {}
              {}
            }
            else
            { if ((int)(coval)!=(int)(T[arg1][0]))
                if ((ret_c) > (2)) (ret_c) = (2);
              aTmp = *Ares;
              *Ares++ = 0.0;
              if ((*Aarg) < (aTmp)) (*Aarg) = (aTmp);
              Aarg++;

              for (i=0; i<k; i++)
              { *Aarg++ += *Ares;
                if (arg != res)
                  *Ares++ = 0;
                else
                  *Ares++;
              }
            }
        }
 break;


      case 74:
        size = *(--g_loc_ptr);
        arg = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);
        arg2 = *(--g_loc_ptr);

        d = get_val_v_r(size);
        coval = *(--g_real_ptr);

        if ((int)(coval) != (int)(T[arg1][0]))
          if ((ret_c) > (2)) (ret_c) = (2);

        res = arg2 + ((int)(T[arg1][0]) + 1)*size + arg;
        for (ls=size; ls>0; ls--)
        { res--;

          get_taylors(res,k);

          Ares = A[res];

          for (l=0; l<k1; l++)
            *Ares++ = 0.0;
        }
 break;






      case 90:
        res = *(--g_loc_ptr);
        size = *(--g_loc_ptr);
        d = get_val_v_r(size);

        res += size;
 for (ls=size;ls>0;ls--)
 { res--;

          Ares = A[res];

          for (l=0; l<k1; l++)
     *Ares++ = 0.0;
 }




 break;


      case 1:
        arg2 = *(--g_loc_ptr);
        arg1 = *(--g_loc_ptr);

 for (j=arg1;j<=arg2;j++)
 { Aarg1 = A[j];

  
            for (i=0; i<k1; i++)
              *Aarg1++ = 0.0;

          get_taylors(j,k);
 }
 break;


      default:


        fprintf((DIAG_OUT),"ADOL-C fatal error in " "hos_reverse" " ("
                "ho_rev.c"
                ") : no such operation %d\n", operation);
 exit(12);
 break;
      }


      operation=*(--g_op_ptr);
    }

  end_sweep();
  return ret_c;
}






