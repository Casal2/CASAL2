#ifndef _ADUTILS_H_
#define _ADUTILS_H_
/*
   ------------------------------------------------------------- 
   File adutils.h of ADOL-C version 1.8.0        as of Nov/30/98
   -------------------------------------------------------------
   Provides all C/C++ interfaces of ADOL-C.
   NOTICE: This file is kept for compatibility reasons only. 
           The new header adolc.h is included. 
 
   Last changes: 
     981130 olvo     this remaining version

  ------------------------------------------------------------- 
*/


/****************************************************************************/
/*                                                                 INCLUDES */

#include "adolc.h"


/****************************************************************************/
/*                                                               THAT'S ALL */

#endif



