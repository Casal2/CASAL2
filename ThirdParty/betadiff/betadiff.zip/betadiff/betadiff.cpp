// const char* time_stamp = "$Date: 2012-11-08 09:33:38 +1300 (Thu, 08 Nov 2012) $\n";
// const char* betadiff_id = "$Id: betadiff.cpp 4824 2012-11-07 20:33:38Z Dunn $\n";

#include "betadiff.h"
#include "newran.h"
#include "limits.h"

bool betadiff_seed=false; // Ugh! A global variable. This is used by the random number generators
                          // to remember the current seed.

void error(const std::string& problem){
  if(problem.size() > 1) std::cerr << "Betadiff error: " << problem << '\n';
  std::cerr << "Please notify the software maintainer about this error.\n\n";
  exit(BETADIFF_FATAL_EXIT);
}

dvariable::dvariable()
  :x(){}
dvariable::dvariable(double t)
  :x(t){}
dvariable::dvariable(const dvariable& d)
  :x(d.x){}
dvariable& dvariable::operator=(double t){
  x=t;
  return *this;
}
dvariable& dvariable::operator=(const dvariable& d){
  x=d.x;
  return *this;
}

dvariable::dvariable(const asub& a)
  :x(0){
  x=a;
}
dvariable::dvariable(const adub& a)
  :x(a){}
dvariable::dvariable(const badouble& b)
  :x(0){
  x=b;
}
dvariable::dvariable(const adouble& a)
  :x(a){}
dvariable& dvariable::operator=(const asub& a){
  x=a;
  return *this;
}
dvariable& dvariable::operator=(const adub& a){
  x=a;
  return *this;
}
dvariable& dvariable::operator=(const badouble& b){
  x=b;
  return *this;
}

adub dvariable::operator++(int){
  adub n=x++;
  return n;
}
adub dvariable::operator--(int){
  adub n=x--;
  return n;
}
void dvariable::operator+=(const dvariable &d){
  x += d.x;
}
void dvariable::operator-=(const dvariable &d){
  x -= d.x;
}
void dvariable::operator*=(const dvariable &d){
  x *= d.x;
}
void dvariable::operator/=(const dvariable &d){
  x /= d.x;
}
void dvariable::operator+=(double t){
  x+=t;
}
void dvariable::operator-=(double t){
  x-=t;
}
void dvariable::operator*=(double t){
  x*=t;
}
void dvariable::operator/=(double t){
  x/=t;
}

void dvariable::operator>>=(double& rt){
  x>>=rt;
}
void dvariable::operator<<=(double t){
  x<<=t;
}
void dvariable::operator>>=(dvariable& rd){
  double t;
  x >>= t;
  rd=t;
}
void dvariable::operator<<=(const dvariable& d){
  double t;
  t=value(d.x);
  x <<= t;
}

/*dvariable operator*(const dvariable& d1, const dvariable& d2){
  adub n=d1.x*d2.x;
  return n;}*/ // USED TO BE LIKE THIS - LESS EFFICIENT
adub operator*(const dvariable& d1, const dvariable& d2){
  return d1.x*d2.x;
}
adub operator*(double t, const dvariable& d){
  return t*d.x;
}
adub operator*(const dvariable& d, double t){
  return t*d.x;
}
adub operator/(const dvariable& d1, const dvariable& d2){
  return d1.x/d2.x;
}
adub operator/(double t, const dvariable& d){
  return t/d.x;
}
adub operator/(const dvariable& d, double t){
  return d.x/t;
}
adub operator+(const dvariable& d1, const dvariable& d2){
  return d1.x+d2.x;
}
adub operator+(double t, const dvariable& d){
  return t+d.x;
}
adub operator+(const dvariable& d, double t){
  return d.x+t;
}
adub operator-(const dvariable& d1, const dvariable& d2){
  return d1.x-d2.x;
}
adub operator-(double t, const dvariable& d){
  return t-d.x;
}
adub operator-(const dvariable& d, double t){
  return d.x-t;
}
adub operator-(const dvariable& d){
  return -(d.x);
}
int operator<(const dvariable& d1, const dvariable& d2){
  return (d1.x<d2.x);
}
int operator>(const dvariable& d1, const dvariable& d2){
  return (d1.x>d2.x);
}
int operator>=(const dvariable& d1, const dvariable& d2){
  return (d1.x>=d2.x);
}
int operator<=(const dvariable& d1, const dvariable& d2){
  return (d1.x<=d2.x);
}
int operator==(const dvariable& d1, const dvariable& d2){
  return (d1.x==d2.x);
}
int operator!=(const dvariable& d1, const dvariable& d2){
  return (d1.x!=d2.x);
}
int operator<(const dvariable& d, double t){
  return (d.x<t);
}
int operator>(const dvariable& d, double t){
  return (d.x>t);
}
int operator>=(const dvariable& d, double t){
  return (d.x>=t);
}
int operator<=(const dvariable& d, double t){
  return (d.x<=t);
}
int operator==(const dvariable& d, double t){
  return (d.x==t);
}
int operator!=(const dvariable& d, double t){
  return (d.x!=t);
}
int operator<(double t, const dvariable& d){
  return (t<d.x);
}
int operator>(double t, const dvariable& d){
  return (t>d.x);
}
int operator<=(double t, const dvariable& d){
  return (t<=d.x);
}
int operator>=(double t, const dvariable& d){
  return (t>=d.x);
}
int operator==(double t, const dvariable& d){
  return (t==d.x);
}
int operator!=(double t, const dvariable& d){
  return (t!=d.x);
}
bool operator!(const dvariable& d){
  return d==0;
}
bool operator!(const asub& d){
  return (dvariable)d==0.;
}
double value(const dvariable& d){
  return value(d.x);
}
double value(double t){
  return t;
}

dvariable pow(const dvariable& d1, const dvariable& d2){
  adouble n=pow(d1.x,d2.x); // Not adub n - see adouble.h
  return n;
}
dvariable pow(const dvariable& d, double t){
  // Be very careful with this one on Kupe. I have had nasty, inexplicable problems with it.
  // Try eg. double t=-4; pow(d,t); instead of pow(d,-4);
  adouble n=pow(d.x,t);
  return n;
}
dvariable pow(double t, const dvariable &d){
  adouble n = pow(t,d.x);
  return n;
}
adub sin(const dvariable& d){
  return sin(d.x);
}
adub cos(const dvariable& d){
  return cos(d.x);
}
adub tan(const dvariable& d){
  return tan(d.x);
}
adub asin(const dvariable& d){
  return asin(d.x);
}
adub acos(const dvariable& d){
  return acos(d.x);
}
adub atan(const dvariable& d){
  return atan(d.x);
}
adub sqrt(const dvariable& d){
  return sqrt(d.x);
}
adub exp(const dvariable& d){
  return exp(d.x);
}
adub log(const dvariable& d){
  return log(d.x);
}
adub log10(const dvariable& d){
  return log10(d.x);
}
adub fabs(const dvariable& d){
  return fabs(d.x);
}
adub sfabs(const dvariable& d){
  return fabs(d.x);
}
adub ceil(const dvariable& d){
  return ceil(d.x);
}
adub floor(const dvariable& d){
  return floor(d.x);
}
adub fmax(const dvariable& d1, const dvariable& d2){
  return fmax(d1.x,d2.x);
}
adub fmax(const dvariable& d, double t){
  return fmax(d.x,t);
}
adub fmax(double t, const dvariable& d){
  return fmax(t,d.x);
}
adub fmin(const dvariable& d1, const dvariable& d2){
  return fmin(d1.x,d2.x);
}
adub fmin(const dvariable& d, double t){
  return fmin(d.x,t);
}
adub fmin(double t, const dvariable& d){
  return fmin(t,d.x);
}
// new in 2004
adub zerofun(const dvariable& x, const dvariable& delta){
  if (x>=delta){
    return x.x+0;
  } else {
    return delta/(2-(x/delta));
  }
}

double zerofun(double x, double delta){
  if (x>=delta){
    return x;
  } else {
    return delta/(2-(x/delta));
  }
}

dvariable zerofun(dvariable& x, double delta){
  if (x>=delta){
    return x;
  } else {
    return delta/(2-(x/delta));
  }
}

adub lngamma(const dvariable& d){
  int j;
  dvariable x,y,tmp,ser;
  dvariable cof[6] = {76.18009172947146,-86.50532032941677,24.01409824083091,-1.231739572450155,0.1208650973866179e-2,-0.5395239384953e-5};
  y = x = d;
  tmp = x + 5.5 - (x + 0.5) * log(x + 5.5);
  ser = 1.000000000190015;
  for (j=0;j<=5;j++){
    y+=1;
    ser += (cof[j] / y);
  }
  return(log(2.5066282746310005 * ser / x) - tmp);
}

double lngamma(double t){
  int j;
  double x,y,tmp,ser;
  double cof[6] = {76.18009172947146,-86.50532032941677,24.01409824083091,-1.231739572450155,0.1208650973866179e-2,-0.5395239384953e-5};
  y = x = t;
  tmp = x + 5.5 - (x + 0.5) * log(x + 5.5);
  ser = 1.000000000190015;
  for (j=0;j<=5;j++)
    ser += (cof[j] / ++y);
  return(log(2.5066282746310005 * ser / x) - tmp);
}


std::ostream& operator<<(std::ostream& ostr, const dvariable& d){
  return (ostr << value(d.x));
}
std::istream& operator>>(std::istream& istr, dvariable& d){
  double t;
  istr >> t;
  if (istr) d=t;
  return istr;
}

dvv::dvv(int i1, int i2)
  :v(i2-i1+1),first(i1){}
dvv::dvv(int i)
  :v(i),first(1){}
dvv::dvv(const dvv& dv)
  :v(dv.v),first(dv.first){}
dvv::dvv(char* c)
  :v(c),first(1){}
dvv::dvv(char* c,int i)
  :v(c),first(i){}
dvv::dvv(const dvector& dv)
  :v(dv.size()),first(dv.first){
  int count;
  for (count=0;count<dv.size();count++){
    v[count]=dv.ptr[count];}
}
dvv::dvv():v(1),first(1){};
dvv& dvv::operator=(const dvv& dv){
#if !defined(_UNCHECKED_)
  if (size() != dv.size()){
    error("bad size in dvv::operator=(dvv)");}
#endif
  v=dv.v;
  return *this;
}
dvv& dvv::operator=(const dvector& dv){
#if !defined(_UNCHECKED_)
  if (size() != dv.size()){
    error("bad size in dvv::operator=(dvector)");}
#endif
  int count;
  for (count=0;count<dv.size();count++){
    v[count]=dv.ptr[count];}
  return *this;
}
dvv& dvv::operator=(double t){
  v=t;
  return *this;
}
dvv& dvv::operator=(int i){
  v=(double)i;
  return *this;
}
dvv& dvv::operator=(const dvariable& d){
  int count;
  for (count=0;count<size();count++){
    v[count]=d.x;}
  return *this;
}
dvv& dvv::operator=(double* tv){
  v=tv;
  return *this;
}

dvv::dvv(const dsubv& dv):first(dv.first),v(dv.size()){
  v=dv.av;}
dvv::dvv(const adubv& av)
  :v(av),first(1){}
dvv::dvv(const adoublev& av)
  :v(av),first(1){}
dvv& dvv::operator=(const adubv& av){
#if !defined(_UNCHECKED_)
  if (size() != av.sz()){
    error("bad size in dvv::operator=(adubv)");}
#endif
  v=av;
  return *this;
}
dvv& dvv::operator=(const adoublev& av){
#if !defined(_UNCHECKED_)
  if (size() != av.sz()){
    error("bad size in dvv::operator=(adoublev)");}
#endif
  v=av;
  return *this;
}
dvv& dvv::operator=(const dsubv& dv){
#if !defined(_UNCHECKED_)
  if (size() != dv.av.sz()){
    error("bad size in dvv::operator=(dsubv)");}
#endif
  v=dv.av;
  return *this;
}

void dvv::initialize(){
  v=0.0;
}

int dvv::indexmin() const {
  return first;
}
int dvv::indexmax() const {
  return first+v.sz()-1;
}
int dvv::size() const {
  return v.sz();
}
void dvv::shift(int m){
  first=m;
}

badouble dvv::operator[](int i) const{
#if !defined(_UNCHECKED_)
  if (i < first || i >= (first + v.sz())){
    error("bad size in dvv::operator[](int)");}
#endif
  return v[i-first];
}
badouble dvv::operator[](double t) const{
  int i = (int) t;
#if !defined(_UNCHECKED_)
  if (i < first || i >= (first + v.sz())){
    error("bad size in dvv::operator[](double)");}
#endif
  return v[i-first];
}

dvv dvv::operator[](const dvector& d) const{
  dvv n(d.indexmin(),d.indexmax());
  int count;
  for (count=0;count<d.size();count++){
    n.v[count]=v[(int)(d.ptr[count])-first];}
  return n;
}

void dvv::operator>>=(double* tv){
  v>>=tv;
}
void dvv::operator<<=(double* tv){
  v<<=tv;
}
void dvv::operator>>=(dvv dv){
  double* tv = new double[size()];
  v>>=tv;
  dv=tv;
  delete[] tv;
}
void dvv::operator<<=(const dvv& dv){
  double* tv = new double[dv.size()];
  int count;
  for (count=0; count<dv.size(); count++){
    tv[count]=value(dv.v[count]);}
  v<<=tv;
  delete[] tv;
}
void dvv::operator>>=(dvector dv){
  double* tv = new double[size()];
  v>>=tv;
  int count;
  for (count=0;count<size();count++){
    dv.ptr[count]=tv[count];}
  delete[] tv;
}
void dvv::operator<<=(const dvector& dv){
  double* tv = new double[dv.size()];
  int count;
  for (count=0; count<dv.size(); count++){
    tv[count]=dv.ptr[count];}
  v<<=tv;
  delete[] tv;
}

void dvv::fill(char *s){
  dvector dv(s);
  (*this) = dv;
}
void dvv::fill_seqadd(const dvariable& base, const dvariable& offset){
  int count;
  for (count=0;count<size();count++){
    v[count]=base.x+count*offset.x;}
}
void dvv::fill_randu(const long int& i){
  static Uniform u;
  double newseed=double(abs(i+1))/RNG_LONGMAX;
  newseed=newseed-floor(newseed);
  if (!betadiff_seed){
    Random::Set(newseed);
    betadiff_seed=true;
  }
  int count;
  for (count=0;count<size();count++){
    v[count]=u.Next();}
}
void dvv::fill_randn(const long int& i){
  static Normal n;
  double newseed;
  newseed=double(abs(i+1))/RNG_LONGMAX;
  newseed=newseed-floor(newseed);
  if (!betadiff_seed){
    Random::Set(newseed);
    betadiff_seed=true;
  }
  int count;
  for (count=0;count<size();count++){
    v[count]=n.Next();}
}
void dvv::fill_randbi(const long int& i, double p){
  static Uniform u;
  double newseed;
  newseed=double(abs(i+1))/RNG_LONGMAX;
  newseed=newseed-floor(newseed);
  if (!betadiff_seed){
    Random::Set(newseed);
    betadiff_seed=true;
  }
  int count;
  for (count=0;count<size();count++){
    v[count]=((u.Next()>p)?0:1);}
}
void dvv::fill_multinomial(const long int& i, const dvector& p){
  if (fabs(sum(p)-1) >= 1e-10){
    error("Bad p in dvv::fill_multinomial");}
  static Uniform u;
  double newseed=double(abs(i+1))/RNG_LONGMAX;
  newseed=newseed-floor(newseed);
  if (!betadiff_seed){
    Random::Set(newseed);
    betadiff_seed=true;
  }
  for (int count=0;count<size();count++){
    v[count]=u.Next();
    double sum=0;
    for (int count2=p.indexmin(); count2<=p.indexmax(); count2++){
      sum += p[count2];
      if (sum >= v[count]){
        v[count] = count2;
        break;
      }
    }
  }
}
void dvv::fill_multinomial_counts(const long int& i, const dvector& p, int N){
  // number of multinomial random numbers in each category
  dvv temp(1,N);
  temp.fill_multinomial(i,p);
  initialize();
  for (int j=1; j<=N; j++){
    (*this)[(int)(value(temp[j]))] += 1;}
}

void dvv::operator+=(const dvv& dv){
#if !defined(_UNCHECKED_)
  if (dv.size() != size()){
    error("bad size in dvv::operator+=(dvv)");}
#endif
  v+=dv.v;
}
void dvv::operator-=(const dvv& dv){
#if !defined(_UNCHECKED_)
  if (dv.size() != size()){
    error("bad size in dvv::operator-=(dvv)");}
#endif
  v-=dv.v;
}
void dvv::operator*=(const dvv& dv){
#if !defined(_UNCHECKED_)
  if (dv.size() != size()){
    error("bad size in dvv::operator*=(dvv)");}
#endif
  for (int i=0; i<size(); i++){
    v[i]*=dv.v[i];
  }
}
void dvv::operator*=(const dvariable& d){
  v*=d.x;
}
void dvv::operator/=(const dvariable& d){
  v/=d.x;
}
void dvv::operator/=(double t){
  v/=t;
}
void dvv::operator*=(double t){
  v*=t;
}

dvariable operator*(const dvv& dv1, const dvv& dv2){
#if !defined(_UNCHECKED_)
  if (dv1.size() != dv2.size()){
    error("bad size in operator*(dvv,dvv)");}
#endif
  adub n=dv1.v*dv2.v;
  return n;
}
dvv operator*(double t, const dvv& dv){
  adubv n=t*dv.v;
  return n;}
dvv operator*(const dvv& dv, double t){
  adubv n=dv.v*t;
  return n;}
dvv operator*(const dvariable& d, const dvv& dv){
  adubv n=d.x*dv.v;
  return n;}
dvv operator*(const dvv& dv, const dvariable& d){
  adubv n=dv.v*d.x;
  return n;}
dvv operator/(const dvv& dv, double t){
  adubv n=dv.v/t;
  return n;}
dvv operator/(const dvv& dv, const dvariable& d){
  adubv n=dv.v/d.x;
  return n;}
dvv operator/(double t, const dvv& dv){
  dvv tv(1,dv.size());
  tv=t;
  dvv n=elem_div(tv,dv);
  return n;}
dvv operator/(const dvariable& d, const dvv& dv){
  dvv d_v(1,dv.size());
  d_v=d;
  dvv n=elem_div(d_v,dv);
  return n;}
dvv operator+(const dvv& dv1, const dvv& dv2){
#if !defined(_UNCHECKED_)
  if (dv1.size() != dv2.size()){
    error("bad size in operator+(dvv,dvv)");}
#endif
  adubv n=dv1.v+dv2.v;
  return n;}
dvv operator+(const dvv& dv, const dvariable& d){
  adoublev n=dv.v;
  int count;
  for (count=0;count<dv.size();count++)
    n[count]+=d.x;
  return n;}
dvv operator+(const dvariable& d, const dvv& dv){
  adoublev n=dv.v;
  int count;
  for (count=0;count<dv.size();count++)
    n[count]+=d.x;
  return n;}
dvv operator-(const dvv& dv1, const dvv& dv2){
#if !defined(_UNCHECKED_)
  if (dv1.size() != dv2.size()){
    error("bad size in operator-(dvv,dvv)");}
#endif
  adubv n=dv1.v-dv2.v;
  return n;}
dvv operator-(const dvv& dv, const dvariable& d){
  adoublev n=dv.v;
  int count;
  for (count=0;count<dv.size();count++)
    n[count]-=d.x;
  return n;}
dvv operator-(const dvariable& d, const dvv& dv){
  adoublev n=-dv.v;
  int count;
  for (count=0;count<dv.size();count++)
    n[count]+=d.x;
  return n;}
dvv operator-(const dvv& dv){
  adubv n=(-dv.v);
  return n;}
dvv operator&(const dvv& dv1, const dvv& dv2){
  int s1=dv1.size();
  int s2=dv2.size();
  adoublev n(s1+s2);
  int count;
  for (count=0;count<s1;count++){
    n[count]=dv1.v[count];}
  for (count=0;count<s2;count++){
    n[count+s1]=dv2.v[count];}
  return n;}
void dvv::operator+=(const dvariable& d){
  int count;
  for (count=0;count<size();count++){
    v[count]+=d.x;}
}
void dvv::operator-=(const dvariable& d){
  int count;
  for (count=0;count<size();count++){
    v[count]-=d.x;}
}
void dvv::operator+=(double t){
  int count;
  for (count=0;count<size();count++){
    v[count]+=t;}
}
void dvv::operator-=(double t){
  int count;
  for (count=0;count<size();count++){
    v[count]-=t;}
}

dvector value(const dvv& dv){
  dvector d(dv.size());
  int count;
  for (count=1;count<=dv.size();count++){
    d[count]=value(dv.v[count-1]);}
  d.shift(dv.indexmin());
  return d;
}

dvv elem_prod(const dvv& d1, const dvv& d2){
  int count;
  int l1=d1.size(),l2=d2.size();
#if !defined(_UNCHECKED_)
  if (l1 != l2){
    error("bad size in elem_prod(dvv,dvv)");}
#endif
  dvv d(l1);
  for (count=0;count<l1;count++)
    d.v[count]=d1.v[count]*d2.v[count];
  return d;}
dvv elem_prod(const dvv& d1, const dvv& d2, const dvv& d3){
  int count;
  int l1=d1.size(),l2=d2.size(),l3=d3.size();
#if !defined(_UNCHECKED_)
  if (l1 != l2 || l2 != l3){
    error("bad size in elem_prod(dvv,dvv,dvv)");}
#endif
  dvv d(l1);
  for (count=0;count<l1;count++)
    d.v[count]=d1.v[count]*d2.v[count]*d3.v[count];
  return d;}
dvv elem_div(const dvv& d1, const dvv& d2){
  int count;
  int l1=d1.size(),l2=d2.size();
#if !defined(_UNCHECKED_)
  if (l1 != l2){
    error("bad size in elem_div(dvv,dvv)");}
#endif
  dvv d(l1);
  for (count=0;count<l1;count++)
    d.v[count]=d1.v[count]/d2.v[count];
  return d;}
dvariable sum(const dvv& d){
  dvv ones(1,d.size());
  ones=1;
  return d*ones;}
dvariable norm(const dvv& d){
  return sqrt(d*d);}
dvariable norm2(const dvv& d){
  return d*d;}
dvariable max(const dvv& d){
  int count;
  dvariable m=d[d.indexmin()];
  if (d.size()>1)
    for (count=d.indexmin()+1;count<=d.indexmax();count++)
      m=fmax(m,d[count]);
  return m;
}
dvariable min(const dvv& d){
  int count;
  dvariable m=d[d.indexmin()];
  if (d.size()>1)
    for (count=d.indexmin()+1;count<=d.indexmax();count++)
      m=fmin(m,d[count]);
  return m;
}
dvariable mean(const dvv& d){
  dvariable m;
  m=sum(d)/d.size();
  return m;
}
dvariable std_dev(const dvv& d){
  dvariable m;
  int n=d.size();
  m=sqrt((norm2(d)-sum(d)*sum(d)/n)/(n-1));
  return m;
}
dvv pow(const dvv& d1, const dvv& d2){
  int count, s=d1.size();
#if !defined(_UNCHECKED_)
  if (s!=d2.size()) {error("Bad size in pow(dvv,dvv)");}
#endif
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=pow(d1.v[count],d2.v[count]);
  return n;
}
dvv pow(double t, const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=pow(t,d.v[count]);
  return n;
}
dvv pow(const dvv& d, double t){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=pow(d.v[count],t);
  return n;
}
dvv pow(const dvv& dv, const dvariable& d){
  int count, s=dv.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=pow(dv.v[count],d);
  return n;
}
dvv sin(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=sin(d.v[count]);
  return n;
}
dvv cos(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=cos(d.v[count]);
  return n;
}
dvv tan(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=tan(d.v[count]);
  return n;
}
dvv asin(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=asin(d.v[count]);
  return n;
}
dvv acos(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=acos(d.v[count]);
  return n;
}
dvv atan(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=atan(d.v[count]);
  return n;
}
dvv sqrt(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=sqrt(d.v[count]);
  return n;
}
dvv exp(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=exp(d.v[count]);
  return n;
}
dvv log(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=log(d.v[count]);
  return n;
}
dvv log10(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=log10(d.v[count]);
  return n;
}
dvv fabs(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=fabs(d.v[count]);
  return n;
}
dvv sfabs(const dvv& d){
  return fabs(d);
}
dvv ceil(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=ceil(d.v[count]);
  return n;
}
dvv floor(const dvv& d){
  int count, s=d.size();
  adoublev n(s);
  for (count=0;count<s;count++)
    n[count]=floor(d.v[count]);
  return n;
}

std::istream& operator>>(std::istream& istr, dvv& dv){
  int count;
  double t;
  for (count=dv.indexmin();count<=dv.indexmax();count++){
    istr >> t;
    if (istr) dv[count]=t;
    else {
      error("Error in input file - invalid number of values found.");
    }
  }
  return istr;
}

std::ostream& operator<<(std::ostream& ostr, const dvv& dv){
  int count;
  for (count=dv.indexmin();count<=dv.indexmax();count++){
    ostr << value(dv[count]) << " ";}
  return ostr;
}

dvm::dvm(int lbr,int lur,int lbc,int luc){
  rows = lur - lbr + 1;
  cols = luc - lbc + 1;
  firstrow = lbr;
  firstcol = lbc;
  //index = new dvv[rows](firstcol,firstcol+cols-1);
  index.resize(rows,dvv(firstcol,firstcol+cols-1));
}
dvm::dvm(int lur,int luc){
  rows = lur;
  cols = luc;
  firstrow = 1;
  firstcol = 1;
  //index = new dvv[rows](1,cols);
  index.resize(rows,dvv(1,cols));
}
dvm::dvm(const dvm &dm){
  rows = dm.rows;
  cols = dm.cols;
  firstrow = dm.firstrow;
  firstcol = dm.firstcol;
  //index = new dvv[rows](firstcol,firstcol+cols-1);
  index.resize(rows,dvv(firstcol,firstcol+cols-1));
  for (int i=0; i<rows; i++){
    index[i] = dm.index[i];}
}
dvm::dvm(const dmatrix &dm){
  rows = dm.rows;
  cols = dm.cols;
  firstrow = dm.firstrow;
  firstcol = dm.firstcol;
  //index = new dvv[rows](firstcol,firstcol+cols-1);
  index.resize(rows,dvv(firstcol,firstcol+cols-1));
  for (int i=0; i<rows; i++){
    index[i] = dm.index[i];}
}
dvm::dvm(char* c){
// a bit different from the Betadiff version: takes only a single string argument.
// Example usage: dvm W("{1 2 3}{4 5 6}{7 8 9}");
// but not dvm W("{ 1 2 3}... or dvm W("{1 2 3 }...
// ie. watch out for excess spaces.
// note, stray text words in a file come out as 0's
  dmatrix temp(c);
  firstrow = temp.firstrow;
  firstcol = temp.firstcol;
  rows = temp.rowsize();
  cols = temp.colsize();
  // index = new dvv[rows](firstcol,firstcol+cols-1);
  index.resize(rows,dvv(firstcol,firstcol+cols-1));
  for (int i=firstrow; i<=firstrow+rows-1; i++){
    (*this)[i] = temp[i];}
}
dvm::dvm(){
  rows = 1;
  cols = 1;
  firstrow = 1;
  firstcol = 1;
  //index = new dvv[rows](firstcol,firstcol+cols-1);
  index.resize(rows,dvv(firstcol,firstcol+cols-1));
}
dvm& dvm::operator=(const dvm &dm){
#if !defined(_UNCHECKED_)
  if (dm.rows!=rows || dm.cols!=cols){
    error("bad size in dvm::operator=(dvm)");}
#endif
  int count;
  for (count=0;count<rows;count++){
    index[count]=dm.index[count];}
  return *this;
}
dvm& dvm::operator=(const dmatrix& dm){
#if !defined(_UNCHECKED_)
  if (dm.rows!=rows || dm.cols!=cols){
    error("bad size in dvm::operator=(dmatrix)");}
#endif
  int count;
  for (count=0;count<rows;count++){
    index[count]=dm.index[count];}
  return *this;
}
dvm& dvm::operator=(const dvariable &d){
  int count;
  for (count=0;count<rows;count++){
    (*this)[count+firstrow]=d;}
  return *this;
}

void dvm::initialize(){
  int count;
  for (count=firstrow;count<=firstrow+rows-1;count++){
    (*this)[count]=0.0;}
}

int dvm::rowmin() const{
  return firstrow;
}
int dvm::rowmax() const{
  return firstrow+rows-1;
}
int dvm::colmin() const{
  return firstcol;
}
int dvm::colmax() const{
  return firstcol+cols-1;
}
int dvm::rowsize() const{
  return rows;
}
int dvm::colsize() const{
  return cols;
}
void dvm::colshift(int min){
  firstcol=min;
}
void dvm::rowshift(int min){
  firstrow=min;
}

dvv& dvm::operator[](int i){
#if !defined(_UNCHECKED_)
  if (i<firstrow || i>(firstrow+rows-1)){
    error("subscript out of range in dvm::operator[](int)");}
#endif
  return index[i-firstrow];
}

const dvv& dvm::operator[](int i) const{
  //return const_cast<const dvv&>(operator[](i));
#if !defined(_UNCHECKED_)
  if (i<firstrow || i>(firstrow+rows-1)){
    error("subscript out of range in dvm::operator[](int)");}
#endif
  return index[i-firstrow];
}

dvv& dvm::operator[](double t){
  int i = (int) t;
#if !defined(_UNCHECKED_)
  if (i<firstrow || i>(firstrow+rows-1)){
    error("subscript out of range in dvm::operator[](int)");}
#endif
  return index[i-firstrow];
}

const dvv& dvm::operator[](double t) const{
  int i = (int) t;
//return const_cast<const dvv&>(operator[](i));
#if !defined(_UNCHECKED_)
  if (i<firstrow || i>(firstrow+rows-1)){
    error("subscript out of range in dvm::operator[](int)");}
#endif
  return index[i-firstrow];
}

void dvm::rowfill(int i, const dvv& dv){
#if !defined(_UNCHECKED_)
  if (dv.size() != cols){
    error("bad size in dvm::rowfill(int,dvv)");}
#endif
  (*this)[i]=dv;
}
void dvm::colfill(int j, const dvv& dv){
#if !defined(_UNCHECKED_)
  if (dv.size() != rows){
    error("bad size in dvm::colfill(int,dvv)");}
#endif
  int count;
  for (count=0;count<dv.size();count++){
    (*this)[count+rowmin()][j]=dv.v[count];}
}
void dvm::rowfill_seqadd(int i, const double base, const double offset){
  dvv dv(cols);
  dv.fill_seqadd(base,offset);
  (*this).rowfill(i,dv);
}
void dvm::colfill_seqadd(int j, const double base, const double offset){
  dvv dv(rows);
  dv.fill_seqadd(base,offset);
  (*this).colfill(j,dv);
}
void dvm::rowfill_randu(int i, const long int& s){
  dvv dv(cols);
  dv.fill_randu(s);
  (*this).rowfill(i,dv);
}
void dvm::colfill_randu(int j, const long int& s){
  dvv dv(rows);
  dv.fill_randu(s);
  (*this).colfill(j,dv);
}
void dvm::rowfill_randn(int i, const long int& s){
  dvv dv(cols);
  dv.fill_randn(s);
  (*this).rowfill(i,dv);
}
void dvm::colfill_randn(int j, const long int& s){
  dvv dv(rows);
  dv.fill_randn(s);
  (*this).colfill(j,dv);
}
void dvm::rowfill_randbi(int i, const long int& s, double t){
  dvv dv(cols);
  dv.fill_randbi(s,t);
  (*this).rowfill(i,dv);
}
void dvm::colfill_randbi(int j, const long int& s, double t){
  dvv dv(rows);
  dv.fill_randbi(s,t);
  (*this).colfill(j,dv);
}

void dvm::operator+=(const dvm& dm){
#if !defined(_UNCHECKED_)
  if(rows!=dm.rows || cols!=dm.cols){
    error("bad size in dvm::operator+=(dvm)");}
#endif
  int count;
  for (count=firstrow;count<=firstrow+rows-1;count++){
    (*this)[count]+=dm[count];}
}
void dvm::operator-=(const dvm& dm){
#if !defined(_UNCHECKED_)
  if(rows!=dm.rows || cols!=dm.cols){
    error("bad size in dvm::operator-=(dvm)");}
#endif
  int count;
  for (count=firstrow;count<=firstrow+rows-1;count++){
    (*this)[count]-=dm[count];}
}
void dvm::operator+=(const dvariable& d){
  dvv dv(cols);
  dv=d;
  int count;
  for (count=rowmin();count<=rowmax();count++){
    (*this)[count]+=dv;}
}
void dvm::operator-=(const dvariable& d){
  dvv dv(cols);
  dv=d;
  int count;
  for (count=rowmin();count<=rowmax();count++){
    (*this)[count]-=dv;}
}
void dvm::operator*=(const dvariable& d){
  int count;
  for (count=rowmin();count<=rowmax();count++){
    (*this)[count]*=d.x;}
}
void dvm::operator/=(const dvariable& d){
  int count;
  for (count=rowmin();count<=rowmax();count++){
    (*this)[count]/=d.x;}
}

dvm::~dvm(){
}

dvm operator+(const dvm& m1,const dvm& m2){
  dvm m(m1);
  m+=m2;
  return m;
}
dvm operator-(const dvm& m1,const dvm& m2){
  dvm m(m1);
  m-=m2;
  return m;
}
dvm operator+(const dvm& dm,const dvariable& d){
  dvm m(dm);
  m+=d;
  return m;
}
dvm operator+(const dvariable& d,const dvm& dm){
  dvm m(dm);
  m+=d;
  return m;
}
dvm operator-(const dvm& dm,const dvariable& d){
  dvm m(dm);
  m-=d;
  return m;
}
dvm operator-(const dvariable& d,const dvm& dm){
  dvm m(dm);
  m=-m;
  m+=d;
  return m;
}
dvm operator*(const dvm& dm,const dvariable& d){
  dvm m(dm);
  m*=d;
  return m;
}
dvm operator*(const dvariable& d,const dvm& dm){
  dvm m(dm);
  m*=d;
  return m;
}
dvm operator*(const dvm& dm,double t){
  dvm m(dm);
  m*=t;
  return m;
}
dvm operator*(double t,const dvm& dm){
  dvm m(dm);
  m*=t;
  return m;
}
dvm operator-(const dvm& dm){
  dvm m(dm);
  m*=-1;
  return m;
}
dvm operator*(const dvm& m1,const dvm& m2){
  int count,count2;
  int m1r=m1.rows,m2c=m2.cols,m1c=m1.cols,m2r=m2.rows;
  int m1rm=m1.rowmin(),m2cm=m2.colmin();
#if !defined(_UNCHECKED_)
  if (m1c != m2r){
    error("bad sizes in operator*(dvm,dvm)");}
#endif
  dvm m3(1,m1r,1,m2c);
  dvv this_col(m2r);
  for (count2=0;count2<m2c;count2++){
    this_col = extract_column(m2,count2+m2cm);
    for (count=0;count<m1r;count++){
      m3[count+1][count2+1] = m1[count+m1rm]*this_col;}}  // easier to extract row than col
  return m3;
}
dvm operator*(const dvv& v1,const dvm& m2){
  int count;
  int v1s=v1.size(),m2c=m2.cols,m2r=m2.rows;
  int v1m=v1.first,m2cm=m2.colmin();
#if !defined(_UNCHECKED_)
  if (v1s != m2r){
    error("bad sizes in operator*(dvv,dvm)");}
#endif
  dvm m3(1,1,1,m2c);
  dvv this_col(m2r);
  for (count=0;count<m2c;count++){
    this_col = extract_column(m2,count+m2cm);
    m3[1][count+1] = v1*this_col;}
  return m3;
}
dvv operator*(const dvm& m1,const dvv& v2){
  int count;
  int m1r=m1.rows,m1c=m1.cols,v2s=v2.size();
  int m1rm=m1.rowmin(),v2m=v2.first;
#if !defined(_UNCHECKED_)
  if (m1c != v2s){
    error("bad sizes in operator*(dvm,dvv)");}
#endif
  dvv v3(1,m1r);
  for (count=0;count<m1r;count++){
    v3[count+1] = m1[count+m1rm]*v2;}  // easier to extract row than col
  return v3;
}

dvm elem_prod(const dvm& m1,const dvm& m2){
#if !defined(_UNCHECKED_)
  if(m1.rows!=m2.rows || m1.cols!=m2.cols){
    error("bad sizes in elem_prod(dvm,dvm)");}
#endif
  dvm m=m1;
  int count;
  int rm=m.rowmin(),rm1=m1.rowmin(),rm2=m2.rowmin();
  for (count=0;count<m.rows;count++){
    m[count+rm]=elem_prod(m1[count+rm1],m2[count+rm2]);}
  return m;
}
dvm elem_div(const dvm& m1,const dvm& m2){
#if !defined(_UNCHECKED_)
  if(m1.rows!=m2.rows || m1.cols!=m2.cols){
     error("bad sizes in elem_div(dvm,dvm)");}
#endif
  dvm m=m1;
  int count;
  int rm=m.rowmin(),rm1=m1.rowmin(),rm2=m2.rowmin();
  for (count=0;count<m.rows;count++){
    m[count+rm]=elem_div(m1[count+rm1],m2[count+rm2]);}
  return m;
}
dvm column_vector(dvv& dv){
  dvm m(dv.size(),1);
  int count;
  for (count=dv.indexmin();count<=dv.indexmax();count++){
    m[count-dv.indexmin()+1][1]=dv.v[count-dv.indexmin()];}
  return m;
}
dvm row_vector(dvv& dv){
  dvm m(1,dv.size());
  int count;
  for (count=dv.indexmin();count<=dv.indexmax();count++){
    m[1][count-dv.indexmin()+1]=dv.v[count-dv.indexmin()];}
  return m;
}
dvv extract_column(const dvm& dm, const int j){
  dvv d(dm.rowmin(),dm.rowmax());
  int count;
  for (count=dm.rowmin();count<=dm.rowmax();count++){
    d[count]=dm[count][j];}
  return d;
}
dvv extract_diagonal(const dvm& dm){
#if !defined(_UNCHECKED_)
  if(dm.rows!=dm.cols){
    error("extract_diagonal: matrix not square!");}
#endif
  dvv d(dm.rows);
  int count;
  for (count=0;count<dm.rows;count++){
    d[count+1]=dm[count+dm.rowmin()][count+dm.colmin()];}
  return d;
}
dvm sqrt(const dvm& dm){
  dvm r(dm);
  for (int i=r.rowmin(); i<=r.rowmax(); i++){
    r[i] = sqrt(dm[i]);
  }
  return r;
}
dvm log(const dvm& dm){
  dvm r(dm);
  for (int i=r.rowmin(); i<=r.rowmax(); i++){
    r[i] = log(dm[i]);
  }
  return r;
}
dvariable norm(dvm dm){
  dvariable sum=0;
  int count;
  for (count=dm.rowmin();count<=dm.rowmax();count++){
    sum += norm2(dm[count]);}
  return sqrt(sum);
}
dvariable norm2(dvm dm){
  dvariable sum=0;
  int count;
  for (count=dm.rowmin();count<=dm.rowmax();count++){
    sum += norm2(dm[count]);}
  return sum;
}
dvv rowsum(dvm dm){
  dvv rsum(dm.rowmin(),dm.rowmax());
  int count;
  for (count=dm.rowmin();count<=dm.rowmax();count++){
    rsum[count] = sum(dm[count]);}
  return rsum;
}
dvv colsum(dvm dm){
  dvv csum(dm.colmin(),dm.colmax());
  int count;
  for (count=dm.colmin();count<=dm.colmax();count++){
    csum[count] = sum(extract_column(dm,count));}
  return csum;
}
dvm inverse(const dvm& dm){
  // Invert the square matrix argument, which should have rows and columns starting from 1.
  // See also the non-differentiable version.
  //
  // This was written for inverting a Hessian to get an approximate covariance matrix.
  // Sometimes the Hessian can have a zero row and corresponding zero column, when a
  // parameter has no effect on the objective function (perhaps because it is not allowed
  // to vary). In this case the matrix is less than full rank and not invertible.
  // We kludge this by temporarily setting the relevant diagonal element to 1, going ahead
  // and doing the inverse, and setting the corresponding row and column of the result to 0.
  // The result is not strictly an inverse - the product A*inv(A) will have zeros
  // in the corresponding diagonal elements rather than ones - but will do for the purpose at hand.
  //
  // The algorithm used for the inverse is Gauss-Jordan, from Numerical Recipes in C, section 2.1.
  //  We could do better, see other algorithms in the same reference.
  dvm a(dm);
  int n = a.rowsize();
  dvm b(identity_matrix(1,n));
#if !defined(_UNCHECKED_)
  if (a.rowmin() != 1 || a.colmin() != 1 || a.rowsize() != a.colsize()){
    std::cerr << a << '\n'; error("Bad matrix in inverse");
  }
#endif
  // go through, find zero rows (with corresponding zero columns)
  // set the corresponding diagonal elements equal to 1 -
  // we will zero the corresponding rows and columns of the inverse at the end.
  dvector zero_rows(1,n);
  zero_rows = 0;
  for (int i=1; i<=n; i++){
    if (max(fabs(a[i]))==0.0 && max(fabs(extract_column(a,i)))==0.0){
      zero_rows[i] = 1;
      a[i][i] = 1;
    }
  }
  // invert a (store the result in a)
  // this is equivalent to solving a * a_inverse = b.
  dvector indxc(1,n);
  dvector indxr(1,n);
  dvector ipiv(1,n);
  ipiv = 0;
  dvariable big, dum, pivinv, temp;
  int icol=0, irow=0;
  for (int i=1; i<=n; i++){
    big = 0;
    for (int j=1; j<=n; j++){
      if (ipiv[j] != 1){
        for (int k=1; k<=n; k++){
          if (ipiv[k] == 0){
            if (fabs(a[j][k]) >= big){
              big = fabs(a[j][k]);
              irow = j;
              icol = k;
            }
          } else {
            if (ipiv[k] > 1){
              error("Singular matrix in inverse");
            }
          }
        }
      }
    }
    ipiv[icol]++;
    if (irow != icol){
      for (int l=1; l<=n; l++){
        temp = a[irow][l];
        a[irow][l] = a[icol][l];
        a[icol][l] = temp;
        temp = b[irow][l];
        a[irow][l] = b[icol][l];
        b[icol][l] = temp;
      }
    }
    indxr[i] = irow;
    indxc[i] = icol;
    if (a[icol][icol]==0){
      error("Singular matrix in inverse");
    }
    pivinv = 1.0/a[icol][icol];
    a[icol][icol] = 1;
    for (int l=1; l<=n; l++){
      a[icol][l] *= pivinv;
      b[icol][l] *= pivinv;
    }
    for (int ll=1; ll<=n; ll++){
      if (ll != icol){
        dum = a[ll][icol];
        a[ll][icol] = 0;
        for (int l=1; l<=n; l++){
          a[ll][l] -= a[icol][l] * dum;
          b[ll][l] -= b[icol][l] * dum;
        }
      }
    }
  }
  for (int l=n; l>=1; l--){
    if (indxr[l] != indxc[l]){
      for (int k=1; k<=n; k++){
        temp = a[k][indxr[l]];
        a[k][indxr[l]] = a[k][indxc[l]];
        a[k][indxc[l]] = temp;
      }
    }
  }
  // zero the rows and columns corresponding to zero rows and columns in the original matrix.
  dvector zeros(1,n);
  zeros = 0;
  for (int i=1; i<=n; i++){
    if (zero_rows[i]){
      a[i] = zeros;
      a.colfill(i,zeros);
    }
  }
  return a;
}

std::ostream& operator<<(std::ostream& ostr, const dvm& dm){
  for (int count=dm.rowmin();count<=dm.rowmax();count++){
    ostr << dm[count]; // << "\n";
    if (count<dm.rowmax()){
      ostr << "\n";}}
  return ostr;
}
std::istream& operator>>(std::istream& istr, dvm& dm){
  double t;
  for (int count=dm.rowmin();count<=dm.rowmax();count++){
    for (int count2=dm.colmin();count2<=dm.colmax();count2++){
      istr >> t;
      if (istr) dm[count][count2]=t;
      else {
        error("Error in input file - invalid number of values found.");
      }
    }
  }
  return istr;
}

dsubv& dsubv::operator=(const dvv& dv){
#if !defined(_UNCHECKED_)
  if (av.sz() != dv.v.sz()){
    error("bad size in dsubv::operator=");}
#endif
  av=dv.v;
  return *this;
}
dsubv& dsubv::operator=(double* tp){
  av=tp;
  return *this;
}
dsubv& dsubv::operator=(const dvariable& d){
  dvv a(size());
  a=d;
  av=a.v;
  return *this;
}
dsubv& dsubv::operator=(double t){
  dvv a(size());
  a=t;
  av=a.v;
  return *this;
}

dsubv& dsubv::operator=(const adoublev& dv){
#if !defined(_UNCHECKED_)
  if (av.sz() != dv.sz()){
    error("bad size in dsubv::operator=(adoublev)");}
#endif
  av=dv;
  return *this;
}
dsubv& dsubv::operator=(const adubv& dv){
#if !defined(_UNCHECKED_)
  if (av.sz() != dv.sz()){
    error("bad size in dsubv::operator=(adubv)");}
#endif
  av=dv;
  return *this;
}

int dsubv::size() const{
  return av.sz();
}
void dsubv::shift(int min){
  first=min;
}

badouble dsubv::operator[](int i){
#if !defined(_UNCHECKED_)
  if (i < first || i >= first+av.sz()){
    error("bad index in dsubv::operator[](int)");}
#endif
  return av.base+i-first;
}
badouble dsubv::operator[](double t){
  int i = (int) t;
#if !defined(_UNCHECKED_)
  if (i < first || i >= first+av.sz()){
    error("bad index in dsubv::operator[](double)");}
#endif
  return av.base+i-first;
}

void dsubv::operator+=(const dvv& dv){
#if !defined(_UNCHECKED_)
  if (size() != dv.size()){
    error("bad size in dsubv::operator+=(dvv)");}
#endif
  av+=dv.v;
}
void dsubv::operator-=(const dvv& dv){
#if !defined(_UNCHECKED_)
  if (size() != dv.size()){
    error("bad size in dsubv::operator-=(dvv)");}
#endif
  av-=dv.v;
}
void dsubv::operator*=(const dvariable& d){
  av*=d.x;
}
void dsubv::operator/=(const dvariable& d){
  av/=d.x;
}
void dsubv::operator+=(const dvariable& d){
  dvv dv(size());
  dv.initialize();
  dv += d;
  *this += dv;
}
void dsubv::operator-=(const dvariable& d){
  dvv dv(size());
  dv.initialize();
  dv += d;
  *this -= dv;
}
void dsubv::operator+=(double t){
  dvv dv(size());
  dv = t;
  *this += dv;
}
void dsubv::operator-=(double t){
  dvv dv(size());
  dv = t;
  *this -= dv;
}

dvector::dvector(int i1, int i2){
  first = i1;
  int i = i2-i1+1;
#if !defined(_UNCHECKED_)
  if (i<=0){
    error("Attempt to create dvector of length <=0: this is illegal");}
#endif
  sz = i;
  ptr = new double[i];
}
dvector::dvector(int i){
#if !defined(_UNCHECKED_)
  if (i<=0){
    error("Attempt to create dvector of length <=0: this is illegal");}
#endif
  first = 1;
  sz = i;
  ptr = new double[i];
}
dvector::dvector(const dvector& d){
  first = d.first;
  sz = d.sz;
  ptr = new double[sz];
  for (int i=0; i<sz; i++){
    ptr[i] = d.ptr[i];}
}
dvector::dvector(char* c){
  first = 1;
  // is it a file or a set of values?
  if (c[0]=='{'){
    // it's a set of values
    c++;
    char **u=(char**)malloc(sizeof(char*));
    double **buffer;
    buffer = (double**)malloc(10*sizeof(double*));
    buffer[0] = (double*)malloc(50*sizeof(double));
    int bufcount=0; // the sub-buffer we are about to write to
    int subcount=0; // the position in sub-buffer we are about to write to
    while (c[0]!=0){
      if (subcount == 50){
        subcount=0;
        bufcount++;
        if (bufcount%10 == 0){
          buffer=(double**)realloc(buffer,10*bufcount*sizeof(double*));}
        buffer[bufcount]=(double*)malloc(50*sizeof(double));
      }
      buffer[bufcount][subcount]=strtod(c,u);
      c=(*u)+1;
      subcount++;
    }
    sz = bufcount*50+subcount;
    if (sz){
      ptr = new double[sz];}

    int count1,count2;
    for (count1=0;count1<=bufcount;count1++){
      for (count2=0;count2<50;count2++){
        if (count1==bufcount && count2==subcount) break;
        ptr[count1*50+count2]=buffer[count1][count2];
      }
      free(buffer[count1]);
    }
    free(buffer);
    free(u);
  }
  else{
    // it's a file
    std::ifstream istr(c);
    if (!istr) {error("bad file in dvector::dvector(" + std::string(c) + ")");}
    double **buffer;
    buffer = (double**)malloc(10*sizeof(double*));
    buffer[0] = (double*)malloc(50*sizeof(double));
    int bufcount=0; // the sub-buffer we are about to write to
    int subcount=0; // the position in sub-buffer we are about to write to
    while (1){
      if (subcount == 50){
        subcount=0;
        bufcount++;
        if (bufcount%10 == 0){
          buffer=(double**)realloc(buffer,10*bufcount*sizeof(double*));
        }
        buffer[bufcount]=(double*)malloc(50*sizeof(double));
      }
      if (!GOOD(istr >> buffer[bufcount][subcount])){
        break;
      } else {
        subcount++;
      }
    }
    sz = bufcount*50+subcount;
    if (sz){
      ptr = new double[sz];}

    int count1,count2;
    for (count1=0;count1<=bufcount;count1++){
      for (count2=0;count2<50;count2++){
        if (count1==bufcount && count2==subcount) break;
        ptr[count1*50+count2]=buffer[count1][count2];
      }
      free(buffer[count1]);
    }
    free(buffer);
  }
}
dvector::dvector(){
  first = 1;
  sz = 1;
  ptr = new double[1];
}
dvector& dvector::operator=(const dvector& d){
#if !defined(_UNCHECKED_)
  if (sz != d.sz){
    error("bad size in dvector::operator=(dvector)");}
#endif
  for (int i=0; i<sz; i++){
    ptr[i] = d.ptr[i];}
  return *this;
}
dvector& dvector::operator=(double t){
  for (int i=0; i<sz; i++){
    ptr[i] = t;}
  return *this;
}
dvector& dvector::operator=(int j){
  for (int i=0; i<sz; i++){
    ptr[i] = j;}
  return *this;
}

void dvector::initialize(){
  (*this) = 0.0;
}

int dvector::indexmin() const {
  return first;
}
int dvector::indexmax() const {
  return first+sz-1;
}
int dvector::size() const{
  return sz;
}
void dvector::shift(int m){
  first=m;
}

double& dvector::operator[](int i) const{
#if !defined(_UNCHECKED_)
  if (i<first || (i >= first + sz)){
    error("bad index in dvector::operator[](int)");}
#endif
  return ptr[i-first];
}
double& dvector::operator[](double t) const{
  int i = (int) t;
#if !defined(_UNCHECKED_)
  if (i<first || (i >= first + sz)){
    error("bad index in dvector::operator[](double)");}
#endif
  return ptr[i-first];
}

dvector dvector::operator[](const dvector& d) const{
  dvector n(d.indexmin(),d.indexmax());
  int count;
  for (count=0;count<d.sz;count++){
    n.ptr[count] = ptr[(int)d.ptr[count]-first];}
  return n;
}

void dvector::fill_randu(const long int& i){
  static Uniform u;
  double newseed=double(abs(i+1))/RNG_LONGMAX;
  newseed=newseed-floor(newseed);
  if (!betadiff_seed){
    Random::Set(newseed);
    betadiff_seed=true;
  }
  int count;
  for (count=0;count<sz;count++){
    ptr[count]=u.Next();}
}
void dvector::fill_randn(const long int& i){
  static Normal n;
  double newseed;
  newseed=double(abs(i+1))/RNG_LONGMAX;
  newseed=newseed-floor(newseed);
  if (!betadiff_seed){
    Random::Set(newseed);
    betadiff_seed=true;
  }
  int count;
  for (count=0;count<sz;count++){
    ptr[count]=n.Next();}
}
void dvector::fill_randbi(const long int& i, double p){
  static Uniform u;
  double newseed;
  newseed=double(abs(i+1))/RNG_LONGMAX;
  newseed=newseed-floor(newseed);
  if (!betadiff_seed){
    Random::Set(newseed);
    betadiff_seed=true;
  }
  int count;
  for (count=0;count<sz;count++){
    ptr[count]=((u.Next()>p)?0:1);}
}

int rbinomial(const long int& i, int N, double p){
  // slow - accurate but inefficient
  if (N<1) return 0;
  dvector bern(1,N);
  bern.fill_randbi(i,p);
  return (int)sum(bern);
}

void dvector::fill_multinomial(const long int& i, const dvector& p){
  if (fabs(sum(p)-1) >= 1e-10){
    error("Bad p in dvector::fill_multinomial");}
  static Uniform u;
  double newseed=double(abs(i+1))/RNG_LONGMAX;
  newseed=newseed-floor(newseed);
  if (!betadiff_seed){
    Random::Set(newseed);
    betadiff_seed=true;
  }
  for (int count=0;count<size();count++){
    ptr[count]=u.Next();
    double sum=0;
    for (int count2=p.indexmin(); count2<=p.indexmax(); count2++){
      sum += p[count2];
      if (sum >= ptr[count]){
        ptr[count] = count2;
        break;
      }
    }
  }
}
void dvector::fill_multinomial_counts(const long int& i, const dvector& p, int N){
  // number of multinomial random numbers in each category
  dvector temp(1,N);
  temp.fill_multinomial(i,p);
  initialize();
  for (int j=1; j<=N; j++){
        (*this)[(int)(temp[j])]++;}
}
void dvector::fill_chisq(const long int& i, int df){
  static ChiSq c(df);
  double newseed=double(abs(i+1))/RNG_LONGMAX;
  newseed=newseed-floor(newseed);
  if (!betadiff_seed){
    Random::Set(newseed);
    betadiff_seed=true;
  }
  int count;
  for (count=0;count<sz;count++){
    ptr[count]=c.Next();}
}
void dvector::fill_mvnorm(const long int& s, const dvector& mean, const dmatrix& _covar){
  // Found a problem here for the case where some variances (and hence the corresponding
  // rows and columns of covar) are 0. The cholesky decomposition does not work in these
  // cases. I thought of this kludge: Set the 0 variances to 1, leaving the covariances at 0.
  // When finished, set the corresponding deviations from the mean to 0.
  dmatrix covar(_covar);
  int n = covar.rowsize();
  if (!(n == covar.colsize() && n == size() && n == mean.size())){
    error("Bad argument to fill_mvnorm");}
  // set zero variances to 1 as above
  dvector zero_variances(covar.rowmin(),covar.rowmax());
  zero_variances = 0;
  for (int i=covar.rowmin(); i<=covar.rowmax(); i++){
    if (covar[i][i]==0){
      covar[i][i] = 1;
      zero_variances[i] = 1;
    }
  }
  // generate the standard normal random numbers
  fill_randn(s);
  // get lower triangular part of choleski decomposition of covar
  dmatrix L(1,n,1,n);
  if (!chol(covar,L)){
    error("Failed choleski decomposition in fill_mvnorm");}
  (*this) = L*(*this) + mean;
  // find the elements with 0 variances and set them to their means
  for (int i=covar.rowmin(); i<=covar.rowmax(); i++){
    if (zero_variances[i]){
      (*this)[i] = mean[i];
    }
  }
}
void dvector::fill_mvt(const long int& s, const dvector& mean, const dmatrix& _covar, int df){
  // Result is mean + 1/sqrt(y/df) * x,
  // where x ~ multivariate normal(0,_covar)
  // and y ~ chi-square(df).
  // See fill_mvnorm for treatment of zero variances.
  dvector zeros(mean * 0);
  fill_mvnorm(s,zeros,_covar);
  dvector y(1,1);
  y.fill_chisq(s,df);
  (*this) *= (1/sqrt(y[1]/df));
  (*this) += mean;
}
void dvector::fill(char *s){
  dvector dv(s);
  (*this) = dv;
}
void dvector::fill_seqadd(double base, double offset){
  int count;
  for (count=0;count<sz;count++){
    ptr[count]=base+count*offset;}
}

void dvector::operator*=(const dvector& dv){
#if !defined(_UNCHECKED_)
  if (sz != dv.sz){
    error("bad size in dvector::operator*=");}
#endif
  for (int i=0; i<sz; i++){
    ptr[i] *= dv.ptr[i];}
}
void dvector::operator+=(const dvector& dv){
#if !defined(_UNCHECKED_)
  if (sz != dv.sz){
    error("bad size in dvector::operator+=");}
#endif
  for (int i=0; i<sz; i++){
    ptr[i] += dv.ptr[i];}
}
void dvector::operator-=(const dvector& dv){
#if !defined(_UNCHECKED_)
  if (sz != dv.sz){
    error("bad size in dvector::operator-=");}
#endif
  for (int i=0; i<sz; i++){
    ptr[i] -= dv.ptr[i];}
}
void dvector::operator/=(double t){
  for (int i=0; i<sz; i++){
    ptr[i] /= t;}
}
void dvector::operator*=(double t){
  for (int i=0; i<sz; i++){
    ptr[i] *= t;}
}
void dvector::operator+=(double t){
  for (int i=0; i<sz; i++){
    ptr[i] += t;}
}
void dvector::operator-=(double t){
  for (int i=0; i<sz; i++){
    ptr[i] -= t;}
}

dvector::~dvector(){
  delete[] ptr;
}

double operator*(const dvector& dv1, const dvector& dv2){
#if !defined(_UNCHECKED_)
  if (dv1.sz != dv2.sz){
    error("bad size in operator*(dvector,dvector)");}
#endif
  double total = 0;
  for (int i=0; i<dv1.sz; i++){
    total += dv1.ptr[i] * dv2.ptr[i];}
  return total;
}
dvector operator*(double t, const dvector& dv){
  dvector n=dv;
  for (int i=0; i<dv.sz; i++){
    n.ptr[i] *= t;}
  return n;
}
dvector operator*(const dvector& dv, double t){
  dvector n=dv;
  for (int i=0; i<dv.sz; i++){
    n.ptr[i] *= t;}
  return n;
}
dvector operator/(double t, const dvector& dv){
  dvector n(1,dv.sz);
  for (int i=0; i<dv.sz; i++){
    n.ptr[i] = t / dv.ptr[i];}
  return n;
}
dvector operator/(const dvector& dv, double t){
  dvector n(1,dv.sz);
  for (int i=0; i<dv.sz; i++){
    n.ptr[i] = dv.ptr[i] / t;}
  return n;
}
dvector operator+(const dvector& dv1, const dvector& dv2){
#if !defined(_UNCHECKED_)
  if (dv1.sz != dv2.sz){
    error("bad size in operator+(dvector,dvector)");}
#endif
  dvector n(1,dv1.sz);
  for (int i=0; i<dv1.sz; i++){
    n.ptr[i] = dv1.ptr[i] + dv2.ptr[i];}
  return n;
}
dvector operator+(const dvector& dv, double t){
  dvector n(1,dv.sz);
  for (int i=0; i<dv.sz; i++){
    n.ptr[i] = dv.ptr[i] + t;}
  return n;
}
dvector operator+(double t, const dvector& dv){
  dvector n(1,dv.sz);
  for (int i=0; i<dv.sz; i++){
    n.ptr[i] = dv.ptr[i] + t;}
  return n;
}
dvector operator-(const dvector& dv1, const dvector& dv2){
#if !defined(_UNCHECKED_)
  if (dv1.sz != dv2.sz){
    error("bad size in operator-(dvector,dvector)");}
#endif
  dvector n(1,dv1.sz);
  for (int i=0; i<dv1.sz; i++){
    n.ptr[i] = dv1.ptr[i] - dv2.ptr[i];}
  return n;
}
dvector operator-(const dvector& dv, double t){
  dvector n(1,dv.sz);
  for (int i=0; i<dv.sz; i++){
    n.ptr[i] = dv.ptr[i] - t;}
  return n;
}
dvector operator-(double t, const dvector& dv){
  dvector n(1,dv.sz);
  for (int i=0; i<dv.sz; i++){
    n.ptr[i] = t - dv.ptr[i];}
  return n;
}
dvector operator-(const dvector& dv){
  dvector n(1,dv.sz);
  for (int i=0; i<dv.sz; i++){
    n.ptr[i] = -dv.ptr[i];}
  return n;
}
dvector operator&(const dvector& dv1, const dvector& dv2){
  int s1=dv1.size();
  int s2=dv2.size();
  dvector n(s1+s2);
  int count;
  for (count=0;count<s1;count++){
    n[count+1]=dv1.ptr[count];}
  for (count=0;count<s2;count++){
    n[count+s1+1]=dv2.ptr[count];}
  return n;
}

dvector value(const dvector& dv){
  return dv;
}

double sum(const dvector& d){
  dvector ones(1,d.size());
  ones=1;
  return d*ones;
}
double norm(const dvector& d){
  return sqrt(d*d);
}
double norm2(const dvector& d){
  return d*d;
}
dvector elem_prod(const dvector& d1, const dvector& d2){
  int count;
  int l1=d1.size(),l2=d2.size();
#if !defined(_UNCHECKED_)
  if (l1!=l2) {error("bad size in elem_prod(dvector,dvector)");}
#endif
  dvector d(l1);
  for (count=0;count<l1;count++)
    d.ptr[count]=d1.ptr[count]*d2.ptr[count];
  return d;
}
dvector elem_prod(const dvector& d1, const dvector& d2, const dvector& d3){
  int count;
  int l1=d1.size(),l2=d2.size(),l3=d3.size();
#if !defined(_UNCHECKED_)
  if (l1!=l2 || l2!=l3) {error("bad size in elem_prod(dvector,dvector,dvector)");}
#endif
  dvector d(l1);
  for (count=0;count<l1;count++)
    d.ptr[count]=d1.ptr[count]*d2.ptr[count]*d3.ptr[count];
  return d;
}
dvector elem_div(const dvector& d1, const dvector& d2){
  int count;
  int l1=d1.size(),l2=d2.size();
#if !defined(_UNCHECKED_)
  if (l1!=l2) {error("bad size in elem_div(dvector,dvector)");}
#endif
  dvector d(l1);
  for (count=0;count<l1;count++)
    d.ptr[count]=d1.ptr[count]/d2.ptr[count];
  return d;
}
double max(const dvector& d){
  int count;
  double m=d[d.indexmin()];
  if (d.size()>1)
    for (count=d.indexmin()+1;count<=d.indexmax();count++)
      m=fmax(m,d[count]);
  return m;
}
double min(const dvector& d){
  int count;
  double m=d[d.indexmin()];
  if (d.size()>1)
    for (count=d.indexmin()+1;count<=d.indexmax();count++)
      m=fmin(m,d[count]);
  return m;
}
double mean(const dvector& d){
  double m;
  m=sum(d)/d.size();
  return m;
}
double std_dev(const dvector& d){
  double m;
  int n=d.size();
  m=sqrt((norm2(d)-sum(d)*sum(d)/n)/(n-1));
  return m;
}
dvector pow(const dvector& d1, const dvector& d2){
#if !defined(_UNCHECKED_)
  if (d1.sz != d2.sz) error("bad size in pow(dvector,dvector)");
#endif
  dvector n(d1.sz);
  for (int i=0; i<d1.sz; i++){
    n.ptr[i] = pow(d1.ptr[i],d2.ptr[i]);}
  return n;
}
dvector pow(double t, const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = pow(t,d.ptr[i]);}
  return n;
}
dvector pow(const dvector& d, double t){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = pow(d.ptr[i],t);}
  return n;
}
dvector sin(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = sin(d.ptr[i]);
  }
  return n;
}
dvector cos(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = cos(d.ptr[i]);
  }
  return n;
}
dvector tan(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = tan(d.ptr[i]);
  }
  return n;
}
dvector asin(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = asin(d.ptr[i]);
  }
  return n;
}
dvector acos(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = acos(d.ptr[i]);
  }
  return n;
}
dvector atan(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = atan(d.ptr[i]);
  }
  return n;
}
dvector sqrt(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = sqrt(d.ptr[i]);
  }
  return n;
}
dvector exp(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = exp(d.ptr[i]);
  }
  return n;
}
dvector log(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = log(d.ptr[i]);
  }
  return n;
}
dvector log10(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = log10(d.ptr[i]);
  }
  return n;
}
dvector fabs(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = fabs(d.ptr[i]);
  }
  return n;
}
dvector sfabs(const dvector& d){
  return fabs(d);
}
dvector ceil(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = ceil(d.ptr[i]);
  }
  return n;
}
dvector floor(const dvector& d){
  dvector n(d.sz);
  for (int i=0; i<d.sz; i++){
    n.ptr[i] = floor(d.ptr[i]);
  }
  return n;
}

std::istream& operator>>(std::istream& istr, dvector& dv){
  int count;
  double t;
  for (count=dv.indexmin();count<=dv.indexmax();count++){
    istr >> t;
    if (istr) dv[count]=t;
  }
  return istr;
}
std::ostream& operator<<(std::ostream& ostr, const dvector& dv){
  int count;
  for (count=dv.indexmin();count<=dv.indexmax();count++){
    ostr << dv[count] << " ";}
  return ostr;
}

// sorts
int qsortcmp(const void* t1, const void* t2){
  return ((*(double*)t1==*(double*)t2) ? 0 : (*(double*)t1>*(double*)t2 ? 1 : -1));
}
dvector sort(const dvector& d){
  int length=d.size();
  dvector res(length);
  double* t = new double[length];
  int count;
  for (count=0;count<length;count++){
    t[count]=d.ptr[count];}
  qsort(t,length,sizeof(double),&qsortcmp);
  for (count=0;count<length;count++){
    res.ptr[count]=t[count];}
  delete[] t;
  return res;
}
class double_and_int{
  public:
  double t;
  int i;
};
int qsortcmp_di(const void* ti1, const void* ti2){
  double t1=((double_and_int*)ti1)->t;
  double t2=((double_and_int*)ti2)->t;
  return ((t1==t2) ? 0 : (t1>t2 ? 1 : -1));
}
dvector sort(const dvector& d, dvector& indices){
  int length=d.size();
  int first=d.indexmin();
  int count;
  dvector res(length);
  double_and_int* ti = new double_and_int[length];
  for (count=0;count<length;count++){
    ti[count].t=d.ptr[count];
    ti[count].i=count+first;}
  qsort(ti,length,sizeof(double_and_int),&qsortcmp_di);
  for (count=0;count<length;count++){
    res.ptr[count]=ti[count].t;
    indices.ptr[count]=ti[count].i;}
  delete[] ti;
  return res;
}

int chol(const dmatrix& M,dmatrix& L){
  // calculates the choleski decomposition of M and puts the lower triangular part into L
  // returns 1 if successful, 0 else
  // used by fill_mvnorm
  int n = M.rowsize();
  int i, j, k;
#if !defined(_UNCHECKED_)
  if (!(n==M.colsize() && n==L.rowsize() && n==L.colsize())){
    error("Bad size in chol()");}
#endif
  L.initialize();
  for (i=1;i<=n;i++){
    L[i][i]=1;}
  double sum;
  if (M[1][1]<0){
    return(0);
  } else {
    L[1][1] = sqrt(M[1][1]);
    for (i=2;i<=n;i++){
      L[i][1]=M[i][1]/L[1][1];}
    for (i=2;i<n;i++){
      sum = 0;
      for (k=1;k<i;k++){
        sum+=L[i][k]*L[i][k];}
      if (M[i][i] <= sum){
        return(0);
      } else {
        L[i][i] = sqrt(M[i][i]-sum);
        for (j=i+1;j<=n;j++){
          sum = 0;
          for (k=1;k<i;k++){
            sum += L[j][k]*L[i][k];}
          L[j][i] = (M[j][i]-sum)/L[i][i];
        }
      }
    }
    sum = 0;
    for (int k=1;k<n;k++){
      sum+=L[n][k]*L[n][k];}
    if (M[n][n] <= sum)
      return(0);
    L[n][n] = sqrt(M[n][n] - sum);
  }
  return(1);
}

dmatrix::dmatrix(int lbr,int lur,int lbc,int luc){
  rows = lur - lbr + 1;
  cols = luc - lbc + 1;
  firstrow = lbr;
  firstcol = lbc;
  //index = new dvector[rows](firstcol,firstcol+cols-1);
  index.resize(rows,dvector(firstcol,firstcol+cols-1));
}
dmatrix::dmatrix(int lur,int luc){
  rows = lur;
  cols = luc;
  firstrow = 1;
  firstcol = 1;
  //index = new dvector[rows](1,cols);
  index.resize(rows,dvector(1,cols));
}
dmatrix::dmatrix(const dmatrix &dm){
  rows = dm.rows;
  cols = dm.cols;
  firstrow = dm.firstrow;
  firstcol = dm.firstcol;
  //index = new dvector[rows](firstcol,firstcol+cols-1);
  index.resize(rows,dvector(firstcol,firstcol+cols-1));
  for (int i=0; i<rows; i++){
    index[i] = dm.index[i];}
}
dmatrix::dmatrix(char* c, int skip_lines){
// a bit different from the Betadiff version: takes only a single string argument.
// Example usage: dmatrix W("{1 2 3}{4 5 6}{7 8 9}");
// but not dmatrix W("{ 1 2 3}... or dmatrix W("{1 2 3 }...
// ie. watch out for excess spaces.
// note, stray text words in a file come out as 0's
// note again, if skip_lines=x then skip the first few x lines in the file  (header?)
  firstrow = 1;
  firstcol = 1;
  if (c[0]=='{'){ // it's a string
    c++;
    int width=-1,height=1;
    int thisrow=0;
    int count;
    char **u=(char**)malloc(sizeof(char*));
    double **buffer;
    buffer = (double**)malloc(10*sizeof(double*));
    buffer[0] = (double*)malloc(50*sizeof(double));
    int bufcount=0; // the sub-buffer we are about to write to
    int subcount=0; // the position in sub-buffer we are about to write to
    while (c[0]!=0){
      if (c[0]=='{'){
        if (width==-1){
          width=thisrow;
        } else {
          if (thisrow!=width){
            std::cerr << "bad data in mat::mat\n";
            break;
          }
        }
        if (c[1]==0){  // last row
          break;
        }
        c+=1; // pass over the braces
        height++;
        thisrow=0;  // start next row
      }
      else {
        thisrow++;
        if (subcount == 50){
          subcount=0;
          bufcount++;
          if (bufcount%10 == 0){
            buffer=(double**)realloc(buffer,10*bufcount*sizeof(double*));}
          buffer[bufcount]=(double*)malloc(50*sizeof(double));
        }
        buffer[bufcount][subcount]=strtod(c,u);
        c=(*u)+1;
        subcount++;
      }
    }

    rows = height;
    cols = width;
    //index = new dvector[rows](firstcol,firstcol+cols-1);
    index.resize(rows,dvector(firstcol,firstcol+cols-1));


    int count1,count2;
    int ele,row,col;
    ele=0;
    for (count1=0;count1<=bufcount;count1++){
      for (count2=0;count2<50;count2++){
        if (count1==bufcount && count2==subcount) {break;}
        col=ele%cols;
        row=ele/cols;
        ele++;
        (*this)[row+1][col+1]=buffer[count1][count2];
      }
      free(buffer[count1]);
    }
    free(buffer);
  } else { // it's a file
    std::ifstream istr(c);
    if (!istr) {error("bad file in dmatrix::dmatrix(" + std::string(c) + ")");}
    for (int skip=1; skip<=skip_lines; skip++){
      std::string junk;
      getline(istr,junk);
    }
    //istr.unsetf(ios::skipws);//richard
    int width=-1,height=0;
    int thisrow=0;
    char ch;
    int count;
    double **buffer;
    buffer = (double**)malloc(10*sizeof(double*));
    buffer[0] = (double*)malloc(50*sizeof(double));
    int bufcount=0; // the sub-buffer we are about to write to
    int subcount=0; // the position in sub-buffer we are about to write to
    while (1){
      if (subcount == 50){
        subcount=0;
        bufcount++;
        if (bufcount%10 == 0){
          buffer=(double**)realloc(buffer,10*bufcount*sizeof(double*));
        }
        buffer[bufcount]=(double*)malloc(50*sizeof(double));
      }
      if (!istr.good()) {
        break;
      }
      istr >> buffer[bufcount][subcount];
      thisrow++;
      subcount++;
      ch=' ';
      while (ch==' ' && istr.good()){
        istr >> ch;
      }
      if (ch=='0' || ch=='1' || ch=='2' || ch=='3' || ch=='4' || ch=='5' || ch=='6' || ch=='7' || ch=='8' || ch=='9' || ch=='-' || ch=='.') istr.putback(ch);
      height++;
    }
    rows = (int)sqrt((double)height);
    cols = (int)ceil((double)height / (double)rows);

    //index = new dvector[rows](firstcol,firstcol+cols-1);
    index.resize(rows,dvector(firstcol,firstcol+cols-1));

    int count1,count2;
    int ele,row,col;
    ele=0;
    for (count1=0;count1<=bufcount;count1++){
      for (count2=0;count2<50;count2++){
        if (count1==bufcount && count2==subcount) {break;}
        col=ele%cols;
        row=ele/cols;
        ele++;
        (*this)[row+1][col+1]=buffer[count1][count2];
      }
      free(buffer[count1]);
    }
    free(buffer);
  }
}

dmatrix::dmatrix(){
  rows = 1;
  cols = 1;
  firstrow = 1;
  firstcol = 1;
  //index = new dvector[rows](firstcol,firstcol+cols-1);
  index.resize(rows,dvector(firstcol,firstcol+cols-1));
}
dmatrix& dmatrix::operator=(const dmatrix &dm){
#if !defined(_UNCHECKED_)
  if (dm.rows!=rows || dm.cols!=cols){
    error("bad size in dmatrix::operator=(dmatrix)");}
#endif
  int count;
  for (count=0;count<rows;count++){
    index[count]=dm.index[count];}
  return *this;
}
dmatrix& dmatrix::operator=(double t){
  int count;
  for (count=0;count<rows;count++){
    (*this)[count+firstrow]=t;}
  return *this;
}

void dmatrix::initialize(){
  int count;
  for (count=firstrow;count<=firstrow+rows-1;count++){
    (*this)[count]=0.0;}
}

int dmatrix::rowmin() const{
  return firstrow;
}
int dmatrix::rowmax() const{
  return firstrow+rows-1;
}
int dmatrix::colmin() const{
  return firstcol;
}
int dmatrix::colmax() const{
  return firstcol+cols-1;
}
int dmatrix::rowsize() const{
  return rows;
}
int dmatrix::colsize() const{
  return cols;
}
void dmatrix::colshift(int min){
  firstcol=min;
}
void dmatrix::rowshift(int min){
  firstrow=min;
}

dvector& dmatrix::operator[](int i) {
#if !defined(_UNCHECKED_)
  if (i<firstrow || i>(firstrow+rows-1)){
    error("Subscript out of range: dmatrix[int]");}
#endif
  return index[i-firstrow];
}

const dvector& dmatrix::operator[](int i) const{
//return const_cast<const dvector&>(operator[](i));
#if !defined(_UNCHECKED_)
  if (i<firstrow || i>(firstrow+rows-1)){
    error("Subscript out of range: dmatrix[int]");}
#endif
  return index[i-firstrow];
}

dvector& dmatrix::operator[](double t) {
  int i = (int)t;
#if !defined(_UNCHECKED_)
  if (i<firstrow || i>(firstrow+rows-1)){
    error("Subscript out of range: dmatrix[double]");}
#endif
  return index[i-firstrow];
}

const dvector& dmatrix::operator[](double t) const{
  int i = (int)t;
//return const_cast<const dvector&>(operator[](i));
#if !defined(_UNCHECKED_)
  if (i<firstrow || i>(firstrow+rows-1)){
    error("Subscript out of range: dmatrix[double]");}
#endif
  return index[i-firstrow];
}

void dmatrix::rowfill(int i, const dvector& dv){
#if !defined(_UNCHECKED_)
  if (dv.size() != cols){
    error("bad size in dmatrix::rowfill");}
#endif
  (*this)[i]=dv;
}
void dmatrix::colfill(int j, const dvector& dv){
#if !defined(_UNCHECKED_)
  if (dv.size() != rows){
    error("bad size in dmatrix::colfill");}
#endif
  int count;
  for (count=0;count<dv.size();count++){
    (*this)[count+rowmin()][j]=dv.ptr[count];}
}
void dmatrix::rowfill_seqadd(int i, const double base, const double offset){
  dvector dv(cols);
  dv.fill_seqadd(base,offset);
  (*this).rowfill(i,dv);
}
void dmatrix::colfill_seqadd(int j, const double base, const double offset){
  dvector dv(rows);
  dv.fill_seqadd(base,offset);
  (*this).colfill(j,dv);
}
void dmatrix::rowfill_randu(int i, const long int& s){
  dvector dv(cols);
  dv.fill_randu(s);
  (*this).rowfill(i,dv);
}
void dmatrix::colfill_randu(int j, const long int& s){
  dvector dv(rows);
  dv.fill_randu(s);
  (*this).colfill(j,dv);
}
void dmatrix::rowfill_randn(int i, const long int& s){
  dvector dv(cols);
  dv.fill_randn(s);
  (*this).rowfill(i,dv);
}
void dmatrix::colfill_randn(int j, const long int& s){
  dvector dv(rows);
  dv.fill_randn(s);
  (*this).colfill(j,dv);
}
void dmatrix::rowfill_randbi(int i, const long int& s, double t){
  dvector dv(cols);
  dv.fill_randbi(s,t);
  (*this).rowfill(i,dv);
}
void dmatrix::colfill_randbi(int j, const long int& s, double t){
  dvector dv(rows);
  dv.fill_randbi(s,t);
  (*this).colfill(j,dv);
}
void dmatrix::fill_mvnorm(const long int& s, const dvector& mean, const dmatrix& _covar){
  // Found a problem here for the case where some variances (and hence the corresponding
  // rows and columns of covar) are 0. The cholesky decomposition does not work in these
  // cases. I thought of this kludge: Set the 0 variances to 1, leaving the covariances at 0.
  // When finished, set the corresponding deviations from the mean to 0.
  dmatrix covar(_covar);
  int n = covar.rowsize();
#if !defined(_UNCHECKED_)
  if (!(n == covar.colsize() && n == rowsize() && n == mean.size())){
    error("Bad argument to dmatrix::fill_mvnorm");}
#endif
  // set zero variances to 1 as above
  dvector zero_variances(covar.rowmin(),covar.rowmax());
  zero_variances = 0;
  for (int i=covar.rowmin(); i<=covar.rowmax(); i++){
    if (covar[i][i]==0){
      covar[i][i] = 1;
      zero_variances[i] = 1;
    }
  }
  // generate all the standard normal random numbers at once
  dvector all_rands(1,n*colsize());
  all_rands.fill_randn(s);
  // get lower triangular part of choleski decomposition of covar
  dmatrix L(1,n,1,n);
  if (!chol(covar,L)){
    error("Failed choleski decomposition in fill_mvnorm");}
  dvector dv(1,n);
  for (int j=colmin();j<=colmax();j++){
    for (int i=1;i<=n;i++){
      dv[i]=all_rands[(j-colmin())*n+i];}
    dv = L*dv + mean;
    colfill(j,dv);
  }
  // find the elements with 0 variances and set them to their means
  for (int i=covar.rowmin(); i<=covar.rowmax(); i++){
    if (zero_variances[i]){
      (*this)[i] = mean[i];
    }
  }
}
void dmatrix::fill_mvt(const long int& s, const dvector& mean, const dmatrix& _covar, int df){
  // Result is mean + 1/sqrt(y/df) * x,
  // where x ~ multivariate normal(0,_covar)
  // and y ~ chi-square(df).
  // See fill_mvnorm for treatment of zero variances.
  dvector zeros(mean * 0);
  fill_mvnorm(s,zeros,_covar);
  dvector y(colmin(),colmax());
  y.fill_chisq(s,df);
  for (int j=colmin(); j<=colmax(); j++){
    colfill(j,mean + (1/sqrt(y[j]/df)) * extract_column(*this,j));
  }
}

void dmatrix::operator+=(const dmatrix& dm){
#if !defined(_UNCHECKED_)
  if(rows!=dm.rows || cols!=dm.cols){
    error("bad size in dmatrix::operator+=(dmatrix)");}
#endif
  int count;
  for (count=firstrow;count<=firstrow+rows-1;count++){
    (*this)[count]+=dm[count+dm.firstrow-firstrow];}
}
void dmatrix::operator-=(const dmatrix& dm){
#if !defined(_UNCHECKED_)
  if(rows!=dm.rows || cols!=dm.cols){
    error("bad size in dmatrix::operator-=(dmatrix)");}
#endif
  int count;
  for (count=firstrow;count<=firstrow+rows-1;count++){
    (*this)[count]-=dm[count+dm.firstrow-firstrow];}
}
void dmatrix::operator+=(double t){
  dvector dv(cols);
  dv=t;
  int count;
  for (count=rowmin();count<=rowmax();count++){
    (*this)[count]+=dv;}
}
void dmatrix::operator-=(double t){
  dvector dv(cols);
  dv=t;
  int count;
  for (count=rowmin();count<=rowmax();count++){
    (*this)[count]-=dv;}
}
void dmatrix::operator*=(double t){
  int count;
  for (count=rowmin();count<=rowmax();count++){
    (*this)[count]*=t;}
}
void dmatrix::operator/=(double t){
  int count;
  for (count=rowmin();count<=rowmax();count++){
    (*this)[count]/=t;}
}

dmatrix::~dmatrix(){
//  delete[] index;
}

dmatrix operator+(const dmatrix& m1,const dmatrix& m2){
#if !defined(_UNCHECKED_)
  if (m1.rows != m2.rows || m1.cols != m2.cols){
    error("bad size in operator+(dmatrix,dmatrix)");}
#endif
  dmatrix m(m1);
  m+=m2;
  return m;
}
dmatrix operator-(const dmatrix& m1,const dmatrix& m2){
#if !defined(_UNCHECKED_)
  if (m1.rows != m2.rows || m1.cols != m2.cols){
    error("bad size in operator-(dmatrix,dmatrix)");}
#endif
  dmatrix m(m1);
  m-=m2;
  return m;
}
dmatrix operator+(const dmatrix& dm,double t){
  dmatrix m(dm);
  m+=t;
  return m;
}
dmatrix operator+(double t,const dmatrix& dm){
  dmatrix m(dm);
  m+=t;
  return m;
}
dmatrix operator-(const dmatrix& dm,double t){
  dmatrix m(dm);
  m-=t;
  return m;
}
dmatrix operator-(double t,const dmatrix& dm){
  dmatrix m(dm);
  m=-m;
  m+=t;
  return m;
}
dmatrix operator*(const dmatrix& dm,double t){
  dmatrix m(dm);
  m*=t;
  return m;
}
dmatrix operator*(double t,const dmatrix& dm){
  dmatrix m(dm);
  m*=t;
  return m;
}
dmatrix operator-(const dmatrix& dm){
  dmatrix m(dm);
  m*=-1;
  return m;
}
dmatrix elem_div(const dmatrix& m1,const dmatrix& m2){
#if !defined(_UNCHECKED_)
  if (m1.rows != m2.rows || m1.cols != m2.cols){
    error("bad size in elem_div(dmatrix,dmatrix)");}
#endif
  dmatrix m=m1;
  int count;
  int rm=m.rowmin(),rm1=m1.rowmin(),rm2=m2.rowmin();
  for (count=0;count<m.rows;count++){
    m[count+rm]=elem_div(m1[count+rm1],m2[count+rm2]);}
  return m;
}
dmatrix elem_prod(const dmatrix& m1,const dmatrix& m2){
#if !defined(_UNCHECKED_)
  if (m1.rows != m2.rows || m1.cols != m2.cols){
    error("bad size in elem_prod(dmatrix,dmatrix)");}
#endif
  dmatrix m=m1;
  int count;
  int rm=m.rowmin(),rm1=m1.rowmin(),rm2=m2.rowmin();
  for (count=0;count<m.rows;count++){
    m[count+rm]=elem_prod(m1[count+rm1],m2[count+rm2]);}
  return m;
}
dmatrix operator*(const dmatrix& m1,const dmatrix& m2){
  int count,count2;
  int m1r=m1.rows,m2c=m2.cols,m1c=m1.cols,m2r=m2.rows;
  int m1rm=m1.rowmin(),m2cm=m2.colmin();
#if !defined(_UNCHECKED_)
  if (m1c != m2r){
    error("bad size in operator*(dmatrix,dmatrix)");}
#endif
  dmatrix m3(1,m1r,1,m2c);
  dvector this_col(m2r);
  for (count2=0;count2<m2c;count2++){
    this_col = extract_column(m2,count2+m2cm);
    for (count=0;count<m1r;count++){
      m3[count+1][count2+1] = m1[count+m1rm]*this_col;}}  // easier to extract row than col
  return m3;
}
dmatrix operator*(const dvector& v1,const dmatrix& m2){
  int count;
  int v1s=v1.size(),m2c=m2.cols,m2r=m2.rows;
  int v1m=v1.first,m2cm=m2.colmin();
#if !defined(_UNCHECKED_)
  if (v1s != m2r){
    error("bad size in operator*(dvector,dmatrix)");}
#endif
  dmatrix m3(1,1,1,m2c);
  dvector this_col(m2r);
  for (count=0;count<m2c;count++){
    this_col = extract_column(m2,count+m2cm);
    m3[1][count+1] = v1*this_col;}
  return m3;
}
dvector operator*(const dmatrix& m1,const dvector& v2){
  int count;
  int m1r=m1.rows,m1c=m1.cols,v2s=v2.size();
  int m1rm=m1.rowmin(),v2m=v2.first;
#if !defined(_UNCHECKED_)
  if (m1c != v2s){
    error("bad size in operator*(dmatrix,dvector)");}
#endif
  dvector v3(1,m1r);
  for (count=0;count<m1r;count++){
    v3[count+1] = m1[count+m1rm]*v2;}  // easier to extract row than col
  return v3;
}

dmatrix column_vector(dvector& dv){
  dmatrix m(dv.size(),1);
  int count;
  for (count=dv.indexmin();count<=dv.indexmax();count++){
    m[count-dv.indexmin()+1][1]=dv[count];}
  return m;
}
dmatrix row_vector(dvector& dv){
  dmatrix m(1,dv.size());
  int count;
  for (count=dv.indexmin();count<=dv.indexmax();count++){
    m[1][count-dv.indexmin()+1]=dv[count];}
  return m;
}
dvector extract_column(const dmatrix& dm, const int j){
  dvector d(dm.rowmin(),dm.rowmax());
  int count;
  for (count=dm.rowmin();count<=dm.rowmax();count++){
    d[count]=dm[count][j];}
  return d;
}
dvector extract_diagonal(const dmatrix& dm){
#if !defined(_UNCHECKED_)
  if(dm.rows!=dm.cols){
    error("extract_diagonal(dmatrix): matrix not square!");}
#endif
  dvector d(dm.rows);
  int count;
  for (count=0;count<dm.rows;count++){
    d[count+1]=dm[count+dm.rowmin()][count+dm.colmin()];}
  return d;
}
dmatrix sqrt(const dmatrix& dm){
  dmatrix r(dm);
  for (int i=r.rowmin(); i<=r.rowmax(); i++){
    r[i] = sqrt(dm[i]);
  }
  return r;
}
dmatrix log(const dmatrix& dm){
  dmatrix r(dm);
  for (int i=r.rowmin(); i<=r.rowmax(); i++){
    r[i] = log(dm[i]);
  }
  return r;
}
double norm(dmatrix dm){
  double sum=0;
  int count;
  for (count=dm.rowmin();count<=dm.rowmax();count++){
    sum += norm2(dm[count]);}
  return sqrt(sum);
}
double norm2(dmatrix dm){
  double sum=0;
  int count;
  for (count=dm.rowmin();count<=dm.rowmax();count++){
    sum += norm2(dm[count]);}
  return sum;
}
dvector rowsum(dmatrix dm){
  dvector rsum(dm.rowmin(),dm.rowmax());
  int count;
  for (count=dm.rowmin();count<=dm.rowmax();count++){
    rsum[count] = sum(dm[count]);}
  return rsum;
}
dvector colsum(dmatrix dm){
  dvector csum(dm.colmin(),dm.colmax());
  int count;
  for (count=dm.colmin();count<=dm.colmax();count++){
    csum[count] = sum(extract_column(dm,count));}
  return csum;
}
dmatrix identity_matrix(int i,int j){
  dmatrix d(i,j,i,j);
  d.initialize();
  int count;
  for (count=i;count<=j;count++){
    d[count][count]++;}
  return d;
}
dmatrix inverse(const dmatrix& dm){
  // Invert the square matrix argument, which should have rows and columns starting from 1.
  // See also the differentiable version.
  //
  // This was written for inverting a Hessian to get an approximate covariance matrix.
  // Sometimes the Hessian can have a zero row and corresponding zero column, when a
  // parameter has no effect on the objective function (perhaps because it is not allowed
  // to vary). In this case the matrix is less than full rank and not invertible.
  // We kludge this by temporarily setting the relevant diagonal element to 1, going ahead
  // and doing the inverse, and setting the corresponding row and column of the result to 0.
  // The result is not strictly an inverse - the product A*inv(A) will have zeros
  // in the corresponding diagonal elements rather than ones - but will do for the purpose at hand.
  //
  // The algorithm used for the inverse is Gauss-Jordan, from Numerical Recipes in C, section 2.1.
  //  We could do better, see other algorithms in the same reference.
  dmatrix a(dm);
  int n = a.rowsize();
  dmatrix b(identity_matrix(1,n));
#if !defined(_UNCHECKED_)
  if (a.rowmin() != 1 || a.colmin() != 1 || a.rowsize() != a.colsize()){
    std::cerr << a << '\n'; error("Bad matrix in inverse");
  }
#endif
  // go through, find zero rows (with corresponding zero columns)
  // set the corresponding diagonal elements equal to 1 -
  // we will zero the corresponding rows and columns of the inverse at the end.
  dvector zero_rows(1,n);
  zero_rows = 0;
  for (int i=1; i<=n; i++){
    if (max(fabs(a[i]))==0.0 && max(fabs(extract_column(a,i)))==0.0){
      zero_rows[i] = 1;
      a[i][i] = 1;
    }
  }
  // invert a (store the result in a)
  // this is equivalent to solving a * a_inverse = b.
  dvector indxc(1,n);
  dvector indxr(1,n);
  dvector ipiv(1,n);
  ipiv = 0;
  double big, dum, pivinv, temp;
  int icol=0, irow=0;
  for (int i=1; i<=n; i++){
    big = 0;
    for (int j=1; j<=n; j++){
      if (ipiv[j] != 1){
        for (int k=1; k<=n; k++){
          if (ipiv[k] == 0){
            if (fabs(a[j][k]) >= big){
              big = fabs(a[j][k]);
              irow = j;
              icol = k;
            }
          } else {
            if (ipiv[k] > 1){
              error("Singular matrix in inverse");
            }
          }
        }
      }
    }
    ipiv[icol]++;
    if (irow != icol){
      for (int l=1; l<=n; l++){
        temp = a[irow][l];
        a[irow][l] = a[icol][l];
        a[icol][l] = temp;
        temp = b[irow][l];
        a[irow][l] = b[icol][l];
        b[icol][l] = temp;
      }
    }
    indxr[i] = irow;
    indxc[i] = icol;
    if (a[icol][icol]==0){
      error("Singular matrix in inverse");
    }
    pivinv = 1.0/a[icol][icol];
    a[icol][icol] = 1;
    for (int l=1; l<=n; l++){
      a[icol][l] *= pivinv;
      b[icol][l] *= pivinv;
    }
    for (int ll=1; ll<=n; ll++){
      if (ll != icol){
        dum = a[ll][icol];
        a[ll][icol] = 0;
        for (int l=1; l<=n; l++){
          a[ll][l] -= a[icol][l] * dum;
          b[ll][l] -= b[icol][l] * dum;
        }
      }
    }
  }
  for (int l=n; l>=1; l--){
    if (indxr[l] != indxc[l]){
      for (int k=1; k<=n; k++){
        temp = a[k][indxr[l]];
        a[k][indxr[l]] = a[k][indxc[l]];
        a[k][indxc[l]] = temp;
      }
    }
  }
  // zero the rows and columns corresponding to zero rows and columns in the original matrix.
  dvector zeros(1,n);
  zeros = 0;
  for (int i=1; i<=n; i++){
    if (zero_rows[i]){
      a[i] = zeros;
      a.colfill(i,zeros);
    }
  }
  return a;
}

std::ostream& operator<<(std::ostream& ostr, const dmatrix& dm){
  int count;
  for (count=dm.rowmin();count<=dm.rowmax();count++){
    ostr << dm[count];
    if (count<dm.rowmax()){
      ostr << "\n";}}
  return ostr;
}
std::istream& operator>>(std::istream& istr, dmatrix& dm){
  int count,count2;
  double t;
  for (count=dm.rowmin();count<=dm.rowmax();count++){
    for (count2=dm.colmin();count2<=dm.colmax();count2++){
      istr >> t;
      if (istr) dm[count][count2]=t;
    }
  }
  return istr;
}

 dmatrix sort(const dmatrix& d,int sorton){
  dvector sortcol=extract_column(d,sorton);
  dvector indices(1,d.rowsize());
  sort(sortcol,indices);  // returns nothing but changes indices
  dmatrix res(d.rowsize(),d.colsize());
  int count;
  for (count=1;count<=d.rowsize();count++){
    res[count]=d[(int)indices[count]];}
  return res;
}

void RNG_reset(long seed){
  // go back to the start of the random number sequence generated from 'seed'
  // You should only need to use this when you want to generate the same
  //  sequence of random numbers multiple times within one program.
  double newseed=double(abs(seed+1))/RNG_LONGMAX;
  newseed=newseed-floor(newseed);
  Random::Set(newseed);
  betadiff_seed = false;
}

extern int am_taping,loc_ptr,op_ptr,real_ptr;
void ADOLC_storage(char* output){
  std::cerr << output << ": ";//richard test
  //if (am_taping) std::cerr << loc_ptr * sizeof(locint) + op_ptr * sizeof(unsigned char) + real_ptr * sizeof(double) << '\n';
  //else std::cerr << "not in active segment\n";
}

 dmatrix covariance_to_correlation(const dmatrix& cov){
   double diag;
   dmatrix cor = cov;
   int n = cov.rowsize();
  for (int i=1;i<=n;i++){
    diag = cov[i][i];
    for (int j=1;j<=n;j++){
      cor[i][j] = cor[i][j]/sqrt(diag);
      cor[j][i] = cor[j][i]/sqrt(diag);
    }
  }
  return(cor);
}

int bb_function(short int tag,int n,dvv& x,double& y){
  // A handle for ADOL-C's function, but using a dvv and double as the final two arguments
  // and requires a scalar function value
  double* adolx = new double[n];
  double* adoly = new double[1];
  int status;
  int count;
  for (count=0;count<x.size();count++){
    adolx[count]=value(x[count+x.indexmin()]);
    if (!(adolx[count]==adolx[count])){error("NaN passed to bb_function - aborting");}
  }
  status=function(tag,1,n,adolx,adoly);
  y=adoly[0];
  delete[] adolx;
  delete[] adoly;
  return status;
}
int bb_gradient(short int tag,int n,dvv& x,dvector& g){
  // A handle for ADOL-C's function, but using dvv and dvector as the final two arguments
  double* adolx = new double[n];
  double* adolg = new double[n];
  int status;
  int count;
  for (count=0;count<x.size();count++){
    adolx[count]=value(x[count+x.indexmin()]);}
  status=gradient(tag,n,adolx,adolg);
  for (count=0;count<x.size();count++){
    g[count+g.indexmin()]=adolg[count];}
  delete[] adolg;
  delete[] adolx;
  return status;
}
int bb_hessian(short int tag,int n,dvv& x,dmatrix& h){
  // A handle for ADOL-C's function, but using dvv and dmatrix as the final two arguments.
  // Fills in the Hessian matrix into h.
  // This function is currently dysfunctional. Sometimes it returns NaN values, sometimes
  // values of the wrong sign. I don't know why. Use instead the Hessian approximation produced
  // by the fmm minimiser (which the optimise() functions will extract for you) - they tend
  // to be pretty accurate.
  double* adolx = new double[n];
  double** adolh = new double*[n];
  int status;
  int count;
  for (count=0;count<n;count++){
    adolh[count] = new double[n];}
  for (count=0;count<x.size();count++){
    adolx[count]=value(x[count+x.indexmin()]);}
  status=hessian(tag,n,adolx,adolh);
  int count2;
  for (count=0;count<n;count++){
    for (count2=count;count2<n;count2++){
      h[count+h.rowmin()][count2+h.colmin()] = adolh[count2][count];
      h[count2+h.rowmin()][count+h.colmin()] = adolh[count2][count];}}
  delete[] adolx;
  for (count=0;count<n;count++){
    delete[] adolh[count];}
  delete[] adolh;
  return status;
}

dvariable boundp(const dvariable& xx, double fmin, double fmax, dvariable& fpen){
  // courtesy of AUTODIF - modified to correct error -
  // penalty on values outside [-1,1] multiplied by 100 as of 14/1/02.
  dvariable t,y;
  t = fmin+(fmax-fmin)*(sin(xx*1.57079633)+1)/2;
  condassign(y.x,-.9999-xx.x,(xx.x+.9999)*(xx.x+.9999),0);
  fpen+=y;
  condassign(y.x,xx.x-.9999,(xx.x-.9999)*(xx.x-.9999),0);
  fpen+=y;
  condassign(y.x,-1-xx.x,1e5*(xx.x+1)*(xx.x+1),0);
  fpen+=y;
  condassign(y.x,xx.x-1,1e5*(xx.x-1)*(xx.x-1),0);
  fpen+=y;
  return(t);
}
double boundpin(double y, double fmin, double fmax){
  if (y == fmin){
    return -1;
  } else if (y == fmax){
    return 1;
  } else return asin(2*(y-fmin)/(fmax-fmin)-1)/1.57079633;
}

fmm::fmm(int n){
  nvar=n;
  x=new double[n];
  g=new double[n];
  p=new double[n];
  pp=new double[n];
  L=new double*[n];
  temp=new double[n];
  int count,count2;
  for (count=0; count<n; count++){
    L[count]=new double[n];}
  xplus=new double[n];
  xlast=new double[n];
  xgood=new double[n];
  glast=new double[n];
  maxfn=300;
  maxit=200;
  imax=200;
  iprint=0;  // default: no print
  ireturn=2; // i.e. not called yet
  iters=0; evals=1;
  // this next bit allegedly calculates machine epsilon
  eps=1;
  do{
    eps=eps/2;}
  while((1+eps)!=1);
  eps=2*eps;
  // grad_tol=pow(eps,1./3.); much too small for our problems
  grad_tol = 0.0025;
  step_tol=pow(eps,2./3.);
  alpha=0.0001;
  maxstep=1000;
  for (count=0;count<nvar;count++){
    xlast[count]=-999;}  // arbitrary value to be not equal to the initial x
  maxtaken=0;
  reinitialized = 0;
}
fmm::~fmm(){
  delete[] x;
  delete[] g;
  int count;
  for (count=0; count<nvar; count++){
    delete[] L[count];}
  delete[] L;
  delete[] xplus;
  delete[] xlast;
  delete[] glast;
  delete[] xgood;
  delete[] p;
  delete[] pp;
  delete[] temp;
}
void fmm::fmin(dvv& xvec, double& func, dvector& gvec){

  if (ireturn==0){   // bringing a function call for the linear search

    evals++;
    if (evals>maxfn){  // have exceeded maximum no. of function evaluations
      ireturn=-2;
      std::cerr << "fmm: too many function evaluations\n";
      xvec = x; // go back to the last accepted point
      return;}

    iters_this_lnsrch++;
    if (iters_this_lnsrch>imax){  //  have exceeded maximum no. of loops in this linear search
      ireturn=-3;
      std::cerr << "fmm: too many loops in this linear search\n";
      xvec = x; // go back to the last accepted point
      return;}

    // transfer new function value into fplus
    fplus=func;

    // proceed with a lnsrch step

    if (fplus<=(f+alpha*lambda*initslope)){ // this point is acceptable
      for (count=0;count<nvar;count++){
        xlast[count]=x[count];    // keep for checking convergence
      }
      if (lambda>=1 && newtlen>0.99*maxstep){
        maxtaken=1;}
      ireturn=1;
      return;
    }

    if (lambda<lambdamin){  // stepsize is too small
      ireturn=-3;
      std::cerr << "fmm: Linear search stepsize is too small.\n";
      return;
    }

    // another line search step
    if (lambda==1){
      lambdatemp=-initslope/(2*(fplus-f-initslope));
    } else{
      a=(1/(lambda-lambdaprev))*((1/(pow(lambda,2)))*(fplus-f-lambda*initslope)+(-1/pow(lambdaprev,2))*(fplusprev-f-lambdaprev*initslope));
      b=(1/(lambda-lambdaprev))*((-lambdaprev/(pow(lambda,2)))*(fplus-f-lambda*initslope)+(lambda/pow(lambdaprev,2))*(fplusprev-f-lambdaprev*initslope));
      disc=b*b-3*a*initslope;
      if (a==0){
        lambdatemp=-initslope/(2*b);
      } else {
        lambdatemp=(-b+sqrt(disc))/(3*a);
      }
    }
    lambdaprev=lambda;
    fplusprev=fplus;
    lambda=fmax(0.1*lambda,lambdatemp);
    // std::cerr << "lambda = " << lambda << "\n";

    for (count=0;count<nvar;count++){
      xplus[count]=x[count]+lambda*p[count];
      xvec[count+xvec.indexmin()]=xplus[count]; // copy back to calling program
    }
    return;
  }

  if (ireturn>=1){   // bringing a gradient for the quasi-Newton step
    iters++;
    if (iters==1){  // set up the initial approximation to the Hessian
      for (count=0;count<nvar;count++){
        for (count2=0;count2<nvar;count2++){
          L[count][count2]=0;}
        if (func>1 || func < -1){
          L[count][count]=sqrt(fabs(func));
        } else {
          L[count][count]=1;
        }
      }
    }

    if (iters>maxit){  // have exceeded maximum no. of iterations
      ireturn=-2;
      std::cerr << "fmm: too many quasi-Newton iterations\n";
      return;}

    if (iprint>0){
      if (iters%iprint==0){
        std::cerr << "fmm: Iteration " << iters << "\nFunction value " << func << "\nCurrent parameter estimates " << xvec << '\n';}}

    // transfer xvec into x, func into f, gvec into g.
    for (count=0;count<nvar;count++){
      x[count]=value(xvec[xvec.indexmin()+count]);}
    f=func;
    for (count=0;count<nvar;count++){
      glast[count]=g[count];
      g[count]=gvec[gvec.indexmin()+count];}

    // proceed with quasi-Newton step

    if (maxtaken==1){
      consecmax++;
      if (consecmax==5){
        std::cerr << "fmm: The maximum Newton step has been taken 5 times in a row, see D&S p 348\n";
        ireturn=-3;
        return;}
    } else {
      consecmax=0;
    }

    // grad_tol check

    t=0;
    for (count=0;count<nvar;count++){
      t=fmax(t,fabs(g[count])*fmax(1,fabs(x[count])) / fabs(f));} // was xplus not x
    std::cerr << "Convergence check: current value is " << t << " and threshold is " << grad_tol << '\n';
    if (t<=grad_tol){
      ireturn=-1; // convergence!
      std::cerr << "fmm: have converged: t = " << t << " f = " << f << "\nx = ";
      for (count=0;count<nvar;count++){
        std::cerr << x[count] << ' ';
      }
      std::cerr << "\ng = ";
      for (count=0;count<nvar;count++){
        std::cerr << g[count] << ' ';
      }
      std::cerr << '\n';
      return;
    }

    if (iters>1){
      // step_tol check
      t=0;
      for (count=0;count<nvar;count++){
        t=fmax(t, fabs(x[count]-xlast[count]) / fmax(fabs(x[count]),1) );}
      if (t<=step_tol){
        std::cerr << "fmm: step size too small. Indicates successful convergence (though this is not the textbook ideal convergence situation)\n";
        ireturn=-1;
        return;
      }

      // and update BFGS Hessian approximation
      bfgsfac(nvar,x,xlast,g,glast,eps,eps,L); // second eps is value of nu. not sure whether appropriate or not
    }

    // work out descent direction (using D&S's cholsolve) and put in p

    cholsolve(nvar,g,L,p);
    for (count=0;count<nvar;count++){
      p[count]=-p[count];}

    // done: a linear search will be next

    ireturn=0;
    iters_this_lnsrch=0;

    good=0;
    maxtaken=0;
    newtlen=0;
    for (count=0;count<nvar;count++){
      newtlen+=p[count]*p[count];}
    newtlen=sqrt(newtlen);

    if (newtlen > maxstep){
      for (count=0;count<nvar;count++){
        p[count]*=maxstep/newtlen;}
      newtlen=maxstep;}

    initslope=0;
    for (count=0;count<nvar;count++){
      initslope+=g[count]*p[count];}

    rellength=0;
    for (count=0;count<nvar;count++){
      temp[count]=fabs(p[count])/fmax(fabs(x[count]),1);
      rellength=fmax(rellength,temp[count]);}
    lambdamin=step_tol*rellength;
    lambda=1;
    // std::cerr << "lambda = 1\n";
    for (count=0;count<nvar;count++){
      xplus[count]=x[count]+lambda*p[count];
      xvec[count+xvec.indexmin()]=xplus[count]; // pass back to calling program
    }

    return;}
}

void bfgsfac(int nvar,double* x,double* xlast,double* g,double* glast,double eps,double nu,double **M){
  // Used by the fmm minimiser.
  // only the lower triangle of L comes out correct; the upper triangle is used for storage. Makes
  // me a bit uncomfortable but I don't think the upper triangle gets used by any of my other functions.

  double *s,*y,*t,*u;
  s = new double[nvar];
  y = new double[nvar];
  t = new double[nvar];
  u = new double[nvar];
  int count,count2,skipupdate;
  double temp1,temp2,temp3,alpha;

  temp1=0;
  temp2=0;
  temp3=0;
  for (count=0;count<nvar;count++){
    s[count]=x[count]-xlast[count];
    y[count]=g[count]-glast[count];
    temp1+=s[count]*y[count];
    temp2+=pow(s[count],2);
    temp3+=pow(y[count],2);
  }
  temp2=sqrt(temp2);
  temp3=sqrt(temp3);
  if (temp1 >= (sqrt(eps)*temp2*temp3)){
    temp2=0;
    for (count=0;count<nvar;count++){
      t[count]=0;
      for (count2=count;count2<nvar;count2++){
        t[count]+=M[count2][count]*s[count2];}
      temp2 += t[count]*t[count];
    }
    alpha=sqrt(temp1/temp2);

    skipupdate=1;
    for (count=0;count<nvar;count++){
      temp3=0;
      for (count2=0;count2<=count;count2++){
        temp3+=M[count][count2]*t[count2];}
      if (fabs(y[count]-temp3)>=(nu*fmax(fabs(g[count]),fabs(glast[count])))){
        skipupdate=0;}
      u[count]=y[count]-alpha*temp3;
    }
    if (!skipupdate){
      temp3=1/sqrt(temp1*temp2);
      for (count=0;count<nvar;count++){
        t[count]*=temp3;}
      for (count=1;count<nvar;count++){
        for (count2=0;count2<count;count2++){
          M[count2][count]=M[count][count2];}
      }
      qrupdate(nvar,t,u,M);
      for (count=1;count<nvar;count++){
        for (count2=0;count2<count;count2++){
          M[count][count2]=M[count2][count];}
      }
    }
  }
  delete[] s;
  delete[] y;
  delete[] t;
  delete[] u;
}

void qrupdate(int nvar, double* u, double* v, double** M){
  // Used by the fmm minimiser.
  // note qrupdate is called with u=t, v=u...!
  int count,k;

  for (count=1;count<nvar;count++){
    M[count][count-1]=0;}

  k=nvar-1;
  while (u[k]==0 && k>0){
    k--;}

  for (count=k-1;count>=0;count--){
    jacrotate(nvar,count,u[count],-u[count+1],M);
    if (u[count]==0){
      u[count]=fabs(u[count+1]);
    } else {
      u[count]=sqrt(pow(u[count],2)+pow(u[count+1],2));
    }
  }

  for (count=0;count<nvar;count++){
    M[0][count]+=u[0]*v[count];}

  for (count=0;count<k;count++){
    jacrotate(nvar,count,M[count][count],-M[count+1][count],M);}
}

void jacrotate(int nvar,int i,double a,double b,double** M){
  // Used by the fmm minimiser.
  double c,s,w,y,den;
  int count;

  if (a==0){
    c=0;
    if (b>0){
      s=1;
    } else {
      s=-1;
    }
  } else {
    den = sqrt(a*a+b*b);
    c=a/den;
    s=b/den;
  }

  for (count=i;count<nvar;count++){
    y=M[i][count];
    w=M[i+1][count];
    M[i][count]=c*y-s*w;
    M[i+1][count]=s*y+c*w;
  }
}

void cholsolve(int nvar,double* g,double** L,double* p){
  // Used by the fmm minimiser.

  double *y;
  y=new double[nvar];
  int count,count2;
  double temp;

  y[0]=g[0]/L[0][0];
  for (count=1;count<nvar;count++){
    temp=0;
    for (count2=0;count2<count;count2++){
      temp+=L[count][count2]*y[count2];}
    y[count]=(g[count]-temp)/L[count][count];
  }

  p[nvar-1]=y[nvar-1]/L[nvar-1][nvar-1];
  for (count=nvar-2;count>=0;count--){
    temp=0;
    for (count2=count+1;count2<nvar;count2++){
      temp+=L[count2][count]*p[count2];}
    p[count]=(y[count]-temp)/L[count][count];
  }

  delete[] y;
}

extern locint next_loc(int);
adoublev::adoublev(char *s){
  // This is the guts of dvv::dvv(char *s).
  // It works basically the same as dvector::dvector(char *s).
  //
  // is s a filename or a set of values?
  if (s[0]=='{'){
    // it's a set of values
    s++;
    char **u=(char**)malloc(sizeof(char*));
    double **buffer;
    buffer = (double**)malloc(10*sizeof(double*));
    buffer[0] = (double*)malloc(50*sizeof(double));
    int bufcount=0; // the sub-buffer we are about to write to
    int subcount=0; // the position in sub-buffer we are about to write to
    while (s[0]){
      if (subcount == 50){
        subcount=0;
        bufcount++;
        if (bufcount%10 == 0){
          buffer=(double**)realloc(buffer,10*bufcount*sizeof(double*));
        }
        buffer[bufcount]=(double*)malloc(50*sizeof(double));
      }
      buffer[bufcount][subcount]=strtod(s,u);
      s=(*u)+1;
      subcount++;
    }

    size=bufcount*50+subcount;
    start_loc = next_loc(size);

    int count1,count2;
    for (count1=0;count1<=bufcount;count1++){
      for (count2=0;count2<50;count2++){
        if (count1==bufcount && count2==subcount) break;
        (*this)[count1*50+count2]=buffer[count1][count2];
      }
      free(buffer[count1]);
    }
    free(buffer);
    free(u);
  }
  else{
    // it's a file
    std::ifstream istr(s);
    if (!istr) {error("bad file in dvv::dvv(" + std::string(s) + ")");}
    double **buffer;
    buffer = (double**)malloc(10*sizeof(double*));
    buffer[0] = (double*)malloc(50*sizeof(double));
    int bufcount=0; // the sub-buffer we are about to write to
    int subcount=0; // the position in sub-buffer we are about to write to
    while (1){
      if (subcount == 50){
        subcount=0;
        bufcount++;
        if (bufcount%10 == 0){
          buffer=(double**)realloc(buffer,10*bufcount*sizeof(double*));
        }
        buffer[bufcount]=(double*)malloc(50*sizeof(double));
      }
      if (!GOOD(istr >> buffer[bufcount][subcount])){
        break;}
      subcount++;
    }

    size=bufcount*50+subcount;
    start_loc = next_loc(size);

    int count1,count2;
    for (count1=0;count1<=bufcount;count1++){
      for (count2=0;count2<50;count2++){
        if (count1==bufcount && count2==subcount) break;
        (*this)[count1*50+count2]=buffer[count1][count2];
      }
      free(buffer[count1]);
    }
    free(buffer);
  }
}

// One can speed up Betadiff a bit by adding these member functions to the ADOL-C active
// variable classes 'badouble' and 'asub'. Users should never need to use them directly.
badouble& badouble::operator = (const dvariable& a){(*this)=a.x; return (*this);}
badouble& badouble::operator += (const dvariable& a){(*this)+=a.x; return (*this);}
badouble& badouble::operator -= (const dvariable& a){(*this)-=a.x; return (*this);}
badouble& badouble::operator *= (const dvariable& a){(*this)*=a.x; return (*this);}
badouble& badouble::operator /= (const dvariable& a){(*this)/=a.x; return (*this);}
asub& asub::operator = (const dvariable& d){(*this)=d.x; return *this;}
asub& asub::operator += (const dvariable& d){(*this)+=d.x; return *this;}
asub& asub::operator -= (const dvariable& d){(*this)-=d.x; return *this;}
asub& asub::operator *= (const dvariable& d){(*this)*=d.x; return *this;}
asub& asub::operator /= (const dvariable& d){(*this)/=d.x; return *this;}
