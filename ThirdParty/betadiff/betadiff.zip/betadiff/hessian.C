// const char* time_stamp = "$Date: 2006-08-08 15:18:31 +1200 (Tue, 08 Aug 2006) $\n";

#include "betadiff.h"

dvariable func(dvector& constants,dvv& x){

  dvariable y = (constants[1]*x[1]*x[1] + constants[2]*x[1] + constants[3])
              * (constants[4]*x[2]*x[2] + constants[5]*x[2] + constants[6]);
  return(y);
}

dmatrix analytical_hessian(dvector& constants,dvector loc,
                 dvector& lower_bounds,dvector& upper_bounds,
                 int untransformed_hessian=0){
  int n = loc.size();
  dmatrix H(1,n,1,n);
  // will depend on func

  double a = constants[1]; double b = constants[2]; double c = constants[3];
  double d = constants[4]; double e = constants[5]; double f = constants[6];
  double x1 = loc[1]; double x2 = loc[2];
  H[1][1] = 2*a*d*x2*x2 + 2*a*e*x2 + 2*a*f;
  H[1][2] = H[2][1] = 4*a*d*x1*x2 + 2*b*d*x2 + 2*a*e*x1 + b*e;
  H[2][2] = 2*a*d*x1*x1 + 2*b*d*x1 + 2*c*d;
  if (!untransformed_hessian){
   // now convert the hessian of the boundp'd loc
   dvv loc_unbounded(1,n);
   for (int count=1;count<=n;count++){
    loc_unbounded[count]=boundpin(loc[count],lower_bounds[count],upper_bounds[count]);}
   dvector grad_boundpin = elem_prod((upper_bounds-lower_bounds)*1.57079633/2,
                                     cos(value(loc_unbounded)*1.57079633));
   for (int i=1;i<=n;i++){
    for (int j=1;j<=n;j++){
       H[i][j] *= grad_boundpin[i];
       H[j][i] *= grad_boundpin[i];
    }
   }
  }
  return(H);
}

template<class M,class F> dmatrix finite_diff_hessian(M& model,F objective,dvector& loc,
                                       dvector& lower_bounds,dvector& upper_bounds,
                                       int untransformed_hessian=0){
// algorithm of vcov.nlminb in S+ library MASS
// applicable only at the mode
 int n = loc.size();
 double eps = 1e-5;
 if (!untransformed_hessian){
  // return the hessian on the scale of the bounded variables
  dvariable zpen;
  dvv x(1,n);
  dvv y(1,n), y_unbounded(1,n);
  for (int count=1;count<=n;count++){
   x[count]=boundpin(loc[count],lower_bounds[count],upper_bounds[count]);}
  y = x;
  for (int count=1;count<=n;count++){
   y_unbounded[count]=boundp(y[count],lower_bounds[count],upper_bounds[count],zpen);}
  double f;
  f = value(objective(model,y_unbounded));
  dvector h(1,n);
  for (int i=1;i<=n;i++){
   y = x;
   y[i] += eps;
   for (int count=1;count<=n;count++){
     y_unbounded[count]=boundp(y[count],lower_bounds[count],upper_bounds[count],zpen);}
   h[i] = value(objective(model,y_unbounded)) - f;
  }
  dmatrix H(1,n,1,n);
  double fij;
  dvv yij(1,n), yij_unbounded(1,n);
  for (int i=2;i<=n;i++){
    for (int j=1;j<i;j++){
      yij = x;
      yij[i] += eps;
      yij[j] += eps;
      for (int count=1;count<=n;count++){
        yij_unbounded[count]=boundp(yij[count],lower_bounds[count],upper_bounds[count],zpen);}
      fij = value(objective(model,yij_unbounded));
      H[i][j] = H[j][i] = (fij - f - h[i] - h[j])/(eps*eps);
    }
  }
  for (int i=1;i<=n;i++){
    H[i][i] = 2*h[i]/(eps*eps);
  }
  return(H);
 } else {
  // return the hessian on the scale of the original variables
  dvv y = loc;
  double f;
  f = value(objective(model,y));
  dvector h(1,n);
  for (int i=1;i<=n;i++){
   y = loc;
   y[i] += eps;
   h[i] = value(objective(model,y)) - f;
  }
  dmatrix H(1,n,1,n);
  double fij;
  dvv yij(1,n);
  for (int i=2;i<=n;i++){
    for (int j=1;j<i;j++){
      yij = loc;
      yij[i] += eps;
      yij[j] += eps;
      fij = value(objective(model,yij));
      H[i][j] = H[j][i] = (fij - f - h[i] - h[j])/(eps*eps);
    }
  }
  for (int i=1;i<=n;i++){
    H[i][i] = 2*h[i]/(eps*eps);
  }
  return(H);
 }
}

main(){

 dvector consts="{1,2,3,2,3,4}";
 dvector x = "{1,1}";
 dvector lbd("{-1000,-1000}");
 dvector ubd("{1000,1000}");
 double minimum;
 int n = x.size();

 cout << "Hessians on scale of transformed variables:\n";
 dmatrix adolc_hessian(1,n,1,n);
 dmatrix optim_hessian(1,n,1,n);
 int conv=0;
 int maxit=50, maxfn=200;
 minimum = optimise(consts,func,x,lbd,ubd,conv,0,maxit,maxfn,2e-3,0,&optim_hessian,&adolc_hessian);
 cout << "Optimiser approximation to Hessian: \n" << optim_hessian << "\n";
 cout << "ADOL-C automatic differentiation Hessian: \n" << adolc_hessian << "\n";

 dmatrix exact_hessian = analytical_hessian(consts,x,lbd,ubd);
 cout << "Analytical Hessian: \n" << exact_hessian << "\n";

 dmatrix fdiff_hessian(1,n,1,n);
 fdiff_hessian = finite_diff_hessian(consts,func,x,lbd,ubd);
 cout << "Finite difference Hessian: \n" << fdiff_hessian << "\n";
 // the above is applicable only at the mode!

 cout << "Hessians on original scale:\n";
 x[1]=1; x[2]=1;
 int conv2=0, maxit2=50, maxfn2=200;
 minimum = optimise(consts,func,x,lbd,ubd,conv2,10,maxit2,maxfn2,2e-3,0,&optim_hessian,&adolc_hessian,1);
 cout << "Optimiser approximation to Hessian: \n" << optim_hessian << "\n";
 cout << "ADOL-C automatic differentiation Hessian: \n" << adolc_hessian << "\n";

 exact_hessian = analytical_hessian(consts,x,lbd,ubd,1);
 cout << "Analytical Hessian: \n" << exact_hessian << "\n";

 fdiff_hessian = finite_diff_hessian(consts,func,x,lbd,ubd,1);
 cout << "Finite difference Hessian: \n" << fdiff_hessian << "\n";
 // the above is applicable only at the mode!

 cout << "Correlation matrices:\n";
 optim_hessian = covariance_to_correlation(optim_hessian);
 adolc_hessian = covariance_to_correlation(adolc_hessian);
 exact_hessian = covariance_to_correlation(exact_hessian);
 fdiff_hessian = covariance_to_correlation(fdiff_hessian);
 cout << "Optimiser approximation: \n" << optim_hessian << "\n";
 cout << "ADOL-C automatic differentiation: \n" << adolc_hessian << "\n";
 cout << "Analytical: \n" << exact_hessian << "\n";
 cout << "Finite difference: \n" << fdiff_hessian << "\n";


}





