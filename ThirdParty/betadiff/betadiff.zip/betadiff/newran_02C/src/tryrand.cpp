#define WANT_STREAM
#define WANT_TIME

#include "include.h"
#include "newran.h"
#include "tryrand.h"
#include <iomanip>

#ifdef use_namespace
using namespace NEWRAN;
#endif

int main()
{
   time_lapse tl;      // measure program run time

   Random::Set(0.46875);

   Real* s1; Real* s2; Real* s3; Real* s4;
   std::cout << "\nBegin test\n";   // Forces cout to allocate memory at beginning
   std::cout << "Now print a real number: " << 3.14159265 << std::endl;
   { s1 = new Real[8000]; delete [] s1; }
   { s3 = new Real; delete s3;}
   {

      Real* A = new Real[3750];

      long n = 200000;
      long n_large = 1000000;

      test1(n);
      test2(n);
      test3(n_large);
      test4(n);
      test5(n_large);


      std::cout << "\nEnd of tests\n";

      delete [] A;
   }

   { s2 = new Real[8000]; delete [] s2; }
   std::cout << "\n(The following memory checks are probably not valid with all\n";
   std::cout << "compilers - see documentation)\n";
   std::cout << "\nChecking for lost memory: "
      << (unsigned long)s1 << " " << (unsigned long)s2 << " ";
   if (s1 != s2) std::cout << " - error\n"; else std::cout << " - ok\n\n";
   { s4 = new Real; delete s4;}
   std::cout << "\nChecking for lost memory: "
      << (unsigned long)s3 << " " << (unsigned long)s4 << " ";
   if (s3 != s4) std::cout << " - error\n"; else std::cout << " - ok\n\n";

   return 0;
}

//************** elapsed time class ****************

time_lapse::time_lapse()
{
   start_time = ((double)clock())/(double)CLOCKS_PER_SEC;
}

time_lapse::~time_lapse()
{
   double time = ((double)clock())/(double)CLOCKS_PER_SEC - start_time;
   std::cout << "Elapsed (processor) time = " << time << " seconds" << std::endl;
   std::cout << std::endl;
}




