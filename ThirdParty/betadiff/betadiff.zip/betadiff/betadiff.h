// const char* time_stamp = "$Date: 2008-04-29 13:53:33 +1200 (Tue, 29 Apr 2008) $\n";

#if !defined(BETADIFF)
#define BETADIFF
// static const char* betadiff_header_id = "$Id: betadiff.h 1889 2008-04-29 01:53:33Z adunn $\n";
// extern const char* betadiff_id;

/* Betadiff: Brian Bull 15/5/02.

This program is an attempt to emulate early 90's versions of AUTODIF (pre arrays of dimension >2)
but with greater ease of use - in particular without having to do 'gradient_structure' and
'return_arrays' calls, and with a more convenient interface to the minimiser.

The automatic differentiation part of Betadiff is based on a program called ADOL-C v1.8.4,
subtitled "A package for automatic differentiation of algorithms written in C/C++",
which is made by a team including Andreas Griewank (Technical University of Dresden,
griewank@math.tu-dresden.de).
However I have had to heavily modify ADOL-C as well as adding an AUTODIF-like interface to it.

The other externally sourced component is the 'newran' random number generation package,
which is freeware written by a guy called Robert Davies (see http://webnz.co.nz/robert).

The minimiser is closely based on the main algorithm of Dennis & Schnabel, Numerical Methods for
Unconstrained Optimisation and Nonlinear Equations (1996). I have implemented a new, object-oriented
interface, which makes it somewhat simpler to use - see optimise(), also optimise_finite_differences()
which uses finite difference gradients instead of automatic generation.

User information follows, and should be used as an addition to
an early AUTODIF manual. Note that there is not enough information in
this documentation to diagnose or correct an ADOL-C error. Contact Brian Bull if you find one.

Make betadiff into a library file using the makefile provided, which should compile all the components.
Use either 'make libbd.a' or preferably 'make test' which makes libbd.a, compiles a small test program
and diff's the results against the 'correct' output.
Use betadiff by linking -lbd -lad -lm,
and #include "betadiff.h" (instead of the AUTODIF #include <fvar.hpp>


Differences from AUTODIF:

-There is a new handler to the minimiser - see optimise() at the bottom of the file.
  Now you only need to supply the model, objective function, start values, bounds,
  and control values, and the handler does all the rest. You no longer need
  to extract the gradient and pass it to the fmc minimiser. If you do want to extract
  the gradient vector for some other purpose, have a look at the contents of the
  optimise() class and copy the calls there.

-The minimisation algorithm is different, though still of the same general type.

-gradient_structure and RETURN_ARRAYS calls are unnecessary and ignored.

-My boundp and boundpin are as documented for AUTODIF, except with the error corrected
 (the lower quadratic term now starts at -.9999 instead of 0.00001), a slightly more
 accurate value of pi, and a bigger penalty on values outside [-1, 1].
 If you find moderate numerical differences between results using AUTODIF and results
 using the replacement, this could well be a reason.

-The RNGs use different algorithms. The only difference in usage is that if you make
 two successive seed calls to the same seed, the second is ignored. So if you set the
 seed to a value v, get a sequence S, and then set the seed to v again, the sequence S
 _will not_ come out again; it will go on as if the second seed call had not been made.
 Whereas if you set it to v1, get S1, set it to v2, get S2, and then set it
 back to v1, you _will_ get S1 again. (Or if you get S1, then call RNG_reset(v1),
 you will get S1 again)

-We now have a multivariate normal RNG, dmatrix::fill_mvnorm and dvector::fill_mvnorm,
 and a multivariate t RNG, dmatrix::fill_mvt and dvector::fill_mvt,
 and a chi-square RNG, dvector::fill_chisq,
 and multinomial RNGs, dvector::fill_multinomial and dvv:fill_multinomial.

-The product of two matrices is now a matrix whose row and column indices start at 1,
 not 0 as in AUTODIF.
 The product of a matrix and a vector is now a vector whose indices start at 1,
 not a matrix as in AUTODIF.
 The product of a vector and a matrix is now a matrix with one row whose indices start at 1,
 not 0 as in AUTODIF.

-The ivector and imatrix classes are now based on doubles, not ints. They use double
 arithmetic! I think this is probably not a problem. Occasionally you may need to
 add an (int) cast to prevent a compile-time error.

-dvector[dvector], dvv[dvector] can't be the left side of an expression.

-The index matrix(int) is no longer supported: use matrix[int]

-A copy constructor is not a shallow copy, for user classes.
 In AUTODIF, dvector v=w; v=v*2; has the effect of doubling w. Not any more:
 they have different memory locations.

-There is some vector/matrix range checking provided. Like AUTODIF, I also implement a
 non-range-checked version - see libbd_unchecked.a. Only use this for code which has
 been tested with libbd.a!!

-Ragged arrays have not been implemented.

-Avoid excess spaces when inputting character strings (ie. not dvv a("{ 1 , 2 }"))

-When inputting character strings into vectors, I have added an optional integer argument
 which is the first index of the result (default 1).

-The constructor dvar_matrix(char*) now works slightly differently. If the argument is
 some data (not a filename), it now takes only a single string argument of the form:
 dvm W("{1 2 3}{4 5 6}{7 8 9}");
 Alternatively the argument can be the name of a datafile. Do not put any excess spaces or words
 inside the file. testfile.mat is a valid example (comes with betadiff).

-On Kupe, cout does not flush until cin is called. So use cout.flush() or use cerr instead
 or set the cout stream to flush straightaway, if that is what you want.


Known bugs:

-Betadiff can run out of memory. If this happens, it writes out the contents of memory to several
 large files prefixed _adol_ in the current working directory. This is a bad thing because it
 is very slow: it also will cause problems if multiple processes are running in the same directory
 because they will each try and use the same filenames.
 However, this problem is avoidable. In my experience, it only happens when you create many active
 variables using 'new' and fail to destroy them using 'delete': a stack within ADOL-C then just keeps
 getting larger and larger. So, make sure to delete anything you create.
 If you want to check whether the ADOL-C stack is getting out of hand, look at the standard error
 for messages like "resizing from 10000 to 11000". These indicate the current size of the stack of
 active variables. The stack should grow a lot at the start of a minimisation, but should stop
 growing after the first 1 or 2 differentiations. If it keeps growing, then you are probably
 failing to delete something.
 See also the ADOLC_storage() function, which prints out a message about the total amount of 'tape'
 storage used, which increases with the number of operations which have been carried out on active
 variables in the current objective function evaluation. When this number gets very high, you are
 in danger of paging to disk, and you need to reduce the number of active-variable operations in
 your objective function.

-NaNs in the gradient vector can indicate a non-differentiable function. This can come about
 either because your function is genuinely, mathematically non-differentiable, or simply as
 the result of a (seemingly unrelated) programming error which confuses ADOL-C, e.g. one time I got
 this problem because I was taking the log of a non-positive number.
 If you really can't get the differentiation to work, you can resort to the finite differences
 version of the minimiser, but this can be a lot slower.

- 22/9/04 Updated memory allocation for betadiff in usrparms.h from 200K to 1000K
*/

// standard libraries
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>
// ADOL-C libraries
#include "adouble.h"
#include "DRIVERS/drivers.h"

#define NOTKUPE
#define GOOD(x) (x).good()

/* With gcc v 3.2 these should be read out of math.h but aren't, not sure why */

#ifdef WIN32
inline double fmax(double a, double b){
        return (a > b) ? a : b;}
inline double fmin(double a, double b){
        return (a < b) ? a : b;}
#endif

// This 'very large number' may need to change on some machines?
#define RNG_LONGMAX 2147483647

// Error handling
void error(const std::string& problem);
#define BETADIFF_FATAL_EXIT 12

// This is a complete list of the classes in Betadiff.
class dvariable;
class dvv;
class dvm;
class dsubv;
class dvector;
class dmatrix;
class fmm;
class gradient_structure;

class dvariable{
  // The 'dvariable' class is a differentiable version of 'double'.
  // The key component of a dvariable is an 'adouble' from ADOL-C.

 public:
  // The guts of a dvariable is an adouble.
  // Users should not manipulate this adouble except through Betadiff functions:
  // I've left it public to avoid a huge list of 'friend's.
  adouble x;

  // These are the constructors and assignments that a user might want to use:
  dvariable();
  dvariable(double);
  dvariable(const dvariable&);
  dvariable& operator=(double);
  dvariable& operator=(const dvariable&);

  // and these are used internally by Betadiff.
  dvariable(const asub&);
  dvariable(const adub&);
  dvariable(const badouble&);
  dvariable(const adouble&);
  dvariable& operator=(const asub&);
  dvariable& operator=(const adub&);
  dvariable& operator=(const badouble&);

  // Member function operators are listed here:
  adub operator++(int);
  adub operator--(int);
  void operator+=(const dvariable&);
  void operator-=(const dvariable&);
  void operator/=(const dvariable&);
  void operator*=(const dvariable&);
  void operator+=(double);
  void operator-=(double);
  void operator/=(double);
  void operator*=(double);

  // These next 4 functions are used for passing in values at the start
  // of a function to be differentiated, and passing out values at the end.
  // optimise() does this for you, so you shouldn't need to worry about it.
  void operator>>=(double&);
  void operator<<=(double);
  void operator>>=(dvariable&);
  void operator<<=(const dvariable&);
};

// Non-member operators on dvariables are listed here.
adub operator*(const dvariable&, const dvariable&);
adub operator*(double, const dvariable&);
adub operator*(const dvariable&, double);
adub operator/(const dvariable&, const dvariable&);
adub operator/(double, const dvariable&);
adub operator/(const dvariable&, double);
adub operator+(const dvariable&, const dvariable&);
adub operator+(double, const dvariable&);
adub operator+(const dvariable&, double);
adub operator-(const dvariable&, const dvariable&);
adub operator-(double, const dvariable&);
adub operator-(const dvariable&, double);
adub operator-(const dvariable&);
int operator>(const dvariable&, const dvariable&);
int operator<(const dvariable&, const dvariable&);
int operator>=(const dvariable&, const dvariable&);
int operator<=(const dvariable&, const dvariable&);
int operator!=(const dvariable&, const dvariable&);
int operator==(const dvariable&, const dvariable&);
int operator>(const dvariable&, double);
int operator<(const dvariable&, double);
int operator>=(const dvariable&, double);
int operator<=(const dvariable&, double);
int operator!=(const dvariable&, double);
int operator==(const dvariable&, double);
int operator<(double, const dvariable&);
int operator>(double, const dvariable&);
int operator<=(double, const dvariable&);
int operator>=(double, const dvariable&);
int operator==(double, const dvariable&);
int operator!=(double, const dvariable&);
bool operator!(const dvariable&);
bool operator!(const asub&); // should be in ADOL-C -
                             // inserted here for convenience

// The value() function extracts the number from a dvariable
// and puts it into a double. Of course, differentability is lost in the process - so don't
// let the result of value() affect the function you are differentiating!!
double value(const dvariable&);
double value(double); // just the identity function

// Math functions on dvariables (see also those listed under dvv, dvm)
dvariable pow(const dvariable&, const dvariable&);
dvariable pow(const dvariable&, double);
dvariable pow(double, const dvariable&);
adub sin(const dvariable&);
adub cos(const dvariable&);
adub tan(const dvariable&);
adub asin(const dvariable&);
adub acos(const dvariable&);
adub atan(const dvariable&);
adub sqrt(const dvariable&);
adub log(const dvariable&);
adub exp(const dvariable&);
adub log10(const dvariable&);
adub fabs(const dvariable&);
adub sfabs(const dvariable&); // same as fabs
adub ceil(const dvariable&);
adub floor(const dvariable&);
adub fmax(const dvariable&, const dvariable&);
adub fmax(const dvariable&, double);
adub fmax(double, const dvariable&);
adub fmin(const dvariable&, const dvariable&);
adub fmin(const dvariable&, double);
adub fmin(double, const dvariable&);

// new in 2004
adub lngamma(const dvariable&);
double lngamma(double);
adub zerofun(const dvariable&, const dvariable&);
double zerofun(double, double);
dvariable zerofun(dvariable&,double);

// Stream-based I/O of dvariables.
std::ostream& operator<<(std::ostream&, const dvariable&);
std::istream& operator>>(std::istream&, dvariable&);


class dvv{
  // This is a differentiable vector class, like dvar_vector in AUTODIF.
  // The key component of a dvv is an 'adoublev' from ADOL-C.
  // The main difference between dvv and adoublev is that the indices of an adoublev always
  //  start at 0, but those of a dvv can start at any integer.
  // There is now no need for the AUTODIF class 'independent_variables', use a dvv instead.
  //
  // One design decision worth mentioning - I decided that assignment of a dvv
  // does not change indices, and nor do arithmetic operators.
  // so a=b*scalar, a's indices do not change
  // and b*=scalar, b's indices do not change.
  friend class badouble;
//  friend class badoublev;
//  friend class dsubv;

 public:
  // The guts of a dvv is an adoublev.
  // Users should not manipulate this adoublev except through Betadiff functions:
  // I've left it public to avoid a huge list of 'friend's. Ditto 'first'.
  adoublev v;
  int first;  // the index of the first element, often 1

  // These are the constructors and assignments:
  dvv(int,int);
  dvv(int); // lower bound=1;
  dvv(const dvv&);
  dvv(char*);
  dvv(char*,int);
  dvv(const dvector&);
  dvv(); // don't use this explicitly
  dvv& operator=(const dvv&);
  dvv& operator=(const dvector&);
  dvv& operator=(double);
  dvv& operator=(int i); // set all elements to i
  dvv& operator=(const dvariable&);
  dvv& operator=(double*);

  // plus these, which are used internally by Betadiff:
  dvv(const dsubv&);
  dvv(const adubv&);
  dvv(const adoublev&);
  dvv& operator=(const adubv&);
  dvv& operator=(const adoublev&);
  dvv& operator=(const dsubv&);

  void initialize(); // assign a value of 0 to all elements

  // size and indices
  int indexmin() const;
  int indexmax() const;
  int size() const;
  void shift(int); // changes the index range: this is the new first index

  // access an element (to read or change it);
  badouble operator[](int) const;
  badouble operator[](double) const;

  // access a bunch of elements (read-only)
  dvv operator[](const dvector&) const;

  // These next 6 functions are used for passing in values at the start
  // of a function to be differentiated, and passing out values at the end.
  // optimise() does this for you, so you shouldn't need to worry about it.
  void operator>>=(double*);
  void operator<<=(double*);
  void operator>>=(dvv);
  void operator<<=(const dvv&);
  void operator>>=(dvector);
  void operator<<=(const dvector&);

  // put contents into the dvv
  // class dvector also supplies multivariate normal random numbers
  void fill(char*); // same format as the char* constructor
  void fill_seqadd(const dvariable& base, const dvariable& offset); // arithmetic sequence
  void fill_randu(const long int&);                       // uniform random numbers
  void fill_randn(const long int&);                       // normal random numbers
  void fill_randbi(const long int&, const double);        // binomial (n=1) random numbers
  void fill_multinomial(const long int&, const dvector&); // multinomial random numbers
  void fill_multinomial_counts(const long int&, const dvector&, int N); // number of multinomial random numbers in each category

  // Member function operators are listed here.
  void operator+=(const dvv&);
  void operator-=(const dvv&);
  void operator+=(const dvariable&);
  void operator-=(const dvariable&);
  void operator/=(const dvariable&);
  void operator*=(const dvariable&);
  void operator+=(double);
  void operator-=(double);
  void operator/=(double);
  void operator*=(double);
  void operator*=(const dvv&);
};

// Non-member operators on dvvs, and dvvs with dvariables, are listed here.
dvariable operator*(const dvv&, const dvv&);  // dot product - as opposed to elem_prod()
dvv operator*(const dvv&, double);
dvv operator*(double, const dvv&);
dvv operator*(const dvv&, const dvariable&);
dvv operator*(const dvariable&, const dvv&);
dvv operator/(const dvv&, double);
dvv operator/(const dvv&, const dvariable&);
dvv operator/(double, const dvv&);
dvv operator/(const dvariable&, const dvv&);
dvv operator+(const dvv&, const dvv&);
dvv operator+(const dvv&, const dvariable&);
dvv operator+(const dvariable&, const dvv&);
dvv operator-(const dvv&, const dvv&);
dvv operator-(const dvv&, const dvariable&);
dvv operator-(const dvariable&, const dvv&);
dvv operator-(const dvv&);             // unary -
dvv operator&(const dvv&, const dvv&); // concatenation

// The value() function extracts the number from a dvv and puts it into a dvector.
//  Of course, differentability is lost in the process - so don't
// let the result of value() affect the function you are differentiating!!
dvector value(const dvv&);

// Math functions on dvvs.
dvv elem_prod(const dvv&, const dvv&);
dvv elem_prod(const dvv&, const dvv&, const dvv&); // BB added - elem_prod(a,b,c)[i] = a[i]*b[i]*c[i]
dvv elem_div(const dvv&, const dvv&);
dvv pow(const dvv&, const dvv&);
dvv pow(const dvv&, double);  // not double*
dvv pow(const dvv&, const dvariable&);
dvv pow(double, const dvv&);
dvv sin(const dvv&);
dvv cos(const dvv&);
dvv tan(const dvv&);
dvv asin(const dvv&);
dvv acos(const dvv&);
dvv atan(const dvv&);
dvv sqrt(const dvv&);
dvv exp(const dvv&);
dvv log(const dvv&);
dvv log10(const dvv&);
dvv fabs(const dvv&);
dvv sfabs(const dvv&); // same as fabs
dvv ceil(const dvv&);
dvv floor(const dvv&);
dvariable mean(const dvv&);
dvariable std_dev(const dvv&);
dvariable sum(const dvv&);
dvariable norm(const dvv&);
dvariable norm2(const dvv&);
dvariable min(const dvv&);
dvariable max(const dvv&);

// Stream-based I/O of dvvs.
std::ostream& operator<<(std::ostream&, const dvv&);
std::istream& operator>>(std::istream&, dvv&);

// A slow binomial variate generator
int rbinomial(const long int&, int, double);

class dvm{
  // This is a differentiable matrix class, like dvar_matrix in AUTODIF.
  // The key component of a dvm is an vector of pointers to dvv.
  // There is an adoublem class in ADOL-C, I could instead have used that,
  //  but it turned out to be easier to do this way. (adoublem is now broken
  //  due to my changes to the code!)
  // Row and column indices can start at any integer.

 public:
  // The guts of a dvm is a vector of dvv's.
  // Users should not manipulate this object except through Betadiff functions:
  // I've left it public to avoid a huge list of 'friend's.
  // Ditto 'firstrow', 'firstcol', 'rows', 'cols'.
  std::vector<dvv> index;  // was:  dvv *index;
  int firstrow, firstcol;
  int rows, cols;

  // These are the constructors and assignments:
  dvm(int lbr,int lur,int lbc,int luc);
  dvm(int lur,int luc); // lower bounds=1;
  dvm(const dvm&);
  dvm(const dmatrix&);
  dvm(char*);  // slightly different to AUTODIF, see definition
  dvm(); // don't use this explicitly
  dvm& operator=(const dvm&);
  dvm& operator=(const dmatrix&);
  dvm& operator=(const dvariable&);

  void initialize(); // assign a value of 0 to all elements

  // size and indices
  int rowmin() const;
  int rowmax() const;
  int colmin() const;
  int colmax() const;
  int rowsize() const;
  int colsize() const;
  void colshift(int); // changes the index range: this is the new first column
  void rowshift(int); // changes the index range: this is the new first row

  // access an element (to read or change it);
  dvv& operator[](int);
  dvv& operator[](double);
  const dvv& operator[](int) const;
  const dvv& operator[](double) const;

  // put contents into the dvm
  // in each case the first argument is the row or column into which to insert
  // dmatrix's also have a multivariate normal random number generator.
  void rowfill(int, const dvv&);  // a specified vector
  void colfill(int, const dvv&);
  void rowfill_seqadd(int, const double, const double);    // an arithmetic sequence
  void colfill_seqadd(int, const double, const double);
  void rowfill_randu(int, const long int&);                // uniform random numbers
  void colfill_randu(int, const long int&);
  void rowfill_randn(int, const long int&);                // normal random numbers
  void colfill_randn(int, const long int&);
  void rowfill_randbi(int, const long int&, const double); // binomial (n=1) random numbers
  void colfill_randbi(int, const long int&, const double);

  // Member function operators are listed here.
  void operator+=(const dvm&);
  void operator-=(const dvm&);
  void operator+=(const dvariable&);
  void operator-=(const dvariable&);
  void operator*=(const dvariable&);
  void operator/=(const dvariable&);

  ~dvm();
};

// Non-member operators on dvms, and dvms with dvvs and/or dvariables, are listed here.
dvm operator*(const dvm&,const dvm&); // matrix products - as distinct from elem_prod()
dvv operator*(const dvm&,const dvv&); // note result is dvv, not dvm
dvm operator*(const dvv&,const dvm&);
dvm operator+(const dvm&,const dvm&);
dvm operator-(const dvm&,const dvm&);
dvm operator+(const dvariable&,const dvm&);
dvm operator+(const dvm&,const dvariable&);
dvm operator-(const dvariable&,const dvm&);
dvm operator-(const dvm&,const dvariable&);
dvm operator*(double,const dvm&);
dvm operator*(const dvm&,double);
dvm operator*(const dvariable&,const dvm&);
dvm operator*(const dvm&,const dvariable&);
dvm operator-(const dvm&); // unary -

// Math functions on dvms.
dvm sqrt(const dvm&);
dvm log(const dvm&);
dvm elem_div(const dvm&, const dvm&);
dvm elem_prod(const dvm&, const dvm&);
dvariable norm(dvm);
dvariable norm2(dvm);
dvv rowsum(dvm);
dvv colsum(dvm);
dvm column_vector(dvv&); // make a dvm with 1 column
dvm row_vector(dvv&);    // make a dvm with 1 row
dvv extract_column(const dvm&, const int);
dvv extract_diagonal(const dvm&);
dvm inverse(const dvm&);

// Stream-based I/O of dvms.
std::ostream& operator<<(std::ostream&, const dvm&);
std::istream& operator>>(std::istream&, dvm&);


class dsubv{
  // This is a class used internally by Betadiff. Users need not be interested in it.
  // A dsubv is produced by subscripting a dvm. It needs to be able to take assignment-
  // as in dvm[1] = dvv - and be assigned - as in dvv = dvm[1].
  // The key component of a dsubv is an 'asubv' from ADOL-C.
  // The main difference between dsubv and asubv is that the indices of an adoublev always
  //  start at 0, but those of a dsubv can start at any integer.

 public:
  // The guts of a dsubv is an asubv.
  // Users should not manipulate this object except through Betadiff functions:
  // I've left it public to avoid a long list of 'friend's. Ditto 'first'.
  asubv av;
  int first;

  // These are the assignments that a user might want to use:
  dsubv& operator=(const dvv&);
  dsubv& operator=(double*);
  dsubv& operator=(const dvariable&);
  dsubv& operator=(double);

  // and these are used internally by Betadiff.
  dsubv& operator=(const adoublev&);
  dsubv& operator=(const adubv&);

  // size and indices
  int size() const;
  void shift(int); // changes the index range: this is the new first index

  // access an element (to read or change it);
  badouble operator[](int i);
  badouble operator[](double t);

  // Member function operators are listed here.
  void operator+=(const dvv&);
  void operator+=(const dvariable&);
  void operator+=(double);
  void operator-=(const dvv&);
  void operator-=(const dvariable&);
  void operator-=(double);
  void operator*=(const dvariable&);
  void operator*=(double);
  void operator/=(const dvariable&);
  void operator/=(double);
};


class dvector{
  // This is a non-differentiable vector class, like dvector in AUTODIF.

 public:
  // The guts of a dvector is an array of doubles.
  // Users should not manipulate this object except through Betadiff functions:
  // I've left it public to avoid a long list of friends.
  double *ptr; // contains the data

  int first;  // the index of the first element, often 1
  int sz;     // the length of the vector, so indices are first...first+sz-1

  // These are the constructors and assignments:
  dvector(int,int);
  dvector(int);  // lower bound = 1
  dvector(const dvector&);
  dvector(char*);
  dvector(char*,int);
  dvector& operator=(const dvector&);
  dvector& operator=(double);
  dvector& operator=(int i); // set all elements to i
  dvector(); // don't use this explicitly

  void initialize(); // assign a value of 0 to all elements

  // size and indices
  int indexmin() const;
  int indexmax() const;
  int size() const;
  void shift(int); // changes the index range: this is the new first index

  // access an element (to read or change it);
  double& operator[](int) const;
  double& operator[](double) const;

  // access a bunch of elements (read-only)
  dvector operator[](const dvector&) const;

  // put contents into the dvector
  void fill(char*); // same format as the char* constructor
  void fill_seqadd(double base, double offset); // arithmetic sequence
  void fill_randu(const long int&);                       // uniform random numbers
  void fill_randn(const long int&);                       // normal random numbers
  void fill_randbi(const long int&, const double);        // binomial (n=1) random numbers
  void fill_multinomial(const long int&, const dvector&); // multinomial random numbers
  void fill_multinomial_counts(const long int&, const dvector&, int N); // number of multinomial random numbers in each category
  void fill_chisq(const long int&, int);                  // chi-square random numbers
  void fill_mvnorm(const long int&, const dvector&, const dmatrix&);
  void fill_mvt(const long int&, const dvector&, const dmatrix&, int df);

  // Member function operators are listed here.
  void operator+=(const dvector&);
  void operator-=(const dvector&);
  void operator+=(double);
  void operator-=(double);
  void operator/=(double);
  void operator*=(double);
  void operator*=(const dvector&);

  ~dvector();
};

// Non-member operators on dvectors are listed here.
double operator*(const dvector&, const dvector&);  // dot product - as opposed to elem_prod()
dvector operator*(const dvector&, double);
dvector operator*(double, const dvector&);
dvector operator*(const dvector&, double);
dvector operator*(double, const dvector&);
dvector operator/(const dvector&, double);
dvector operator/(const dvector&, double);
dvector operator/(double, const dvector&);
dvector operator/(double, const dvector&);
dvector operator+(const dvector&, const dvector&);
dvector operator+(const dvector&, double);
dvector operator+(double, const dvector&);
dvector operator-(const dvector&, const dvector&);
dvector operator-(const dvector&, double);
dvector operator-(double, const dvector&);
dvector operator-(const dvector&);             // unary -
dvector operator&(const dvector&, const dvector&); // concatenation

// The value() function is just the identity function for dvectors but we include it anyway for
// compatibility with dvv.
dvector value(const dvector&);

// Math functions on dvectors.
dvector pow(const dvector&, const dvector&);
dvector pow(const dvector&, double);  // not double*
dvector pow(double, const dvector&);
dvector sin(const dvector&);
dvector cos(const dvector&);
dvector tan(const dvector&);
dvector asin(const dvector&);
dvector acos(const dvector&);
dvector atan(const dvector&);
dvector sqrt(const dvector&);
dvector exp(const dvector&);
dvector log(const dvector&);
dvector log10(const dvector&);
dvector fabs(const dvector&);
dvector sfabs(const dvector&); // same as fabs
dvector ceil(const dvector&);
dvector floor(const dvector&);
double mean(const dvector&);
double std_dev(const dvector&);
double sum(const dvector&);
double norm(const dvector&);
double norm2(const dvector&);
dvector elem_prod(const dvector&, const dvector&);
dvector elem_prod(const dvector&, const dvector&, const dvector&);
dvector elem_div(const dvector&, const dvector&);
double min(const dvector&);
double max(const dvector&);

// Stream-based I/O of dvectors.
std::ostream& operator<<(std::ostream&, const dvector&);
std::istream& operator>>(std::istream&, dvector&);

// Sorting - only implemented for dvector, not dvv
dvector sort(const dvector&);
dvector sort(const dvector&,dvector&);  // second argument becomes the index table (see AD4-12)

int chol(const dmatrix&,dmatrix&); // used by fill_mvnorm


class dmatrix{
  // This is a non-differentiable matrix class, like dmatrix in AUTODIF.
  // The key component of a dmatrix is an vector of pointers to dvector,
  // like dvm and dvv.
  // Row and column indices can start at any integer.

 public:
  // The guts of a dmatrix is a vector of dvector's.
  // Users should not manipulate this object except through Betadiff functions:
  // I've left it public to avoid a huge list of 'friend's.
  // Ditto 'firstrow', 'firstcol', 'rows', 'cols'.
  std::vector<dvector> index;  // was:  dvector *index;
  int firstrow, firstcol;
  int rows, cols;

  // These are the constructors and assignments:
  dmatrix(int lbr,int lur,int lbc,int luc);
  dmatrix(int lur,int luc); // lower bounds=1;
  dmatrix(const dmatrix&);
  dmatrix(char*, int skip_lines=0);  // slightly different to AUTODIF, see definition
  dmatrix(); // don't use this explicitly
  dmatrix& operator=(const dmatrix&);
  dmatrix& operator=(double);

  void initialize(); // assign a value of 0 to all elements

  // size and indices
  int rowmin() const;
  int rowmax() const;
  int colmin() const;
  int colmax() const;
  int rowsize() const;
  int colsize() const;
  void colshift(int); // changes the index range: this is the new first column
  void rowshift(int); // changes the index range: this is the new first row

  // access an element (to read or change it);
  dvector& operator[](int);
  dvector& operator[](double);
  const dvector& operator[](int) const;
  const dvector& operator[](double) const;

  // put contents into the dmatrix
  // in each case the first argument is the row or column into which to insert
  void rowfill(int, const dvector&);  // a specified vector
  void colfill(int, const dvector&);
  void rowfill_seqadd(int, const double, const double);    // an arithmetic sequence
  void colfill_seqadd(int, const double, const double);
  void rowfill_randu(int, const long int&);                // uniform random numbers
  void colfill_randu(int, const long int&);
  void rowfill_randn(int, const long int&);                // normal random numbers
  void colfill_randn(int, const long int&);
  void rowfill_randbi(int, const long int&, const double); // binomial (n=1) random numbers
  void colfill_randbi(int, const long int&, const double);
  void fill_mvnorm(const long int&, const dvector&, const dmatrix&);
  void fill_mvt(const long int&, const dvector&, const dmatrix&, int df);

  // Member function operators are listed here.
  void operator+=(const dmatrix&);
  void operator-=(const dmatrix&);
  void operator+=(double);
  void operator-=(double);
  void operator*=(double);
  void operator/=(double);

  ~dmatrix();
};

// Non-member operators on dmatrix's, and dmatrix's with dvectors, are listed here.
dmatrix operator*(const dmatrix&,const dmatrix&); // matrix products - as distinct from elem_prod()
dvector operator*(const dmatrix&,const dvector&); // note result is dvector, not dmatrix
dmatrix operator*(const dvector&,const dmatrix&);
dmatrix operator+(const dmatrix&,const dmatrix&);
dmatrix operator-(const dmatrix&,const dmatrix&);
dmatrix operator+(double,const dmatrix&);
dmatrix operator+(const dmatrix&,double);
dmatrix operator-(double,const dmatrix&);
dmatrix operator-(const dmatrix&,double);
dmatrix operator*(double,const dmatrix&);
dmatrix operator*(const dmatrix&,double);
dmatrix operator*(double,const dmatrix&);
dmatrix operator*(const dmatrix&,double);
dmatrix operator-(const dmatrix&); // unary -

// Math functions on dmatrix's.
dmatrix sqrt(const dmatrix&);
dmatrix log(const dmatrix&);
dmatrix elem_div(const dmatrix&, const dmatrix&);
dmatrix elem_prod(const dmatrix&, const dmatrix&);
double norm(dmatrix);
double norm2(dmatrix);
dvector rowsum(dmatrix);
dvector colsum(dmatrix);
dmatrix column_vector(dvector&); // make a dmatrix with 1 column
dmatrix row_vector(dvector&);    // make a dmatrix with 1 row
dvector extract_column(const dmatrix&, const int);
dvector extract_diagonal(const dmatrix&);
dmatrix identity_matrix(int,int);
dmatrix inverse(const dmatrix&);

// Stream-based I/O of dmatrix's.
std::ostream& operator<<(std::ostream&, const dmatrix&);
std::istream& operator>>(std::istream&, dmatrix&);

// Sorting - only implemented for dmatrix, not dvm
dmatrix sort(const dmatrix&, int); // sort the rows based on the (int)th comment

// Go back to the start of the RNG sequence generated from the specified seed
void RNG_reset(long seed);

void ADOLC_storage(char* output);


class fmm{
  // Minimiser to replace the Autodif fmm.
  // See 'optimise()' above, which calls it.
  //
  //  -It is a quasi-Newton algorithm using user-supplied derivatives, and a linear search.
  //   See (all of) Dennis & Schnabel.
  //
  //  -The stopping criteria are different. The algorithm will terminate if
  //    (a) a maximum no. of function evaluations is reached (maxfn, default=300)
  //    (b) a maximum no. of quasi-Newton steps is reached (maxit, default=200)
  //    (c) a maximum no. of steps in a single linear search is reached (imax, default=20)
  //    (d) The scaled stepsize (D&S p 279) is too small (step_tol, default= eps^(2/3))
  //    (e) The scaled gradient (Dennis & Schnabel p 279) is small enough (grad_tol, default=0.0025,
  //           though D&S recommended the rather smaller eps^(1/3))
  //   with a-c being failures to converge and d and e being successful convergence.
  //   All the above limits are public members of fmm: and some of the Autodif fmm members no longer exist.
  //   eps is calculated by fmm::fmm (it's not from a header file or anything like that).
  //
  //  -This algorithm is intended for variables scaled by boundp/boundpin. Not recommended
  //   for variables of greater or lesser magnitudes! It would need to be changed (see D&S p 278)
  //
  //  -ireturn is now a more informative member. Its values are
  //    -3: odd convergence failure (see the code)
  //    -2: failed to converge due to running out of evaluations or iterations
  //    -1: converged
  //     0: in quasi-Newton step
  //         (& if returned, need new gradient- send the same function as last time-
  //           except on the first fmin call for a given fmm, when f and g will both need to be done)
  //     1: in linear search
  //         (& if returned, need new function only - send the same gradient as last time)
  //
  //  -As in Autodif, it will print current parameter estimates every (iprint) steps,
  //   unless iprint=0 (the default). The output format is much less flash though! (so far)
  //
  //  -By the way, this code is similar to Autodif and different from D&S in that
  //   program control jumps out of it, back to the calling program, every time it wants a function
  //   evaluation, or gradient.
 public:
  long maxfn;   // maximum no. of function evaluations.
  long maxit;   // maximum no. of quasi-Newton steps
  long imax;    // maximum no. of steps in a single linear search
  double grad_tol; // scaled gradient (see Dennis & Schnabel p 279) required for termination
  double step_tol; // scaled step size (D&S p 279) required for termination
  double maxstep;  // maximum scaled step size (D&S p 279) permitted
  long iprint;
  int iters, evals; // quasi-Newton iterations, function evaluations
  int ireturn;      // now more informative
  fmm(int n);
  ~fmm();
  void fmin(dvv& xvec, double& func, dvector& gvec);
  double **L;  // made this public so it can be extracted for the Hessian

 private: // this is all local variables- do I really have to show it here?
  double *x;
  double f;
  double *g;
  double *xplus;
  double fplus;
  double *p;
  double *pp;
  double *xlast;
  double *glast;
  double *temp; // used for arithmetic steps, should not be expected to hold its value
  double t;     // ditto
  int count;
  int nvar;
  double eps;
  int iters_this_lnsrch;
  double alpha,lambda,lambdamin,initslope,lambdatemp,lambdaprev,fplusprev,newtlen,rellength,a,b,disc;
  int maxtaken, consecmax;
  int count2,count3; double wsum;
  int good;
  double fgood;
  double fgood_previous;
  int reinitialized;
  double *xgood;
};

// These functions are used to access the ADOL-C function, gradient, and hessian calls.
// They are accessed internally from optimise() and the user should not need to call
// them directly.
int bb_function(short int tag,int n,dvv& x,double& y);
int bb_gradient(short int tag,int n,dvv& x,dvector& g);
int bb_hessian(short int tag,int n,dvv &x,dmatrix& h);
// Warning - bb_hessian currently seems to be dysfunctional.

// These functions are used to transform estimated parameters, as a means of converting
// a box-constrained optimization problem into an unconstrained optimization,
// as per AUTODIF. Again, they are accessed internally from optimise() and the user
// should not need to call them directly.
dvariable boundp(const dvariable& x, double fmin, double fmax, dvariable& fpen);
double boundpin(double y, double fmin, double fmax);

// The following four functions are used in the fmm minimiser.
void bfgsfac(int nvar,double* x,double* xlast,double* g,double* glast,double eps,double nu,double **M);
void cholsolve(int nvar,double* g,double** L,double* p);
void qrupdate(int nvar,double* u,double* v,double** M);
void jacrotate(int nvar,int i,double a,double b,double** M);

class gradient_structure{
  // does nothing - purely for backward compatibility with AUTODIF
 public:
  gradient_structure(int a){}
  gradient_structure(){}
  static void set_CMPDIF_BUFFER_SIZE(int a){}
  static void set_GRADSTACK_BUFFER_SIZE(int a){}
  static void set_MAX_NVAR_OFFSET(int a){}
};

///////////////////////////////////////////////////////////////////////////////////////////
// optimise: BB new function 10/5/01 - a handler to run the AUTODIF-style minimiser fmm.
// This function solves a local optimisation problem,
//   ie. minimises or maximises a function.
// It is a template function which is passed an object 'model'
//   and a function object 'objective' whose operator() takes references
//   to the 'model' and a dvar_vector& - the unscaled parameter vector - and returns
//   a dvariable - the resulting function value.
// Other arguments to optimise include 'start' the starting parameter values
//   and 'lower_bounds' and 'upper_bounds' the lower and upper bounds (all dvectors),
//   and the optional control values 'iprint'=10, 'maxit'=50, 'maxfn'=200
//   and 'grad_tol'=2e-3 (see fmin documentation),
//   and 'maximise'=0 (maximise rather than minimise if ==1)
//   and 'ADOLC_hessian'=0 and 'optimise_hessian'=0 (see below)
// optimise returns the minimal function value (as a double) and updates
//   'start' to contain the optimal parameter vector and 'convergence' to be 1
//   for successful convergence, 0 for running out of iters/evals and -1 for unclear convergence.
//   Actual numbers of iterations and function evaluations are returned in maxit and maxfn.
//   If optimise_hessian!=0 it uses it to return the optimiser's approximation
//   to the Hessian: if ADOLC_hessian!=0 it uses it to return the ADOL-C analytic
//   Hessian (warning - time-consuming). In both cases the Hessian returned by default
//   is for the bounded parameter values: set untransformed_hessians=1 to get the Hessian
//   for the parameter vector without bounding.
// Any problems in the minimiser (failure to converge, too many linear search steps,
//   exceeding max. iterations or max. function calls...) cause a warning to be printed
//   to cerr but do not error out.
// Incidentally, I put this function in the header rather than the .C because otherwise
//   the compiler can't deal with the templating.
//
template<class M,class F> double optimise(M& model,F& objective,
                                   dvector& start,dvector& lower_bounds,dvector& upper_bounds,
                                   int& convergence,
                                   int iprint,int& maxit,int& maxfn,double grad_tol=2e-3,
                                   int maximise=0,
                                   dmatrix* optimise_hessian=0, dmatrix* ADOLC_hessian=0,
                                   int untransformed_hessians=0){

  int nvar = start.size();
  if (lower_bounds.size()!=nvar || upper_bounds.size()!=nvar || nvar<1){
    std::cerr << "Betadiff error: inconsistent sizes in optimise\n";
    std::cerr << "Please notify the software maintainer about this error.\n\n";
    exit(BETADIFF_FATAL_EXIT);
  }
  // create the minimiser
  fmm minimiser(nvar);
  // set the control parameters
  minimiser.maxfn = maxfn;
  minimiser.maxit = maxit;
  minimiser.grad_tol = grad_tol;
  minimiser.iprint = iprint;

  // initialize the parameter vector, with bounds
  dvv x(1,nvar);
  int count;
  for (count=1;count<=nvar;count++){
    if (start[count]<lower_bounds[count] || start[count]>upper_bounds[count]){
      std::cerr << lower_bounds << '\n' << upper_bounds << '\n' << start << "\nBetadiff error: in the minimiser, starting value # " << count << " is not within bounds - its value is " << start[count] << " and it should be between " << lower_bounds[count] << " and " << upper_bounds[count] << "\n";
      std::cerr << "Please notify the software maintainer about this error.\n\n";
      exit(BETADIFF_FATAL_EXIT);
    }
    if (lower_bounds[count]==upper_bounds[count]){
      x[count]=0;
    } else {
      x[count]=boundpin(start[count],lower_bounds[count],upper_bounds[count]);
    }
  }

  // variables used in the minimiser loop:
  dvariable fa;
  double f;
  dvector g(1,nvar);
  dvv x_unbounded(1,nvar);
  dvariable zpen;
  std::vector<int> nan_gradients;
  int iters=0, evals=0;
  int status;

  // run the minimiser
  while (minimiser.ireturn>=0){
    if (minimiser.ireturn==0 || minimiser.ireturn==2){
      // need to evaluate objective before calling minimiser.fmin again
      //std::cerr << "about to evaluate function ";
      trace_on(0);
      // ADOLC_storage("storage at trace_on");
      x <<= value(x);  // set x independent and initialise at current values
      zpen=0;
      for (count=1;count<=nvar;count++){
        if (lower_bounds[count]==upper_bounds[count])
      x_unbounded[count] = lower_bounds[count];
    else {
      x_unbounded[count]=boundp(x[count],lower_bounds[count],upper_bounds[count],zpen);
    }
      }
      //std::cerr << "with x = " << x_unbounded << "\n";
      // ADOLC_storage("storage before calling objective");
      fa = objective(model,x_unbounded);
      // ADOLC_storage("storage after calling objective");
      if (maximise==1) fa = -fa;
      fa += zpen;
      fa >>= f;
      trace_off();
      //std::cerr << "finished objective call: f = " << f << "\n";
    }
    if (minimiser.ireturn>=1){
      // need to call gradient before calling minimiser.fmin again
      //std::cerr << "about to evaluate gradient with x = " << x_unbounded << "\n";
      //std::cerr << "transformed = " << x << '\n';
      status = bb_gradient(0,nvar,x,g);
      //std::cerr << "finished gradient call: status = " << status << " g = " << g << "\n";
      if (status < 0){
        error("Failed gradient call in optimise: status = " + status);}
      for (int i=1; i<=nvar; i++){
        if (!(g[i]==g[i])){
          nan_gradients.push_back(i);}
      }
      if (nan_gradients.size()==1){
        std::cerr << "Betadiff returned a NaN gradient for parameter number " << nan_gradients[0] << " of " << nvar << '\n';
        error("");
      } else if (nan_gradients.size()>1){
        std::cerr << "Betadiff returned a NaN gradient for parameters ";
        for (unsigned int i=0; i<nan_gradients.size(); i++){
          std::cerr << nan_gradients[i] << ' ';}
        std::cerr << " of " << nvar << '\n';
        error("");
      }
    }
    //std::cerr << "about to do fmin call with x = " << x_unbounded << " f = " << f << " g = " << g << '\n';
    minimiser.fmin(x,f,g);
    //std::cerr << "done fmin call\n";
    //std::cerr << "ireturn = " << minimiser.ireturn << '\n';
  }

  std::cerr << "finished main minimiser loop\n";
  if (minimiser.ireturn==-3){
    std::cerr << "Unclear convergence in optimise. May or may not be a local minimum - you need to investigate further.\n";
    std::cout.flush();
  } else if (minimiser.ireturn==-2){
    std::cerr << "Ran out of iterations or evaluations in optimise\n";
    std::cout.flush();
  } else if (minimiser.ireturn==-1){
    std::cerr << "Successful convergence in optimise\n";
    std::cout.flush();
  } else {
    std::cerr << "Betadiff error: Unexpected ireturn value of " << minimiser.ireturn << " in optimise\n";
    std::cerr << "Please notify the software maintainer about this error.\n\n";
    std::cout.flush();
    exit(BETADIFF_FATAL_EXIT);
  }

  // return values
  for (count=1;count<=nvar;count++){
    x_unbounded[count]=boundp(x[count],lower_bounds[count],upper_bounds[count],zpen);}
  start = value(x_unbounded);
 fa = objective(model,x_unbounded);
 if (maximise==1) fa = -fa;
 f = value(fa);

  // from here it's all hessian return values
  if (optimise_hessian){
    dmatrix l(1,nvar,1,nvar),lt(1,nvar,1,nvar),opt_hessian(1,nvar,1,nvar);
    l.initialize();
    lt.initialize();
    for (int i=1;i<=nvar;i++){
      for (int j=1;j<=i;j++){
        l[i][j] = lt[j][i] = minimiser.L[i-1][j-1];
      }
    }
    *optimise_hessian = l*lt;
    if (untransformed_hessians){
      dvector grad_boundp = (4/3.14159265)/elem_prod(upper_bounds-lower_bounds,sqrt(1-elem_prod(2*elem_div(start-lower_bounds,upper_bounds-lower_bounds)-1,2*elem_div(start-lower_bounds,upper_bounds-lower_bounds)-1)));
      for (int i=1; i<=grad_boundp.size(); i++){  // if bounds are equal, divide by 0 gives NaN
        if (grad_boundp[i]!=grad_boundp[i]){      // find these NaNs and replace with zeros
          grad_boundp[i]=0;
        }
      }
      for (int i=1;i<=nvar;i++){
        for (int j=1;j<=nvar;j++){
          (*optimise_hessian)[i][j] *= grad_boundp[i];
          (*optimise_hessian)[j][i] *= grad_boundp[i];
        }
      }
    }
  }
  if (ADOLC_hessian){
    dmatrix hessian(1,nvar,1,nvar);
    dvv xvar = x;
    status = bb_hessian(0,nvar,xvar,hessian);
    if (status < 0){std::cerr << "bad status in hessian call\n";}
    *ADOLC_hessian = hessian;
    if (untransformed_hessians){
      dvector grad_boundp = (4/3.14159265)/elem_prod(upper_bounds-lower_bounds,sqrt(1-elem_prod(2*elem_div(start-lower_bounds,upper_bounds-lower_bounds)-1,2*elem_div(start-lower_bounds,upper_bounds-lower_bounds)-1)));
      for (int i=1; i<=grad_boundp.size(); i++){  // if bounds are equal, divide by 0 gives NaN
        if (grad_boundp[i]!=grad_boundp[i]){      // find these NaNs and replace with zeros
          grad_boundp[i]=0;
        }
      }
      for (int i=1;i<=nvar;i++){
        for (int j=1;j<=nvar;j++){
          (*ADOLC_hessian)[i][j] *= grad_boundp[i];
          (*ADOLC_hessian)[j][i] *= grad_boundp[i];
        }
      }
    }
  }

  convergence = minimiser.ireturn + 2;
  maxit = minimiser.iters;
  maxfn = minimiser.evals;

  return(f);
}
//
// Example follows:
//
// class polynomial{
//  public:
//  int degree;
//  dvector coeffs;
//  polynomial(char *coeff_vals):coeffs(coeff_vals){
//    degree = coeffs.size()-1;}
//  dvariable value(dvv& x){
//    dvariable xval = x[1];
//    dvariable val = 0;
//    for (int count=0;count<=degree;count++){
//      val += coeffs[degree+1-count]*pow(xval,count);}
//    return(val);
//  }
// };
// dvariable polyval(polynomial& p,dvv& x){
//    return(p.value(x));
// };
//
// main(){
//
//  polynomial quartic("{1,2,3,4,5}");
//  dvector x("{1}");
//  dvector lbd("{-1000}");
//  dvector ubd("{1000}");
//  double minimum;
//
//  minimum = optimise(quartic,polyval,x,lbd,ubd);
//  std::cerr << "Minimum of " << minimum << " at " << x << '\n';
// }

// Invert the Hessian at the estimate to get an estimate of the covariance matrix, using
// dmatrix inverse(const dmatrix& dm);
// dvm inverse(const dvm& dm);
//
// To convert that to correlation, use the following:
dmatrix covariance_to_correlation(const dmatrix& cov);

// 10/01: I've just added a new version of optimise which calculates gradients via finite
//   differences rather than automatic differentiation.
//   The speed may be faster or slower than the automatic differentiation version,
//   but will probably be a lot slower if there are many parameters. The resulting gradients may
//   not be as accurate, on the other hand the potential for bugs is less.
//   The finite difference algorithm is a modified version of fdgrad from Dennis & Schnabel.

template<class M,class F> double optimise_finite_differences(M& model,F& objective,
                                  dvector& start,dvector& lower_bounds,dvector& upper_bounds,
                                  int& convergence,
                                  int iprint,int& maxit,int& maxfn,double grad_tol=2e-3,
                                  int maximise=0,
                                  dmatrix* optimise_hessian=0, int untransformed_hessians=0,
                                  double stepsize=1e-7){

  int nvar = start.size();
  if (lower_bounds.size()!=nvar || upper_bounds.size()!=nvar || nvar<1){
    std::cerr << "Betadiff error: inconsistent sizes in optimise\n";
    std::cerr << "Please notify the software maintainer about this error.\n\n";
    exit(BETADIFF_FATAL_EXIT);
  }
  // create the minimiser
  fmm minimiser(nvar);
  // set the control parameters
  minimiser.maxfn = maxfn;
  minimiser.maxit = maxit;
  minimiser.grad_tol = grad_tol;
  minimiser.iprint = iprint;

  // initialize the parameter vector, with bounds
  dvector x(1,nvar);
  int count;
  for (count=1;count<=nvar;count++){
    if (start[count]<lower_bounds[count] || start[count]>upper_bounds[count]){
      std::cerr << lower_bounds << '\n' << upper_bounds << '\n' << start << "\nBetadiff error: in the minimiser, starting value # " << count << " is not within bounds - its value is " << start[count] << " and it should be between " << lower_bounds[count] << " and " << upper_bounds[count] << "\n";
      std::cerr << "Please notify the software maintainer about this error.\n\n";
      exit(BETADIFF_FATAL_EXIT);
    }
    if (lower_bounds[count]==upper_bounds[count]) x[count]=0;
    else x[count]=value(boundpin(start[count],lower_bounds[count],upper_bounds[count]));
  }

  // variables used in the minimiser loop:
  double f;
  dvector g(1,nvar);
  dvector x_unbounded(1,nvar);
  dvariable zpen;
  std::vector<int> nan_gradients;
  int iters=0, evals=0;

  // run the minimiser
  while (minimiser.ireturn>=0){
    if (minimiser.ireturn==0 || minimiser.ireturn==2){
      // need to evaluate objective before calling minimiser.fmin again
      //std::cerr << "about to evaluate function ";
      zpen=0;
      for (count=1;count<=nvar;count++){
        if (lower_bounds[count]==upper_bounds[count]) x_unbounded[count] = lower_bounds[count];
        else x_unbounded[count]=value(boundp(x[count],lower_bounds[count],upper_bounds[count],zpen));}
      //std::cerr << "with x = " << x_unbounded << "\n";
      f = value(objective(model,x_unbounded));
      if (maximise==1) f = -f;
      f += value(zpen);
      //std::cerr << "finished objective call: f = " << f << "\n";
    }
    if (minimiser.ireturn>=1){
      // need to get gradient before calling minimiser.fmin again
      //std::cerr << "about to evaluate finite differences gradient with x = " << x_unbounded << "\n";
      //std::cerr << "transformed = " << x << '\n';
        // modified by AD to have user-defined stepsize. Default is 1e-7 = pow(10.0,-14/2.0)
        // modified version of Dennis & Schnabel's FDGRAD here
        //int digits = 14; // arbitrary, seems to work well (on brief examination) -
        //                 // 12 too small, 16 too big
        //double sqrteta = pow(10.0,-digits/2.0);
      double sqrteta = stepsize;
      double stepsizei, tempi,fi;
      for (int i=1; i<=nvar; i++){
        if (lower_bounds[i]==upper_bounds[i]){
          g[i] = 0;
        } else {
          stepsizei = sqrteta * ((value(x[i])>0) ? 1 : -1); // changed from D&S here
          tempi = x[i];
          x[i] = x[i] + stepsizei;
          stepsizei = x[i] - tempi;
          // calculate f(x)
          zpen=0;
          for (count=1;count<=nvar;count++){
            if (lower_bounds[count]==upper_bounds[count]) x_unbounded[count] = lower_bounds[count];
            else x_unbounded[count]=value(boundp(x[count],lower_bounds[count],upper_bounds[count],zpen));}
          fi = value(objective(model,x_unbounded));
          if (maximise==1) fi = -fi;
          fi += value(zpen);
          // get g[i]
          g[i] = (fi - f) / stepsizei;
          x[i] = tempi;
        }
      }
      //std::cerr << "finished gradient call: g = " << g << "\n";
    }
    //std::cerr << "about to do fmin call with x = " << x_unbounded << " f = " << f << " g = " << g << '\n';
    dvv xx(x);
    minimiser.fmin(xx,f,g);
    x = value(xx);
    //std::cerr << "done fmin call\n";
    //std::cerr << "ireturn = " << minimiser.ireturn << '\n';
 }

  std::cerr << "finished main minimiser loop\n";
  if (minimiser.ireturn==-3){
    std::cerr << "Unclear convergence in optimise. May or may not be a local minimum - you need to investigate further.\n";
  } else if (minimiser.ireturn==-2){
    std::cerr << "Ran out of iterations or evaluations in optimise\n";
  } else if (minimiser.ireturn==-1){
    std::cerr << "Successful convergence in optimise\n";
  } else {
    std::cerr << "Betadiff error: Unexpected ireturn value of " << minimiser.ireturn << " in optimise\n";
    std::cerr << "Please notify the software maintainer about this error.\n\n";
    exit(BETADIFF_FATAL_EXIT);
  }

  // return values
  for (count=1;count<=nvar;count++){
    x_unbounded[count]=value(boundp(x[count],lower_bounds[count],upper_bounds[count],zpen));}
  start = value(x_unbounded);
  f = value(objective(model,x_unbounded));
  if (maximise==1) f = -f;

  // from here it's all hessian return values
  if (optimise_hessian){
    dmatrix l(1,nvar,1,nvar),lt(1,nvar,1,nvar),opt_hessian(1,nvar,1,nvar);
    l.initialize();
    lt.initialize();
    for (int i=1;i<=nvar;i++){
      for (int j=1;j<=i;j++){
        l[i][j] = lt[j][i] = minimiser.L[i-1][j-1];
      }
    }
    *optimise_hessian = l*lt;
    if (untransformed_hessians){
      dvector grad_boundp = (4/3.14159265)/elem_prod(upper_bounds-lower_bounds,sqrt(1-elem_prod(2*elem_div(start-lower_bounds,upper_bounds-lower_bounds)-1,2*elem_div(start-lower_bounds,upper_bounds-lower_bounds)-1)));
      for (int i=1; i<=grad_boundp.size(); i++){  // if bounds are equal, divide by 0 gives NaN
        if (grad_boundp[i]!=grad_boundp[i]){      // find these NaNs and replace with zeros
          grad_boundp[i]=0;
        }
      }
      for (int i=1;i<=nvar;i++){
        for (int j=1;j<=nvar;j++){
          (*optimise_hessian)[i][j] *= grad_boundp[i];
          (*optimise_hessian)[j][i] *= grad_boundp[i];
        }
      }
    }
  }

  convergence = minimiser.ireturn + 2;
  maxit = minimiser.iters;
  maxfn = minimiser.evals;
  return(f);
}

#endif

