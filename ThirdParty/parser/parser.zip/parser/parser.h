#ifndef PARSER_H
#define PARSER_H

#ifdef WIN32

// disable warnings about long names
#pragma warning( disable : 4786)

#endif

#include <string>
#include <map>
#include <stdexcept>
#include <sstream>

#include <cmath>
#include <ctime>
#include <cstdlib>

template<class T>
class LookupObject {
public:
  virtual T& LookupValue(const std::string& name) = 0;
};

template<class T>
class Parser {
  typedef T (*OneArgFunction)(T arg);
  typedef const T (*TwoArgFunction)(const T arg1, const T arg2);
  typedef const T (*ThreeArgFunction)(const T arg1, const T arg2, const T arg3);

public:
  enum TokenType {
    NONE,
    NAME,
    NUMBER,
    END,
    PLUS = '+',
    MINUS = '-',
    MULTIPLY = '*',
    DIVIDE = '/',
    ASSIGN = '=',
    LHPAREN = '(',
    RHPAREN = ')',
    COMMA = ',',
    NOT = '!',

    // comparisons
    LT = '<',
    GT = '>',
    LE,     // <=
    GE,     // >=
    EQ,     // ==
    NE,     // !=
    AND,    // &&
    OR,      // ||

    // special assignments
    ASSIGN_ADD,  //  +=
    ASSIGN_SUB,  //  +-
    ASSIGN_MUL,  //  +*
    ASSIGN_DIV   //  +/
  };

  // members
  Parser(LookupObject<T>* object);

  const T Evaluate(const std::string& program);  // get result
  const TokenType GetToken(const bool ignoreSign = false);
  const T CommaList(const bool get);
  const T Expression(const bool get);
  const T Comparison(const bool get);
  const T AddSubtract(const bool get);
  const T Term(const bool get);      // multiply and divide
  const T Primary(const bool get);   // primary (base) tokens

  inline void CheckToken(const TokenType wanted) {
    if (type_ != wanted) {
      std::ostringstream s;
      s << "'" << static_cast<char>(wanted) << "' expected.";
      throw std::runtime_error(s.str());
    }
  }

private:
  // members
  std::string program_;
  const char * pWord_;
  const char * pWordStart_;
  // last token parsed
  TokenType type_;
  std::string word_;
  T value_;

  LookupObject<T>* lookup_object_ = nullptr;

  // maps of function names to functions
  std::map<std::string, OneArgFunction> OneArgumentFunctions;
  std::map<std::string, TwoArgFunction> TwoArgumentFunctions;
  std::map<std::string, ThreeArgFunction> ThreeArgumentFunctions;


}; // class Parser

#include "parser-inl.h"

#endif // PARSER_H
