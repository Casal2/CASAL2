#ifndef DLIB_REVISION_H
// Version:  19.17
// Date:     Sun Mar 10 11:04:56 EDT 2019
// Git Changeset ID:  810ef7937d87c9265bcb5814a00a1f1691285ceb
#define DLIB_MAJOR_VERSION  19
#define DLIB_MINOR_VERSION  17
#define DLIB_PATCH_VERSION  0
#endif
