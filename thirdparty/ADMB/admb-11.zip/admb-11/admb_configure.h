adstring admb_banner = ".767 [admb-linux-gcc4.7-64bit]";
