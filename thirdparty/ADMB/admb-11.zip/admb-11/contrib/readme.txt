*** ecolib
Functions related to the book "Ecological Models and Data in R" (Bolker 2008),
contributed by Mollie Brooks

*** qfclib
Likelihood functions and simulation tools, contributed by Weihai Liu

*** statslib
Likelihood functions, contributed by Steve Martell
