/*
 * $Id: denorm.cpp 494 2012-06-13 20:41:16Z johnoel $
 *
 * Author: David Fournier
 * Copyright (c) 2008-2012 Regents of the University of California 
 */
/**
 * \file
 * Description not yet available.
 */

/**
 * Description not yet available.
 * \param
 */
  void denormalize_ptr(void * ptr, unsigned int byte_offset)
  {
  }
