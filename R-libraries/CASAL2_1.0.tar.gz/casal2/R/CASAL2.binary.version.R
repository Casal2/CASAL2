"CASAL2.binary.version"<-
function() {
return("2017-08-07")
}
