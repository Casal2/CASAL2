#' Utility extract function
#'
#' @author Craig Marsh
#'
pow = function(x,exponent) {return(x^exponent)}
