#' Utility extract function
#'
#' @author C Marsh
#'
make.string_vector <- function(lines)
{
   data = as.character(lines[1])
   data
}
