#' Utility extract function
#'
#' @author Dan Fu
#'
is.in = function(x,y) {
   x %in% y }
