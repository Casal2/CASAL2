"CASAL2.binary.version"<-
function() {
return("2016-10-24")
}
