#' Utility extract function
#'
#' @author Dan Fu
#'
"Regexpr" <-
function(x, y,fixed=T)
{
    return(regexpr(x, y, fixed=fixed))
}

