"iSAM.version"<-
function()
{
  cat(paste("iSAM R package for use with iSAM v",iSAM.binary.version(),"\n",sep=""))
}
