#' Utility extract function
#'
#' @author Craig Marsh
#' @keywords internal
#'
pow <- function(x, exponent) {
  return(x^exponent)
}
