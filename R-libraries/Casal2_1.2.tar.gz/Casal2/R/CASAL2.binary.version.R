"Casal2.binary.version"<-
function() {
return("1.2")
}
