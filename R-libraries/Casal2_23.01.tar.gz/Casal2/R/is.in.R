#' Utility extract function
#'
#' @author Dan Fu
#' @keywords internal
#'
is.in = function(x, y) {
  x %in% y
}
