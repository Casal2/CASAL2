"CASAL2.binary.version"<-
function() {
return("2018-03-09")
}
