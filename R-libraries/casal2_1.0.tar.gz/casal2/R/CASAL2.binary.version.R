"CASAL2.binary.version"<-
function() {
return("2017-11-30")
}
