"CASAL2.binary.version"<-
function() {
return("2020-05-29")
}
