"CASAL2.binary.version"<-
function() {
return("2019-05-06")
}
