"CASAL2.binary.version"<-
function() {
return("2021-03-30")
}
