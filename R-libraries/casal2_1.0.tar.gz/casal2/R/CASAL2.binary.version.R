"CASAL2.binary.version"<-
function() {
return("2017-09-01")
}
