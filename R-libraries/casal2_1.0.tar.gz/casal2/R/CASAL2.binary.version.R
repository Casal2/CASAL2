"CASAL2.binary.version"<-
function() {
return("2020-06-04")
}
