"CASAL2.binary.version"<-
function() {
return("2019-10-16")
}
