"CASAL2.binary.version"<-
function() {
return("2019-07-02")
}
