#' Utility plot function
#'
#' @author Craig Marsh
#'
evalit = function(x) {eval(parse(text = x))}

