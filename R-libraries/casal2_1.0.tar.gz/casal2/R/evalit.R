#' Utility plot function
#'
#' @author Craig Marsh
#' @keywords internal
#'
evalit = function(x) {eval(parse(text = x))}

