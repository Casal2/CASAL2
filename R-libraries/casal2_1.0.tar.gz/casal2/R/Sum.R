#' Utility plot function
#'
#' @author Craig Marsh
#' @keywords internal
#'
Sum = function(...,na.rm = T) {sum(..., na.rm = na.rm)}


