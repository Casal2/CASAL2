#' @title plot_prior
#' @description
#' Plot priors available in Casal2
#'
#' @author A. Dunn
#' @param type The prior type
#' @param mu mean of the distribution for the prior
#' @param sd standard deviation (where required) of the distribution for the prior
#' @param cv CV (where required) of the distribution for the prior
#' @param A The A parameter for the beta prior
#' @param B The B parameter for the beta prior
#' @param beta The beta parameter for the prior
#' @param bounds The bounds of the prior
#' @param xlim The x-axis limits for the plot
#' @param label TRUE/FALSE (default = FALSE) display the name of the prior
#' @param logx TRUE/FALSE (default = FALSE) to plot the xaxis in log-space
#' @param add TRUE/FALSE (default = FALSE) to add to an existing plot
#' @param dump TRUE/FALSE (default = FALSE) to dump the coordinates of the plotted line
#' @rdname plot_prior
#' @export plot_prior

"plot_prior" <-
  function(type = "lognormal", mu, sd, cv, A = 0, B = 1, beta = 0, bounds, xlim, label = F, xlab = "x", ylab = "Density", logx = F, add = F, dump = F, ...) {
    n <- 201
    if (missing(xlim) & !missing(bounds)) {
      xlim <- bounds
    } else if (missing(bounds) & !missing(xlim)) {
      bounds <- xlim
    } else if (missing(bounds) & missing(xlim)) stop("You must supply either the bounds or xlim or both")
    if (logx & (min(xlim) <= 0 | min(bounds) <= 0)) stop("With 'logx' option, the lower bound/xlim must be a postive number")
    Allowed <- c("lognormal", "normal-by-stdev", "uniform", "uniform-log", "normal-log", "beta")
    type <- Allowed[as.numeric(pmatch(casefold(type), casefold(Allowed), nomatch = NA))]
    if (type == "") {
      stop(paste("Prior not found. Available priors are\n", paste(Allowed, collapse = ", ")))
    } else {
      cat(paste("Plotting ", type, " prior\n", sep = ""))
    }
    if (logx) {
      p <- exp(seq(log(bounds[1]), log(bounds[2]), length = n))
    } else {
      p <- seq(bounds[1], bounds[2], length = n)
    }
    if (type == "lognormal") {
      sigma <- sqrt(log(1 + (cv^2)))
      res <- exp(-(log(p) + 0.5 * ((log(p / mu) / sigma + sigma / 2)^2)))
    } else if (type == "normal-by-stdev") {
      res <- exp(-(0.5 * (((p - mu) / sd)^2)))
    } else if (type == "uniform") {
      if (logx) {
        res <- p
      } else {
        res <- rep(1, length(p))
      }
    } else if (type == "uniform-log") {
      if (logx) {
        res <- rep(1, length(p))
      } else {
        res <- exp(-log(p))
      }
    } else if (type == "normal-log") {
      res <- exp(-(log(p) + 0.5 * (((log(p) - mu) / sd)^2)))
    } else if (type == "beta") {
      new.mu <- (mu - A) / (B - A)
      new.t <- (((mu - A) * (B - mu)) / (sd^2)) - 1
      if (new.t <= 0) stop("Standard deviation too large")
      if (min(bounds, na.rm = T) < A || max(bounds, na.rm = T) > B) stop("Bad bounds on Beta prior")
      Bm <- new.t * new.mu
      Bn <- new.t * (1 - new.mu)
      res <- (1 - Bm) * log(p - A) + (1 - Bn) * log(B - p)
      res <- exp(-res)
    }
    res <- c(0, res / max(res), 0)
    p <- c(bounds[1], p, bounds[2])
    res <- res[p >= beta]
    p <- p[p >= beta]
    res <- res / casal.area(list("x" = p, "y" = res))
    ylim <- c(min(res), max(res) * 1.04)
    if (logx) {
      xlab <- paste("log(", xlab, ")", sep = "")
      if (!add) {
        plot(log(p), res, type = "n", xlab = xlab, ylab = "", xlim = log(xlim), axes = F, ylim = ylim)
        axis(side = 1)
        mtext(side = 2, line = 0.5, text = ylab)
        if (label) mtext(side = 3, type, adj = 0, line = 0.3)
        box()
      }
      lines(log(p), res, type = "l", ...)
    } else {
      if (!add) {
        plot(p, res, type = "n", xlab = xlab, ylab = "", xlim = xlim, axes = F, ylim = ylim)
        axis(side = 1)
        mtext(side = 2, line = 0.5, text = ylab)
        if (label) mtext(side = 3, type, adj = 0, line = 0.3)
        box()
      }
      lines(p, res, type = "l", ...)
    }
    if (dump) {
      return(data.frame("x" = p, "y" = res))
    } else {
      invisible()
    }
  }
