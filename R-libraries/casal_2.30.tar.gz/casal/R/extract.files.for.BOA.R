# $Id: extract.files.for.BOA.R 1748 2007-11-13 00:03:36Z adunn $
"extract.files.for.BOA"<-
function(...)
{
  cat("extract.files.for.BOA is deprecated. Use extract.mcmc(...) instead.\n")
  invisible()
}
