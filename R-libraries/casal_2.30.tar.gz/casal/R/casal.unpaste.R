"casal.unpaste"<-
function(string, sep=" ")  {
  return(unlist(strsplit(string, sep)))
}
