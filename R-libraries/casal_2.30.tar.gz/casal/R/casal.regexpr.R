# $Id: casal.regexpr.R 4636 2012-03-19 23:48:49Z Dunn $
"casal.regexpr"<-
function(x, y) {
  return(regexpr(x, y))
}
