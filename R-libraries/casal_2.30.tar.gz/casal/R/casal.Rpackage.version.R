"casal.Rpackage.version"<-
function() {
return("2015-07-26 23:03:27 UTC (rev.5436)")
}
