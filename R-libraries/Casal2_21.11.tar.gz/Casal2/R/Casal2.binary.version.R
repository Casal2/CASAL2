"casal2.binary.version"<-
function() {
return("21.11")
}
