#' @title plot.year.class 
#'
#' @description
#' A plotting function to fits to Casal2 year class observations from a model run. This function require package ggplot2
#'
#' @author Jingjing Zhang
#' @param model <casal2MPD, casal2TAB> object that are generated from one of the extract() functions.
#' @param report_label <string>
#' @param plot.it Whether to generate a default plot or return the values as a matrix.
#' @param type Whether to plot an observed vs expected (fit) or plot the residuals (resid)
#' @param ... remaining plotting options
#' @return A plot of derived quantities over time if plot.it = T, if plot.it = F it will return a matrix of derived quantities.
#' @rdname plot.year.class
#' @export plot.year.class
#' @examples
#' library(ggplot2)
#' library(casal2)
#' # plotting Standard Output
#' mpd <- extract.mpd(file = system.file("extdata", "mpd.log", package="casal2"))
#' names(mpd)
#' plot.year.class(model = mpd, report_label = "tan_at_age")
#' # if you are unhappy with the default plotting you can use plot.it = FALSE and create a plot of your own.
#' Tangaroa_yc = plot.year.class(model = data, report_label = "tan_at_age", plot.it = FALSE)
#' # plotting Tabular Output
#' tab <- extract.tabular(file = system.file("extdata", "tabular_report.out", package="casal2"))
#' names(tab)
#' plot.year.class(model = tab, report_label = "Tangaroa_propn_at_age_Aug")
#' plot.year.class(model = tab, report_label = "wcsiTRLcpue")


"plot.year.class"<-
function(model, report_label="", plot.it = T, xlim, ylim, xlab, ylab, main, col, ...){
  UseMethod("plot.year.class",model)
}

#' @return \code{NULL}
#'
#' @rdname plot.year.class
#' @method plot.year.class casal2MPD
#' @export
"plot.year.class.casal2MPD" = function(model, report_label="", type = "fit" ,plot.it = T) {
  muliple_iterations_in_a_report = FALSE;
  N_runs = 1;
  temp_DF = NULL;
  if (type != "fit")
    stop("Haven't written the code to deal with resid for class 'casal2MPD', try type = 'fit'")
  ## check report label exists
  if (!report_label %in% names(model))
    stop(Paste("In model the report label '", report_label, "' could not be found. The report labels available are ", paste(names(model),collapse = ", ")))
  ## get the report out
  this_report = get(report_label, model)
  ## check that the report label is of type derived_quantity
  if (this_report$'1'$type != "observation") {
    stop(Paste("The report label ", report_label, " in model is not a observation plz Check you have specified the correct report_label."))     
  }
  if (length(this_report) > 1) {
      print("multi iteration report found")
      muliple_iterations_in_a_report = TRUE;
      N_runs = length(this_report);
  }
  likelihoods_allowed = c( "multinomial")
  observations_allowed = c("proportions_at_age", "process_proportions_at_age", "proportions_at_length", "process_proportions_at_length", "process_removals_by_age", "process_removals_by_length")
  if (!this_report$'1'$likelihood %in% likelihoods_allowed) {
    stop(Paste("We have only coded this function to deal with the following likelihoods " , paste(likelihoods_allowed, collapse = ", "), " please add the functionalty to the R-library for future users"))
  }
  if (!this_report$'1'$observation_type %in% observations_allowed) {
    stop(Paste("We have only coded this function to deal with the following observation types " , paste(observations_allowed, collapse = ", "), " please add the functionalty to the R-library for future users"))
  }  
  if (!muliple_iterations_in_a_report) { 
    ## pull out the comparisons oject
    Comparisons = this_report$'1'$Comparisons
    if (plot.it) {
      if (type == "fit") {
        if (this_report$'1'$likelihood == "multinomial") {
          if (all(Comparisons$length==0)){
          ggplot(Comparisons,aes(x = age, y = expected, shape = "1")) +
                   geom_point(size = 1.2, colour = "red") +
                   geom_bar(stat = "identity", aes(age, observed), colour = "grey", fill = NA)+
                   facet_wrap(~ year, scales = "free") +
                   theme_bw() + ylim(0,0.5) ## the y axis range can be customised 
          }else{
            ggplot(Comparisons,aes(x = length, y = expected, shape = "1")) +
              geom_point(size = 1.2, colour = "red") +
              geom_bar(stat = "identity", aes(length, observed), colour = "grey", fill = NA)+
              facet_wrap(~ year, scales = "free") +
              theme_bw() #+ ylim(0, 0.5)
          }
        } else {
          stop("unidentified likelihood")
        }    
      } else if (type == "resid") {
        stop("haven't written these yet... Not sure what they would look like.\n")
      }
    } else {
      return(t_comp);
    }
  } else {
    stop("haven't written these yet...\n")
  }
}


#' @return \code{NULL}
#'
#' @rdname plot.year.class
#' @method plot.year.class casal2TAB
#' @export
"plot.year.class.casal2TAB" = function(model, report_label="", type = "resid" ,plot.it = T, xlim, ylim, xlab, ylab, main, col, ...) {
  if (type != "resid")
    stop("Haven't written the code to deal with fit for class 'casal2TAB', try type = 'resid'")

  ## check report label exists
  if (!report_label %in% names(model))
    stop(Paste("In model the report label '", report_label, "' could not be found. The report labels available are ", paste(names(model),collapse = ", ")))
  ## get the report out
  this_report = get(report_label, model)
  ## check that the report label is of type derived_quantity
  if (this_report$type != "observation") {
    stop(Paste("The report label ", report_label, " in model is not a observation plz Check you have specified the correct report_label."))     
  }
  likelihoods_allowed = c("multinomial")
  observations_allowed = c("proportions_at_age", "process_proportions_at_age", "proportions_at_length", "process_proportions_at_length", "process_removals_by_age", "process_removals_by_length")
  if (!this_report$likelihood %in% likelihoods_allowed) {
    stop(Paste("We have only coded this function to deal with the following likelihoods " , paste(likelihoods_allowed, collapse = ", "), " please add the functionalty to the R-library for future users"))
  }
  if (!this_report$observation_type %in% observations_allowed) {
    stop(Paste("We have only coded this function to deal with the following observation types " , paste(observations_allowed, collapse = ", "), " please add the functionalty to the R-library for future users"))
  }  
  
  if (plot.it) {
      obs_ndx = grepl(pattern = "obs", x = names(this_report$values))
      exp_ndx = grepl(pattern = "fit", x = names(this_report$values))
    
      this_pearson = this_report$values[,pear_ndx]
      this_obs = this_report$values[,obs_ndx]
      this_exp = this_report$values[,exp_ndx]
      
      start_index_obs = as.numeric(regexpr(pattern = "\\[",text = names(this_obs))) + 1
      stop_index_obs = as.numeric(regexpr(pattern = "\\]",text = names(this_obs))) - 1
      start_index_exp = as.numeric(regexpr(pattern = "\\[",text = names(this_exp))) + 1
      stop_index_exp = as.numeric(regexpr(pattern = "\\]",text = names(this_exp))) - 1
      years = unique(as.numeric(substring(names(this_obs), start_index_obs,last = stop_index_obs)))
      start_nd = as.numeric(regexpr(pattern = "\\]",text = colnames(this_pearson))) + 2
      start_nd_obs = as.numeric(regexpr(pattern = "\\]",text = colnames(this_obs))) + 2
      start_nd_exp = as.numeric(regexpr(pattern = "\\]",text = colnames(this_exp))) + 2
      
      bins = unique(as.numeric(substring(colnames(this_pearson),first = start_nd, last = nchar(colnames(this_pearson)) - 1)))
      bins_obs = unique(as.numeric(substring(colnames(this_obs),first = start_nd_obs, last = nchar(colnames(this_obs)) - 1)))
      bins_exp = unique(as.numeric(substring(colnames(this_exp),first = start_nd_exp, last = nchar(colnames(this_exp)) - 1)))
      end_nd = as.numeric(regexpr(pattern = "\\.",text = names(this_pearson))) - 1
      end_nd_obs = as.numeric(regexpr(pattern = "\\.",text = names(this_obs))) - 1
      end_nd_exp = as.numeric(regexpr(pattern = "\\.",text = names(this_exp))) - 1
      
      obs = unique(substring(colnames(this_pearson),first = 0, last = end_nd))
      obs_obs = unique(substring(colnames(this_obs),first = 0, last = end_nd_obs))
      obs_exp = unique(substring(colnames(this_exp),first = 0, last = end_nd_exp))
      ## generate a boxplot of observation for each year and add model expected values as points
      n_years = length(years)
      if (n_years <= 4) {
        par(mfrow=c(1,n_years))
      } else if (n_years > 4 && n_years <= 8) {
        par(mfrow=c(2,ceiling (n_years/2)))      
      } else if (n_years > 8 && n_years <= 12) {
        par(mfrow=c(3,ceiling (n_years/2)))            
      } else 
        stop(Paste("there are ", n_years, " years of compositional data you should just have plot.it = FALSE and use another axuillary function to plot them, it will most likely look prettier than what I can be bothered coding"))
      for (y in 1:n_years) {
       this_year_obs = this_obs[,grepl(pattern = Paste("obs\\[",years[y]), x = names(this_obs))]
       this_year_exp = this_exp[,grepl(pattern = Paste("fits\\[",years[y]), x = names(this_exp))]
       barplot1 <- barplot(colMeans(this_year_obs),ylim = c(0,max(colMeans(this_year_obs)+0.1)),width = 1, xlab = "age", ylab = "observation", main = years[y] ,names = bins, col = "grey90")
       points(x = barplot1, y = colMeans(this_year_exp), col = "red", pch = 16) 
    }
  } else {
    return(this_report$values);
  }
}

