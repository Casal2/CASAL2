#' Utility function extract and summarise objective score by category
#'
#' This function reads in the objective list from casal2MPD and casal2MCMC objects.
#'
#' @author Jingjing Zhang
#' @param extract_list the name of the object that belongs to casal2MPD or casal2MCMC class that extract from CASAL2 output file
#' @param Label the lable of objective function, normally "objective"
#' @return Data <"data.frame"> of the summed value of objective score by label/category.
#' @export
#' @example 
#' mpd <- extract.mpd(file = system.file("extdata", "mpd.log", package="casal2"))
#' split_obj(mpd, "objective")



"split_obj"<-
  function(extract_list,label) {
  if(class(extract_list) != "casal2MPD" & class(extract_list) != "casal2MCMC")
    warning("extract_list should be of class 'casal2MPD' or class 'casal2MCMC");
  
  if (!(label %in% names(extract_list)))
    stop("Your label is not in the list check names of extract_list");
  
  obj = get(label,extract_list)$"1"$values;
  elements = unique(names(obj));
  values = as.numeric(obj);
  nam = vector();
  value = vector();
  list_index = 1;
  ## Observations will be broken by obs -> label - year
  ## prior will be prior -> label -> parameter
  ## penalty will be penalty -> label
  ## We want to break down by class and label so find all the unique comninations of that
  obs = elements[grep("obs->" , elements)];
  prior = elements[grep("prior->" , elements)]; 
  penalty = elements[grep("penalty->" , elements)]; 
  store_vec = vector();
  if (length(obs) > 0) {
    nd = strsplit(obs, "->");
    for (i in 1:length(obs))
      store_vec[i] = strsplit(nd[[i]], "-")[[2]][1];
    store_vec = unique(store_vec);
    
    for (k in 1:length(store_vec)) {
      ndx = grep(paste("obs", store_vec[k], sep = "->"),elements);
      nam[list_index]= store_vec[k];
      value[list_index] = sum(values[ndx]);
      list_index = list_index + 1;
    }
  }
  if(abs(sum(value) - values[length(values)]) > 0.001)
    warning("You may have missed a component of the objective function difference between total and sum > 0.001")
  nam[list_index] = "Total Objective";
  value[list_index] = values[length(values)];
  ## Convert this to a dataframe because they are nicer to deal with
  
  return(data.frame(Label = nam, Value = value))
}
