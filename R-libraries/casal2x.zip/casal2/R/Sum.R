#' Utility plot function
#'
#' @author Craig Marsh
#'
Sum = function(...,na.rm = T) {sum(..., na.rm = na.rm)}


