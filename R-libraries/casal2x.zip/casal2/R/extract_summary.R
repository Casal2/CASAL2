#' Utility function extract the summary of estimated parameters' label and value
#'
#' This function reads in the objective list from casal2MPD objects.
#'
#' @author Jingjing Zhang
#' @param extract_list the name of the object that belongs to casal2MPD class that extract from CASAL2 output file
#' @param Label the lable of objective function, normally "summary"
#' @return Data <"data.frame"> of the summary labels and values.
#' @export
#' @example 
#' mpd <- extract.mpd(file = system.file("extdata", "mpd.log", package="casal2"))
#' extract_summary(mpd, "summary")


#extract estimated values label = "summary"
"extract_summary"<-
  function(extract_list,label) {
  if(class(extract_list) != "casal2MPD" & class(extract_list) != "casal2MCMC")
    warning("extract_list should be of class 'casal2MPD' or class 'casal2MCMC");
  
  
  if (!(label %in% names(extract_list)))
    stop("Your label is not in the list check names of extract_list");
  
  obj = get(label,extract_list)$"1"$values;
  elements = unique(names(obj));
  values = as.numeric(obj);
  return(data.frame(Label = elements, Value = values))
}