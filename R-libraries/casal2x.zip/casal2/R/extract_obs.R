#' Utility function extract the each observation with its expected value, residual and score  from casal2MPD objects
#'
#' This function reads in the observation list from casal2MPD objects.
#'
#' @author Jingjing Zhang
#' @param extract_list the name of the object that belongs to casal2MPD class that extract from CASAL2 output file
#' @param Label the lable of objective function, normally one of the observation block 
#' @return Data <"data.frame"> of the observation labels and values.
#' @export
#' @example 
#' mpd <- extract.mpd(file = system.file("extdata", "mpd.log", package="casal2"))
#' names(mpd)
#' extract_obs(mpd, "obs_tan")

"extract_obs"<-
  function(extract_list,label) {
  if(class(extract_list) != "casal2MPD" & class(extract_list) != "casal2MCMC")
    warning("extract_list should be of class 'casal2MPD' or class 'casal2MCMC");
  
  if (!(label %in% names(extract_list)))
    stop("Your label is not in the list check names of extract_list");
  
  obj = get(label,extract_list)$"1"$Comparisons;
  return(as.data.frame(obj))
}
