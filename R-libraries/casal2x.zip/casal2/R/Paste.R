#' Utility plot function
#'
#' @author Craig Marsh
#'
Paste = function(... , sep = "") {paste(..., sep = sep)}


